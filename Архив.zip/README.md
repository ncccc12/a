# OTM Admin client

This React 18 application is built with [Vite](https://vite.dev/) and uses Ant Design 5 with Day.js.

The generated API client must be available at `src/services/Client.ts` before the app can be built or started.

## Development

Install dependencies and start the development server:

```sh
npm install
npm start
```

The application is available at <http://localhost:3000>. `npm run dev` is an alias for the same development server.

## Checks and production build

```sh
npm test
npm run typecheck
npm run build
npm run format:check
```

The production output is written to `build/`. Preview it locally with `npm run preview`.

Set `VITE_BASE_PATH` when the app is deployed below the domain root. For example:

```sh
VITE_BASE_PATH=/otm/ npm run build
```
