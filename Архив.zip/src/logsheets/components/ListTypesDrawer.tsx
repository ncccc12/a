import React from 'react';
import { Form, Drawer, Button, Switch, Input } from 'antd';

export type ListTypeForm = {
    id: number;
    name: string;
    code: string;
    description: string;
    isActive: boolean;
};

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
};

const ListTypesDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const {
        visible: visible,
        form: form,
        form: {},
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');

    return (
        <Drawer
            title={id ? 'Edit list type' : 'Add list type'}
            open={visible}
            width={500}
            destroyOnHidden={true}
            onClose={props.onClose}
        >
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item
                    label="Name"
                    name="name"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Name is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    label="Code"
                    name="code"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Code is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item label="Description" name="description">
                    <Input.TextArea autoSize={{ minRows: 4 }} />
                </Form.Item>
                <Form.Item label="Is active" name="isActive" valuePropName="checked">
                    <Switch disabled={!id} />
                </Form.Item>
            </Form>
            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button onClick={props.onSubmit} type="primary">
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const ListTypesDrawer = ListTypesDrawerInner;

export default ListTypesDrawer;
