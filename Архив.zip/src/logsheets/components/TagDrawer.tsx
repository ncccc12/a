import React from 'react';
import { Drawer, Form, Input, Select, Tag, InputNumber, Button, Switch, Checkbox } from 'antd';
import {
    DictionaryDto,
    GetLogsheetsQuery,
    GroupDto,
    ListTypeValueVm,
    LogSheetVm,
    LogsheetListItemVm,
} from '../../services/Client';
import { DataTypes } from '../models';
import { logSheetsClient } from '../../services';
import { values } from 'lodash';

export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    dataTypes: DictionaryDto[];
    listTypes: DictionaryDto[];
    listTypeValues: ListTypeValueVm[];
    unitOfMeasurements: DictionaryDto[];
    groups: Array<{ id: number; name: string }>;
    editOnlyValues?: boolean;
    onSubmit: () => void;
    onClose: () => void;
};

const TagDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form: form0, listTypeValues } = props;

    const [filteredLisTypeValues, setFilteredLisTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [selectedDataTypeCode, setSelectedDataTypeCode] = React.useState<string>('');
    const [changeParentGroup, setChangeParentGroup] = React.useState<boolean>(false);
    const [logsheets, setLogsheets] = React.useState<LogsheetListItemVm[]>([]);
    const [logsheetGroup, setLogsheetGroup] = React.useState<GroupDto[]>();
    const previousProps = React.useRef(props);

    const search = async () => {
        //const form = filterFormRef.current!.form as FormInstance;
        //form.validateFields(async (err: any, values: SearchForm) => {

        try {
            let values = {
                locationCode: undefined,
                areaCode: undefined,
                isActive: undefined,
            };
            let query = new GetLogsheetsQuery();
            query.init(values);
            let logsheets = await logSheetsClient.getLogsheets(query);
            console.log('func', logsheets);
            setLogsheets(logsheets);
        } finally {
        }
        //});
    };

    const handleListTypeChange = React.useCallback(
        (code: string) => {
            let filteredValues = listTypeValues.filter((r) => r.listTypeCode === code);
            setFilteredLisTypeValues(filteredValues);
        },
        [listTypeValues],
    );

    const handleDataType = (code: string, callback?: () => void) => {
        setSelectedDataTypeCode(code);
        callback?.();
    };

    const onChange = React.useCallback((e: any) => {
        console.log('checked = ', e.target.checked);
        setChangeParentGroup(e.target.checked);
    }, []);

    const getValueNode = () => {
        let valueNode;
        if (selectedDataTypeCode === DataTypes.List) {
            valueNode = (
                <Select>
                    {filteredLisTypeValues.map((r) => {
                        return (
                            <Select.Option value={r.code} key={r.code}>
                                {r.name}
                            </Select.Option>
                        );
                    })}
                </Select>
            );
        } else if (selectedDataTypeCode === DataTypes.Number) {
            valueNode = <InputNumber />;
        } else {
            valueNode = <Input />;
        }

        return valueNode;
    };

    const logsheetGroup0 = React.useCallback(async (value: number) => {
        let groups: GroupDto[] = [];
        let finalGroup: GroupDto[] = [];
        let logsheet = await logSheetsClient.getLogsheetForm(value);
        logsheet.groups?.map((x) => groups!.push(x) && finalGroup.push(x));
        if (groups != null && groups.length > 0) {
            groups.map((r) => r.childGroups?.map((i) => finalGroup.push(i)));
        }
        console.log(finalGroup);
        setLogsheetGroup(finalGroup);
    }, []);

    const handleLogSheetChange = React.useCallback(
        (value: number) => {
            logsheetGroup0(value);
            props.form.setFieldsValue({
                areaCodes: [],
            });
        },
        [logsheetGroup0, props.form],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        } else {
            const prevProps = previousProps.current;
            if (!prevProps.visible && props.visible) {
                let listTypeCode = form0.getFieldValue('listTypeCode');
                let dataTypeCode = form0.getFieldValue('dataTypeCode');

                handleDataType(dataTypeCode);
                handleListTypeChange(listTypeCode);
            } else if (!props.visible && selectedDataTypeCode !== '') {
                setSelectedDataTypeCode('');
            }
            previousProps.current = props;
        }
    });

    const {
        visible: visible,
        form: {},
        form: form,
        dataTypes: dataTypes,
        listTypes: listTypes,
        unitOfMeasurements: unitOfMeasurements,
        groups: groups,
        editOnlyValues: editOnlyValues,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');

    console.log('logsheet', logsheets);
    console.log('logsheetGroup', logsheetGroup);

    let title = editOnlyValues ? 'Edit tag values' : id ? 'Edit tag' : 'Add new tag';

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item name="groupId" hidden />
                <Form.Item name="taskValueId" hidden />
                <Form.Item label="Group/Device name" name="groupId">
                    <Select disabled={editOnlyValues || changeParentGroup}>
                        {groups.map((r) => {
                            return (
                                <Select.Option key={r.id} value={r.id}>
                                    {r.name}
                                </Select.Option>
                            );
                        })}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Tag name"
                    name="name"
                    rules={[
                        {
                            required: true,
                            message: 'Tag name is required',
                        },
                    ]}
                >
                    <Input readOnly={editOnlyValues} />
                </Form.Item>
                <Form.Item label="Description" name="description">
                    <Input.TextArea readOnly={editOnlyValues} />
                </Form.Item>
                <Form.Item
                    label="Data type"
                    name="dataTypeCode"
                    rules={[
                        {
                            required: true,
                            message: 'Data type is required',
                        },
                    ]}
                >
                    <Select onChange={(code: string) => handleDataType(code)} disabled={editOnlyValues}>
                        {dataTypes.map((r) => {
                            return (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            );
                        })}
                    </Select>
                </Form.Item>
                {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.List) && (
                    <>
                        <Form.Item
                            label="List type"
                            name="listTypeCode"
                            rules={[
                                {
                                    required: selectedDataTypeCode === DataTypes.List,
                                    message: 'Listy type required',
                                },
                            ]}
                        >
                            <Select onChange={handleListTypeChange} disabled={editOnlyValues}>
                                {listTypes.map((r) => {
                                    return (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item label="Values">
                            {filteredLisTypeValues.map((r) => {
                                return <Tag color={r.isExceed ? 'red' : undefined}>{r.name}</Tag>;
                            })}
                        </Form.Item>
                    </>
                )}

                {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.Number) && (
                    <>
                        <Form.Item label="Min Value" name="minValue">
                            <InputNumber readOnly={editOnlyValues} />
                        </Form.Item>
                        <Form.Item label="Max Value" name="maxValue">
                            <InputNumber readOnly={editOnlyValues} />
                        </Form.Item>
                    </>
                )}

                {(selectedDataTypeCode === '' || selectedDataTypeCode !== DataTypes.List) && (
                    <Form.Item label="Unit of measurement" name="unitOfMeasurementCode">
                        <Select disabled={editOnlyValues}>
                            {unitOfMeasurements.map((r) => (
                                <Select.Option key={r.code} value={r.code}>
                                    {`${r.description} (${r.name})`}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                )}

                <Form.Item label="Is required" name="isRequired" valuePropName="checked">
                    <Switch disabled={editOnlyValues} />
                </Form.Item>
                {!editOnlyValues && (
                    <>
                        <Form.Item label="Change Parent Group">
                            <Checkbox checked={changeParentGroup} onChange={onChange}></Checkbox>
                        </Form.Item>
                    </>
                )}
                {!editOnlyValues && changeParentGroup && (
                    <>
                        <Form.Item label="LogSheet">
                            <Select onChange={handleLogSheetChange}>
                                {logsheets.map((r) => (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>
                            ,
                        </Form.Item>
                    </>
                )}
                {!editOnlyValues && changeParentGroup && (
                    <>
                        <Form.Item label="Parent Groups" name="groupId">
                            <Select>
                                {logsheetGroup?.map((r) => (
                                    <Select.Option key={r.id!} value={r.id!}>
                                        {r.name!}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </>
                )}

                {editOnlyValues && (
                    <>
                        <Form.Item label="Value" name="value">
                            this.getValueNode()
                        </Form.Item>

                        <Form.Item label="Comment" name="comment">
                            <Input.TextArea />
                        </Form.Item>
                    </>
                )}
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const TagDrawer = TagDrawerInner;

export default TagDrawer;
