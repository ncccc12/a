import React from 'react';
import { Drawer, Form, Input, Button, Switch } from 'antd';

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
};

const GroupDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const {
        visible: visible,
        form: {},
        form: form,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');
    let isDevice = form.getFieldValue('isDevice');

    let title = '';
    if (id) {
        title = isDevice ? 'Edit device' : 'Edit group';
    } else {
        title = isDevice ? 'Add device' : 'Add group';
    }

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item name={['parentGroup', 'id']} hidden />
                <Form.Item name="isParentLogsheet" hidden />
                <Form.Item label="Parent group" name={['parentGroup', 'name']}>
                    <Input readOnly />
                </Form.Item>
                <Form.Item
                    label={isDevice ? 'Device name' : 'Group name'}
                    name="groupName"
                    rules={[
                        {
                            required: true,
                            message: 'Name is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item label="Is Device" name="isDevice" valuePropName="checked">
                    <Switch disabled />
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const GroupDrawer = GroupDrawerInner;

export default GroupDrawer;
