import { DeleteOutlined, DownCircleOutlined, UpCircleOutlined } from '@ant-design/icons';
import React from 'react';
import { Modal, Table, Button, Popconfirm, Alert } from 'antd';
import { GroupDto } from '../../services/Client';
import { orderBy } from 'lodash';

type Props = {
    visible: boolean;
    parentGroup: GroupDto;
    onOk: () => void;
    onAddDevice: (parentGroup: GroupDto) => void;
    onDeleteDevice: (groupdId: number) => void;
    onChangeIndex: (groupdId: number, upDown: number) => void;
    onReorderSave: () => void;
};

const DeviceListModal: React.FC<Props> = (props) => {
    const { visible, parentGroup } = props;
    let devices = parentGroup && parentGroup.childGroups!.filter((r) => r.isDevice);
    // if(parentGroup?.order===0){
    //    parentGroup.childGroups?.map(x=>x.order=x.id)
    // }

    return (
        <Modal open={visible} title="Devices" width={800} onCancel={props.onOk} onOk={props.onOk}>
            <div>
                <Alert
                    message="Warning"
                    description={<span>After deleteing device, tags will be deleted accordingly.</span>}
                    type="warning"
                    showIcon
                />
            </div>
            <Button type="primary" onClick={() => props.onReorderSave()}>
                Save
            </Button>
            <Table
                dataSource={devices}
                rowKey={(r) => r.id + ''}
                title={() => <Button onClick={() => props.onAddDevice(parentGroup!)}>Add new device</Button>}
            >
                <Table.Column
                    title="Actions"
                    render={(row: GroupDto) => (
                        <>
                            <Button
                                shape="circle"
                                icon={<UpCircleOutlined />}
                                title="edit"
                                onClick={() => props.onChangeIndex(row!.id!, 1)}
                            ></Button>{' '}
                            <Button
                                shape="circle"
                                icon={<DownCircleOutlined />}
                                title="edit"
                                onClick={() => props.onChangeIndex(row!.id!, 2)}
                            ></Button>
                        </>
                    )}
                ></Table.Column>
                <Table.Column
                    title="Is Active"
                    dataIndex="isActive"
                    render={(isActive: boolean) => (isActive ? 'Yes' : 'No')}
                ></Table.Column>
                <Table.Column title="ID" dataIndex="id" sortDirections={['descend']}></Table.Column>
                <Table.Column title="Order" dataIndex="order" sortDirections={['descend']}></Table.Column>
                <Table.Column title="Name" dataIndex="name"></Table.Column>
                <Table.Column
                    title="Actions"
                    render={(row: GroupDto) => (
                        <Popconfirm
                            title="Are you sure delete this tag?"
                            onConfirm={() => props.onDeleteDevice(row!.id!)}
                            okText="Yes"
                            cancelText="No"
                        >
                            <Button
                                shape="circle"
                                style={{ color: 'red' }}
                                title="delete"
                                icon={<DeleteOutlined />}
                            ></Button>
                        </Popconfirm>
                    )}
                ></Table.Column>
            </Table>
        </Modal>
    );
};

export default DeviceListModal;
