import React from 'react';
import { Drawer, Form, Input, Select, Button, Switch } from 'antd';
import { DictionaryDto, AreaVm } from '../../services/Client';

export type LogsheetForm = {
    id?: number;
    locationCode?: string;
    areaCode?: string;
    name?: string;
    isActive?: boolean;
};

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    onSubmit: () => void;
    onClose: () => void;
};

const LogsheetDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form: form0, areas } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const previousProps = React.useRef(props);

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (locationCode: string) => {
            filterAreas(locationCode);
            form0.setFieldsValue({
                areaCode: '',
            });
        },
        [filterAreas, form0],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            const prevProps = previousProps.current;
            if (prevProps.visible === false && props.visible) {
                setTimeout(() => {
                    const locationCode = form0.getFieldValue('locationCode');
                    filterAreas(locationCode);
                }, 1000);
            }
            previousProps.current = props;
        }
    });

    const {
        visible: visible,
        form: {},
        form: form,
        locations: locations,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');

    return (
        <Drawer title={id ? 'Edit logsheet' : 'Add new Logsheet'} open={visible} width={700} onClose={props.onClose}>
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item
                    label="Location"
                    name="locationCode"
                    rules={[
                        {
                            required: true,
                            message: 'Location is required',
                        },
                    ]}
                >
                    <Select disabled={!!id} onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Area"
                    name="areaCode"
                    rules={[
                        {
                            required: true,
                            message: 'Area is required',
                        },
                    ]}
                >
                    <Select>
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Name"
                    name="name"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Name is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>

                <Form.Item label="Is active" name="isActive" valuePropName="checked">
                    <Switch />
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const LogsheetDrawer = LogsheetDrawerInner;

export default LogsheetDrawer;
