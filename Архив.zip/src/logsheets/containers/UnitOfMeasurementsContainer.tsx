import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Spin, Form, Button, Table, Select } from 'antd';
import PageComponent from '../../common/components/PageComponent';
import { unitOfMeasureClient } from '../../services';
import {
    DictionaryDto,
    GetUnitOfMeasurementsQuery,
    UpdateUnitOfMeasurementCommand,
    AddUnitOfMeasurementCommand,
} from '../../services/Client';
import UnitOfMeasurementDrawer, { UnitOfMeasureForm } from '../components/UnitOfMeasurementDrawer';
import type { FormInstance } from 'antd';
import { Space } from 'antd';

type Props = {};

const UnitOfMeasurementsContainerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const [loading, setLoading] = React.useState<boolean>(false);
        const [unitOfMeasurements, setUnitOfMeasurements] = React.useState<DictionaryDto[]>([]);
        const [unitOfMeasureDrawerShown, setUnitOfMeasureDrawerShown] = React.useState<boolean>(false);
        const unitOfMeasureRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

        const search = React.useCallback(() => {
            props.form
                .validateFields()
                .then(async (values: { isActive: number[] }) => {
                    setLoading(true);
                    try {
                        let query = new GetUnitOfMeasurementsQuery();
                        query.isActive = values.isActive;
                        let uoms = await unitOfMeasureClient.get(query);
                        setUnitOfMeasurements(uoms);
                    } finally {
                        setLoading(false);
                    }
                })
                .catch((err: any) => {
                    return undefined;
                });
        }, [props.form]);

        const openUnitOMeasureDrawer = (row: DictionaryDto | undefined) => {
            const form = unitOfMeasureRef.current!.form as FormInstance;
            setUnitOfMeasureDrawerShown(true);
            if (row) {
                const groupForm: UnitOfMeasureForm = {
                    id: row.id!,
                    name: row.name!,
                    code: row.code!,
                    description: row.description!,
                    isActive: row.isActive!,
                };
                form.setFieldsValue(groupForm);
            } else {
                form.resetFields();
                form.setFieldsValue({ isActive: true });
            }
        };

        const submitForm = React.useCallback(() => {
            const form = unitOfMeasureRef.current!.form as FormInstance;
            form.validateFields()
                .then(async (values: UnitOfMeasureForm) => {
                    try {
                        setLoading(true);
                        if (values.id) {
                            let updateCommand = new UpdateUnitOfMeasurementCommand();
                            updateCommand.init(values);
                            await unitOfMeasureClient.update(updateCommand);
                        } else {
                            let addCommand = new AddUnitOfMeasurementCommand();
                            addCommand.init(values);
                            await unitOfMeasureClient.add(addCommand);
                        }
                        message.success('Successful');
                        setUnitOfMeasureDrawerShown(false);
                        search();
                    } finally {
                        setLoading(false);
                    }
                })
                .catch((err: any) => {
                    return undefined;
                });
        }, [search]);

        const renderActions = (row: DictionaryDto) => {
            return (
                <Button
                    icon={<EditOutlined />}
                    shape="circle"
                    title="Edit"
                    onClick={() => openUnitOMeasureDrawer(row)}
                ></Button>
            );
        };

        const resetFilter = React.useCallback(() => {
            props.form.resetFields();
            search();
        }, [search, props.form]);

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                search();
            }
        });

        const {
            form: {},
        } = props;

        return (
            <PageComponent title={'Unit of measurements'}>
                <Spin spinning={loading}>
                    <Form form={props.form} labelAlign="left" layout="inline">
                        <Form.Item label="Is active" name="isActive" initialValue={[1]}>
                            <Select style={{ width: 150 }} mode="multiple">
                                <Select.Option key="y" value={1}>
                                    Yes
                                </Select.Option>
                                <Select.Option key="n" value={0}>
                                    No
                                </Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item>
                            <Space.Compact>
                                <Button type="primary" onClick={search}>
                                    Search
                                </Button>
                                <Button onClick={resetFilter}>Reset</Button>
                            </Space.Compact>
                        </Form.Item>
                    </Form>

                    <Table
                        rowKey={(r) => r.id + ''}
                        dataSource={unitOfMeasurements}
                        title={() => (
                            <Button type="primary" onClick={() => openUnitOMeasureDrawer(undefined)}>
                                Add new
                            </Button>
                        )}
                    >
                        <Table.Column dataIndex="name" title="Name"></Table.Column>
                        <Table.Column dataIndex="code" title="Code"></Table.Column>
                        <Table.Column dataIndex="description" title="Description"></Table.Column>
                        <Table.Column
                            dataIndex="isActive"
                            title="Is Active"
                            render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                        ></Table.Column>
                        <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
                    </Table>
                    <UnitOfMeasurementDrawer
                        visible={unitOfMeasureDrawerShown}
                        ref={(compRef: any) => (unitOfMeasureRef.current = compRef)}
                        onSubmit={submitForm}
                        onClose={() => setUnitOfMeasureDrawerShown(false)}
                    />
                </Spin>
            </PageComponent>
        );
    },
);

const UnitOfMeasurementsContainer = UnitOfMeasurementsContainerInner;

export default UnitOfMeasurementsContainer;
