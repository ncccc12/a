import {
    BarChartOutlined,
    ContainerOutlined,
    ControlOutlined,
    DashboardOutlined,
    DatabaseOutlined,
    HistoryOutlined,
    MenuFoldOutlined,
    MenuUnfoldOutlined,
    ScheduleOutlined,
    SettingOutlined,
    TeamOutlined,
} from '@ant-design/icons';
import React, { useEffect, useState } from 'react';
import { Layout, Menu, Row, Button, type MenuProps } from 'antd';
import { Link, type RouteComponentProps, withRouter } from 'react-router-dom';
import authService from '../common/components/api-authorization/AuthorizeService';
import { ApplicationPaths } from '../common/components/api-authorization/ApiAuthorizationConstants';
import { User } from '../common/components/api-authorization/types';

const { Header, Content, Sider } = Layout;

const PageTemplate = withRouter((props: RouteComponentProps & React.PropsWithChildren<{}>) => {
    const { location } = props;
    const [collapsed, setCollapsed] = useState(false);
    const [user, setUser] = useState<User>({} as any);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isExceedance, setIsExceedance] = useState(false);

    useEffect(() => {
        const getUser = async () => {
            const data: User = await authService.getUser();
            setUser(data);
            const authenticated = await authService.isAuthenticated();
            setIsAuthenticated(authenticated);
        };

        getUser();
        //userRole()
    }, []);
    useEffect(() => {
        userRole();
    }, [user]);
    const userRole = () => {
        if (user?.role?.includes('Supervisor')) {
            setIsExceedance(true);
        } else if (user?.role?.includes('ChiefSupervisor')) {
            setIsExceedance(true);
        }
    };

    const link = (path: string, label: string) => <Link to={path}>{label}</Link>;
    const menuItems: MenuProps['items'] = [
        { key: '/', icon: <DashboardOutlined />, label: link('/', 'Dashboard') },
        {
            key: '/logsheets',
            icon: <ContainerOutlined />,
            label: 'LogSheets manager',
            children: [
                { key: '/logsheets', label: link('/logsheets', 'Logsheets') },
                {
                    key: '/logsheets/uom',
                    label: link('/logsheets/uom', 'Unit of measure'),
                },
                {
                    key: '/logsheets/list-types',
                    label: link('/logsheets/list-types', 'List types'),
                },
            ],
        },
        {
            key: 'Schedule Manager',
            icon: <ScheduleOutlined />,
            label: 'Schedule manager',
            children: [
                {
                    key: '/scheduleManager/schedules',
                    icon: <ScheduleOutlined />,
                    label: link('/scheduleManager/schedules', 'Schedules'),
                },
                {
                    key: '/scheduleManager/scheduleConfigs',
                    icon: <ControlOutlined />,
                    label: link('/scheduleManager/scheduleConfigs', 'Schedule configs'),
                },
                {
                    key: '/scheduleManager/operators',
                    icon: <TeamOutlined />,
                    label: link('/scheduleManager/operators', 'Operators'),
                },
            ],
        },
        {
            key: 'reports',
            icon: <BarChartOutlined />,
            label: 'Reports',
            children: [
                {
                    key: '/reports/schedule-configs',
                    label: link('/reports/schedule-configs', 'Schedule configs'),
                },
                {
                    key: '/reports/general',
                    label: link('/reports/general', 'General'),
                },
                { key: '/reports/daily', label: link('/reports/daily', 'Daily') },
                {
                    key: '/reports/by-device',
                    label: link('/reports/by-device', 'By devices/tags'),
                },
                {
                    key: '/reports/technological-oil',
                    label: link('/reports/technological-oil', 'Technological reglament exceedances'),
                },
            ],
        },
        ...(user?.role?.includes('Admin')
            ? [
                  {
                      key: 'log',
                      icon: <DatabaseOutlined />,
                      label: 'Submited Exceedances',
                      children: [
                          {
                              key: '/exceedances/submitedExceedance',
                              label: link('/exceedances/submitedExceedance', 'Submmited exceedances'),
                          },
                      ],
                  },
                  {
                      key: 'administration',
                      icon: <SettingOutlined />,
                      label: 'Administration',
                      children: [
                          { key: '/admin/users', label: link('/admin/users', 'Users') },
                          {
                              key: '/dictionary/crews',
                              label: link('/dictionary/crews', 'Crews'),
                          },
                      ],
                  },
              ]
            : []),
        ...(isExceedance
            ? [
                  {
                      key: 'exceedance',
                      icon: <HistoryOutlined />,
                      label: 'Exceedance',
                      children: [
                          {
                              key: '/exceedances/supervisorsList',
                              label: link('/exceedances/supervisorsList', 'Exceedance list'),
                          },
                          ...(user?.role?.includes('ChiefSupervisor')
                              ? [
                                    {
                                        key: '/exceedances/shiftSupervisor',
                                        label: link('/exceedances/shiftSupervisor', 'Shift supervisor’s list'),
                                    },
                                ]
                              : []),
                          {
                              key: '/exceedances/resolvedExceedance',
                              label: link('/exceedances/resolvedExceedance', 'Resolved Exceedances'),
                          },
                          {
                              key: '/exceedances/run',
                              label: link('/exceedances/run', 'Run & Maintain'),
                          },
                      ],
                  },
              ]
            : []),
    ];

    return (
        <Layout>
            <Sider trigger={null} width={250} style={{ height: '100vh' }} collapsible collapsed={collapsed}>
                <div
                    className="logo"
                    style={{
                        height: 32,
                        background: '#334454',
                        margin: 16,
                    }}
                />

                <Menu
                    mode="inline"
                    theme="dark"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    selectedKeys={[location.pathname]}
                    items={menuItems}
                    style={{ height: '100%', borderRight: 0 }}
                />
            </Sider>
            <Layout>
                <Header style={{ background: '#fff', padding: 0 }}>
                    <Row justify="space-between" align="middle">
                        <div>
                            {collapsed ? (
                                <MenuUnfoldOutlined
                                    style={{
                                        fontSize: 18,
                                        lineHeight: '64px',
                                        paddingLeft: 24,
                                        cursor: 'pointer',
                                        transition: '#1890ff',
                                    }}
                                    onClick={() => setCollapsed(false)}
                                />
                            ) : (
                                <MenuFoldOutlined
                                    style={{
                                        fontSize: 18,
                                        lineHeight: '64px',
                                        paddingLeft: 24,
                                        cursor: 'pointer',
                                    }}
                                    onClick={() => setCollapsed(true)}
                                />
                            )}

                            <h2 style={{ paddingLeft: 10, display: 'inline' }}>Welcome to Admin Panel</h2>
                        </div>
                        <div style={{ paddingRight: 24 }}>
                            {isAuthenticated ? (
                                <Button type="link">
                                    <Link
                                        to={{
                                            pathname: `${ApplicationPaths.LogOut}`,
                                            state: { local: true },
                                        }}
                                    >
                                        Logout
                                    </Link>
                                </Button>
                            ) : (
                                <Button type="link">
                                    <Link to={`${ApplicationPaths.Login}`}>Login</Link>
                                </Button>
                            )}
                        </div>
                    </Row>
                </Header>
                <Content
                    style={{
                        margin: '24px 16px',
                        padding: 24,
                        minHeight: 280,
                    }}
                >
                    {props.children}
                </Content>
            </Layout>
        </Layout>
    );
});

export default PageTemplate;
