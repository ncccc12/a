import React from 'react';
import { Spin, Card, DatePicker, Form, Select, Button, Row, Col, Typography } from 'antd';
import { PieChart } from '@opd/g2plot-react';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, GetTimeHistoriesStatusesCountQuery } from '../../services/Client';
import dayjs, { type Dayjs } from '@dayjs';

import { Space } from 'antd';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const LogsheetTasksPieInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form, areas } = props;

    const [loading, setLoading] = React.useState<boolean>(false);
    const [datas, setDatas] = React.useState<any[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const colorMapping = (status: any) => {
        if (status.x === 'Completed') {
            return '#a0d911';
        }
        return '#FF0000';
    };

    const config = React.useRef({
        title: {
            visible: true,
            text: '',
        },
        description: {
            visible: true,
            text: '',
        },
        legend: {
            flipPage: false,
        },
        height: 250,
        forceFit: true,
        radius: 1,
        colorField: 'x',
        angleField: 'y',
        color: (status: any) => colorMapping(status),
    });

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (value: string) => {
            form.setFieldsValue({ areaCode: '' });
            filterAreas(value);
        },
        [filterAreas, form],
    );

    const search = React.useCallback(async () => {
        setLoading(true);

        form.validateFields()
            .then(async (values: any) => {
                let period = values.datePeriod?.map((r: Dayjs) => r.utc(true).toDate());
                let query = new GetTimeHistoriesStatusesCountQuery();
                query.datePeriod = period || [];
                query.areaCode = values.areaCode;
                query.locationCode = values.locationCode;
                let result = await logsheetTimeHistoriesClient.getTimeHistoriesStatusesCount(query);
                result.forEach(async (result) => {
                    if (result.statusId === 1) {
                    }
                });
                let datas = result.map((r) => {
                    return { x: r.statusName, y: r.count };
                });
                setLoading(false);
                setDatas(datas);
            })
            .catch((errors: any) => {
                return undefined;
            });
    }, [form]);

    const resetFilter = React.useCallback(() => {
        props.form.resetFields();
        search();
    }, [search, props.form]);

    const renderHeader = () => {
        const {
            form: {},
            locations,
        } = props;

        return (
            <>
                <Form form={props.form} layout="inline" labelAlign="left">
                    <Row justify="space-between">
                        <Typography.Title level={4}>Tasks status</Typography.Title>
                        <Form.Item style={{ margin: 0 }}>
                            <Space.Compact>
                                <Button type="primary" onClick={search}>
                                    Search
                                </Button>
                                <Button onClick={resetFilter}>Reset</Button>
                            </Space.Compact>
                        </Form.Item>
                    </Row>
                    <Row gutter={24}>
                        <Col md={12}>
                            <Form.Item
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                                label="Location"
                                name="locationCode"
                            >
                                <Select onChange={handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        </Col>
                        <Col md={12}>
                            <Form.Item
                                label="Area"
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                                name="areaCode"
                            >
                                <Select>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col md={24}>
                            <Form.Item
                                label="Date period"
                                style={{ width: '100%' }}
                                name="datePeriod"
                                initialValue={[dayjs().startOf('day'), dayjs().startOf('day')]}
                            >
                                <DatePicker.RangePicker
                                    format="DD-MM-YYYY"
                                    presets={[
                                        { label: 'Today', value: [dayjs(), dayjs()] },
                                        {
                                            label: 'This week',
                                            value: [dayjs().startOf('week'), dayjs().endOf('week')],
                                        },
                                        {
                                            label: 'This Month',
                                            value: [dayjs().startOf('month'), dayjs().endOf('month')],
                                        },
                                        {
                                            label: 'This year',
                                            value: [dayjs().startOf('year'), dayjs().endOf('year')],
                                        },
                                    ]}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            </>
        );
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    return (
        <Spin spinning={loading}>
            <Card title={renderHeader()}>{!loading && <PieChart {...config.current} data={datas} />}</Card>
        </Spin>
    );
});

const LogsheetTasksPie = LogsheetTasksPieInner;

export default LogsheetTasksPie;
