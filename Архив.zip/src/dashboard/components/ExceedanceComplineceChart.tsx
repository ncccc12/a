import React from 'react';
import { Card, List, Col, DatePicker, Spin, Form, Row, Select, Button, Typography } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import { LineChart } from '@opd/g2plot-react';
import { reportsClient } from '../../services';
import { DeviceTag, DictionaryDto, AreaVm, GetExceedanceComplianceCountQuery } from '../../services/Client';
import { Space } from 'antd';

const dateFormat = 'DD-MM-YYYY';

const config = {
    title: {
        visible: true,
        text: '',
    },
    description: {
        visible: true,
        text: '',
    },
    legend: {
        flipPage: false,
    },
    forceFit: true,
    height: 376,
    xField: 'x',
    yField: 'y',
    seriesField: 'series',
    color: ['#5B8FF9', '#5AD8A6'],
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const ExceedanceComplinceChartInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form, areas } = props;

        const [loading, setLoading] = React.useState<boolean>(false);
        const [datas, setDatas] = React.useState<any[]>([]);
        const [topTags, setTopTags] = React.useState<DeviceTag[]>([]);
        const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

        const search = React.useCallback(async () => {
            setLoading(true);
            form.validateFields()
                .then(async (values: any) => {
                    let query = new GetExceedanceComplianceCountQuery();
                    query.datePeriod = values.datePeriod?.map((r: Dayjs) => r.utc(true).toDate()) || [];
                    query.locationCode = values.locationCode;
                    query.areaCode = values.areaCode;
                    let data = await reportsClient.getExceedanceComplianceCount(query);
                    let datas = data.complinceExceedanceItems!.map((r) => {
                        return {
                            series: r.type,
                            x: dayjs(r.date).format(dateFormat),
                            y: r.count,
                        };
                    });
                    setDatas(datas);
                    setTopTags(data.topTags!);
                    setLoading(false);
                })
                .catch((errors: any) => {
                    return undefined;
                });
        }, [form]);

        const filterAreas = React.useCallback(
            (locationCode: string) => {
                const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
                setFilteredAreas(filteredAreas);
            },
            [areas],
        );

        const handleLocationChange = React.useCallback(
            (value: string) => {
                form.setFieldsValue({ areaCode: '' });
                filterAreas(value);
            },
            [filterAreas, form],
        );

        const resetFilter = React.useCallback(() => {
            props.form.resetFields();
            search();
        }, [search, props.form]);

        const renderHeader = () => {
            const {
                form: {},
                locations,
            } = props;

            return (
                <Form form={props.form} layout="inline" labelAlign="left">
                    <Row gutter={24}>
                        <Col md={6}>
                            <Form.Item
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                                label="Location"
                                name="locationCode"
                            >
                                <Select onChange={handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        </Col>
                        <Col md={5}>
                            <Form.Item
                                label="Area"
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                                name="areaCode"
                            >
                                <Select>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>
                            </Form.Item>
                        </Col>
                        <Col md={7}>
                            <Form.Item
                                style={{ width: '100%' }}
                                name="datePeriod"
                                initialValue={[dayjs().startOf('day'), dayjs().startOf('day')]}
                            >
                                <DatePicker.RangePicker
                                    format="DD-MM-YYYY"
                                    presets={[
                                        { label: 'Today', value: [dayjs(), dayjs()] },
                                        {
                                            label: 'This week',
                                            value: [dayjs().startOf('week'), dayjs().endOf('week')],
                                        },
                                        {
                                            label: 'This Month',
                                            value: [dayjs().startOf('month'), dayjs().endOf('month')],
                                        },
                                        {
                                            label: 'This year',
                                            value: [dayjs().startOf('year'), dayjs().endOf('year')],
                                        },
                                    ]}
                                />
                            </Form.Item>
                        </Col>
                        <Col md={6}>
                            <Form.Item>
                                <Space.Compact>
                                    <Button type="primary" onClick={search}>
                                        Search
                                    </Button>
                                    <Button onClick={resetFilter}>Reset</Button>
                                </Space.Compact>
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            );
        };

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                search();
            }
        });

        return (
            <Spin spinning={loading}>
                <Card
                    title={<Typography.Title level={3}>Exceedance/Compliance tasks status</Typography.Title>}
                    extra={renderHeader()}
                >
                    <Col span={18}>{!loading && <LineChart {...config} data={datas} />}</Col>
                    <Col span={6}>
                        <List
                            header={<b> Top 10 sensors with exceedance: </b>}
                            dataSource={topTags}
                            renderItem={(item) => (
                                <List.Item>{`${item.deviceName}/${item.tagName}(${item.exceedanceCount})`}</List.Item>
                            )}
                        ></List>
                    </Col>
                </Card>
            </Spin>
        );
    },
);

const ExceedanceComplinceChart = ExceedanceComplinceChartInner;

export default ExceedanceComplinceChart;
