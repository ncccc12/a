import React from 'react';
import { Row, Card, List, Col, Select, Form, Button, Spin, Typography } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, LogsheestTaskVm } from '../../services/Client';
import { Space } from 'antd';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const PendingLogsheetTasksInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form, areas } = props;

        const [pendingTasks, setPendingTasks] = React.useState<LogsheestTaskVm[]>([]);
        const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
        const [loading, setLoading] = React.useState<boolean>(false);

        const search = React.useCallback(async () => {
            form.validateFields()
                .then(async (values: any) => {
                    setLoading(true);
                    let pendingTasks = await logsheetTimeHistoriesClient.getPendingLogsheetTasks(
                        values.locationCode,
                        values.areaCode,
                    );
                    setPendingTasks(pendingTasks);
                    setLoading(false);
                })
                .catch((err: any) => {
                    return undefined;
                });
        }, [form]);

        const filterAreas = React.useCallback(
            (locationCode: string) => {
                const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
                setFilteredAreas(filteredAreas);
            },
            [areas],
        );

        const handleLocationChange = React.useCallback(
            (value: string) => {
                form.setFieldsValue({ areaCode: '' });
                filterAreas(value);
            },
            [filterAreas, form],
        );

        const resetFilter = React.useCallback(() => {
            props.form.resetFields();
            search();
        }, [search, props.form]);

        const renderHeader = () => {
            const {
                form: {},
                locations,
            } = props;

            return (
                <>
                    <Typography.Title level={4}>Pending tasks</Typography.Title>
                    <Form form={props.form} layout="inline">
                        <Form.Item label="Location" name="locationCode">
                            <Select style={{ width: 250 }} onChange={handleLocationChange}>
                                {locations.map((r) => {
                                    return (
                                        <Select.Option key={r.code} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item label="Area" name="areaCode">
                            <Select style={{ width: 250 }}>
                                {filteredAreas.map((r) => {
                                    return (
                                        <Select.Option key={r.code} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item>
                            <Space.Compact>
                                <Button type="primary" onClick={search}>
                                    Search
                                </Button>
                                <Button onClick={resetFilter}>Reset</Button>
                            </Space.Compact>
                        </Form.Item>
                    </Form>
                </>
            );
        };

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                search();
            }
        });

        return (
            <Spin spinning={loading}>
                <Card title={renderHeader()} style={{ height: '100%', minHeight: 730 }}>
                    <List
                        dataSource={pendingTasks}
                        pagination={{ pageSize: 8 }}
                        renderItem={(r) => (
                            <List.Item>
                                <List.Item.Meta
                                    title={
                                        <Row>
                                            <Col md={20}>{r.logsheetName}</Col>
                                            <Col>{dayjs(r.dateTime).format('DD-MM-YYYY HH:mm')}</Col>
                                        </Row>
                                    }
                                    description={
                                        <Row>
                                            <Col>
                                                Location: {r.location}/{r.area}
                                            </Col>
                                            {/* <Col>Responsible: {r.crewName}</Col> */}
                                        </Row>
                                    }
                                />
                            </List.Item>
                        )}
                    />
                </Card>
            </Spin>
        );
    },
);

const PendingLogsheetTasks = PendingLogsheetTasksInner;

export default PendingLogsheetTasks;
