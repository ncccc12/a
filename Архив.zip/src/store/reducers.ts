import { combineReducers } from 'redux';
import reportsHistoryFilterFormDuck from '../repots/ducks/ReportsHistoryFilterFormDuck';
import LogsheetsFilterDuck from '../logsheets/ducks/LogsheetsFilterDuck';
import ScheduleManagerDuck from '../schedule/ducks/ScheduleMangerDuck';

export interface AppState {
    reportsHistoryFilterFormDuck: ReturnType<typeof reportsHistoryFilterFormDuck>;
    LogsheetsFilterDuck: ReturnType<typeof LogsheetsFilterDuck>;
    ScheduleManagerDuck: ReturnType<typeof ScheduleManagerDuck>;
}

const reducers = {
    reportsHistoryFilterFormDuck,
    LogsheetsFilterDuck,
    ScheduleManagerDuck,
};

const rootReducer = combineReducers(reducers as any);

export default rootReducer;
