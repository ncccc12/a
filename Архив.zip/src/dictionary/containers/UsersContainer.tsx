import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import { Button, Input, Spin, Table, Tag, Row, Col } from 'antd';
import type { FormInstance } from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import { usersClient } from '../../services';
import { GetUsersQuery, UserVm, UpdateUserCommand, CreateUserCommand } from '../../services/Client';
import UserDrawer, { UserFormModel } from '../components/UserDrawer';
import fileDownload from 'js-file-download';

const UsersContainer: React.FC = () => {
    const [users, setUsers] = useState<UserVm[]>([]);
    const [isUserDrawerShown, setIsUserDrawerShown] = useState(false);
    const [loading, setLoading] = useState(false);
    const [filterUserName, setFilterUserName] = useState('');
    const [filterName, setFilterName] = useState('');
    const [exportingUsers, setExportingUsers] = useState(false);

    const userDrawerRef = useRef<{ form: import('antd').FormInstance } | null>(null);

    useEffect(() => {
        loadData();
        // eslint-disable-next-line
    }, []);

    const loadData = async (filters?: { userName?: string; name?: string }) => {
        setLoading(true);
        let query = new GetUsersQuery();
        if (filters) {
            if (filters.userName) query.username = filters.userName;
            if (filters.name) {
                query.fullName = filters.name;
            }
        }
        let users = await usersClient.getUsers(query);
        setUsers(users);
        setLoading(false);
    };

    const submitUser = () => {
        const form = userDrawerRef.current!.form as FormInstance;
        form.validateFields()
            .then(async (values: UserFormModel) => {
                try {
                    setLoading(true);
                    if (values.id) {
                        let command = new UpdateUserCommand();
                        command.id = values.id;
                        command.email = values.email;
                        command.userName = values.userName;
                        command.roles = values.roles;
                        command.locationCode = values.locationCode;
                        command.areaCodes = values.areaCodes;
                        command.disciplineId = values.disciplineId;
                        command.nk = values.nk;
                        await usersClient.updateUser(command);
                        message.success('User has been updated successfully!');
                    } else {
                        let command = new CreateUserCommand();
                        command.locationCode = values.locationCode;
                        command.areaCodes = values.areaCodes;
                        command.userName = values.userName;
                        command.email = values.email;
                        command.nk = values.nk;
                        command.password = values.password;
                        command.confirmPassword = values.confPassword;
                        command.roles = values.roles;
                        command.accountType = values.accountType;
                        command.disciplineId = values.disciplineId;
                        command.firstName = values.firstName;
                        command.lastName = values.lastName;
                        await usersClient.createUser(command);
                        message.success('User has been created successfully!');
                    }
                    setIsUserDrawerShown(false);
                    await loadData();
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    };

    const openUserDrawer = (row: UserVm | undefined) => {
        const form = userDrawerRef.current!.form as FormInstance;
        if (row) {
            setIsUserDrawerShown(true);
            setTimeout(() => {
                form.setFieldsValue({
                    accountType: row.accountType,
                    locationCode: row.locationCode,
                    areaCodes: row.areaCodes,
                    id: row.id,
                    userName: row.userName,
                    email: row.email,
                    roles: row.roles,
                    disciplineId: row.disciplineId,
                });
            });
        } else {
            setIsUserDrawerShown(true);
        }
    };

    const closerUserDrawer = () => {
        const form = userDrawerRef.current!.form as FormInstance;
        form.resetFields();
        setIsUserDrawerShown(false);
    };

    const renderActions = (row: UserVm) => {
        return <Button icon={<EditOutlined />} title="Edit" onClick={() => openUserDrawer(row)}></Button>;
    };

    const renderRoles = (roles: string[]) => {
        return roles.map((r) => {
            return <Tag key={r}>{r}</Tag>;
        });
    };

    const renderAreas = (areas: string[]) => {
        return areas.map((r) => <Tag key={r}>{r}</Tag>);
    };

    const handleFilter = () => {
        loadData({
            userName: filterUserName,
            name: filterName,
        });
    };

    const handleReset = () => {
        setFilterUserName('');
        setFilterName('');
        loadData();
    };

    const handleExportUsers = async () => {
        setExportingUsers(true);
        try {
            const response = await usersClient.exportUsers();
            fileDownload(response.data, response.fileName!);
        } finally {
            setExportingUsers(false);
        }
    };

    return (
        <>
            <Row gutter={8} style={{ marginBottom: 16 }}>
                <Col span={6}>
                    <Input
                        placeholder="Filter by User name"
                        value={filterUserName}
                        onChange={(e) => setFilterUserName(e.target.value)}
                        onPressEnter={handleFilter}
                        allowClear
                    />
                </Col>
                <Col span={6}>
                    <Input
                        placeholder="Filter by Name"
                        value={filterName}
                        onChange={(e) => setFilterName(e.target.value)}
                        onPressEnter={handleFilter}
                        allowClear
                    />
                </Col>
                <Col span={6}>
                    <Button
                        type="primary"
                        onClick={handleFilter}
                        loading={exportingUsers}
                        disabled={loading}
                        style={{ marginRight: 8 }}
                    >
                        Search
                    </Button>
                    <Button onClick={handleReset}>Reset</Button>
                </Col>
            </Row>
            <Spin spinning={loading}>
                <Table
                    dataSource={users}
                    bordered
                    title={() => (
                        <Row justify="space-between">
                            <Col>
                                <Button type="primary" onClick={() => openUserDrawer(undefined)}>
                                    Add New User
                                </Button>
                            </Col>
                            <Col>
                                <Button type="dashed" onClick={() => handleExportUsers()}>
                                    Export Users
                                </Button>
                            </Col>
                        </Row>
                    )}
                    rowKey={(r) => r.id!}
                >
                    <Table.Column dataIndex="location" title="Location" />
                    <Table.Column dataIndex="areas" title="Areas" render={renderAreas} />
                    <Table.Column dataIndex="userName" title="User name" />
                    <Table.Column dataIndex="firstName" title="First name" />
                    <Table.Column dataIndex="lastName" title="Last name" />
                    <Table.Column dataIndex="email" title="Email" />
                    <Table.Column dataIndex="roles" title="Roles" render={renderRoles} />
                    <Table.Column title="Actions" render={(r: UserVm) => renderActions(r)} />
                </Table>

                <UserDrawer
                    ref={(ref: { form: import('antd').FormInstance } | null) => (userDrawerRef.current = ref)}
                    visible={isUserDrawerShown}
                    onSubmit={submitUser}
                    onClose={closerUserDrawer}
                ></UserDrawer>
            </Spin>
        </>
    );
};

export default UsersContainer;
