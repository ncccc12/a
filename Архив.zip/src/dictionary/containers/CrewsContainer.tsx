import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Spin, Row, Form, Select, Button, Divider, Table } from 'antd';
import { Space } from 'antd';
import { dictionaryClient, groupsClient } from '../../services';
import {
    DictionaryDto,
    AreaVm,
    GetGroupsQuery,
    GroupVm,
    AddNewGroupCommand,
    UpdateGroupCommand,
} from '../../services/Client';
import CrewDrawer, { GroupForm } from '../components/CrewDrawer';
import type { FormInstance } from 'antd';

type SearchForm = {
    locationCode: string;
    areaCode: string;
    isActive: number[];
};

type Props = {};

const CrewsContainerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const [loading, setLoading] = React.useState<boolean>(false);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [groups, setGroups] = React.useState<GroupVm[]>([]);
    const [isCrewDrawerShown, setIsCrewDrawerShown] = React.useState<boolean>(false);
    const crewFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const loadData = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
    };

    const handleLocationChange = React.useCallback(
        (value: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === value);
            setFilteredAreas(filteredAreas);

            props.form.setFieldsValue({
                areaCode: '',
            });
        },
        [areas, props.form],
    );

    const search = React.useCallback(() => {
        props.form
            .validateFields()
            .then(async (values: SearchForm) => {
                setLoading(true);
                try {
                    var query = new GetGroupsQuery();
                    query.init(values);
                    let groups = await groupsClient.getGroups(query);
                    setGroups(groups);
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [props.form]);

    const submitForm = React.useCallback(() => {
        const form = crewFormRef.current!.form as FormInstance;
        form.validateFields()
            .then(async (values: GroupForm) => {
                try {
                    setLoading(true);
                    if (values.id) {
                        let updateCommand = new UpdateGroupCommand();
                        updateCommand.init(values);
                        await groupsClient.updateGroup(updateCommand);
                    } else {
                        // add new
                        let command = new AddNewGroupCommand();
                        command.init(values);
                        await groupsClient.addNewGroup(command);
                    }
                    message.success('Successful');
                    setIsCrewDrawerShown(false);
                    search();
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [search]);

    const resetFilter = React.useCallback(() => {
        props.form.resetFields();
        search();
    }, [search, props.form]);

    const renderActions = (r: GroupVm) => {
        return <Button icon={<EditOutlined />} shape="circle" title="edit" onClick={() => openDrawer(r)} />;
    };

    const openDrawer = (r: GroupVm | undefined) => {
        const form = crewFormRef.current!.form as FormInstance;
        setIsCrewDrawerShown(true);
        if (r) {
            const groupForm: GroupForm = {
                id: r.id!,
                areaCode: r.areaCode!,
                locationCode: r.locationCode!,
                name: r.name!,
                code: r.code!,
                description: r.description!,
                isActive: r.isActive!,
            };
            form.setFieldsValue(groupForm);
        } else {
            form.resetFields();
            form.setFieldsValue({ isActive: true });
        }
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadData();
                search();
            }
        })();
    });

    const {
        form: {},
    } = props;

    const selectStyle = {
        width: 150,
    };

    return (
        <Spin spinning={loading}>
            <Row>
                <Form form={props.form} labelAlign="left" layout="inline">
                    <Form.Item label="Location" name="locationCode">
                        <Select style={selectStyle} onChange={handleLocationChange}>
                            {locations.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Area" name="areaCode">
                        <Select style={selectStyle}>
                            {filteredAreas.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Is active" name="isActive" initialValue={[]}>
                        <Select style={selectStyle} mode="multiple">
                            <Select.Option key="y" value={1}>
                                Yes
                            </Select.Option>
                            <Select.Option key="n" value={0}>
                                No
                            </Select.Option>
                        </Select>
                    </Form.Item>

                    <Form.Item>
                        <Space.Compact>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </Space.Compact>
                    </Form.Item>
                </Form>
            </Row>
            <Divider />
            <Row>
                <Table
                    dataSource={groups}
                    title={() => <Button onClick={() => openDrawer(undefined)}>Add new</Button>}
                    rowKey={(r) => r.id + ''}
                    bordered
                >
                    <Table.Column dataIndex="locationName" title="Location"></Table.Column>
                    <Table.Column dataIndex="areaName" title="Area"></Table.Column>
                    <Table.Column dataIndex="name" title="Name"></Table.Column>
                    <Table.Column dataIndex="code" title="Code"></Table.Column>
                    <Table.Column dataIndex="description" title="Description"></Table.Column>
                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                    ></Table.Column>
                    <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
                </Table>
            </Row>
            <Row>
                <CrewDrawer
                    visible={isCrewDrawerShown}
                    ref={(compRef: any) => (crewFormRef.current = compRef)}
                    locations={locations}
                    areas={areas}
                    onSubmit={submitForm}
                    onClose={() => setIsCrewDrawerShown(false)}
                />
            </Row>
        </Spin>
    );
});

const CrewsContainer = CrewsContainerInner;

export default CrewsContainer;
