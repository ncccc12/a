import { notification } from '../../common/antdFeedback';
import React from 'react';
import { Form, Drawer, Input, Button, Checkbox, Row, Col, Select, Dropdown, Radio, Alert } from 'antd';
import { dictionaryClient } from '../../services';
import { AdUserVm, AreaVm, DictionaryDto, AccountType, DisciplinesVm } from '../../services/Client';
import { usersClient } from '../../services';
import { debounce, last } from 'lodash';

type CheckboxValueType = string | number | boolean;

export interface UserFormModel {
    locationCode?: string;
    areaCodes?: string[];
    id: string;
    userName: string;
    lastName: string;
    firstName: string;
    email: string;
    password?: string;
    confPassword?: string;
    roles: string[];
    accountType: AccountType;
    discipline: number | undefined;
    disciplineId: number | undefined;
    nk?: string | undefined;
}

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
};

const UserDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form: form0 } = props;

    const [confirmDirty, setConfirmDirty] = React.useState<boolean>(false);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [hasDiscipline, setHasDiscipline] = React.useState<boolean>(false);
    const [accountType, setAccountType] = React.useState<AccountType | undefined>(AccountType.IsExternal);
    const [filterredPersons, setFilterredPersons] = React.useState<AdUserVm[]>([]);
    const [selectedPersons, setSelectedPersons] = React.useState<AdUserVm>({} as AdUserVm);
    const [selectedNk, setSelectedNk] = React.useState<string>('');
    const [disciplines, setDisciplines] = React.useState<DisciplinesVm[]>([]);
    const [selectedDiscipline, setSelectedDiscipline] = React.useState<DisciplinesVm | undefined>(undefined);
    const previousProps = React.useRef(props);

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (value: string) => {
            filterAreas(value);
            props.form.setFieldsValue({
                areaCodes: [],
            });
        },
        [filterAreas, props.form],
    );

    const loadData = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
        let discipline = await usersClient.getDisciplines(undefined);

        setDisciplines(discipline);
    };

    const handleConfirmBlur = React.useCallback(
        (e: any) => {
            const { value } = e.target;
            setConfirmDirty(confirmDirty || !!value);
        },
        [confirmDirty],
    );

    const compareToFirstPassword = React.useCallback(
        async (_rule: any, value: any) => {
            if (value && value !== form0.getFieldValue('password')) {
                throw new Error('Two passwords that you enter is inconsistent!');
            }
        },
        [form0],
    );

    const validateToNextPassword = React.useCallback(
        async (_rule: any, value: any) => {
            if (value && confirmDirty) {
                await form0.validateFields(['confPassword']);
            }
        },
        [confirmDirty, form0],
    );

    const unique = (checkedValues: CheckboxValueType[]) => {
        let result: any[] = [];

        for (let str of checkedValues) {
            if (!result.includes(str)) {
                result.push(str);
            }
        }

        return result;
    };

    const onChange = React.useCallback((checkedValues: CheckboxValueType[]) => {
        if (checkedValues.includes('Supervisor')) {
            if (!checkedValues.includes('Read')) {
                checkedValues.push('Read');
            }
            if (!checkedValues.includes('Write')) {
                checkedValues.push('Write');
            }
        }
        if (checkedValues.includes('DisciplineEnginer')) {
            if (!checkedValues.includes('Read')) {
                checkedValues.push('Read');
            }
            setHasDiscipline(true);
        }
        if (!checkedValues.includes('DisciplineEnginer')) {
            setHasDiscipline(false);
        }
        const uniqueArr = new Set(checkedValues);

        checkedValues = Array.from(uniqueArr);
    }, []);

    const radioChange = React.useCallback(
        (e: any) => {
            setAccountType(e.target.value);

            props.form.setFieldsValue({ ['accountType']: e.target.value });
        },
        [props.form],
    );

    const filterPersons0 = React.useCallback(async (lastname: string) => {
        if (lastname && lastname.length > 3) {
            try {
                const result = await usersClient.getUsersFromAdByQuery(lastname);
                setFilterredPersons(result);
            } catch (error) {
                notification.error({
                    message: 'Error on persons search',
                });
            }
        } else {
            setFilterredPersons([]);
        }
    }, []);

    const debouncedFilterPersons = React.useMemo(() => debounce(filterPersons0, 800), [filterPersons0]);

    React.useEffect(() => () => debouncedFilterPersons.cancel(), [debouncedFilterPersons]);

    const onSelectNk = React.useCallback(
        (value: any) => {
            setSelectedNk(value);
            const selectedUser = filterredPersons.filter((p) => p.email === value)[0];
            setSelectedPersons(selectedUser);
            props.form.setFieldsValue({ nk: selectedUser.nk });
            props.form.setFieldsValue({ ['email']: value });
            props.form.setFieldsValue({ firstName: selectedUser.firstName });
            props.form.setFieldsValue({ lastName: selectedUser.lastName });
        },
        [filterredPersons, props.form],
    );

    const onDisciplineChange = (value: any) => {
        disciplines.map((x) => {
            if (x.id === value) {
                setSelectedDiscipline(x);
            }
        });
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadData();
            } else {
                const prevProps = previousProps.current;
                if (prevProps.visible === false && props.visible) {
                    setTimeout(() => {
                        const locationCode = form0.getFieldValue('locationCode');
                        filterAreas(locationCode);

                        let roless = form0.getFieldValue('roles');
                        if (roless?.includes('DisciplineEnginer')) {
                            setHasDiscipline(true);
                        } else {
                            setHasDiscipline(false);
                        }
                    }, 1000);
                }
                previousProps.current = props;
            }
        })();
    });

    const {
        visible: visible,
        form: form,
        form: {},
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let nk = form.getFieldValue('nk');
    let id = form.getFieldValue('id');
    let accType = form.getFieldValue('accountType');
    let discipline = form.getFieldValue('disciplineId');

    return (
        <Drawer
            title={id ? 'Edit user' : 'Add new user'}
            open={visible}
            width={500}
            destroyOnHidden={true}
            onClose={props.onClose}
        >
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item name="accountType" hidden />
                <Form.Item name="discipline" hidden />
                <Form.Item name="disciplineId" hidden />
                <Form.Item name="roles" hidden />
                <Form.Item name="nk" hidden />
                <Form.Item name="lastName" hidden />
                <Form.Item name="firstName" hidden />
                <Form.Item label="Location" name="locationCode">
                    <Select onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>

                <Form.Item label="Area" name="areaCodes">
                    <Select mode="multiple">
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    name="accountType"
                    rules={[
                        {
                            required: true,
                            message: 'AccountType is required',
                        },
                    ]}
                >
                    <Radio.Group disabled={id} onChange={radioChange}>
                        <Radio value={AccountType.IsExternal}>External</Radio>
                        <Radio value={AccountType.IsInternal}>Internal</Radio>
                    </Radio.Group>
                </Form.Item>
                {accountType === 0 && (
                    <Form.Item
                        label="User Name"
                        name="userName"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'User name is required',
                            },
                        ]}
                    >
                        <Input disabled={accType === AccountType.IsInternal} />
                    </Form.Item>
                )}
                {accountType === 1 && (
                    <Form.Item
                        label="User NK"
                        name="userName"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'User name is required',
                            },
                        ]}
                    >
                        <Select
                            filterOption={false}
                            allowClear
                            showSearch
                            placeholder={'Write User NK'}
                            onSearch={debouncedFilterPersons}
                            onSelect={onSelectNk}
                            disabled={id}
                        >
                            {filterredPersons.map((x) => (
                                <Select.Option key={x.nk!} value={x.email!} title={x.fullName}>
                                    {x.fullName!}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                )}
                {accountType === 1 && selectedPersons !== null && (
                    <>
                        <span>Position:{selectedPersons!.position}</span>
                        <br />
                        <span>NK: {nk}</span>
                    </>
                )}
                {
                    <Form.Item
                        label="Email"
                        name="email"
                        rules={[
                            {
                                type: 'email',
                                message: 'The input is not valid E-mail!',
                            },
                            {
                                required: true,
                                message: 'Please input your E-mail!',
                            },
                        ]}
                    >
                        <Input
                            disabled={accountType === 1 || accType === AccountType.IsInternal}
                            // placeholder={selectedNk}
                            value={selectedNk}
                        />
                    </Form.Item>
                }
                {!id && accountType === AccountType.IsExternal && (
                    <>
                        <Form.Item
                            label="Password"
                            hasFeedback
                            name="password"
                            rules={[
                                {
                                    required: true,
                                    whitespace: true,
                                    message: 'Password is required',
                                },
                                {
                                    validator: validateToNextPassword,
                                },
                            ]}
                        >
                            <Input.Password />
                        </Form.Item>
                        <Form.Item
                            label="Confirm password"
                            hasFeedback
                            name="confPassword"
                            rules={[
                                {
                                    required: true,
                                    whitespace: true,
                                    message: 'Confirm password is required',
                                },
                                {
                                    validator: compareToFirstPassword,
                                },
                            ]}
                        >
                            <Input.Password onBlur={handleConfirmBlur} />
                        </Form.Item>
                    </>
                )}

                <Form.Item label="Roles" name="roles">
                    <Checkbox.Group style={{ width: '100%' }} onChange={onChange}>
                        <Row>
                            <Col span={8}>
                                <Checkbox value="Admin">Admin</Checkbox>
                            </Col>
                            <Col span={8}>
                                <Checkbox value="Read">Read</Checkbox>
                            </Col>
                            <Col span={8}>
                                <Checkbox value="Write">Write</Checkbox>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={12}>
                                <Checkbox value="Supervisor">Supervisor</Checkbox>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={12}>
                                <Checkbox value="ChiefSupervisor">Shift-Supervisor</Checkbox>
                            </Col>
                        </Row>
                    </Checkbox.Group>
                </Form.Item>
            </Form>
            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button onClick={props.onSubmit} type="primary">
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const UserDrawer = UserDrawerInner;

export default UserDrawer;
