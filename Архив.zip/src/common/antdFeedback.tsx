import React, { useEffect } from 'react';
import { App } from 'antd';

type AppApi = ReturnType<typeof App.useApp>;

let appApi: AppApi | undefined;

function getAppApi(): AppApi {
    if (!appApi) throw new Error('Ant Design feedback API is not mounted');
    return appApi;
}

export const message = {
    success: (...args: any[]) => (getAppApi().message.success as any)(...args),
    error: (...args: any[]) => (getAppApi().message.error as any)(...args),
};

export const notification = {
    error: (...args: any[]) => (getAppApi().notification.error as any)(...args),
};

export function AntdFeedbackProvider({ children }: React.PropsWithChildren<{}>) {
    const api = App.useApp();
    appApi = api;

    useEffect(
        () => () => {
            if (appApi === api) appApi = undefined;
        },
        [api],
    );

    return <>{children}</>;
}
