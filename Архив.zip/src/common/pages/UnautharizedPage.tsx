import { Button, Result } from 'antd';
import React from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { ApplicationPaths } from '../components/api-authorization/ApiAuthorizationConstants';

type Props = {} & RouteComponentProps<any>;

const UnautharizedPage: React.FC<Props> = (props) => {
    const updateRoles = React.useCallback(() => {
        window.location.href = `${ApplicationPaths.Login}`;
    }, []);

    return (
        <Result
            status="403"
            title="403"
            subTitle="Sorry, you are not authorized to access this page."
            extra={
                <>
                    <Button type="primary" onClick={() => props.history.push('/')}>
                        Back Home
                    </Button>
                    <Button style={{ marginLeft: 5 }} type="primary" onClick={updateRoles}>
                        Update roles
                    </Button>
                </>
            }
        />
    );
};

export default UnautharizedPage;
