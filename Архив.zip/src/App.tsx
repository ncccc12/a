import './App.css';
import './common/axiosConfig';

import React from 'react';
import { Route, Switch, BrowserRouter } from 'react-router-dom';
import routes from './routes';
import PageTemplate from './pages/PageTemplate';
import { Provider } from 'react-redux';
import configureStore from './store/configureStore';
import AuthorizeRoute from './common/components/api-authorization/AuthorizeRoute';
import { ApplicationPaths } from './common/components/api-authorization/ApiAuthorizationConstants';
import ApiAuthorizationRoutes from './common/components/api-authorization/ApiAuthorizationRoutes';
import { App as AntdApp, ConfigProvider } from 'antd';
import en_US from 'antd/locale/en_US';
import { AntdFeedbackProvider } from './common/antdFeedback';

const baseUrl = document.getElementsByTagName('base')[0].getAttribute('href') as any;
const store = configureStore();

const App: React.FC = () => {
    return (
        <ConfigProvider locale={en_US}>
            <AntdApp>
                <AntdFeedbackProvider>
                    <BrowserRouter basename={baseUrl}>
                        <Provider store={store}>
                            <PageTemplate>
                                <Switch>
                                    {/* {routes.map((i, index) => (
                            <Route key={index} exact={i.exact} path={i.path} component={i.component} />
                        ))} */}
                                    {/* <Route component={NotFound} /> */}

                                    {routes.map((i: any) => (
                                        <AuthorizeRoute
                                            key={i.path}
                                            exact={i.exact}
                                            path={i.path}
                                            component={i.component}
                                        />
                                    ))}

                                    <Route
                                        path={ApplicationPaths.ApiAuthorizationPrefix}
                                        component={ApiAuthorizationRoutes}
                                    />
                                </Switch>
                            </PageTemplate>
                        </Provider>
                    </BrowserRouter>
                </AntdFeedbackProvider>
            </AntdApp>
        </ConfigProvider>
    );
};

export default App;
// export default process.env.NODE_ENV === 'development' ? hot(App) : App;
