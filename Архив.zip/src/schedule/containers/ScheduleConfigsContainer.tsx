import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Table, Button, Spin, Tag } from 'antd';
import { Link, RouteComponentProps, withRouter } from 'react-router-dom';
import { DictionaryDto, AreaVm, ScheduleConfigRowVm, GetScheduleConfigsQuery } from '../../services/Client';
import { dictionaryClient, schedulesClient } from '../../services';
import dayjs, { type Dayjs } from '@dayjs';
import SchedulesFilterForm, { ScheduleSearchForm } from '../components/SchedulesFilterForm';
import { AppState } from '../../store/reducers';
import {
    ScheduleManagerState,
    changeScheduleConfigFilterForm,
    resetScheduleConfigFilterForm,
    changeReportScheduleConfigFilterForm,
    resetReportScheduleConfigFilterForm,
} from '../ducks/ScheduleMangerDuck';
import { connect } from 'react-redux';
import type { FormInstance } from 'antd';

const { Column } = Table;
// export type ScheduleConfigSearchForm = {
//     locationCode: string;
//     areaCode: string;
//     datePeriod: Dayjs[];
//     isActive: number[];
// };

const mapStateToProps = (state: AppState): ScheduleManagerState => ({
    scheduleConfigFilterForm: state.ScheduleManagerDuck.scheduleConfigFilterForm,
    reportScheduleConfigFilterForm: state.ScheduleManagerDuck.reportScheduleConfigFilterForm,
});

const mapDispatchToProps = {
    changeScheduleConfigFilterForm,
    resetScheduleConfigFilterForm,
    changeReportScheduleConfigFilterForm,
    resetReportScheduleConfigFilterForm,
};

type Props = {
    isReportPage?: boolean;
} & RouteComponentProps<any> &
    typeof mapDispatchToProps &
    ReturnType<typeof mapStateToProps>;

const ScheduleConfigsContainerInner: React.FC<Props> = (props) => {
    const {
        isReportPage,
        resetReportScheduleConfigFilterForm,
        resetScheduleConfigFilterForm,
        history,
        scheduleConfigFilterForm,
        reportScheduleConfigFilterForm,
        changeReportScheduleConfigFilterForm,
        changeScheduleConfigFilterForm,
    } = props;

    const [loading, setLoading] = React.useState<boolean>(true);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [scheduleConfigs, setScheduleConfigs] = React.useState<ScheduleConfigRowVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const filterFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const search = React.useCallback(async () => {
        setLoading(true);
        const form = filterFormRef.current!.form as FormInstance;
        form.validateFields()
            .then(async (values: ScheduleSearchForm) => {
                let query = new GetScheduleConfigsQuery();
                query.locationCode = values.locationCode;
                query.areaCode = values.areaCode;
                query.datePeriod = values.datePeriod?.map((r) => r.utc(true).toDate());
                query.isActive = values.isActive;
                const data = await schedulesClient.getScheduleConfigs(query);
                setScheduleConfigs(data);
                setLoading(false);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, []);

    const initFilter = React.useCallback(
        (ref: any) => {
            if (ref) {
                filterFormRef.current = ref;
                search();
            }
        },
        [search],
    );

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        setLocations(locations);
        setAreas(areas);
    };

    const resetFilter = React.useCallback(() => {
        if (isReportPage) {
            resetReportScheduleConfigFilterForm();
        } else {
            resetScheduleConfigFilterForm();
        }

        search();
    }, [isReportPage, resetReportScheduleConfigFilterForm, resetScheduleConfigFilterForm, search]);

    const renderActions = (config: ScheduleConfigRowVm) => {
        return (
            <>
                {!isReportPage && (
                    <Button
                        style={{ marginLeft: 5 }}
                        icon={<EditOutlined />}
                        title="Edit"
                        onClick={() => history.push(`/scheduleManager/scheduleConfigs/${config.id}`)}
                    ></Button>
                )}

                {isReportPage && (
                    <Button
                        style={{ marginLeft: 5 }}
                        onClick={() => history.push(`/reports/schedule-configs/${config.id}`)}
                    >
                        {' '}
                        View report{' '}
                    </Button>
                )}
            </>
        );
    };

    const renderDatePeriod = React.useCallback((period: Date[]) => {
        let date1 = dayjs(period[0]).format('DD.MM.YYYY');
        let date2 = dayjs(period[1]).format('DD.MM.YYYY');

        return (
            <span>
                {date1} - {date2}
            </span>
        );
    }, []);

    const renderGroups = React.useCallback((groups: string[]): JSX.Element[] => {
        return groups.map((r) => {
            return (
                <Tag key={r} color="blue">
                    {r}
                </Tag>
            );
        });
    }, []);

    const renderSchedules = React.useCallback((schedules: string[]) => {
        return schedules.map((r) => {
            return (
                <Tag key={r} color="#108ee9">
                    {r}
                </Tag>
            );
        });
    }, []);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadDictionaries();
                search();
            }
        })();
    });

    let filterFrom = scheduleConfigFilterForm!;
    let changeFilterFormAction: any = changeScheduleConfigFilterForm;
    if (isReportPage) {
        filterFrom = reportScheduleConfigFilterForm!;
        changeFilterFormAction = changeReportScheduleConfigFilterForm;
    }

    return (
        <Spin spinning={loading}>
            <SchedulesFilterForm
                searchForm={filterFrom}
                areas={areas}
                locations={locations}
                ref={initFilter}
                onSearch={search}
                onReset={resetFilter}
                onChange={changeFilterFormAction}
            />

            <Table
                rowKey={(r: any) => r.id + ''}
                dataSource={scheduleConfigs}
                bordered
                title={() =>
                    !isReportPage && (
                        <Link to="/scheduleManager/scheduleConfigs/new">
                            <Button>Add new</Button>{' '}
                        </Link>
                    )
                }
            >
                <Column title="Location" dataIndex="locationName"></Column>
                <Column title="Area" dataIndex="areaName"></Column>

                <Column title="Name" align="center" dataIndex="name"></Column>
                <Column title="Year" align="center" dataIndex="year"></Column>
                <Column title="Rotation type" align="center" dataIndex="rotationType"></Column>
                <Column title="Date period" align="center" dataIndex="datePeriod" render={renderDatePeriod}></Column>
                <Column title="Groups" align="center" dataIndex="groups" render={renderGroups}></Column>
                <Column title="Schedules" dataIndex="schedules" render={renderSchedules}></Column>
                <Column
                    dataIndex="isActive"
                    title="Is Active"
                    render={(isActive) => (isActive ? 'Yes' : 'No')}
                ></Column>
                <Column title="Actions" align="center" render={(row) => renderActions(row)}></Column>
            </Table>
        </Spin>
    );
};

const ScheduleConfigsContainer = connect(mapStateToProps, mapDispatchToProps)(ScheduleConfigsContainerInner);

export default withRouter(ScheduleConfigsContainer);
