import { message } from '../../common/antdFeedback';
import React from 'react';
import { Spin, Row, Col, Button } from 'antd';
import ScheduleConfigForm, { ConfigFormModel } from '../components/ScheduleConfigForm';
import type { FormInstance } from 'antd';
import generateScheduleSrv from '../GenerateScheduleService';
import { groupsClient, schedulesClient } from '../../services';
import { GroupSimpleVm, AddScheduleConfigCommand, GroupConfigDto } from '../../services/Client';
import { ScheduleConfig } from '../types';
import CalendarTable from '../components/CalendarTable';
import { withRouter, RouteComponentProps } from 'react-router-dom';

type Props = {} & RouteComponentProps<any>;

const AddNewScheduleConfigContainer: React.FC<Props> = (props) => {
    const [loading, setLoading] = React.useState<boolean>(true);
    const [groups, setGroups] = React.useState<GroupSimpleVm[]>([]);
    const [formChanged, setFormChanged] = React.useState<boolean>(false);
    const [scheduleConfig, setScheduleConfig] = React.useState<ScheduleConfig | undefined>();
    const configFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const loadDictionaries = async () => {
        let groups = await groupsClient.getGroupsSimple();
        setGroups(groups);
    };

    const generateSchedule = React.useCallback(() => {
        const form = configFormRef.current!.form as FormInstance;

        form.validateFields()
            .then((values: ConfigFormModel) => {
                let config = generateScheduleSrv.mapFormToScheduleConfig(values, groups);
                generateScheduleSrv.generateSchedule(config);
                setScheduleConfig(config);
                setFormChanged(false);
            })
            .catch((err: any) => {
                setScheduleConfig(undefined);
            });
    }, [groups]);

    const saveSchedule = React.useCallback(async () => {
        generateSchedule();

        try {
            setLoading(true);
            let command = new AddScheduleConfigCommand();
            command.areaCode = scheduleConfig!.areaCode;
            command.configName = scheduleConfig!.scheduleConfigName;
            command.rotationTypeCode = scheduleConfig!.rotationType;
            command.year = scheduleConfig!.year;

            let group1 = new GroupConfigDto();
            group1.code = scheduleConfig!.group1!.code;
            group1.schedule = scheduleConfig!.group1!.schedule!.join('');

            let group2 = new GroupConfigDto();
            group2.code = scheduleConfig!.group2!.code;
            group2.schedule = scheduleConfig!.group2!.schedule!.join('');

            let group3 = new GroupConfigDto();
            group3.code = scheduleConfig!.group3!.code;
            group3.schedule = scheduleConfig!.group3!.schedule!.join('');

            let group4 = new GroupConfigDto();
            group4.code = scheduleConfig!.group4!.code;
            group4.schedule = scheduleConfig!.group4!.schedule!.join('');

            command.group1 = group1;
            command.group2 = group2;
            command.group3 = group3;
            command.group4 = group4;

            // command.dayShiftFirst1 = scheduleConfig!.dayShiftFirst1;
            // command.dayShiftFirst2 = scheduleConfig!.dayShiftFirst2;
            command.datePeriod = [
                scheduleConfig!.datePeriod![0].utc(true),
                scheduleConfig!.datePeriod![1].utc(true),
            ] as any;

            await schedulesClient.addScheduleConfig(command);
            props.history.push('/scheduleManager/scheduleConfigs');
            message.success('Operation successfully completed');
        } finally {
            setLoading(false);
        }
    }, [generateSchedule, scheduleConfig, props.history]);

    const resetSchedule = React.useCallback(() => {
        const form = configFormRef.current!.form as FormInstance;
        form.resetFields();
        setScheduleConfig(undefined);
    }, []);

    const handleLoadingChange = React.useCallback((loading: boolean) => {
        setLoading(loading);
    }, []);

    const handleFormChange = React.useCallback(() => {
        if (!formChanged) {
            setFormChanged(true);
        }
    }, [formChanged]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadDictionaries();
        }
    });

    return (
        <Spin spinning={loading}>
            <ScheduleConfigForm
                ref={(ref: { form: import('antd').FormInstance } | null) => (configFormRef.current = ref)}
                groups={groups}
                onFormChange={handleFormChange}
                onLoadingChange={handleLoadingChange}
            ></ScheduleConfigForm>
            <br />
            <Row>
                <Col span={12} style={{ textAlign: 'left' }}>
                    <Button type="primary" onClick={generateSchedule}>
                        Generate schedule
                    </Button>
                    <Button style={{ marginLeft: 8 }} onClick={resetSchedule}>
                        Reset
                    </Button>
                </Col>
                {scheduleConfig && formChanged === false && (
                    <Col span={12} style={{ textAlign: 'right' }}>
                        <Button
                            style={{ backgroundColor: '#52c41a', color: '#fff' }}
                            type="link"
                            onClick={saveSchedule}
                        >
                            Add new schedule
                        </Button>
                    </Col>
                )}
            </Row>
            <br />

            {scheduleConfig && <CalendarTable scheduleConfig={scheduleConfig} />}
        </Spin>
    );
};

export default withRouter(AddNewScheduleConfigContainer);
