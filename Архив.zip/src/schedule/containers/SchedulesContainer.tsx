import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Table, Button, Spin, Card, Typography } from 'antd';
import { schedulesClient, dictionaryClient } from '../../services';
import { ScheduleVm, DictionaryDto, AreaVm, LogsheetDictionaryVm, GetSchedulesQuery } from '../../services/Client';
import dayjs, { type Dayjs } from '@dayjs';
import { Link, RouteComponentProps, withRouter } from 'react-router-dom';
import SchedulesFilterForm, { ScheduleSearchForm } from '../components/SchedulesFilterForm';
import type { FormInstance } from 'antd';
import { AppState } from '../../store/reducers';
import { ScheduleManagerState, changeScheduleFilterForm, resetScheduleFilterForm } from '../ducks/ScheduleMangerDuck';
import { connect } from 'react-redux';

const { Column } = Table;

const mapStateToProps = (state: AppState): ScheduleManagerState => ({
    scheduleFilterForm: state.ScheduleManagerDuck.scheduleFilterForm,
});

const mapDispatchToProps = {
    changeFilterForm: changeScheduleFilterForm,
    resetFilterForm: resetScheduleFilterForm,
};

type Props = {} & RouteComponentProps<any> & typeof mapDispatchToProps & ScheduleManagerState;

const SchedulesContainerInner: React.FC<Props> = (props) => {
    const { resetFilterForm, scheduleFilterForm } = props;

    const [loading, setLoading] = React.useState<boolean>(true);
    const [schedules, setSchedules] = React.useState<ScheduleVm[]>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [logsheets, setLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const drawerCompRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const filterFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const search = React.useCallback(async () => {
        setLoading(true);
        const form = filterFormRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: ScheduleSearchForm) => {
                let query = new GetSchedulesQuery();
                query.areaCode = values.areaCode;
                query.locationCode = values.locationCode;
                query.datePeriod = values.datePeriod?.map((r) => r.utc(true).toDate()) || [];
                query.isActive = values.isActive;
                const data = await schedulesClient.getSchedules(query);
                setSchedules(data);
                setLoading(false);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, []);

    const initFilter = React.useCallback(
        (ref: any) => {
            if (ref) {
                filterFormRef.current = ref;
                search();
            }
        },
        [search],
    );

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        let logsheets = await dictionaryClient.getLogsheets();

        setLocations(locations);
        setAreas(areas);
        setLogsheets(logsheets);
    };

    const resetFilter = React.useCallback(() => {
        resetFilterForm();
        search();
    }, [resetFilterForm, search]);

    const renderActions = (r: ScheduleVm) => {
        return (
            <>
                <Button
                    style={{ marginLeft: 5 }}
                    icon={<EditOutlined />}
                    title="Edit"
                    onClick={() => props.history.push(`/scheduleManager/schedules/${r.id}`)}
                ></Button>
            </>
        );
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadDictionaries();
                search();
            }
        })();
    });

    return (
        <Card>
            <Typography.Title>Schedules</Typography.Title>
            <SchedulesFilterForm
                searchForm={scheduleFilterForm!}
                areas={areas}
                locations={locations}
                ref={initFilter}
                onSearch={search}
                onReset={resetFilter}
                onChange={props.changeFilterForm}
            />

            <Spin spinning={loading}>
                <Table
                    rowKey={(r: any) => r.id + ''}
                    dataSource={schedules}
                    bordered
                    title={() => (
                        <Link to="/scheduleManager/schedules/new">
                            <Button>Add new</Button>{' '}
                        </Link>
                    )}
                >
                    <Column title="Location" dataIndex="locationName"></Column>
                    <Column title="Area" dataIndex="areaName"></Column>
                    <Column title="Logsheet" dataIndex="logsheet"></Column>
                    <Column title="Name" align="center" dataIndex="name"></Column>
                    <Column title="Schedule config name" align="center" dataIndex="configName"></Column>
                    <Column
                        title="Start date"
                        align="center"
                        dataIndex="startDate"
                        render={(d) => dayjs(d).format('DD.MM.YYYY')}
                    ></Column>
                    <Column
                        title="End date"
                        align="center"
                        dataIndex="endDate"
                        render={(d) => dayjs(d).format('DD.MM.YYYY')}
                    ></Column>

                    <Column title="Schedule type" align="center" dataIndex="scheduleTypeName"></Column>

                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive) => (isActive ? 'Yes' : 'No')}
                    ></Table.Column>
                    <Column title="Actions" align="center" render={(r: ScheduleVm) => renderActions(r)}></Column>
                </Table>
            </Spin>
        </Card>
    );
};

const SchedulesContainer = connect(mapStateToProps, mapDispatchToProps)(SchedulesContainerInner);

export default withRouter(SchedulesContainer);
