import { message } from '../../common/antdFeedback';
import React from 'react';
import { ScheduleConfig } from '../types';
import dayjs, { type Dayjs } from '@dayjs';
import { Spin, Row, Col, Button } from 'antd';
import ScheduleForm, { ScheduleFormModel } from '../components/ScheduleForm';
import CalendarTable from '../components/CalendarTable';
import type { FormInstance } from 'antd';
import { schedulesClient } from '../../services';
import generateScheduleSrv from '../GenerateScheduleService';
import { ScheduleVm, UpdateScheduleCommand, TimeOptionDto } from '../../services/Client';
import { cloneDeep } from 'lodash';
import { RouteComponentProps, withRouter } from 'react-router-dom';

type Props = {
    id: number;
} & RouteComponentProps<any>;

const EditScheduleContainer: React.FC<Props> = (props) => {
    const { id } = props;

    const [loading, setLoading] = React.useState<boolean>(true);
    const [formChanged, setFormChanged] = React.useState<boolean>(false);
    const [scheduleConfig, setScheduleConfig] = React.useState<ScheduleConfig>();
    const formRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const srcFormModel = React.useRef<ScheduleFormModel | undefined>(undefined);

    const loadData = async () => {
        const form = formRef.current!.form as FormInstance;
        let schedule = await schedulesClient.getSchedule(id);

        let formModel = mapVmToScheduleForm(schedule);
        srcFormModel.current = cloneDeep(formModel);
        form.setFieldsValue(formModel);

        let config = await schedulesClient.getScheduleConfig(schedule.scheduleConfigId);
        let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

        setScheduleConfig(scheduleConfig);
    };

    const mapVmToScheduleForm = (vm: ScheduleVm): ScheduleFormModel => {
        let scheduleForm: ScheduleFormModel = {
            id: vm.id!,
            areaCode: vm.areaCode!,
            locationCode: vm.locationCode!,
            logsheetId: vm.logsheetId!,
            year: vm.year!,
            scheduleConfigId: vm.scheduleConfigId!,
            scheduleName: vm.name!,
            scheduleTypeCode: vm.scheduleTypeCode! as any,
            datePeriod: [dayjs(vm.startDate), dayjs(vm.endDate)],
            timeOptions: vm.timeOptions!.map((r) => {
                return {
                    id: r.id!,
                    time: dayjs(r.time, 'HH:mm'),
                };
            }),
            weekDayCodes: vm.weekDayCodes,
            selectedPeriods: vm.selectedPeriods?.map((r) => {
                let period = r.map((r) => dayjs(r));
                return period;
            }),
            date: dayjs(vm.date),
        };

        return scheduleForm;
    };

    const handleLoadingChange = React.useCallback(() => {
        setLoading(false);
    }, []);

    const viewSchedule = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: ScheduleFormModel) => {
                let config = await schedulesClient.getScheduleConfig(values.scheduleConfigId);
                let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);
                setScheduleConfig(scheduleConfig);
                setFormChanged(false);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, []);

    const handleFormChange = React.useCallback(() => {
        if (!formChanged) {
            setFormChanged(true);
        }
    }, [formChanged]);

    const resetDefaults = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;
        form.setFieldsValue(srcFormModel.current!);
    }, []);

    const updateSchedule = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: ScheduleFormModel) => {
                try {
                    setLoading(true);
                    let command = new UpdateScheduleCommand();
                    command.id = values.id;
                    command.date =
                        values.date &&
                        (values.date.utc(true).set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).toDate() as any);
                    command.name = values.scheduleName;
                    command.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                    command.scheduleConfigId = values.scheduleConfigId;
                    command.scheduleTypeCode = values.scheduleTypeCode;
                    command.timeOptions = values.timeOptions!.map((r) => {
                        let dto = new TimeOptionDto();
                        dto.id = r.id;
                        dto.time = r.time.format('HH:mm');
                        return dto;
                    });
                    command.weekDayCodes = values.weekDayCodes;
                    await schedulesClient.updateSchedule(command);
                    message.success('Operation successfully completed');
                    props.history.push('/scheduleManager/schedules');
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [props.history]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadData();
        }
    });

    const datePeriod = formRef.current && formRef.current!.form.getFieldValue('datePeriod');

    return (
        <Spin spinning={loading}>
            <ScheduleForm
                isEdit={true}
                srcFormModel={srcFormModel.current}
                onFormChange={handleFormChange}
                ref={(ref: { form: import('antd').FormInstance } | null) => (formRef.current = ref)}
                onLoadingChange={handleLoadingChange}
            />

            <br />
            <Row>
                <Col span={12} style={{ textAlign: 'left' }}>
                    <Button type="primary" onClick={viewSchedule}>
                        View Schedule
                    </Button>
                    <Button style={{ marginLeft: 8 }} onClick={resetDefaults}>
                        Reset
                    </Button>
                </Col>

                {scheduleConfig && formChanged === false && (
                    <Col span={12} style={{ textAlign: 'right' }}>
                        <Button
                            type="link"
                            style={{ backgroundColor: '#52c41a', color: '#fff' }}
                            onClick={updateSchedule}
                        >
                            Update schedule
                        </Button>
                    </Col>
                )}
            </Row>
            <br />
            {scheduleConfig && (
                <CalendarTable scheduleConfig={scheduleConfig} datePeriod={datePeriod} readonly={true} />
            )}
        </Spin>
    );
};

export default withRouter(EditScheduleContainer);
