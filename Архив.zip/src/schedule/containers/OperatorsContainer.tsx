import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Spin, Row, Select, Table, Form, Button, Divider } from 'antd';
import { dictionaryClient, employeesClient, groupsClient } from '../../services/index';
import {
    DictionaryDto,
    AreaVm,
    EmployeeVm,
    AddNewEmployeeCommand,
    UpdateEmployeeCommand,
    GetEmployeesQuery,
    GroupVm,
    GetGroupsQuery,
} from '../../services/Client';
import OperatorDrawer, { OperatorForm } from '../components/OperatorDrawer';
import type { FormInstance } from 'antd';
import { Space } from 'antd';

type SearchForm = {
    locationCode: string;
    areaCode: string;
    groupCode: string;
    isActive: number[];
};

type Props = {};

const OperatorsContainerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const [loading, setLoading] = React.useState<boolean>(false);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [groups, setGroups] = React.useState<GroupVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredGroups, setFilteredGroups] = React.useState<GroupVm[]>([]);
    const [employees, setEmployees] = React.useState<EmployeeVm[]>([]);
    const [isOperatorDrawerShown, setIsOperatorDrawerShown] = React.useState<boolean>(false);
    const operatorFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const loadData = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        let groupsQuery = new GetGroupsQuery();
        groupsQuery.isActive = [1];
        let groups = await groupsClient.getGroups(groupsQuery);

        setLocations(locations);
        setAreas(areas);
        setGroups(groups);
    };

    const handleLocationChange = React.useCallback(
        (value: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === value);
            setFilteredAreas(filteredAreas);

            props.form.setFieldsValue({
                areaCode: '',
            });
        },
        [areas, props.form],
    );

    const handleAreaChange = React.useCallback(
        (value: string) => {
            const filteredGroups = groups.filter((r) => r.areaCode === value);

            setFilteredGroups(filteredGroups);
            props.form.setFieldsValue({
                groupCode: '',
            });
        },
        [groups, props.form],
    );

    const search = React.useCallback(() => {
        props.form
            .validateFields()
            .then(async (values: SearchForm) => {
                setLoading(true);
                try {
                    var query = new GetEmployeesQuery();
                    query.init(values);
                    let employees = await employeesClient.getEmployees(query);
                    setEmployees(employees);
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [props.form]);

    const resetFilter = React.useCallback(() => {
        props.form.resetFields();
        search();
    }, [search, props.form]);

    const submitForm = React.useCallback(() => {
        const form = operatorFormRef.current!.form as FormInstance;
        form.validateFields()
            .then(async (values: OperatorForm) => {
                try {
                    setLoading(true);
                    if (values.id) {
                        let updateCommand = new UpdateEmployeeCommand();
                        updateCommand.init(values);
                        await employeesClient.updateEmployee(updateCommand);
                    } else {
                        // add new
                        let command = new AddNewEmployeeCommand();
                        command.init(values);
                        await employeesClient.addNewEmployee(command);
                    }
                    message.success('Successful');
                    setIsOperatorDrawerShown(false);
                    search();
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [search]);

    const openDrawer = (r: EmployeeVm | undefined) => {
        const form = operatorFormRef.current!.form as FormInstance;
        setIsOperatorDrawerShown(true);
        if (r) {
            const operatorForm: OperatorForm = {
                id: r.id!,
                areaCode: r.areaCode!,
                groupCode: r.groupCode!,
                firstName: r.firstName!,
                lastName: r.lastName!,
                position: r.position!,
                locationCode: r.locationCode!,
                isActive: r.isActive!,
            };
            form.setFieldsValue(operatorForm);
        } else {
            form.resetFields();
            form.setFieldsValue({ isActive: true });
        }
    };

    const renderActions = (r: EmployeeVm) => {
        return <Button icon={<EditOutlined />} shape="circle" title="edit" onClick={() => openDrawer(r)} />;
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadData();
                search();
            }
        })();
    });

    const {
        form: {},
    } = props;

    const selectStyle = {
        width: 150,
    };

    return (
        <Spin spinning={loading}>
            <Row>
                <Form form={props.form} labelAlign="left" layout="inline">
                    <Form.Item label="Location" name="locationCode">
                        <Select style={selectStyle} onChange={handleLocationChange}>
                            {locations.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Area" name="areaCode">
                        <Select style={selectStyle} onChange={handleAreaChange}>
                            {filteredAreas.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Group" name="groupCode">
                        <Select style={selectStyle}>
                            {filteredGroups.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Is active" name="isActive" initialValue={[1]}>
                        <Select style={selectStyle} mode="multiple">
                            <Select.Option key="y" value={1}>
                                Yes
                            </Select.Option>
                            <Select.Option key="n" value={0}>
                                No
                            </Select.Option>
                        </Select>
                    </Form.Item>

                    <Form.Item>
                        <Space.Compact>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </Space.Compact>
                    </Form.Item>
                </Form>
            </Row>
            <Divider />
            <Row>
                <Table
                    dataSource={employees}
                    title={() => <Button onClick={() => openDrawer(undefined)}>Add new</Button>}
                    rowKey={(r) => r.id + ''}
                    bordered
                >
                    <Table.Column dataIndex="location" title="Location"></Table.Column>
                    <Table.Column dataIndex="area" title="Area"></Table.Column>
                    <Table.Column dataIndex="groupName" title="Group Name"></Table.Column>
                    <Table.Column dataIndex="lastName" title="Last Name"></Table.Column>
                    <Table.Column dataIndex="firstName" title="First Name"></Table.Column>
                    <Table.Column dataIndex="position" title="Position"></Table.Column>
                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                    ></Table.Column>
                    <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
                </Table>
            </Row>

            <OperatorDrawer
                visible={isOperatorDrawerShown}
                ref={(compRef: any) => (operatorFormRef.current = compRef)}
                locations={locations}
                areas={areas}
                groups={groups}
                onSubmit={submitForm}
                onClose={() => setIsOperatorDrawerShown(false)}
            />
        </Spin>
    );
});

const OperatorsContainer = OperatorsContainerInner;

export default OperatorsContainer;
