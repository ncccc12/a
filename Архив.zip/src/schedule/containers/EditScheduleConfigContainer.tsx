import { message } from '../../common/antdFeedback';
import React from 'react';
import { Spin, Row, Col, Button } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import { cloneDeep } from 'lodash';
import ScheduleConfigForm, { ConfigFormModel } from '../components/ScheduleConfigForm';
import type { FormInstance } from 'antd';
import generateScheduleSrv from '../GenerateScheduleService';

import { groupsClient, schedulesClient } from '../../services';
import { GroupSimpleVm, GroupConfigDto, UpdateScheduleConfigCommand } from '../../services/Client';

import { ScheduleConfig } from '../types';
import CalendarTable from '../components/CalendarTable';
import '../ScheduleForm.css';
import { withRouter, RouteComponentProps } from 'react-router-dom';

type Props = {
    id: number;
} & RouteComponentProps<any>;

const EditScheduleConfigContainer: React.FC<Props> = (props) => {
    const [loading, setLoading] = React.useState<boolean>(true);
    const [groups, setGroups] = React.useState<GroupSimpleVm[]>([]);
    const [formChanged, setFormChanged] = React.useState<boolean>(false);
    const [scheduleConfig, setScheduleConfig] = React.useState<ScheduleConfig>();
    const configFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const months = React.useRef<Dayjs[]>([]);
    const srcConfig = React.useRef<ScheduleConfig | undefined>(undefined);

    const setForm = React.useCallback(
        (config: ScheduleConfig | undefined = scheduleConfig) => {
            const form = configFormRef.current!.form as FormInstance;

            let formModel: ConfigFormModel = {
                areaCode: config!.areaCode,
                locationCode: config!.locationCode,
                rotationType: config!.rotationType,
                scheduleConfigName: config!.scheduleConfigName,
                year: config!.year,
                datePeriod: config!.datePeriod,
                // group1DayShift: config!.dayShiftFirst1 === 1,
                // group2DayShift: config!.dayShiftFirst1 === 2,
                // group3DayShift: config!.dayShiftFirst2 === 3,
                // group4DayShift: config!.dayShiftFirst2 === 4,
                group1: config!.group1!.code,
                group2: config!.group2!.code,
                group3: config!.group3!.code,
                group4: config!.group4!.code,
            };

            form.setFieldsValue(formModel);
        },
        [scheduleConfig],
    );

    const updateSchedule = React.useCallback(async () => {
        try {
            setLoading(true);
            let command = new UpdateScheduleConfigCommand();
            command.id = props.id;
            command.configName = scheduleConfig!.scheduleConfigName;
            command.rotationTypeCode = scheduleConfig!.rotationType;

            let group1 = new GroupConfigDto();
            group1.code = scheduleConfig!.group1!.code;
            group1.schedule = scheduleConfig!.group1!.schedule!.join('');

            let group2 = new GroupConfigDto();
            group2.code = scheduleConfig!.group2!.code;
            group2.schedule = scheduleConfig!.group2!.schedule!.join('');

            let group3 = new GroupConfigDto();
            group3.code = scheduleConfig!.group3!.code;
            group3.schedule = scheduleConfig!.group3!.schedule!.join('');

            let group4 = new GroupConfigDto();
            group4.code = scheduleConfig!.group4!.code;
            group4.schedule = scheduleConfig!.group4!.schedule!.join('');

            command.group1 = group1;
            command.group2 = group2;
            command.group3 = group3;
            command.group4 = group4;

            // command.dayShiftFirst1 = scheduleConfig!.dayShiftFirst1;
            // command.dayShiftFirst2 = scheduleConfig!.dayShiftFirst2;
            command.datePeriod = [
                scheduleConfig!.datePeriod![0].utc(true),
                scheduleConfig!.datePeriod![1].utc(true),
            ] as any;

            await schedulesClient.updateScheduleConfig(command);
            props.history.push('/scheduleManager/scheduleConfigs');
            message.success('Operation successfully completed');
        } finally {
            setLoading(false);
        }
    }, [scheduleConfig, props.history, props.id]);

    const generateSchedule = React.useCallback(() => {
        const form = configFormRef.current!.form as FormInstance;

        form.validateFields()
            .then((values: ConfigFormModel) => {
                let config = generateScheduleSrv.mapFormToScheduleConfig(values, groups);
                let copyConfig = cloneDeep(srcConfig.current);
                config.group1!.schedule = copyConfig!.group1!.schedule;
                config.group2!.schedule = copyConfig!.group2!.schedule;
                config.group3!.schedule = copyConfig!.group3!.schedule;
                config.group4!.schedule = copyConfig!.group4!.schedule;
                generateScheduleSrv.generateSchedule(config, true);
                setScheduleConfig(config);
                setFormChanged(false);
            })
            .catch((err: any) => {
                setScheduleConfig(undefined);
            });
    }, [groups]);

    const resetSchedule = React.useCallback(() => {
        const config = srcConfig.current;
        setScheduleConfig(config);
        setForm(config);
    }, [setForm]);

    const handleLoadingChange = React.useCallback((loading: boolean) => {
        setLoading(loading);
    }, []);

    const handleFormChange = React.useCallback(() => {
        if (!formChanged) {
            setFormChanged(true);
        }
    }, [formChanged]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                let groups = await groupsClient.getGroupsSimple();
                let configVm = await schedulesClient.getScheduleConfig(props.id);
                let config = generateScheduleSrv.mapVmToScheduleConfig(configVm);
                srcConfig.current = cloneDeep(config);

                months.current = [];
                for (let i = 0; i < 12; i++) {
                    const currMonth = dayjs([config.year!, i, 1]);
                    months.current.push(currMonth);
                }

                setGroups(groups);
                setScheduleConfig(config);
                setForm(config);
            }
        })();
    });

    return (
        <Spin spinning={loading}>
            <ScheduleConfigForm
                ref={(ref: { form: import('antd').FormInstance } | null) => (configFormRef.current = ref)}
                isEdit={true}
                groups={groups}
                onFormChange={handleFormChange}
                onLoadingChange={handleLoadingChange}
            ></ScheduleConfigForm>
            <br />
            <Row>
                <Col span={12} style={{ textAlign: 'left' }}>
                    <Button type="primary" onClick={generateSchedule}>
                        Generate schedule
                    </Button>
                    <Button style={{ marginLeft: 8 }} onClick={resetSchedule}>
                        Reset
                    </Button>
                </Col>
                {scheduleConfig && formChanged === false && (
                    <Col span={12} style={{ textAlign: 'right' }}>
                        <Button
                            style={{ backgroundColor: '#52c41a', color: '#fff' }}
                            type="link"
                            onClick={updateSchedule}
                        >
                            Update schedule
                        </Button>
                    </Col>
                )}
            </Row>
            <br />

            {scheduleConfig && <CalendarTable scheduleConfig={scheduleConfig} isEdit={true} />}
        </Spin>
    );
};

export default withRouter(EditScheduleConfigContainer);
