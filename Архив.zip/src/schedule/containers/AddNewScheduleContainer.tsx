import { message } from '../../common/antdFeedback';
import React from 'react';
import { Spin, Row, Col, Button } from 'antd';
import '../ScheduleForm.css';
import ScheduleForm, { ScheduleFormModel } from '../components/ScheduleForm';
import type { FormInstance } from 'antd';
import { schedulesClient } from '../../services';
import CalendarTable from '../components/CalendarTable';
import { ScheduleConfig } from '../types';
import generateScheduleSrv from '../GenerateScheduleService';
import { AddScheduleCommand, TimeOptionDto } from '../../services/Client';
import { cloneDeep } from 'lodash';
import { withRouter, RouteComponentProps } from 'react-router-dom';

type Props = {} & RouteComponentProps<any>;

const AddNewScheduleContainer: React.FC<Props> = (props) => {
    const [loading, setLoading] = React.useState<boolean>(true);
    const [formChanged, setFormChanged] = React.useState<boolean>(false);
    const [scheduleConfig, setScheduleConfig] = React.useState<ScheduleConfig>();
    const years = React.useRef<number[]>([]);
    const formRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const handleLoadingChange = React.useCallback(() => {
        setLoading(false);
    }, []);

    const viewSchedule = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: ScheduleFormModel) => {
                let config = await schedulesClient.getScheduleConfig(values.scheduleConfigId);
                let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);
                setScheduleConfig(scheduleConfig);
                setFormChanged(false);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, []);

    const reset = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;

        form.resetFields();
        setScheduleConfig(undefined);
    }, []);

    const addNewSchedule = React.useCallback(() => {
        const form = formRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: ScheduleFormModel) => {
                try {
                    setLoading(true);
                    let cloneDatePeriod = cloneDeep(values.datePeriod);
                    let command = new AddScheduleCommand();
                    command.year = values.year;
                    command.date =
                        values.date &&
                        (values.date.utc(true).set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).toDate() as any);
                    command.name = values.scheduleName;
                    command.datePeriod = cloneDatePeriod.map((r) => r.utc(true) as any); // date
                    command.logsheetId = values.logsheetId;
                    command.scheduleConfigId = values.scheduleConfigId;
                    command.scheduleTypeCode = values.scheduleTypeCode;
                    command.selectedPeriods = values.selectedPeriods?.map((r) => {
                        let period = r.map((r) => r.utc(true).toDate());
                        return period;
                    });
                    command.timeOptions = values.timeOptions
                        .filter((r) => r)
                        .map((r) => {
                            let opt = new TimeOptionDto();
                            opt.id = r.id;
                            opt.time = r.time.format('HH:mm');
                            return opt;
                        });
                    command.weekDayCodes = values.weekDayCodes;
                    await schedulesClient.addSchedule(command);
                    message.success('Operation successfully completed');
                    props.history.push('/scheduleManager/schedules');
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [props.history]);

    const handleFormChange = React.useCallback(() => {
        if (!formChanged) {
            setFormChanged(true);
        }
    }, [formChanged]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
        }
    });

    const datePeriod = formRef.current && formRef.current!.form.getFieldValue('datePeriod');

    return (
        <Spin spinning={loading}>
            <ScheduleForm
                onFormChange={handleFormChange}
                ref={(ref: { form: import('antd').FormInstance } | null) => (formRef.current = ref)}
                onLoadingChange={handleLoadingChange}
            />

            <br />
            <Row>
                <Col span={12} style={{ textAlign: 'left' }}>
                    <Button type="primary" onClick={viewSchedule}>
                        View Schedule
                    </Button>
                    <Button style={{ marginLeft: 8 }} onClick={reset}>
                        Reset
                    </Button>
                </Col>
                {scheduleConfig && formChanged === false && (
                    <Col span={12} style={{ textAlign: 'right' }}>
                        <Button
                            type="link"
                            style={{ backgroundColor: '#52c41a', color: '#fff' }}
                            onClick={addNewSchedule}
                        >
                            Add new schedule
                        </Button>
                    </Col>
                )}
            </Row>
            <br />
            {scheduleConfig && (
                <CalendarTable scheduleConfig={scheduleConfig} datePeriod={datePeriod} readonly={true} />
            )}
        </Spin>
    );
};

export default withRouter(AddNewScheduleContainer);
