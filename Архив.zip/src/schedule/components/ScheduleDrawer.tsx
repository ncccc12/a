import React from 'react';
import { Form, Drawer, Select } from 'antd';
import { DictionaryDto, AreaVm, LogsheetDictionaryVm } from '../../services/Client';

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logsheets: LogsheetDictionaryVm[];
    onSubmit: () => void;
    onClose: () => void;
};

const ScheduleDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form, areas, logsheets } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredLogsheets, setFilteredLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const previousProps = React.useRef(props);

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (locationCode: string) => {
            filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
                logsheetId: undefined,
            });
        },
        [filterAreas, form],
    );

    const filterLogsheets = React.useCallback(
        (areaCode: string) => {
            const filteredLogsheets = logsheets.filter((r) => r.areaCode === areaCode);
            setFilteredLogsheets(filteredLogsheets);
        },
        [logsheets],
    );

    const handlerAreaChange = React.useCallback(
        (areaCode: string) => {
            filterLogsheets(areaCode);
            form.setFieldsValue({
                logsheetId: undefined,
            });
        },
        [filterLogsheets, form],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            const prevProps = previousProps.current;
            if (prevProps.visible === false && props.visible) {
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    filterAreas(locationCode);
                }, 1000);
            }
            previousProps.current = props;
        }
    });

    const {
        visible: visible,
        form: {},

        locations: locations,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 7,
        },
        wrapperCol: {
            span: 17,
        },
    };

    return (
        <Drawer open={visible} title="Add new" width={700} destroyOnHidden onClose={props.onClose}>
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item
                    label="Location"
                    name="locationCode"
                    rules={[
                        {
                            required: true,
                            message: 'Location is required',
                        },
                    ]}
                >
                    <Select onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Area"
                    name="areaCode"
                    rules={[
                        {
                            required: true,
                            message: 'Area is required',
                        },
                    ]}
                >
                    <Select onChange={handlerAreaChange}>
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Logsheet"
                    name="logsheetId"
                    rules={[
                        {
                            required: true,
                            message: 'Logsheet is required',
                        },
                    ]}
                >
                    <Select>
                        {filteredLogsheets.map((r) => (
                            <Select.Option key={r.id} value={r.id} title={r.name}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
            </Form>
        </Drawer>
    );
});

const ScheduleDrawer = ScheduleDrawerInner;

export default ScheduleDrawer;
