import React, { Fragment } from 'react';
import { Row } from 'antd';
import { ScheduleConfig, GroupConfig } from '../types';
import dayjs, { type Dayjs } from '@dayjs';
import generateScheduleSrv from '../GenerateScheduleService';
import { RotationCalendarType } from '../constants';
import './CalendarTable.css';
import { EditSelectedDatesModal } from '../modals/EditSelectedDatesModal';
import type { FormInstance } from 'antd';

type Props = {
    scheduleConfig: ScheduleConfig;

    /** When editing schedule config disable edit past days */
    isEdit?: boolean;

    /**Disable mouse events(editing calendar) */
    readonly?: boolean;

    /** required when using in schedule container, to view only */
    datePeriod?: Dayjs[];
};

const CalendarTable: React.FC<Props> = (props) => {
    const { scheduleConfig } = props;

    const [isSelecting, setIsSelecting] = React.useState<boolean>(false);
    const [modalShown, setModalShown] = React.useState<boolean>(false);
    const [startDate, setStartDate] = React.useState<Dayjs>();
    const [endDate, setEndDate] = React.useState<Dayjs>();
    const selectedClass = React.useRef('selected');
    const months = React.useRef<Dayjs[]>([]);
    const currentRow = React.useRef<HTMLElement | null>(null);
    const editDatesModalRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const selectedGroup = React.useRef<GroupConfig>(undefined);

    const handleMouseDown = (e: React.MouseEvent, date: Dayjs, group: GroupConfig) => {
        setIsSelecting(true);
        setStartDate(date);
        setEndDate(date);

        (e.currentTarget as HTMLElement).classList.add(selectedClass.current);
        currentRow.current = (e.currentTarget as HTMLElement).parentElement;
        selectedGroup.current = group;
    };

    const handleMouseEnter = (e: React.MouseEvent, date: Dayjs) => {
        if (isSelecting) {
            const row: HTMLElement = (e.currentTarget as HTMLElement).parentElement!;
            const target = e.currentTarget as HTMLElement;

            // if cell isn't visited yet
            if (currentRow.current === row && !target.classList.contains(selectedClass.current)) {
                target.classList.add(selectedClass.current);
                setEndDate(date);
            } else {
                // cell is visited or another row
                showModal();
                clearSelected(target.parentElement!.parentElement!);
            }
        }
    };

    const handleMouseUp = (e: React.MouseEvent, date: Dayjs) => {
        if (isSelecting) {
            setIsSelecting(false);
            setEndDate(date);

            showModal();
            const tbody: HTMLElement = (e.currentTarget as HTMLElement).parentElement!.parentElement!;
            clearSelected(tbody);
        }
    };

    function showModal(): void {
        if (startDate! > endDate!) {
            setStartDate(endDate);
            setEndDate(startDate);
        }
        setIsSelecting(false);
        setModalShown(true);
    }

    function clearSelected(tbody: HTMLElement): void {
        const elements: HTMLCollectionOf<Element> = tbody.getElementsByClassName(selectedClass.current);

        for (const element of Array.from(elements)) {
            element.classList.remove(selectedClass.current);
        }
    }

    const handleModalOk = React.useCallback(() => {
        const form = editDatesModalRef.current!.form as FormInstance;
        form.validateFields()
            .then((values: { shiftType: RotationCalendarType }) => {
                const { shiftType } = values;
                const startIdx = startDate!.dayOfYear() - 1;
                const endIdx = endDate!.dayOfYear() - 1;
                for (let i = startIdx; i <= endIdx; i++) {
                    selectedGroup.current!.schedule![i] = shiftType!;
                }
                setModalShown(false);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [endDate, startDate]);

    function getGroupItemRow(group: GroupConfig, month: Dayjs, color: string): JSX.Element[] {
        let today = dayjs();

        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            const monthDate: Dayjs = dayjs([month.year(), month.month(), day]);
            const monthDayOfYear: number = monthDate.dayOfYear();

            let datePeriod: Dayjs[] | undefined = scheduleConfig!.datePeriod;
            if (props.datePeriod) {
                datePeriod = props.datePeriod;
            }

            const isEditable: boolean | undefined =
                group.schedule![monthDayOfYear - 1] !== RotationCalendarType.None &&
                group &&
                datePeriod &&
                datePeriod![0] &&
                datePeriod![1] &&
                monthDate.isBetween(datePeriod![0], datePeriod![1], 'day', '[]');

            let isInactive: boolean = !!props.isEdit && today.startOf('day') > monthDate.startOf('day');

            let dayType: string = '';
            switch (group.schedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let className = isInactive ? 'editable inactive ' : 'editable ';
            className = dayType ? className + color : className;

            if (!isEditable) className = 'disabled';

            let mouseListeners: any = {
                onMouseDown: (e: any) => handleMouseDown(e, monthDate, group),
                onMouseEnter: (e: any) => handleMouseEnter(e, monthDate),
                onMouseUp: (e: any) => handleMouseUp(e, monthDate),
            };

            if (isEditable === false || isInactive || props.readonly) {
                mouseListeners = {};
            }

            return (
                <td key={monthDayOfYear + ' ' + group.code} className={className} {...mouseListeners}>
                    {dayType}
                </td>
            );
        });
    }

    function getGroupRows(month: Dayjs): JSX.Element {
        return (
            <Fragment key={month.month() + '_'}>
                <tr>
                    <td rowSpan={2}>Group 1/2</td>
                    <td>{scheduleConfig!.group1!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group1!, month, 'gold')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group2!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group2!, month, 'blue')}
                </tr>
                <tr>
                    <td rowSpan={2}>Group 3/4</td>
                    <td>{scheduleConfig!.group3!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group3!, month, 'red')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group4!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group4!, month, 'green')}
                </tr>
            </Fragment>
        );
    }

    function getMonthHeaderTHs(date: Dayjs): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(date).map((day: number) => <th key={day}>{day}</th>);
    }

    function getMonthRows(): JSX.Element[] {
        months.current = [];

        for (let i = 0; i < 12; i++) {
            const currMonth = dayjs([scheduleConfig.year!, i, 1]);
            months.current.push(currMonth);
        }

        const rows: JSX.Element[] = [];

        months.current.forEach((month: Dayjs) => {
            const monthRow: JSX.Element = (
                <tr key={month.month()} style={{ height: 40 }}>
                    <th rowSpan={2 * 2 + 1}>{month.month() + 1}</th>
                    <th colSpan={2}>{dayjs.months()[month.month()]}</th>
                    {getMonthHeaderTHs(month)}
                </tr>
            );

            const groupRows: JSX.Element = getGroupRows(month);

            rows.push(monthRow);
            rows.push(groupRows);
        });

        return rows;
    }

    return (
        <Row className="schedule-config">
            <table>
                <tbody>{scheduleConfig && getMonthRows()}</tbody>
            </table>

            <EditSelectedDatesModal
                ref={(ref: { form: import('antd').FormInstance } | null) => {
                    editDatesModalRef.current = ref;
                }}
                visible={modalShown}
                startDate={startDate!}
                endDate={endDate!}
                onOk={handleModalOk}
                onCancel={() => setModalShown(false)}
            />
        </Row>
    );
};

export default CalendarTable;
