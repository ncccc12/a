import React from 'react';
import { Button, Select, DatePicker, Form } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import { AreaVm, DictionaryDto } from '../../services/Client';
import { Space } from 'antd';

export type ScheduleSearchForm = {
    locationCode: string;
    areaCode: string;
    datePeriod: Dayjs[];
    isActive: number[];
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    searchForm: ScheduleSearchForm;
    onSearch: () => void;
    onReset: () => void;
    onChange: (values: ScheduleSearchForm) => void;
};

const SchedulesFilterFormInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { areas, form, locations } = props;

        const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
        const previousProps = React.useRef(props);

        const filterAreas = React.useCallback(
            (value: string) => {
                const filteredAreas = areas.filter((r) => r.locationCode === value);
                setFilteredAreas(filteredAreas);
            },
            [areas],
        );

        const handleLocationChange = React.useCallback(
            (value: string) => {
                filterAreas(value);
                props.form.setFieldsValue({
                    areaCode: '',
                });
            },
            [filterAreas, props.form],
        );

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
            } else {
                const prevProps = previousProps.current;

                if (prevProps.searchForm !== props.searchForm) {
                    props.form.setFieldsValue(props.searchForm);
                }

                if (!prevProps.areas.length && areas.length) {
                    const {
                        searchForm: { locationCode },
                    } = props;

                    if (locationCode) {
                        filterAreas(locationCode);
                    }
                }
                previousProps.current = props;
            }
        });

        const selectStyle = {
            width: 150,
        };

        return (
            <Form
                form={form}
                initialValues={props.searchForm}
                labelAlign="left"
                layout="inline"
                onValuesChange={(_, values) => props.onChange(values as ScheduleSearchForm)}
            >
                <Form.Item label="Location" name="locationCode">
                    <Select style={selectStyle} onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>

                <Form.Item label="Area" name="areaCode">
                    <Select style={selectStyle}>
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>

                <Form.Item label="Date period" name="datePeriod">
                    <DatePicker.RangePicker
                        format="DD-MM-YYYY"
                        presets={[
                            {
                                label: 'This Month',
                                value: [dayjs().startOf('month'), dayjs().endOf('month')],
                            },
                            {
                                label: 'This year',
                                value: [dayjs().startOf('year'), dayjs().endOf('year')],
                            },
                        ]}
                    />
                </Form.Item>

                <Form.Item label="Is active" name="isActive" initialValue={[1]}>
                    <Select style={selectStyle} mode="multiple">
                        <Select.Option key="y" value={1}>
                            Yes
                        </Select.Option>
                        <Select.Option key="n" value={0}>
                            No
                        </Select.Option>
                    </Select>
                </Form.Item>

                <Form.Item>
                    <Space.Compact>
                        <Button type="primary" onClick={props.onSearch}>
                            Search
                        </Button>
                        <Button onClick={props.onReset}>Reset</Button>
                    </Space.Compact>
                </Form.Item>
            </Form>
        );
    },
);

const SchedulesFilterForm = SchedulesFilterFormInner;

export default SchedulesFilterForm;
