import React from 'react';
import { Form, Drawer, Select, Input, Button, Switch } from 'antd';
import { AreaVm, DictionaryDto, GroupVm } from '../../services/Client';

export type OperatorForm = {
    id: number;
    locationCode: string;
    areaCode: string;
    lastName: string;
    firstName: string;
    position: string;
    groupCode: string;
    isActive: boolean;
};

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    groups: GroupVm[];
    onSubmit: () => void;
    onClose: () => void;
};

const OperatorDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form: form0, areas, groups } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredGroups, setFilteredGroups] = React.useState<GroupVm[]>([]);
    const previousProps = React.useRef(props);

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (locationCode: string) => {
            filterAreas(locationCode);
            form0.setFieldsValue({
                areaCode: '',
            });
        },
        [filterAreas, form0],
    );

    const filterGroups = React.useCallback(
        (areaCode: string) => {
            const filteredGroups = groups.filter((r) => r.areaCode === areaCode);
            setFilteredGroups(filteredGroups);
        },
        [groups],
    );

    const handleAreaChange = React.useCallback(
        (areaCode: string) => {
            filterGroups(areaCode);
            props.form.setFieldsValue({
                groupCode: '',
            });
        },
        [filterGroups, props.form],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            const prevProps = previousProps.current;
            if (prevProps.visible === false && props.visible) {
                setTimeout(() => {
                    const locationCode = form0.getFieldValue('locationCode');
                    filterAreas(locationCode);

                    const areacCode = form0.getFieldValue('areaCode');
                    filterGroups(areacCode);
                }, 1000);
            }
            previousProps.current = props;
        }
    });

    const {
        visible: visible,
        form: form,
        locations: locations,
        form: {},
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');

    return (
        <Drawer
            title={id ? 'Edit operator' : 'Add new operator'}
            open={visible}
            width={500}
            destroyOnHidden={true}
            onClose={props.onClose}
        >
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item
                    label="Location"
                    name="locationCode"
                    rules={[
                        {
                            required: true,
                            message: 'Location is required',
                        },
                    ]}
                >
                    <Select onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Area"
                    name="areaCode"
                    rules={[
                        {
                            required: true,
                            message: 'Area is required',
                        },
                    ]}
                >
                    <Select onChange={handleAreaChange}>
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Group"
                    name="groupCode"
                    rules={[
                        {
                            required: true,
                            message: 'Group is required',
                        },
                    ]}
                >
                    <Select>
                        {filteredGroups.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item
                    label="Last name"
                    name="lastName"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Last name is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    label="First name"
                    name="firstName"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'First name is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    label="Position"
                    name="position"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Position is required',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item label="Is active" name="isActive" valuePropName="checked">
                    <Switch disabled={!id} />
                </Form.Item>
            </Form>
            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button onClick={props.onSubmit} type="primary">
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const OperatorDrawer = OperatorDrawerInner;

export default OperatorDrawer;
