import React from 'react';
import { Form, Select, Input, Row, Col, DatePicker, Button, Tag } from 'antd';
import type { FormItemProps } from 'antd';
import { DictionaryDto, LogsheetDictionaryVm, AreaVm, ScheduleConfigDicVm } from '../../services/Client';
import { dictionaryClient } from '../../services';
import dayjs, { type Dayjs } from '@dayjs';
import ConfigureScheduleModal, { ConfigureTimeFormModel } from '../modals/ConfigureScheduleModal';
import type { FormInstance } from 'antd';
import { clone } from 'lodash';

type ScheudleType = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY';

export interface ScheduleFormModel {
    id: number;
    locationCode: string;
    areaCode: string;
    logsheetId: number;
    scheduleName: string;
    year: number;
    datePeriod: Dayjs[];
    scheduleTypeCode: ScheudleType;
    scheduleConfigId: number;
    timeOptions: Array<{ id: number; time: Dayjs }>;
    weekDayCodes?: string[];
    date?: Dayjs;

    selectedPeriods?: Array<Dayjs[]>;
}

type Props = {
    isEdit?: boolean;
    srcFormModel?: ScheduleFormModel;
    onFormChange: (e: any) => void;
    onLoadingChange: (loading: boolean) => void;
};

const ScheduleFormInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { srcFormModel, onLoadingChange, form: form0, onFormChange } = props;

    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [logsheets, setLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredLogsheets, setFilteredLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [scheduleTypes, setScheduleTypes] = React.useState<DictionaryDto[]>([]);
    const [scheduleConfigs, setScheduleConfigs] = React.useState<ScheduleConfigDicVm[]>([]);
    const [filteredScheduleConfigs, setFilteredScheduleConfigs] = React.useState<ScheduleConfigDicVm[]>([]);
    const [scheduleTimeModalShown, setScheduleTimeModalShown] = React.useState<boolean>(false);
    const [scheduleStatus, setScheduleStatus] = React.useState<'Not started' | 'In progress' | 'Finished'>(
        'Not started',
    );
    const [datePeriodDisabled, setDatePeriodDisabled] = React.useState<boolean>();
    const [scheduleConfigDisabled, setScheduleConfigDisabled] = React.useState<boolean>();
    const [scheduleTypeDisabled, setScheduleTypeDisabled] = React.useState<boolean>();
    const previousProps = React.useRef(props);
    const years = React.useRef<number[]>(Array.from({ length: 6 }, (_, index) => dayjs().year() + index));
    const scheduleTimeModalRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const timeFormat = React.useRef('HH:mm');

    const defaultTimes = React.useRef([
        { id: undefined, time: dayjs('07:00', timeFormat.current) },
        { id: undefined, time: dayjs('14:00', timeFormat.current) },
        { id: undefined, time: dayjs('19:00', timeFormat.current) },
        { id: undefined, time: dayjs('02:00', timeFormat.current) },
    ]);

    const setDsiabledFields = (formModel: ScheduleFormModel) => {
        let currDate = dayjs();

        let datePeriodDisabled = false;
        let scheduleConfigDisabled = false;
        let scheduleTypeDisabled = false;

        // finished
        if (currDate.isAfter(formModel.datePeriod[1], 'day')) {
            datePeriodDisabled = true;
            scheduleConfigDisabled = true;
            scheduleTypeDisabled = true;
            setScheduleStatus('Finished');
        }

        // in progress
        if (currDate.isBetween(formModel.datePeriod[0], formModel.datePeriod[1], 'day', '[]')) {
            datePeriodDisabled = false;
            scheduleConfigDisabled = true;
            scheduleTypeDisabled = true;
            setScheduleStatus('In progress');
        }

        // not started yet
        if (currDate.isBefore(formModel.datePeriod[0], 'day')) {
            datePeriodDisabled = false;
            scheduleConfigDisabled = false;
            scheduleTypeDisabled = false;
            setScheduleStatus('Not started');
        }

        setDatePeriodDisabled(datePeriodDisabled);
        setScheduleConfigDisabled(scheduleConfigDisabled);
        setScheduleTypeDisabled(scheduleTypeDisabled);
    };

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        let logsheets = await dictionaryClient.getLogsheets();
        let scheduleTypes = await dictionaryClient.getDictionary('ScheduleTypes');
        let scheduleConfigs = await dictionaryClient.getScheduleConfigs();
        onLoadingChange(false);

        setLocations(locations);
        setAreas(areas);
        setLogsheets(logsheets);
        setScheduleTypes(scheduleTypes);
        setScheduleConfigs(scheduleConfigs);
    };

    const filterDictionaries = () => {
        let locationCode = form0.getFieldValue('locationCode');
        let areaCode = form0.getFieldValue('areaCode');
        let year = form0.getFieldValue('year');

        filterAreas(locationCode);
        filterLogsheets(areaCode);
        filterScheduleConfigs(areaCode, year);
    };

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (locationCode: string) => {
            filterAreas(locationCode);
            form0.setFieldsValue({
                areaCode: '',
                logsheetId: undefined,
                scheduleConfigId: undefined,
            });
        },
        [filterAreas, form0],
    );

    const filterLogsheets = React.useCallback(
        (areaCode: string) => {
            const filteredLogsheets = logsheets.filter((r) => r.areaCode === areaCode);
            setFilteredLogsheets(filteredLogsheets);
        },
        [logsheets],
    );

    const filterScheduleConfigs = React.useCallback(
        (areaCode: string, year: number) => {
            let filteredConfigs: ScheduleConfigDicVm[] = scheduleConfigs;

            if (areaCode) filteredConfigs = filteredConfigs.filter((r) => r.areaCode === areaCode);
            if (year) filteredConfigs = filteredConfigs.filter((r) => r.year === year);

            setFilteredScheduleConfigs(filteredConfigs);
        },
        [scheduleConfigs],
    );

    const handlerAreaChange = React.useCallback(
        (areaCode: string) => {
            const year = form0.getFieldValue('year');
            filterLogsheets(areaCode);
            filterScheduleConfigs(areaCode, year);

            form0.setFieldsValue({
                logsheetId: undefined,
                scheduleConfigId: undefined,
            });
        },
        [filterLogsheets, filterScheduleConfigs, form0],
    );

    const handleYearChange = React.useCallback(
        (year: number) => {
            const areacode = form0.getFieldValue('areaCode');

            filterScheduleConfigs(areacode, year);

            form0.setFieldsValue({
                scheduleConfigId: undefined,
                datePeriod: undefined,
            });

            onFormChange(undefined);
        },
        [filterScheduleConfigs, form0, onFormChange],
    );

    const disableDate = React.useCallback(
        (current: Dayjs | null): boolean => {
            let year = props.form.getFieldValue('year');

            return current!.year() !== year;
        },
        [props.form],
    );

    const saveScheduleConfig = React.useCallback(() => {
        const timeForm = scheduleTimeModalRef.current!.form as FormInstance;

        let scheduleTypeCode: ScheudleType = form0.getFieldValue('scheduleTypeCode');

        timeForm
            .validateFields()
            .then((values: ConfigureTimeFormModel) => {
                // change form datePeriod
                if (scheduleTypeCode === 'MONTHLY') {
                    let startDate: Dayjs | undefined, endDate: Dayjs | undefined;
                    values.selectedPeriods?.forEach((r) => {
                        if (!startDate || r[0].isBefore(startDate, 'day')) startDate = r[0];
                        if (!endDate || r[1].isAfter(endDate, 'day')) endDate = r[1];
                    });
                    form0.setFieldsValue({ datePeriod: [startDate, endDate] });
                }
                if (scheduleTypeCode === 'YEARLY') {
                    form0.setFieldsValue({ date: values.date });
                }
                form0.setFieldsValue({
                    timeOptions: values.timeOptions,
                    weekDayCodes: values.weekDayCodes,
                    selectedPeriods: values.selectedPeriods,
                });
                setScheduleTimeModalShown(false);
                onFormChange(undefined);
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [form0, onFormChange]);

    const validateEndDate = React.useCallback(
        async (_rule: unknown, value?: Dayjs[]) => {
            if (props.isEdit && value?.[1] && dayjs().isAfter(value[1], 'day')) {
                throw new Error('End date cannot be smaller than current date');
            }
        },
        [props.isEdit],
    );

    const validateStartDate = React.useCallback(
        async (_rule: unknown, value?: Dayjs[]) => {
            if (!props.isEdit || !value?.[0]) return;

            const currDate = dayjs().endOf('day');

            if (currDate.isBetween(srcFormModel!.datePeriod[0], srcFormModel!.datePeriod[1], 'day', '[]')) {
                if (!value[0].isSame(srcFormModel!.datePeriod[0], 'day')) {
                    throw new Error('Schedule in progress, start date cannot be changed');
                }
            } else if (
                currDate.isBefore(srcFormModel!.datePeriod[0], 'day') &&
                currDate.isSameOrAfter(value[0], 'day')
            ) {
                throw new Error('Schedule is not started yet, start date cannot be changed to current or past date');
            }
        },
        [srcFormModel, props.isEdit],
    );

    const openScheduleModal = React.useCallback(() => {
        setScheduleTimeModalShown(true);
    }, []);

    const initScheduleModal = React.useCallback(
        (compRef: any) => {
            if (compRef) {
                scheduleTimeModalRef.current = compRef;
                const timeForm = scheduleTimeModalRef.current!.form as FormInstance;
                let selectedPeriods = props.form.getFieldValue('selectedPeriods');
                let date = props.form.getFieldValue('date');

                timeForm.setFieldsValue({
                    selectedPeriods: clone(selectedPeriods),
                    date,
                });
            }
        },
        [props.form],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                await loadDictionaries();

                if (props.isEdit) {
                    filterDictionaries();
                }
            } else {
                const prevProps = previousProps.current;
                if (!prevProps.srcFormModel && props.srcFormModel) {
                    setDsiabledFields(props.srcFormModel!);
                }
                previousProps.current = props;
            }
        })();
    });

    const {
        form: {},
        form: form,
        isEdit: isEdit,
    } = props;

    const formItemProps: FormItemProps = {
        labelCol: { span: 6 },
    };

    // let tomorrow = dayjs().add(1, 'day');
    // let endDate = dayjs().add(10, 'day');

    const timeOptions: any[] = form.getFieldValue('timeOptions');

    const scheduleTypeCode: ScheudleType = form.getFieldValue('scheduleTypeCode');
    const weekDayCodes = form.getFieldValue('weekDayCodes');
    const year = form.getFieldValue('year');

    return (
        <>
            <Form
                form={props.form}
                labelAlign="left"
                className="schedule-form"
                layout="inline"
                onChange={props.onFormChange}
            >
                <Form.Item name="weekDayCodes" hidden />
                <Form.Item name="id" hidden />
                <Form.Item name="selectedPeriods" hidden />
                <Form.Item name="date" hidden />

                <Row gutter={24}>
                    <Col span={8}>
                        <Form.Item
                            label="Location"
                            {...formItemProps}
                            name="locationCode"
                            rules={[
                                {
                                    required: true,
                                    message: 'Location is required',
                                },
                            ]}
                        >
                            <Select disabled={isEdit} onChange={handleLocationChange}>
                                {locations.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            label="Area"
                            {...formItemProps}
                            name="areaCode"
                            rules={[
                                {
                                    required: true,
                                    message: 'Area is required',
                                },
                            ]}
                        >
                            <Select disabled={isEdit} onChange={handlerAreaChange}>
                                {filteredAreas.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            label="Logsheet"
                            {...formItemProps}
                            name="logsheetId"
                            rules={[
                                {
                                    required: true,
                                    message: 'Logsheet is required',
                                },
                            ]}
                        >
                            <Select disabled={isEdit}>
                                {filteredLogsheets.map((r) => (
                                    <Select.Option key={r.id} value={r.id} title={r.name}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col span={8}>
                        <Form.Item
                            label="Schedule name"
                            {...formItemProps}
                            name="scheduleName"
                            rules={[
                                {
                                    required: true,
                                    whitespace: true,
                                    message: 'Name is required',
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            label="Year"
                            {...formItemProps}
                            name="year"
                            rules={[
                                {
                                    required: true,
                                    message: 'Year is required',
                                },
                            ]}
                            initialValue={dayjs().year()}
                        >
                            <Select disabled={isEdit} onChange={handleYearChange}>
                                {years.current.map((r) => (
                                    <Select.Option key={r} value={r}>
                                        {r}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            label="Date period"
                            {...formItemProps}
                            name="datePeriod"
                            rules={[
                                {
                                    type: 'array',
                                    required: true,
                                    message: 'Period is required',
                                },
                                {
                                    validator: validateEndDate,
                                },
                                {
                                    validator: validateStartDate,
                                },
                            ]}
                        >
                            <DatePicker.RangePicker
                                format="DD-MM-YYYY"
                                style={{ width: '100%' }}
                                disabled={datePeriodDisabled}
                                disabledDate={disableDate}
                                onChange={props.onFormChange}
                            />
                        </Form.Item>
                    </Col>

                    <Col span={8}>
                        <Form.Item
                            label="Schedule config"
                            {...formItemProps}
                            name="scheduleConfigId"
                            rules={[
                                {
                                    required: true,
                                    message: 'Schedule config is required',
                                },
                            ]}
                        >
                            <Select disabled={scheduleConfigDisabled} onChange={props.onFormChange}>
                                {filteredScheduleConfigs.map((r) => (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col span={8}>
                        <Row justify="space-between">
                            <Form.Item
                                label="Schedule type"
                                style={{ width: '53%' }}
                                labelCol={{ span: 11 }}
                                name="scheduleTypeCode"
                                rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Schedule type is required',
                                    },
                                ]}
                            >
                                <Select disabled={scheduleTypeDisabled}>
                                    {scheduleTypes.map((r) => (
                                        <Select.Option key={r.code} value={r.code} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>

                            <Form.Item
                                name="timeOptions"
                                initialValue={[...defaultTimes.current]}
                                rules={[
                                    {
                                        type: 'array',
                                        required: true,
                                        message: 'Time configuration is required',
                                    },
                                ]}
                            >
                                <Button
                                    // disabled={scheduleTypeDisabled}
                                    style={{ width: '100%' }}
                                    onClick={openScheduleModal}
                                >
                                    Configure schedule
                                </Button>
                            </Form.Item>
                        </Row>
                    </Col>
                    <Col span={8}>
                        <Form.Item label="Schedule status" {...formItemProps}>
                            <Tag color="blue">{scheduleStatus}</Tag>
                        </Form.Item>
                    </Col>
                </Row>
            </Form>

            {scheduleTimeModalShown && (
                <ConfigureScheduleModal
                    visible={scheduleTimeModalShown}
                    scheduleTypeCode={scheduleTypeCode}
                    ref={initScheduleModal}
                    timeOptions={timeOptions}
                    weekDayCodes={weekDayCodes}
                    year={year}
                    disabled={scheduleTypeDisabled}
                    onOk={saveScheduleConfig}
                    onCancel={() => setScheduleTimeModalShown(false)}
                />
            )}
        </>
    );
});

const ScheduleForm = ScheduleFormInner;

export default ScheduleForm;
