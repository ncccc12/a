import React from 'react';
import { Form, Row, Col, Select, Input, Checkbox, DatePicker, Card } from 'antd';
import type { FormItemProps } from 'antd';
import { dictionaryClient } from '../../services';
import { AreaVm, DictionaryDto, GroupSimpleVm } from '../../services/Client';
import dayjs, { type Dayjs } from '@dayjs';

export interface ConfigFormModel {
    areaCode?: string;
    datePeriod?: Dayjs[];
    group1?: string;
    group1DayShift?: boolean;
    group2?: string;
    group2DayShift?: boolean;
    group3?: string;
    group3DayShift?: boolean;
    group4?: string;
    group4DayShift?: boolean;
    locationCode?: string;
    rotationType?: string;
    scheduleConfigName?: string;
    year?: number;
    isManual?: boolean;
    switchShift?: boolean;
}

type Props = {
    groups: GroupSimpleVm[];
    isEdit?: boolean;
    onFormChange: (e: any) => void;
    onLoadingChange(loading: boolean): void;
};

const ScheduleConfigFormInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { onLoadingChange, form: form0, onFormChange, groups } = props;

    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredGroups, setFilteredGroups] = React.useState<GroupSimpleVm[]>([]);
    const [rotationTypes, setRotationTypes] = React.useState<DictionaryDto[]>([]);
    const years = React.useRef<number[]>([]);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        let rotationTypes = await dictionaryClient.getDictionary('RotationTypes');
        setLocations(locations);
        setAreas(areas);
        setRotationTypes(rotationTypes);

        filterDics();
        onLoadingChange(false);
    };

    const filterDics = () => {
        const locationCode = form0.getFieldValue('locationCode');
        const areaCode = form0.getFieldValue('areaCode');
        filterAreas(locationCode);
        filterGroups(areaCode);
    };

    const filterAreas = React.useCallback(
        (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        },
        [areas],
    );

    const handleLocationChange = React.useCallback(
        (locationCode: string) => {
            filterAreas(locationCode);
            form0.setFieldsValue({
                areaCode: '',
                group1: undefined,
                group2: undefined,
                group3: undefined,
                group4: undefined,
            });

            onFormChange(undefined);
        },
        [filterAreas, form0, onFormChange],
    );

    const filterGroups = React.useCallback(
        (areaCode: string) => {
            const filteredGroups = groups.filter((r) => r.areaCode === areaCode);
            setFilteredGroups(filteredGroups);
        },
        [groups],
    );

    const handleAreaChange = React.useCallback(
        (areaCode: string) => {
            filterGroups(areaCode);
            form0.setFieldsValue({
                group1: undefined,
                group2: undefined,
                group3: undefined,
                group4: undefined,
            });

            onFormChange(undefined);
        },
        [filterGroups, form0, onFormChange],
    );

    const handleYearChange = React.useCallback(
        (year: number) => {
            props.form.setFieldsValue({
                datePeriod: undefined,
            });

            onFormChange(undefined);
        },
        [onFormChange, props.form],
    );

    const disableDate = React.useCallback(
        (date: Dayjs | null): boolean => {
            let year = props.form.getFieldValue('year');

            return !!date && (date.year() < year || date.year() > year);
        },
        [props.form],
    );

    const validateDatePeriod = React.useCallback(
        async (_rule: unknown, value?: Dayjs[]) => {
            if (props.isEdit && value?.[1] && value[1].endOf('day') <= dayjs().endOf('day')) {
                throw new Error('End date cannot be smaller or equal to current date');
            }
        },
        [props.isEdit],
    );

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadDictionaries();

            let currYear = dayjs().year();
            years.current.push(...[currYear, currYear + 1]);
        }
    });

    const {
        form: {},
        form: form,
        isEdit: isEdit,
    } = props;

    const formItemProps: FormItemProps = {
        labelCol: { span: 7 },
    };

    let groups0 = form.getFieldsValue(['group1', 'group2', 'group3', 'group4']);
    let groupVals: string[] = [];
    Object.keys(groups0).forEach((key) => {
        groupVals.push(groups0[key]);
    });

    let groupOptions = filteredGroups.map((r) => (
        <Select.Option key={r.id} value={r.code} disabled={groupVals.includes(r.code!)}>
            {r.name}
        </Select.Option>
    ));

    groupOptions.unshift(
        <Select.Option key={-1} value={undefined}>
            -
        </Select.Option>,
    );

    // let startPeriod = dayjs([2020, 7, 29]);
    // let endPeriod = dayjs().endOf('year');

    return (
        <Form
            form={props.form}
            onChange={props.onFormChange}
            labelAlign="left"
            className="schedule-form"
            layout="inline"
        >
            <Row gutter={24}>
                <Col span={6}>
                    <Form.Item
                        label="Location"
                        {...formItemProps}
                        name="locationCode"
                        rules={[
                            {
                                required: true,
                                message: 'Location is required',
                            },
                        ]}
                    >
                        <Select disabled={isEdit} onChange={handleLocationChange}>
                            {locations.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        label="Area"
                        {...formItemProps}
                        name="areaCode"
                        rules={[
                            {
                                required: true,
                                message: 'Area is required',
                            },
                        ]}
                    >
                        <Select disabled={isEdit} onChange={handleAreaChange}>
                            {filteredAreas.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item
                        label="Year"
                        {...formItemProps}
                        name="year"
                        rules={[
                            {
                                required: true,
                                message: 'Year is required',
                            },
                        ]}
                        initialValue={dayjs().year()}
                    >
                        <Select disabled={isEdit} onChange={handleYearChange}>
                            {years.current.map((r) => (
                                <Select.Option key={r} value={r}>
                                    {r}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        label="Rotation type"
                        {...formItemProps}
                        name="rotationType"
                        rules={[
                            {
                                required: true,
                                message: 'Rotation type is required',
                            },
                        ]}
                    >
                        <Select onChange={props.onFormChange}>
                            {rotationTypes.map((r) => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item
                        label="Config name"
                        {...formItemProps}
                        name="scheduleConfigName"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'Name is required',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="Date period"
                        {...formItemProps}
                        name="datePeriod"
                        rules={[
                            {
                                type: 'array',
                                required: true,
                                message: 'Date period is required',
                            },
                            {
                                validator: validateDatePeriod,
                            },
                        ]}
                    >
                        <DatePicker.RangePicker
                            format="DD-MM-YYYY"
                            disabledDate={disableDate}
                            style={{ width: '100%' }}
                            onChange={props.onFormChange}
                        />
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Card>
                        <Row>
                            <Form.Item
                                label="Group 1"
                                {...formItemProps}
                                style={{ width: '60%' }}
                                name="group1"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Group is required',
                                    },
                                ]}
                            >
                                <Select disabled={isEdit} onChange={props.onFormChange}>
                                    {groupOptions}
                                </Select>
                            </Form.Item>
                        </Row>

                        <Row>
                            <Form.Item
                                label="Group 2"
                                {...formItemProps}
                                style={{ width: '60%' }}
                                name="group2"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Group is required',
                                    },
                                ]}
                            >
                                <Select disabled={isEdit} onChange={props.onFormChange}>
                                    {groupOptions}
                                </Select>
                            </Form.Item>
                        </Row>
                    </Card>
                </Col>

                <Col span={8}>
                    <Card>
                        <Row>
                            <Form.Item
                                label="Group 3"
                                {...formItemProps}
                                style={{ width: '60%' }}
                                name="group3"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Group is required',
                                    },
                                ]}
                            >
                                <Select disabled={isEdit} onChange={props.onFormChange}>
                                    {groupOptions}
                                </Select>
                            </Form.Item>
                        </Row>
                        <Row>
                            <Form.Item
                                label="Group 4"
                                {...formItemProps}
                                style={{ width: '60%' }}
                                name="group4"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Group is required',
                                    },
                                ]}
                            >
                                <Select disabled={isEdit} onChange={props.onFormChange}>
                                    {groupOptions}
                                </Select>
                            </Form.Item>
                        </Row>
                    </Card>
                </Col>

                <Col span={8}>
                    <Form.Item {...formItemProps} name="switchShift" valuePropName="checked">
                        <Checkbox>Switch Day/Night shift</Checkbox>
                    </Form.Item>
                    <Form.Item {...formItemProps} name="isManual" valuePropName="checked">
                        <Checkbox>Is manual</Checkbox>
                    </Form.Item>
                </Col>
            </Row>
        </Form>
    );
});

const ScheduleConfigForm = ScheduleConfigFormInner;

export default ScheduleConfigForm;
