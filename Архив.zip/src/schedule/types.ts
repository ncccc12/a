import dayjs, { type Dayjs } from '@dayjs';

export interface LogsheetScheduleForm {
    id: number;
    keys: number[];
    timeOptions: TimeOption[];
}

export interface TimeOption {
    id: number;
    time: Dayjs | any;
}

export interface ScheduleConfig {
    group1?: GroupConfig;
    group2?: GroupConfig;
    group3?: GroupConfig;
    group4?: GroupConfig;

    areaCode?: string;
    datePeriod?: Dayjs[];
    locationCode?: string;
    rotationType?: string;
    scheduleConfigName?: string;
    year?: number;
    // dayShiftFirst1: number;
    // dayShiftFirst2: number;
    switchShift?: boolean;
    isManual?: boolean;
}

export interface GroupConfig {
    code: string;
    name?: string;
    dayShift?: boolean;
    schedule?: number[];
}
