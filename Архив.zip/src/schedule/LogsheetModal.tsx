import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import React from 'react';
import { Form, Modal, TimePicker, Button } from 'antd';
import type { FormItemProps } from 'antd';
import { LogsheetListItemVm } from '../services/Client';
import dayjs, { type Dayjs } from '@dayjs';
import './ConfigureScheduleModal.css';

type Props = {
    visible: boolean;
    logsheet?: LogsheetListItemVm;
    loading: boolean;
    onOk: () => void;
    onCancel: () => void;
};

const LogsheetModalInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { logsheet, form } = props;

    const [keys0, setKeys] = React.useState<number[]>([]);
    const id = React.useRef(0);
    const timeFormat = React.useRef('HH:mm');

    const initTimeOptions = () => {
        const keys: number[] = [];

        id.current = logsheet!.schedule!.timeOptions!.length;
        let timeOptions: any[] = [];

        for (let i = 0; i < id.current; i++) {
            let opt = logsheet!.schedule!.timeOptions![i];
            keys.push(i);
            timeOptions.push({
                id: opt.id,
                time: dayjs(opt.time, timeFormat.current),
            });
        }

        setKeys(keys);
        form.setFieldsValue({
            timeOptions,
        });
    };

    const addTime = React.useCallback(() => {
        const keys: number[] = form.getFieldValue('keys');
        const nextKeys = keys.concat(id.current++);

        form.setFieldsValue({
            keys: nextKeys,
        });
    }, [form]);

    const removeTime = (k: number) => {
        const keys: number[] = form.getFieldValue('keys');

        if (keys.length === 1) return;

        form.setFieldsValue({
            keys: keys.filter((r) => r !== k),
        });
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            if (!logsheet) return;

            initTimeOptions();
        }
    });

    const {
        visible: visible,
        logsheet: logsheet0,
        form: { getFieldValue: getFieldValue },
    } = props;

    const keys: number[] = getFieldValue('keys');

    const formItemLayoutWithOutLabel: FormItemProps = {
        wrapperCol: {
            span: 16,
            offset: 8,
        },
    };

    const formItemLayout: FormItemProps = {
        labelCol: {
            span: 8,
        },
        wrapperCol: {
            span: 16,
        },
    };

    return (
        <Modal
            open={visible}
            title="Edit logsheet"
            okText="Save"
            className="config-schedule-modal"
            confirmLoading={props.loading}
            onOk={props.onOk}
            onCancel={props.onCancel}
        >
            <Form form={props.form} layout="horizontal" {...formItemLayout} labelAlign="left">
                <Form.Item name="keys" hidden initialValue={keys0} />
                <Form.Item name="id" hidden initialValue={logsheet0 && logsheet0.id} />
                <Form.Item label="Logsheet name">{logsheet0 && logsheet0.name}</Form.Item>
                <Form.Item label="Schedule type">{logsheet0 && logsheet0.schedule!.type}</Form.Item>
                {keys.map((r, idx) => {
                    return (
                        <React.Fragment key={r}>
                            <Form.Item name={['timeOptions', r, 'id']} hidden />
                            <Form.Item
                                label={idx === 0 ? 'Times' : ''}
                                {...(idx === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                name={['timeOptions', r, 'time']}
                                rules={[{ required: true, message: 'time is required' }]}
                            >
                                <TimePicker
                                    minuteStep={5}
                                    style={{ marginRight: 8, width: 180 }}
                                    format={timeFormat.current}
                                />

                                {keys.length > 1 ? (
                                    <MinusCircleOutlined
                                        className="dynamic-delete-button"
                                        title="Remove"
                                        onClick={() => removeTime(r)}
                                    />
                                ) : null}
                            </Form.Item>
                        </React.Fragment>
                    );
                })}

                <Form.Item {...formItemLayoutWithOutLabel}>
                    <Button type="dashed" onClick={addTime} style={{ width: 180 }}>
                        <PlusOutlined /> Add time
                    </Button>
                </Form.Item>
            </Form>
        </Modal>
    );
});

const LogsheetModal = LogsheetModalInner;

export default LogsheetModal;
