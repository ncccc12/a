import { DeleteOutlined, MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import React from 'react';
import { Form, Modal, TimePicker, Button, Checkbox, Row, Col, DatePicker, Tag, Alert } from 'antd';
import type { FormItemProps } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import './ConfigureScheduleModal.css';
import { dictionaryClient } from '../../services';
import { DictionaryDto } from '../../services/Client';
import { clone } from 'lodash';

export interface ConfigureTimeFormModel {
    keys: number[];
    timeOptions: Array<{ id: number; time: Dayjs }>;
    weekDayCodes?: string[];
    date?: Dayjs;
    year: number;
    selectedPeriods?: Array<Dayjs[]>;
}

type Props = {
    visible: boolean;
    // loading: boolean;
    timeOptions: Array<{ id?: number; time: string }>;
    weekDayCodes?: string[];
    scheduleTypeCode: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY';
    year?: number;
    disabled?: boolean;
    onOk: () => void;
    onCancel: () => void;
};

const ConfigureScheduleModalInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { timeOptions, scheduleTypeCode, weekDayCodes, form } = props;

        const [keys0, setKeys] = React.useState<number[]>([]);
        const [weekDays, setWeekDays] = React.useState<DictionaryDto[]>([]);
        const id = React.useRef(0);
        const timeFormat = React.useRef('HH:mm');

        const initWeekDays = async () => {
            let weekDays = await dictionaryClient.getDictionary('WeekDays');
            setWeekDays(weekDays);
            if (props.weekDayCodes) {
                form.setFieldsValue({ weekDayCodes });
            }
        };

        const initTimeOptions = () => {
            const keys: number[] = [];
            id.current = timeOptions.length;

            let times = [...timeOptions];

            if (scheduleTypeCode === 'YEARLY') {
                times = times.slice(0, 1);
            }
            let timeOptionsInner = times.map((r, idx) => {
                keys.push(idx);

                return {
                    id: r.id,
                    time: dayjs(r.time, timeFormat.current),
                };
            });

            setKeys(keys);
            form.setFieldsValue({
                timeOptions: timeOptionsInner,
            });
        };

        const addTime = React.useCallback(() => {
            const keys: number[] = form.getFieldValue('keys');
            const nextKeys = keys.concat(id.current++);

            form.setFieldsValue({
                keys: nextKeys,
            });
        }, [form]);

        const removeTime = (k: number) => {
            const keys: number[] = form.getFieldValue('keys');

            if (keys.length === 1) return;

            form.setFieldsValue({
                keys: keys.filter((r) => r !== k),
            });
        };

        const addDate = React.useCallback(() => {
            let datePeriod: Dayjs[] = form.getFieldValue('datePeriod');
            let year: number = props.year!;
            let selectedPeriods: Array<Dayjs[]> = form.getFieldValue('selectedPeriods') || [];
            let result: Array<Dayjs[]> = [];
            selectedPeriods.push(datePeriod);

            let startDate: Dayjs | undefined, endDate: Dayjs | undefined;

            for (let m = 0; m < 12; m++) {
                let month = dayjs([year, m, 1]);

                for (let d = 1; d <= month.daysInMonth(); d++) {
                    let day = dayjs([year, m, d]);
                    let inRange = false;

                    selectedPeriods.forEach((r) => {
                        if (day.isBetween(r[0], r[1], 'date', '[]')) {
                            inRange = true;
                        }
                    });

                    if (inRange) {
                        if (!startDate) startDate = clone(day);

                        endDate = clone(day);
                    } else {
                        if (startDate && endDate) result.push([startDate, endDate]);

                        startDate = undefined;
                        endDate = undefined;
                    }
                }
            }

            form.setFieldsValue({
                selectedPeriods: result,
                datePeriod: [],
            });
        }, [form, props.year]);

        const getDisabledDates = React.useCallback(
            (current: Dayjs | null) => {
                let selectedPeriods: Array<Dayjs[]> = form.getFieldValue('selectedPeriods') || [];
                let selectedYear: number = props.year!;

                if (selectedYear !== current?.year()) {
                    return true;
                }

                let isSelected = false;
                selectedPeriods.forEach((period) => {
                    if (current?.isBetween(period[0], period[1], 'day', '[]')) {
                        isSelected = true;
                    }
                });

                return isSelected;
            },
            [form, props.year],
        );

        const removeSelectedDate = (period: Dayjs[]) => {
            let selectedPeriods: Array<Dayjs[]> = form.getFieldValue('selectedPeriods') || [];

            selectedPeriods = selectedPeriods.filter((r) => {
                return period[0] !== r[0] && period[1] !== r[1];
            });

            form.setFieldsValue({
                selectedPeriods,
            });
        };

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                if (props.timeOptions) initTimeOptions();

                if (props.scheduleTypeCode === 'WEEKLY') initWeekDays();
            }
        });

        const {
            visible: visible,
            form: { getFieldValue: getFieldValue, getFieldError: getFieldError },
            scheduleTypeCode: scheduleTypeCode0,
        } = props;

        const keys: number[] = getFieldValue('keys');

        const formItemLayoutWithOutLabel: FormItemProps = {
            wrapperCol: {
                span: 16,
                offset: 8,
            },
        };

        const formItemLayout: FormItemProps = {
            labelCol: {
                span: 8,
            },
            wrapperCol: {
                span: 16,
            },
        };

        let selectedPeriods: Array<Dayjs[]> = getFieldValue('selectedPeriods');
        let datePeriod = getFieldValue('datePeriod');

        return (
            <Modal
                open={visible}
                title="Configure schedule times"
                width={700}
                okText="Save"
                okButtonProps={{ disabled: props.disabled }}
                className="config-schedule-modal"
                destroyOnHidden={true}
                onOk={props.onOk}
                onCancel={props.onCancel}
            >
                <Form form={props.form} layout="horizontal" {...formItemLayout} labelAlign="left">
                    <Form.Item name="keys" hidden initialValue={keys0} />
                    <Form.Item
                        name="selectedPeriods"
                        hidden
                        rules={[
                            {
                                required: scheduleTypeCode0 === 'MONTHLY',
                                message: 'Select at least one date period',
                            },
                        ]}
                    />
                    {scheduleTypeCode0 === 'MONTHLY' && (
                        <>
                            <Form.Item label="Select date" name="datePeriod">
                                <DatePicker.RangePicker format="DD-MM-YYYY" disabledDate={getDisabledDates} />

                                <Button style={{ marginLeft: 5 }} disabled={!datePeriod?.length} onClick={addDate}>
                                    Add
                                </Button>
                            </Form.Item>
                            <Form.Item label="Selected periods">
                                {getFieldError('selectedPeriods')?.length! > 0 && (
                                    <Alert type="error" message={getFieldError('selectedPeriods')![0]}></Alert>
                                )}
                                {selectedPeriods?.map((r: Dayjs[]) => (
                                    <div key={r[0].toString() + 'div'}>
                                        <Tag key={r[0].toString()} color="blue">{`${r[0].format(
                                            'YYYY.MM.DD',
                                        )} - ${r[1].format('YYYY.MM.DD')}`}</Tag>
                                        <Button
                                            key={r[0].toString() + 'btn'}
                                            icon={<DeleteOutlined />}
                                            onClick={() => removeSelectedDate(r)}
                                        ></Button>
                                    </div>
                                ))}
                            </Form.Item>
                        </>
                    )}

                    {scheduleTypeCode0 === 'YEARLY' && (
                        <>
                            <Form.Item
                                label="Select date"
                                name="date"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Select date',
                                    },
                                ]}
                            >
                                <DatePicker format="DD-MM-YYYY" />
                            </Form.Item>
                        </>
                    )}

                    {scheduleTypeCode0 === 'WEEKLY' && (
                        <Form.Item
                            label="Week days"
                            name="weekDayCodes"
                            rules={[
                                {
                                    required: true,
                                    message: 'Select at least one weekday',
                                },
                            ]}
                        >
                            <Checkbox.Group style={{ width: '100%' }}>
                                <Row>
                                    {weekDays.map((r) => {
                                        return (
                                            <Col key={r.code} span={8}>
                                                <Checkbox key={r.code} value={r.code}>
                                                    {r.name}
                                                </Checkbox>
                                            </Col>
                                        );
                                    })}
                                </Row>
                            </Checkbox.Group>
                        </Form.Item>
                    )}

                    {keys.map((r, idx) => {
                        return (
                            <React.Fragment key={r}>
                                <Form.Item name={['timeOptions', r, 'id']} hidden />
                                <Form.Item
                                    label={idx === 0 ? 'Times' : ''}
                                    {...(idx === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                    name={['timeOptions', r, 'time']}
                                    rules={[{ required: true, message: 'time is required' }]}
                                >
                                    <TimePicker
                                        minuteStep={5}
                                        style={{ marginRight: 8, width: 180 }}
                                        format={timeFormat.current}
                                    />

                                    {keys.length > 1 ? (
                                        <MinusCircleOutlined
                                            className="dynamic-delete-button"
                                            title="Remove"
                                            onClick={() => removeTime(r)}
                                        />
                                    ) : null}
                                </Form.Item>
                            </React.Fragment>
                        );
                    })}

                    {scheduleTypeCode0 !== 'YEARLY' && (
                        <Form.Item {...formItemLayoutWithOutLabel}>
                            <Button type="dashed" onClick={addTime} style={{ width: 180 }}>
                                <PlusOutlined /> Add time
                            </Button>
                        </Form.Item>
                    )}
                </Form>
            </Modal>
        );
    },
);

const ConfigureScheduleModal = ConfigureScheduleModalInner;

export default ConfigureScheduleModal;
