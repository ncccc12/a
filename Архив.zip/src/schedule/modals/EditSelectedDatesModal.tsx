import { DatePicker, Form, Modal, Select } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import React from 'react';
import { Item, RotationCalendarTypes } from '../constants';
//import { Item, RotationCalendarTypes } from '../constant';

const Option = Select.Option;
const FormItem = Form.Item;

type Props = {
    visible: boolean;
    startDate: Dayjs;
    endDate: Dayjs;
    onOk: (e: any) => void;
    onCancel: (e: any) => void;
};

const EditSelectedDatesModalInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { onOk, visible, onCancel, startDate, endDate } = props;

        const rowConf = React.useRef<{ style: React.CSSProperties }>({
            style: {
                width: 300,
            },
        });

        const {} = props.form;

        return (
            <Modal
                title="Edit selected dates"
                open={visible}
                centered={true}
                width={400}
                onOk={onOk}
                onCancel={onCancel}
            >
                <Form form={props.form} layout="inline" labelCol={{ span: 8 }} labelAlign="left">
                    <FormItem label="Start date" {...rowConf.current}>
                        <DatePicker format="DD-MM-YYYY" disabled={true} value={startDate} />
                    </FormItem>
                    <FormItem label="End date" {...rowConf.current}>
                        <DatePicker format="DD-MM-YYYY" disabled={true} value={endDate} />
                    </FormItem>

                    <FormItem
                        label="Shift type"
                        {...rowConf.current}
                        name="shiftType"
                        initialValue={RotationCalendarTypes[0].value}
                    >
                        <Select style={{ width: 195 }}>
                            {RotationCalendarTypes.map((type: Item) => {
                                return (
                                    <Option key={type.value} value={type.value}>
                                        {type.text}
                                    </Option>
                                );
                            })}
                        </Select>
                    </FormItem>
                </Form>
            </Modal>
        );
    },
);

export const EditSelectedDatesModal = EditSelectedDatesModalInner;
