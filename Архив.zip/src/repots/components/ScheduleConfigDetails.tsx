import React from 'react';
import { Descriptions } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import { ReportScheduleConfig } from '../types';

type Props = {
    scheduleConfig?: ReportScheduleConfig;
};

const ScheduleConfigDetails: React.FC<Props> = (props) => {
    const { scheduleConfig } = props;

    return (
        <Descriptions title="Details">
            <Descriptions.Item label="Location">{scheduleConfig?.locationName}</Descriptions.Item>
            <Descriptions.Item label="Area">{scheduleConfig?.areaName}</Descriptions.Item>
            <Descriptions.Item label="Year">{scheduleConfig?.year}</Descriptions.Item>
            <Descriptions.Item label="Rotation type">{scheduleConfig?.rotationType}</Descriptions.Item>
            <Descriptions.Item label="Config name">{scheduleConfig?.scheduleConfigName}</Descriptions.Item>
            <Descriptions.Item label="Date period">
                {dayjs(scheduleConfig?.datePeriod?.[0]).format('DD.MM.YYYY')} -{' '}
                {dayjs(scheduleConfig?.datePeriod?.[1]).format('DD.MM.YYYY')}
            </Descriptions.Item>
            <Descriptions.Item label="Group 1">{scheduleConfig?.group1?.name} </Descriptions.Item>
            <Descriptions.Item label="Group 2">{scheduleConfig?.group2?.name}</Descriptions.Item>
            <Descriptions.Item label="Group 3">{scheduleConfig?.group3?.name}</Descriptions.Item>
            <Descriptions.Item label="Group 4">{scheduleConfig?.group4?.name}</Descriptions.Item>
        </Descriptions>
    );
};

export default ScheduleConfigDetails;
