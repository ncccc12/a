import { DatePicker, Form } from 'antd';
import type { FormInstance } from 'antd';
import dayjs, { type Dayjs } from '@dayjs';
import React from 'react';

type Props = {
    form: FormInstance;
    startDateFieldName: string;
    endDateFieldName: string;
};

const PeriodDatePicker: React.FC<Props> = (props) => {
    const { endDateFieldName, startDateFieldName } = props;

    const [endOpen, setEndOpen] = React.useState<boolean>(false);

    const disabledStartDate = React.useCallback(
        (startValue?: Dayjs | null): boolean => {
            const { getFieldValue } = props.form;
            const endValue = getFieldValue(endDateFieldName);
            if (!startValue || !endValue) {
                return false;
            }

            return startValue.valueOf() > endValue.valueOf();
        },
        [endDateFieldName, props.form],
    );

    const disabledEndDate = React.useCallback(
        (endValue?: Dayjs | null): boolean => {
            const { getFieldValue } = props.form;
            const startValue = getFieldValue(startDateFieldName);
            if (!endValue || !startValue) {
                return false;
            }

            return endValue.valueOf() <= startValue.valueOf();
        },
        [startDateFieldName, props.form],
    );

    const handleStartOpenChange = React.useCallback((open: boolean): void => {
        if (!open) {
            setEndOpen(true);
        }
    }, []);

    const handleEndOpenChange = React.useCallback((open: boolean): void => {
        setEndOpen(open);
    }, []);

    const {} = props.form;

    return (
        <div>
            {
                <Form.Item name={props.startDateFieldName} noStyle>
                    <DatePicker
                        format="DD-MM-YYYY"
                        disabledDate={disabledStartDate}
                        placeholder="Select start date"
                        onOpenChange={handleStartOpenChange}
                    />
                </Form.Item>
            }
            &nbsp;
            {
                <Form.Item name={props.endDateFieldName} noStyle>
                    <DatePicker
                        format="DD-MM-YYYY"
                        disabledDate={disabledEndDate}
                        placeholder="Select end date"
                        open={endOpen}
                        onOpenChange={handleEndOpenChange}
                    />
                </Form.Item>
            }
        </div>
    );
};

export default PeriodDatePicker;
