import { Button, Collapse, Form, Select, Space } from 'antd';
import type { SelectProps } from 'antd';
import React, { useEffect } from 'react';
import { SearchOutlined } from '@ant-design/icons';
import { AllYesNoSelectOptions } from '../../constants';
// import { AdminFolderFilterForm, FolderStructure } from '../../models';
import PeriodDatePicker from './PeriodDatePicker';
import { ReportsHistoryFilterFormModel } from '../models/reportsHistoryModels';
import { DictionaryDto, AreaVm, LogSheetVm } from '../../services/Client';
const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

type Props = {
    total?: number;
    filterForm: ReportsHistoryFilterFormModel;
    isFilterFormExpanded: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logSheetsOptions: LogSheetVm[];
    onChange: (values: ReportsHistoryFilterFormModel) => void;
    onSubmit: () => void;
    onReset: () => void;
    onExpand: () => void;
};

const FilterPanelView = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref): JSX.Element => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        useEffect(() => {
            props.form.setFieldsValue(props.filterForm);
        }, [props.filterForm, props.form]);
        const activeKey = props.isFilterFormExpanded ? '1' : '';
        const { getFieldValue } = props.form;
        const allYesNoOptions = AllYesNoSelectOptions.map((item: NonNullable<SelectProps['options']>[number]) => (
            <Select.Option key={item.value} value={item.value}>
                {item.title}
            </Select.Option>
        ));
        const selectedLocationId = getFieldValue('locationId');
        const selectedAreaId = getFieldValue('areaId');
        let logSheets = props.logSheetsOptions;
        if (selectedLocationId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.locationId === selectedLocationId);
        }
        if (selectedAreaId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.areaId === selectedAreaId);
        }
        const logSheetsOptions = logSheets.map((item: LogSheetVm) => (
            <Select.Option key={item.id} value={item.id}>
                {item.name}
            </Select.Option>
        ));

        return (
            <Collapse
                onChange={props.onExpand}
                accordion={true}
                defaultActiveKey={activeKey}
                expandIconPosition="right"
                style={{ marginBottom: '10px' }}
                items={[
                    {
                        key: '1',
                        label: (
                            <b>
                                <SearchOutlined /> Search panel
                            </b>
                        ),
                        extra: <b style={{ color: '#1890ff' }}>Found {props.total} items</b>,
                        children: (
                            <Form
                                form={props.form}
                                initialValues={props.filterForm}
                                layout="horizontal"
                                onFinish={props.onSubmit}
                                onValuesChange={(_, values) => props.onChange(values as ReportsHistoryFilterFormModel)}
                            >
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Location"
                                                labelAlign="left"
                                                {...formItemLayout}
                                                name="locationId"
                                            >
                                                <Select placeholder="Select location">
                                                    {props.locations.map((item: DictionaryDto) => (
                                                        <Select.Option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </Select.Option>
                                                    ))}
                                                </Select>
                                            </Form.Item>
                                        </div>
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Area"
                                                labelAlign="left"
                                                {...formItemLayout}
                                                help="Please select location first"
                                                name="areaId"
                                            >
                                                <Select placeholder="Select area">
                                                    {props.areas
                                                        .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                                        .map((item: AreaVm) => (
                                                            <Select.Option key={item.id} value={item.id}>
                                                                {item.name}
                                                            </Select.Option>
                                                        ))}
                                                </Select>
                                            </Form.Item>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Log sheet"
                                                labelAlign="left"
                                                {...formItemLayout}
                                                name="logSheetId"
                                            >
                                                <Select
                                                    placeholder="Select log sheet"
                                                    showSearch
                                                    filterOption={(input: string, option: any) => {
                                                        return (
                                                            option.props.children
                                                                .toLowerCase()
                                                                .indexOf(input.toLowerCase()) >= 0
                                                        );
                                                    }}
                                                >
                                                    {logSheetsOptions}
                                                </Select>
                                            </Form.Item>
                                        </div>
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Schedule date"
                                                labelAlign="left"
                                                {...formItemLayout}
                                            >
                                                <PeriodDatePicker
                                                    form={props.form}
                                                    startDateFieldName="startDate"
                                                    endDateFieldName="endDate"
                                                />
                                            </Form.Item>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Has exceedance?"
                                                labelAlign="left"
                                                {...formItemLayout}
                                                name="hasExceedance"
                                            >
                                                <Select>{allYesNoOptions}</Select>
                                            </Form.Item>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-sm-6 col-xs-12 form-horizontal">
                                            <Form.Item
                                                className="searchFormItem"
                                                label="Has compliance?"
                                                labelAlign="left"
                                                {...formItemLayout}
                                                name="hasCompliance"
                                            >
                                                <Select>{allYesNoOptions}</Select>
                                            </Form.Item>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-sm-6 col-xs-12 pull-right">
                                            <Space.Compact className="pull-right">
                                                <Button type="primary" htmlType="submit">
                                                    Search
                                                </Button>
                                                <Button onClick={props.onReset}>Reset</Button>
                                            </Space.Compact>
                                        </div>
                                    </div>
                                </div>
                            </Form>
                        ),
                    },
                ]}
            />
        );
    },
);
export default FilterPanelView;
