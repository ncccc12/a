import React from 'react';
import { Drawer, Form, Select, Button } from 'antd';
import { EmployeeVm, GroupVm } from '../../services/Client';

export type SelectEmployeeForm = {
    groupCode: string;
    employeeId: number;
};

type Props = {
    visible: boolean;
    groups: GroupVm[];
    employees: EmployeeVm[];
    onSubmit: () => void;
    onClose: () => void;
};

const SelectEmployeeDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form, employees } = props;

        const [filteredEmployees, setFilteredEmployees] = React.useState<EmployeeVm[]>([]);
        const previousProps = React.useRef(props);

        const filterEmployees = React.useCallback(
            (code: string) => {
                let filteredEmployees = employees.filter((r) => r.groupCode === code);
                setFilteredEmployees(filteredEmployees);
            },
            [employees],
        );

        const handleGroupChange = React.useCallback(
            (code: string) => {
                filterEmployees(code);
                form.setFieldsValue({
                    employeeId: undefined,
                });
            },
            [filterEmployees, form],
        );

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
            } else {
                const prevProps = previousProps.current;
                if (!prevProps.visible && props.visible) {
                    let groupCode = form.getFieldValue('groupCode');
                    filterEmployees(groupCode);
                }
                previousProps.current = props;
            }
        });

        const {
            visible: visible,
            form: {},
            groups: groups,
        } = props;

        const formItemLayout = {
            labelCol: {
                span: 10,
            },
            wrapperCol: {
                span: 14,
            },
        };

        return (
            <Drawer title="Select Employee" open={visible} width={700} onClose={props.onClose}>
                <Form form={props.form} labelAlign="left" {...formItemLayout}>
                    <Form.Item
                        label="Group"
                        name="groupCode"
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Select onChange={handleGroupChange}>
                            {groups.map((r) => {
                                return (
                                    <Select.Option key={r.code} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>
                    </Form.Item>

                    <Form.Item
                        label="Employee"
                        name="employeeId"
                        rules={[
                            {
                                required: true,
                            },
                        ]}
                    >
                        <Select>
                            {filteredEmployees.map((r) => {
                                return (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.lastName + ' ' + r.firstName}
                                    </Select.Option>
                                );
                            })}
                        </Select>
                    </Form.Item>
                </Form>

                <div
                    style={{
                        position: 'absolute',
                        right: 0,
                        bottom: 0,
                        width: '100%',
                        borderTop: '1px solid #e9e9e9',
                        padding: '10px 16px',
                        background: '#fff',
                        textAlign: 'right',
                    }}
                >
                    <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                        Cancel
                    </Button>
                    <Button type="primary" onClick={props.onSubmit}>
                        Submit
                    </Button>
                </div>
            </Drawer>
        );
    },
);

const SelectEmployeeDrawer = SelectEmployeeDrawerInner;

export default SelectEmployeeDrawer;
