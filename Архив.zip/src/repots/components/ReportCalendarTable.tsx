import React, { Fragment } from 'react';
import dayjs, { type Dayjs } from '@dayjs';
import { Row, Tag } from 'antd';
import generateScheduleSrv from '../../schedule/GenerateScheduleService';
import { ReportScheduleConfig, ReportGroupConfig } from '../types';
import { RotationCalendarType } from '../../schedule/constants';
import TimeHistoriesModal from '../components/TimeHistoriesModal';
import { reportsClient } from '../../services';
import { ReportDailyInfoVm, ScheduleReportInfos } from '../../services/Client';

type Props = {
    scheduleConfig: ReportScheduleConfig;
};

const ReportCalendarTable: React.FC<Props> = (props) => {
    const { scheduleConfig } = props;

    const [months, setMonths] = React.useState<Dayjs[]>([]);
    const [timeHistoryModalShown, setTimeHistoryModalShown] = React.useState<boolean>(false);
    const [dailytimeHistories, setDailytimeHistories] = React.useState<ReportDailyInfoVm[]>([]);

    const openGroupDetailsModal = async (groupCode: string, monthDate: Dayjs) => {
        let normDate = monthDate.utc(true).toDate();
        let timeHistories = await reportsClient.getGroupReportInfoByDay(scheduleConfig.id, groupCode, normDate);

        setTimeHistoryModalShown(true);
        setDailytimeHistories(timeHistories);
    };

    const openDetailsModal = async (monthDate: Dayjs) => {
        let normDate = monthDate.utc(true).toDate();
        let timeHistories = await reportsClient.getReportInfoByDay(scheduleConfig.id, normDate);

        setTimeHistoryModalShown(true);
        setDailytimeHistories(timeHistories);
    };

    function getGroupItemRow(group: ReportGroupConfig, month: Dayjs): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            const monthDate: Dayjs = dayjs([month.year(), month.month(), day]);
            const monthDayOfYear: number = monthDate.dayOfYear();

            let dayType: string = '';
            switch (group.schedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let tags = [];
            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.NotFilled) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'g'} color="grey">
                        E
                    </Tag>,
                );
            }

            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.HasExceedance) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'r'} color="red">
                        {'>'}
                    </Tag>,
                );
            }

            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.Filled) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'gr'} color="green">
                        OK
                    </Tag>,
                );
            }

            switch (group.reportSchedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let className = 'editable ';

            className = dayType ? className + ' ' : className;

            return (
                <td
                    key={monthDayOfYear + ' ' + group.code}
                    className={className}
                    onDoubleClick={() => openGroupDetailsModal(group.code, monthDate)}
                >
                    <Row justify="center" align="middle">
                        {tags}
                    </Row>
                </td>
            );
        });
    }

    function getGroupRows(month: Dayjs): JSX.Element {
        return (
            <Fragment key={month.month() + '_'}>
                <tr>
                    <td rowSpan={2}>Group 1/2</td>
                    <td>{scheduleConfig!.group1!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group1!, month)}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group2!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group2!, month)}
                </tr>
                <tr>
                    <td rowSpan={2}>Group 3/4</td>
                    <td>{scheduleConfig!.group3!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group3!, month)}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group4!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group4!, month)}
                </tr>
            </Fragment>
        );
    }

    function getMonthHeaderTHs(month: Dayjs): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            let monthDate = dayjs([month.year(), month.month(), day]);

            return (
                <th key={day} onDoubleClick={() => openDetailsModal(monthDate)}>
                    {day}
                </th>
            );
        });
    }

    function getMonthRows(): JSX.Element[] {
        const rows: JSX.Element[] = [];

        months.forEach((month: Dayjs) => {
            const monthRow: JSX.Element = (
                <tr key={month.month()} style={{ height: 40 }}>
                    <th rowSpan={2 * 2 + 1}>{month.month() + 1}</th>
                    <th colSpan={2}>{dayjs.months()[month.month()]}</th>
                    {getMonthHeaderTHs(month)}
                </tr>
            );

            const groupRows: JSX.Element = getGroupRows(month);

            rows.push(monthRow);
            rows.push(groupRows);
        });

        return rows;
    }

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            let months: Dayjs[] = [];

            for (let i = 0; i < 12; i++) {
                const currMonth = dayjs([scheduleConfig.year!, i, 1]);
                months.push(currMonth);
            }

            setMonths(months);
        }
    });

    return (
        <Row className="schedule-config">
            <Row justify="end">
                <div>
                    <Tag color="grey">E</Tag> - Not filled
                    <Tag color="red" style={{ marginLeft: 15 }}>
                        {'>'}
                    </Tag>
                    - Has exceedance
                    <Tag color="green" style={{ marginLeft: 15 }}>
                        OK
                    </Tag>
                    - Filled
                </div>
            </Row>
            <br />

            <table>
                <tbody>{getMonthRows()}</tbody>
            </table>
            <TimeHistoriesModal
                visible={timeHistoryModalShown}
                dailyTimeHistories={dailytimeHistories}
                onOk={() => {}}
                onCancel={() => {
                    setTimeHistoryModalShown(false);
                }}
            />
        </Row>
    );
};

export default ReportCalendarTable;
