import { InfoCircleOutlined } from '@ant-design/icons';
import React from 'react';
import { Modal, Table, Tag, Button } from 'antd';
import { ReportDailyInfoVm, ScheduleReportInfos } from '../../services/Client';
import dayjs, { type Dayjs } from '@dayjs';
import { Link, RouteComponentProps } from 'react-router-dom';
import { withRouter } from 'react-router-dom';

type Props = {
    visible: boolean;
    dailyTimeHistories: ReportDailyInfoVm[];
    onOk: (e: any) => void;
    onCancel: (e: any) => void;
} & RouteComponentProps<any>;

const TimeHistoriesModal: React.FC<Props> = (props) => {
    const { visible, dailyTimeHistories } = props;

    const renderStatus = React.useCallback((status: ScheduleReportInfos) => {
        switch (status) {
            case ScheduleReportInfos.NotFilled:
                return <Tag color="grey">Not filled</Tag>;
            case ScheduleReportInfos.HasExceedance:
                return <Tag color="red">Has exceedance</Tag>;
            case ScheduleReportInfos.Filled:
                return <Tag color="green">Filled</Tag>;
            case ScheduleReportInfos.ValuesUploaded:
                return <Tag color="#108ee9">Values uploaded(pending images)</Tag>;
            default:
                break;
        }
    }, []);

    return (
        <Modal
            open={visible}
            width={1200}
            centered={true}
            title="Tasks by day"
            footer={null}
            onOk={props.onOk}
            onCancel={props.onCancel}
        >
            <Table rowKey={(r) => r.timeHistoryId + ''} dataSource={dailyTimeHistories}>
                <Table.Column title="Logsheet Id" dataIndex="logsheetId"></Table.Column>
                <Table.Column title="Logsheet name" dataIndex="logsheetName"></Table.Column>
                <Table.Column
                    title="Datetime"
                    dataIndex="date"
                    render={(date) => dayjs(date).format('DD.MM.YYYY HH:mm')}
                ></Table.Column>
                <Table.Column title="Status" dataIndex="status" render={renderStatus}></Table.Column>
                <Table.Column
                    title="View details"
                    render={(r: ReportDailyInfoVm) => (
                        <Link to={`/reports/general/${r.timeHistoryId}`}>
                            <Button icon={<InfoCircleOutlined />} />
                        </Link>
                    )}
                ></Table.Column>
            </Table>
        </Modal>
    );
};

export default withRouter(TimeHistoriesModal);
