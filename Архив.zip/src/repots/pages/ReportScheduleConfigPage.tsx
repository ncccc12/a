import React from 'react';
import { Card, Typography } from 'antd';
import ReportScheduleConfigContainer from '../containers/ReportScheduleConfigContainer';
import { RouteComponentProps } from 'react-router-dom';

type Params = {
    id: string;
};

export default (props: RouteComponentProps<Params>) => (
    <Card title={<Typography.Title>Schedule config report</Typography.Title>}>
        <ReportScheduleConfigContainer id={parseInt(props.match.params.id)} />
    </Card>
);
