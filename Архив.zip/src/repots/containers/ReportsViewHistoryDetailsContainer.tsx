import { message } from '../../common/antdFeedback';
import { EditOutlined, EyeOutlined } from '@ant-design/icons';
import React from 'react';
import { Typography, Card, Row, Descriptions, Tag, Modal, Table, Button, Spin } from 'antd';
import {
    LogSheetVm,
    GroupDto,
    DictionaryDto,
    ListTypeValueVm,
    UpdateTagDataCommand,
    GetGroupsQuery,
    GroupVm,
    GetEmployeesQuery,
    EmployeeVm,
    UpdateTimeHistoryEmployeeCommand,
} from '../../services/Client';
import dayjs, { type Dayjs } from '@dayjs';
import { dictionaryClient, employeesClient, groupsClient, reportsClient } from '../../services';
import logsheetService from '../../logsheets/LogsheetsService';
import { DeviceTag } from '../../logsheets/containers/LogsheetDetailsContainer';
import type { FormInstance } from 'antd';
import TagDrawer, { TagForm } from '../../logsheets/components/TagDrawer';
import SelectEmployeeDrawer, { SelectEmployeeForm } from '../components/SelectEmployeeDrawer';

type Props = {
    id: number;
};

const ViewAttachmentModal = ({
    attachment,
    visible,
    onCancel,
}: {
    attachment: string;
    visible: boolean;
    onCancel: () => void;
}) => (
    <Modal open={visible} title="View attachment" footer={null} onCancel={onCancel}>
        <Row justify="center">
            {<img style={{ width: 450 }} src={`data:image/jpeg;base64,${attachment}`} alt="Attachment" />}
        </Row>
    </Modal>
);

const ReportsViewHistoryDetailsContainer: React.FC<Props> = (props) => {
    const { id } = props;

    const [isViewAttachmentModalVisible, setIsViewAttachmentModalVisible] = React.useState<boolean>(false);
    const [attachment, setAttachment] = React.useState<string>('');
    const [selectedGroups, setSelectedGroups] = React.useState<Array<{ id: number; name: string }>>([]);
    const [tagDrawerShown, setTagDrawerShown] = React.useState<boolean>(false);
    const [dataTypes, setDataTypes] = React.useState<DictionaryDto[]>([]);
    const [listTypeValues, setListTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [listTypes, setListTypes] = React.useState<DictionaryDto[]>([]);
    const [unitOfMeasurements, setUnitOfMeasurements] = React.useState<DictionaryDto[]>([]);
    const [loading, setLoading] = React.useState<boolean>(false);
    const [groups, setGroups] = React.useState<GroupVm[]>([]);
    const [employees, setEmployees] = React.useState<EmployeeVm[]>([]);
    const [employeeDrawerShown, setEmployeeDrawerShown] = React.useState<boolean>(false);
    const [logsheet0, setLogsheet] = React.useState<LogSheetVm>();
    const [selectedGroup, setSelectedGroup] = React.useState<GroupDto>();
    const tagDrawerRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const employeeDrawerRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);

    const loadLogSheetsHistoryDetails = React.useCallback(async (id: number) => {
        const result = await reportsClient.getLogSheetTimeHistoryDetails(id);

        setLogsheet(result);
    }, []);

    const loadDictionaries = React.useCallback(async () => {
        let dataTypes = await dictionaryClient.getDictionary('DataTypes');
        let listTypes = await dictionaryClient.getDictionary('ListTypes');
        let listTypeValues = await dictionaryClient.getListTypeValues();
        let unitOfMeasurements = await dictionaryClient.getDictionary('UnitOfMeasurements');

        let groupsQuery = new GetGroupsQuery();
        groupsQuery.areaCode = logsheet0 && logsheet0.areaCode;
        groupsQuery.isActive = [1];
        let groups = await groupsClient.getGroups(groupsQuery);

        let employeesQuery = new GetEmployeesQuery();
        employeesQuery.areaCode = logsheet0 && logsheet0.areaCode;
        employeesQuery.isActive = [1];
        let employees = await employeesClient.getEmployees(employeesQuery);

        setDataTypes(dataTypes);
        setListTypes(listTypes);
        setListTypeValues(listTypeValues);
        setUnitOfMeasurements(unitOfMeasurements);
        setGroups(groups);
        setEmployees(employees);
    }, [logsheet0]);

    const loadData = React.useCallback(async () => {
        setLoading(true);
        await loadLogSheetsHistoryDetails(id);
        await loadDictionaries();
        setLoading(false);
    }, [id, loadDictionaries, loadLogSheetsHistoryDetails]);

    const handleOpenAttachmentModal = (image: string) => {
        setIsViewAttachmentModalVisible(true);
        setAttachment(image);
    };

    const handleCloseAttachmentModal = React.useCallback(() => {
        setIsViewAttachmentModalVisible(false);
    }, []);

    function getGroupTree(
        groups: GroupDto[] | undefined,
        level: number,
        parentGroup: GroupDto | undefined,
    ): JSX.Element {
        let devices = groups && groups.filter((r) => r.isDevice);

        if (devices && devices.length) {
            let devicesAndGroup = [...devices];
            if (parentGroup) devicesAndGroup.unshift(parentGroup);

            return renderTable(devicesAndGroup);
        } else {
            return (
                <>
                    {groups &&
                        groups.map((g: GroupDto) => {
                            let hasOnlyTasks = g.childGroups?.length === 0 && g.tasks?.length;

                            return (
                                <Card key={g.id} type="inner" title={g.name} style={{ margin: '15px 0' }}>
                                    {g.childGroups &&
                                        g.childGroups.length > 0 &&
                                        getGroupTree(g.childGroups, level + 1, g)}

                                    {hasOnlyTasks && renderTable([g])}
                                </Card>
                            );
                        })}
                </>
            );
        }
    }

    const renderTable = (groups: GroupDto[]) => {
        let tags: DeviceTag[] = groups.flatMap((r) => {
            return r.tasks!.map((t) => logsheetService.mapTaskDtoToDeviceType(r, t));
        });

        let parentGroups = groups.map((r) => ({
            id: r.id!,
            name: r.name!,
        }));

        // let parentGroup = groups.filter(r => r.isDevice === false)[0];
        return (
            <Table
                dataSource={tags}
                rowKey={(r) => r.id + ''}
                pagination={{ hideOnSinglePage: true, defaultPageSize: 30 }}
            >
                <Table.Column dataIndex="groupName" title="Group/Device name" width={200}></Table.Column>
                <Table.Column dataIndex="name" title="Tag name" width={200}></Table.Column>
                <Table.Column dataIndex="dataTypeName" title="Data type"></Table.Column>
                <Table.Column dataIndex="listTypeName" title="List type name" width={100}></Table.Column>
                <Table.Column
                    dataIndex="listTypeValues"
                    title="List type values"
                    key="values"
                    width={150}
                    render={(vals) => (
                        <span>
                            {vals.map((r: string) => (
                                <Tag color="blue" key={r}>
                                    {r}
                                </Tag>
                            ))}
                        </span>
                    )}
                ></Table.Column>
                <Table.Column dataIndex="minValue" title="Min value"></Table.Column>
                <Table.Column dataIndex="maxValue" title="Max value"></Table.Column>
                <Table.Column dataIndex="unitOfMeasurementName" title="Unit of measurement"></Table.Column>
                <Table.Column
                    dataIndex="isRequired"
                    title="Is Required"
                    render={(isRequired: boolean) => (isRequired ? 'Yes' : 'No')}
                ></Table.Column>
                <Table.Column
                    title="Value"
                    render={(r: DeviceTag) => {
                        let color = r.isSkipped ? 'grey' : r.isExceed ? 'red' : 'green';
                        return r.value && <Tag color={color}>{r.value}</Tag>;
                    }}
                ></Table.Column>
                <Table.Column dataIndex="comment" title="Comment"></Table.Column>
                <Table.Column
                    title="Attachment"
                    render={(row: DeviceTag) => {
                        return (
                            row.hasAttachments && (
                                <EyeOutlined
                                    title="View attachment"
                                    onClick={() => handleOpenAttachmentModal(row.attachment!)}
                                />
                            )
                        );
                    }}
                ></Table.Column>
                <Table.Column
                    title="Actions"
                    render={(row: DeviceTag) => (
                        <>
                            <Button
                                shape="circle"
                                icon={<EditOutlined />}
                                title="edit"
                                onClick={() => openTagDrawer(row, parentGroups)}
                            ></Button>
                        </>
                    )}
                ></Table.Column>
            </Table>
        );
    };

    const openTagDrawer = (tag: DeviceTag, parentGroups: Array<{ id: number; name: string }> = []) => {
        const form = tagDrawerRef.current!.form as FormInstance;
        const { dataTypeName, listTypeName, unitOfMeasurementName, ...tagValues } = tag;

        form.setFieldsValue({
            ...tagValues,
        });

        setSelectedGroups(parentGroups);
        setTagDrawerShown(true);
    };

    const submitTagValue = React.useCallback(() => {
        const form = tagDrawerRef.current!.form as FormInstance;
        form.validateFields()
            .then(async (values: TagForm) => {
                try {
                    setLoading(true);
                    let updateCommand = new UpdateTagDataCommand();
                    updateCommand.id = values.taskValueId;
                    updateCommand.value = values.value;
                    updateCommand.comment = values.comment;
                    reportsClient.updateTagData(updateCommand);
                    message.success('Successfully updated');
                    await loadData();
                    setTagDrawerShown(false);
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [loadData]);

    const openEmployeeDrawer = () => {
        const form = employeeDrawerRef.current!.form as FormInstance;

        form.setFieldsValue({
            groupCode: logsheet0?.filledByGroupCode,
            employeeId: logsheet0?.filledById,
        });

        setEmployeeDrawerShown(true);
    };

    const submitEmployee = React.useCallback(() => {
        const form = employeeDrawerRef.current!.form as FormInstance;

        form.validateFields()
            .then(async (values: SelectEmployeeForm) => {
                try {
                    setLoading(true);
                    let command = new UpdateTimeHistoryEmployeeCommand();
                    command.timeHistoryId = props.id;
                    command.employeeId = values.employeeId;
                    await reportsClient.updateTimeHistoryEmployee(command);
                    message.success('Successfully updated');
                    await loadData();
                    setEmployeeDrawerShown(false);
                } finally {
                    setLoading(false);
                }
            })
            .catch((err: any) => {
                return undefined;
            });
    }, [loadData, props.id]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadData();
        }
    });

    const logsheet = logsheet0;

    return (
        <Card>
            <Typography.Title>Logsheet report details</Typography.Title>
            <Spin spinning={loading}>
                {logsheet && (
                    <Card title={logsheet.name}>
                        <Card.Meta
                            description={
                                <Descriptions>
                                    <Descriptions.Item label="Area">{logsheet.areaName}</Descriptions.Item>
                                    <Descriptions.Item label="Location">{logsheet.locationName}</Descriptions.Item>
                                    <Descriptions.Item label="Schedule time">
                                        {logsheet.date && dayjs(logsheet.date).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Created">
                                        {dayjs(logsheet.created).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Filled by">
                                        {logsheet.filledBy}
                                        <Button
                                            style={{ marginLeft: 5 }}
                                            icon={<EditOutlined />}
                                            shape="circle"
                                            title="Edit"
                                            onClick={() => openEmployeeDrawer()}
                                        ></Button>
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Last modified">
                                        {dayjs(logsheet.lastModified).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Last modified by">
                                        {logsheet.lastModifiedBy}
                                    </Descriptions.Item>
                                </Descriptions>
                            }
                        />

                        {logsheet && <Row>{getGroupTree(logsheet.groups, 0, undefined)}</Row>}
                    </Card>
                )}
            </Spin>
            <ViewAttachmentModal
                visible={isViewAttachmentModalVisible}
                attachment={attachment}
                onCancel={handleCloseAttachmentModal}
            />

            <TagDrawer
                visible={tagDrawerShown}
                editOnlyValues={true}
                ref={(ref: { form: import('antd').FormInstance } | null) => (tagDrawerRef.current = ref)}
                dataTypes={dataTypes}
                listTypes={listTypes}
                listTypeValues={listTypeValues}
                unitOfMeasurements={unitOfMeasurements}
                groups={selectedGroups}
                onSubmit={submitTagValue}
                onClose={() => setTagDrawerShown(false)}
            />

            <SelectEmployeeDrawer
                visible={employeeDrawerShown}
                ref={(ref: { form: import('antd').FormInstance } | null) => (employeeDrawerRef.current = ref)}
                groups={groups}
                employees={employees}
                onClose={() => setEmployeeDrawerShown(false)}
                onSubmit={submitEmployee}
            />
        </Card>
    );
};

export default ReportsViewHistoryDetailsContainer;
