import React from 'react';
import { Form, DatePicker, Button } from 'antd';

import fileDownload from 'js-file-download';
import { reportsClient } from '../../services';

type Props = {};

const ReportsDailyContainerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const [isLoading, setIsLoading] = React.useState<boolean>(false);

        const handleFormSubmit = React.useCallback(() => {
            props.form
                .validateFields()
                .then(async (values) => {
                    setIsLoading(true);
                    const response = await reportsClient.getReportByPeriod(values);
                    fileDownload(response.data, response.fileName!);
                    setIsLoading(false);
                })
                .catch((errors) => {
                    return undefined;
                });
        }, [props.form]);

        const {} = props.form;

        return (
            <Form form={props.form} layout="inline" onFinish={handleFormSubmit}>
                <Form.Item
                    label="Date"
                    name="date"
                    rules={[
                        {
                            required: true,
                            message: 'Please select date',
                        },
                    ]}
                >
                    <DatePicker format="DD-MM-YYYY" />
                </Form.Item>
                <Form.Item>
                    <Button htmlType="submit" loading={isLoading} type="primary">
                        Export
                    </Button>
                </Form.Item>
            </Form>
        );
    },
);

const ReportsDailyContainer = ReportsDailyContainerInner;

export default ReportsDailyContainer;
