import React from 'react';
import { Button, Form, Select, Spin } from 'antd';
import { dictionaryClient, logSheetsClient, reportsClient } from '../../services';
import {
    LogsheetDictionaryVm,
    DeviceVm,
    GetReportByDeviceQuery,
    GetTagsQuery,
    TagVm,
    DictionaryDto,
    AreaVm,
} from '../../services/Client';
import { Space } from 'antd';
import { DatePicker } from 'antd';
import fileDownload from 'js-file-download';
import dayjs, { type Dayjs } from '@dayjs';

type FilterForm = {
    logsheetId: number;
    deviceIds: number[];
    tagIds: number[];
    datePeriod: Dayjs[];
};

type Props = {};

const { RangePicker } = DatePicker;

const ReportByDeviceContainerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form } = props;

        const [loading, setLoading] = React.useState<boolean>(false);
        const [logsheets0, setLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
        const [devices, setDevices] = React.useState<DeviceVm[]>([]);
        const [filteredDevices, setFilteredDevices] = React.useState<DeviceVm[]>([]);
        const [tags, setTags] = React.useState<TagVm[]>([]);
        const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
        const [areas, setAreas] = React.useState<AreaVm[]>([]);

        const loadData = async () => {
            let logsheets = await dictionaryClient.getLogsheets();
            const locations = await dictionaryClient.getLocations();
            const areas = await dictionaryClient.getAreas();

            setLogsheets(logsheets);
            setLocations(locations);
            setAreas(areas);
        };

        const handleLogsheetChange = React.useCallback(
            async (id: number) => {
                let devices = await logSheetsClient.getDevices(id);
                setFilteredDevices(devices);

                form.setFieldsValue({
                    deviceIds: [],
                });
            },
            [form],
        );

        const handleDeviceChange = React.useCallback(async (deviceIds: number[]) => {
            let query = new GetTagsQuery();
            query.deviceIds = deviceIds;
            let tags = await logSheetsClient.getTags(query);
            setTags(tags);
        }, []);

        const generateReport = React.useCallback(() => {
            form.validateFields()
                .then(async (values: FilterForm) => {
                    try {
                        setLoading(true);
                        let query = new GetReportByDeviceQuery();
                        query.logsheetId = values.logsheetId;
                        query.deviceIds = values.deviceIds;
                        query.tagIds = values.tagIds || [];
                        query.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                        let response = await reportsClient.getReportByDevice(query);
                        fileDownload(response.data, response.fileName!);
                    } finally {
                        setLoading(false);
                    }
                })
                .catch((err: any) => {
                    return undefined;
                });
        }, [form]);

        const resetFilter = React.useCallback(() => {
            form.resetFields();
        }, [form]);

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                loadData();
            }
        });

        const {
            form: { getFieldValue: getFieldValue },
        } = props;

        const selectStyle = {
            width: 250,
        };

        const selectedLocationId = getFieldValue('locationId');
        const selectedAreaCode = getFieldValue('areaCode');

        let logsheets = logsheets0;
        if (selectedAreaCode !== undefined) {
            logsheets = logsheets.filter((item: LogsheetDictionaryVm) => item.areaCode === selectedAreaCode);
        }

        return (
            <Spin spinning={loading}>
                <Form form={props.form} labelAlign="left" layout="inline">
                    <Form.Item label="Location" name="locationId">
                        <Select style={{ width: 150 }} placeholder="Select location">
                            {locations.map((item: DictionaryDto) => (
                                <Select.Option key={item.id} value={item.id}>
                                    {item.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item label="Area" help="Please select location first" name="areaCode">
                        <Select placeholder="Select area">
                            {areas
                                .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                .map((item: AreaVm) => (
                                    <Select.Option key={item.id} value={item.code}>
                                        {item.name}
                                    </Select.Option>
                                ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        label="Logsheet"
                        name="logsheetId"
                        rules={[
                            {
                                required: true,
                                message: 'Logsheet is required',
                            },
                        ]}
                    >
                        <Select
                            style={{ width: 450 }}
                            showSearch
                            optionFilterProp="children"
                            onChange={handleLogsheetChange}
                        >
                            {logsheets.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Devices" name="deviceIds">
                        <Select
                            style={selectStyle}
                            mode="multiple"
                            showSearch
                            optionFilterProp="children"
                            onChange={handleDeviceChange}
                        >
                            {filteredDevices.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="Tags" name="tagIds">
                        <Select style={selectStyle} mode="multiple" showSearch optionFilterProp="children">
                            {tags.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item
                        label="Date period"
                        name="datePeriod"
                        rules={[
                            {
                                required: true,
                                message: 'Date period is required',
                            },
                        ]}
                    >
                        <RangePicker format="DD-MM-YYYY" />
                    </Form.Item>

                    <Form.Item>
                        <Space.Compact>
                            <Button type="primary" onClick={generateReport}>
                                Generate report
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </Space.Compact>
                    </Form.Item>
                </Form>
            </Spin>
        );
    },
);

const ReportByDeviceContainer = ReportByDeviceContainerInner;

export default ReportByDeviceContainer;
