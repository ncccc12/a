import React from 'react';
import { Typography, Table, Button, Tag, Card } from 'antd';
import {
    LogSheetTimeHistoryVm,
    GetLogSheetTimeHistoryQuery,
    DictionaryDto,
    AreaVm,
    GetLogsheetsQuery,
} from '../../services/Client';
import { dictionaryClient, reportsClient, logSheetsClient } from '../../services';
import dayjs, { type Dayjs } from '@dayjs';
import type { PaginationProps } from 'antd';
import { connect } from 'react-redux';
import {
    ReportsHistoryFilterFormState,
    changeFilterForm,
    changePage,
    changePageSize,
    expandFilterForm,
    resetFilterForm,
} from '../ducks/ReportsHistoryFilterFormDuck';
import { AppState } from '../../store/reducers';
import FilterPanel from '../components/FilterPanel';
import { Link, RouteComponentProps, withRouter } from 'react-router-dom';

const mapStateToProps = (state: AppState): ReportsHistoryFilterFormState => ({
    filterForm: state.reportsHistoryFilterFormDuck.filterForm,
    isFilterFormExpanded: state.reportsHistoryFilterFormDuck.isFilterFormExpanded,
});

const mapDispatchToProps = {
    changeFilterForm,
    changePage,
    resetFilterForm,
    expandFilterForm,
    changePageSize,
};

type Props = {} & typeof mapDispatchToProps & ReportsHistoryFilterFormState & RouteComponentProps<any>;

const HistoryContainerInner: React.FC<Props> = (props) => {
    const { filterForm, changePage: changePage0, resetFilterForm: resetFilterForm0 } = props;

    const [isLoading, setIsLoading] = React.useState<boolean>(false);
    const [fetchData, setFetchData] = React.useState<boolean>(false);
    const [data, setData] = React.useState<LogSheetTimeHistoryVm[]>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [logSheetsOptions, setLogSheetsOptions] = React.useState<LogSheetTimeHistoryVm[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [total, setTotal] = React.useState<number>(0);
    const previousProps = React.useRef(props);

    const loadLogSheetsHistory = async () => {
        setIsLoading(true);
        var formData = new GetLogSheetTimeHistoryQuery();
        formData.init(filterForm);
        formData.startDate = filterForm.startDate?.utc(true).startOf('day').toDate();
        formData.endDate = filterForm.endDate?.utc(true).endOf('day').toDate();

        const result = await reportsClient.getLogSheetTimeHistories(formData);
        setData(result.data!);
        setTotal(result.total!);
        setIsLoading(false);
    };

    const loadDictionaries = async () => {
        setIsLoading(true);
        const locations = await dictionaryClient.getLocations();
        const areas = await dictionaryClient.getAreas();

        let query = new GetLogsheetsQuery();

        const logSheetsOptions = await logSheetsClient.getLogsheets(query);

        setLocations(locations);
        setAreas(areas);
        setLogSheetsOptions(logSheetsOptions);
        setIsLoading(false);
    };

    const handlePageChange = React.useCallback(
        (page: number) => {
            changePage0(page);
            setFetchData(true);
        },
        [changePage0],
    );

    const handleSearch = React.useCallback((): void => {
        setFetchData(true);
    }, []);

    const handleReset = React.useCallback((): void => {
        resetFilterForm0();
        setFetchData(true);
    }, [resetFilterForm0]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                setFetchData(true);
                loadDictionaries();
            } else {
                const prevProps = previousProps.current;
                if (fetchData) {
                    setFetchData(false);
                    await loadLogSheetsHistory();
                }
                previousProps.current = props;
            }
        })();
    });

    const paginationConfig: PaginationProps = {
        current: props.filterForm.current,
        pageSize: 10,
        onChange: handlePageChange,
        total: total,
    };

    return (
        <Card title={<Typography.Title>General reports</Typography.Title>}>
            <FilterPanel
                onExpand={props.expandFilterForm}
                onReset={handleReset}
                onSubmit={handleSearch}
                total={total}
                locations={locations}
                areas={areas}
                logSheetsOptions={logSheetsOptions}
                onChange={props.changeFilterForm}
                isFilterFormExpanded={props.isFilterFormExpanded}
                filterForm={props.filterForm}
            />
            <Table
                dataSource={data}
                loading={isLoading}
                expandRowByClick={true}
                pagination={paginationConfig}
                rowKey={(i: LogSheetTimeHistoryVm) => i.id!.toString()}
            >
                <Table.Column dataIndex="id" title="#" />
                <Table.Column dataIndex="logSheetName" title="Log sheet name" />
                <Table.Column dataIndex="areaName" title="Area" />
                <Table.Column dataIndex="locationName" title="Location" />
                <Table.Column
                    key="date"
                    dataIndex="date"
                    title="Date"
                    render={(i: Date) => {
                        return dayjs(i).format('DD-MM-YYYY');
                    }}
                />
                <Table.Column
                    key="time"
                    dataIndex="date"
                    title="Time"
                    render={(i: Date) => {
                        return dayjs(i).format('HH:mm');
                    }}
                />
                <Table.Column
                    key="report"
                    title=""
                    width={100}
                    render={(i: LogSheetTimeHistoryVm) => {
                        return (
                            <span>
                                {i!.hasExceedance && (
                                    <Tag style={{ marginBottom: 2 }} color="red">
                                        Exceedance
                                    </Tag>
                                )}
                                {i!.hasCompliance && <Tag color="orange">Compliance</Tag>}
                            </span>
                        );
                    }}
                />
                <Table.Column
                    key="actions"
                    title=""
                    render={(i: LogSheetTimeHistoryVm) => {
                        return (
                            <Link to={`/reports/general/${i.id}`}>
                                <Button type="primary">View details</Button>
                            </Link>
                        );
                    }}
                />
            </Table>
        </Card>
    );
};

const HistoryContainer = connect(mapStateToProps, mapDispatchToProps)(HistoryContainerInner);

export default withRouter(HistoryContainer);
