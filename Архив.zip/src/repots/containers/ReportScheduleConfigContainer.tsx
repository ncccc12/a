import React from 'react';
import { reportsClient } from '../../services';
import ScheduleConfigDetails from '../components/ScheduleConfigDetails';
import { Spin } from 'antd';
import ReportCalendarTable from '../components/ReportCalendarTable';
import { ReportScheduleConfig } from '../types';
import generateScheduleSrv from '../../schedule/GenerateScheduleService';

type Props = {
    id: number;
};

const ReportScheduleConfigContainer: React.FC<Props> = (props) => {
    const [loading, setLoading] = React.useState<boolean>(true);
    const [reportScheduleConfig, setReportScheduleConfig] = React.useState<ReportScheduleConfig>();
    const configFormRef = React.useRef<{ form: import('antd').FormInstance } | null>(null);
    const isMounted = React.useRef(false);

    React.useEffect(() => {
        void (async () => {
            if (!isMounted.current) {
                isMounted.current = true;
                let configVm = await reportsClient.getScheduleConfig(props.id);
                let reportConfig = generateScheduleSrv.mapVmToReportScheduleConfig(configVm);

                setReportScheduleConfig(reportConfig);
                setLoading(false);
            }
        })();
    });

    return (
        <Spin spinning={loading}>
            <ScheduleConfigDetails scheduleConfig={reportScheduleConfig} />
            {reportScheduleConfig && <ReportCalendarTable scheduleConfig={reportScheduleConfig} />}
        </Spin>
    );
};

export default ReportScheduleConfigContainer;
