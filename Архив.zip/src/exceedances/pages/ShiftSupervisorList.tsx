import React from 'react';
import { Typography, Card } from 'antd';
import ShiftSupervisorList from '../containers/ShiftSupervisorList';

export default () => (
    <Card>
        <Typography.Title></Typography.Title>
        <ShiftSupervisorList />
    </Card>
);
