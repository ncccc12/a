import React from 'react';
import ResolvedExceedancesContainer from '../containers/ResolvedExceedancesContainer';

export default () => <ResolvedExceedancesContainer />;
