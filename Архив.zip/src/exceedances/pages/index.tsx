import SupervisorsListPage from './SupervisorsListPage';
import SubmitedExceedancePage from './SubmitedExceedancePage';
import ResolvedExceedancesListPage from './ResolveExceedancesListPage';
//import ExceedancesListPage from './ExceedancesListPage';

export {
    SubmitedExceedancePage,
    SupervisorsListPage,
    ResolvedExceedancesListPage,
    //ExceedancesListPage
};
