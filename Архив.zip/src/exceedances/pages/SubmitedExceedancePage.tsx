import React from 'react';
import { Typography, Card } from 'antd';
import SubmitedExceedanceContainer from '../containers/SubmitedExceedanceContainer';
import ResolvedExceedancesContainer from '../containers/ResolvedExceedancesContainer';

export default () => (
    <Card>
        <Typography.Title></Typography.Title>
        <SubmitedExceedanceContainer />
    </Card>
);
