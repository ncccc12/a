import React from 'react';
import { Typography, Card } from 'antd';
import RunMaintainContainer from '../containers/RunMaintainListContainer';

export default () => (
    <Card>
        <Typography.Title></Typography.Title>
        <RunMaintainContainer />
    </Card>
);
