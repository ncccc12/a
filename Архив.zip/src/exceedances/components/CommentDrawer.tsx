import React from 'react';
import { Drawer, Form, Input, Select, Tag, InputNumber, Button, Switch } from 'antd';
import { DictionaryDto, ExceedancesVm, ListTypeValueVm } from '../../services/Client';
export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    groups: ExceedancesVm;
    onSubmit: () => void;
    onClose: () => void;
};

const CommentDrawerInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>((externalProps, ref) => {
    const [injectedForm] = Form.useForm();
    React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
    const props = {
        ...externalProps,
        form: injectedForm,
    } as typeof externalProps & { form: typeof injectedForm };
    const { form: form0 } = props;

    const [filteredLisTypeValues, setFilteredLisTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [selectedDataTypeCode, setSelectedDataTypeCode] = React.useState<string>('');
    const previousProps = React.useRef(props);
    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            const prevProps = previousProps.current;
            if (!prevProps.visible && props.visible) {
                let listTypeCode = form0.getFieldValue('listTypeCode');
                let dataTypeCode = form0.getFieldValue('dataTypeCode');
            } else if (!props.visible && selectedDataTypeCode !== '') {
                setSelectedDataTypeCode('');
            }
            previousProps.current = props;
        }
    });

    const {
        visible: visible,
        form: {},
        form: form,
        groups: groups,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    let id = form.getFieldValue('id');

    let groupNames = form.getFieldValue('groupName');

    let taskNames = form.getFieldValue('taskName');

    let title = 'edit tag';

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form form={props.form} labelAlign="left" {...formItemLayout}>
                <Form.Item name="id" hidden />
                <Form.Item name="groupId" hidden />
                <Form.Item name="taskValueId" hidden />
                <Form.Item name="groupName" hidden />
                <Form.Item name="taskName" hidden />
                <Form.Item name="logsheetName" hidden />
                <Form.Item label="Logsheet Name" name="logsheetName">
                    <Input.TextArea readOnly />
                </Form.Item>
                <Form.Item label="Group/Device  name" name="groupName">
                    <Input readOnly />
                </Form.Item>
                <Form.Item label="Task Name" name="taskName">
                    <Input.TextArea readOnly />
                </Form.Item>
                <Form.Item label="Task Value" name="taskValue">
                    <Input.TextArea readOnly />
                </Form.Item>
                <Form.Item label="Comment" name="comment">
                    <Input.TextArea />
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
});

const CommentDrawer = CommentDrawerInner;

export default CommentDrawer;
