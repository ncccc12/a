import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Card, Spin, Form, Select, Button, Table, Input, Modal } from 'antd';
import { reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
    ShiftSupervisorExcUpdate,
} from '../../services/Client';
import { Space } from 'antd';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const ShiftExceedancesTableInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form, areas } = props;

        const [loading, setLoading] = React.useState<boolean>(false);
        const [datas, setDatas] = React.useState<any[]>([]);
        const [topTags, setTopTags] = React.useState<DeviceTag[]>([]);
        const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
        const [exceedances0, setExceedances] = React.useState<ExceedancesListVm[]>([]);
        const [selectedExceedances, setSelectedExceedances] = React.useState<number[]>([]);
        const [selectedExceedancesList, setSelectedExceedancesList] = React.useState<ExceedancesListVm>({} as any);
        const [user, setUser] = React.useState<User>({} as any);
        const [areaCode, setAreaCode] = React.useState<string[]>([]);
        const [commentModalVisible, setCommentModalVisible] = React.useState<boolean>(false);
        const [sendVisible, setSendVisible] = React.useState<boolean>(false);
        const [exceedancesListStatus, setExceedancesListStatus] = React.useState<number>(0);

        const getUser = async () => {
            const data: User = await authService.getUser();
            setUser(data);
            console.log(data);
            getUserArea(data.sub);
            search();
        };

        const getUserArea = async (value: any) => {
            let area: UserVm = await usersClient.getUsersArea(value);
            //let areaCode:string[] = area.areaCodes!
            setAreaCode(area.areaCodes!);
        };

        const search = async () => {
            setLoading(true);
            form.validateFields()
                .then(async (values: any) => {
                    let userId = user.sub;
                    let locationCode = values.locationCode;
                    let areaCode = values.areaCode;
                    let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
                    setExceedances(data);
                    setLoading(false);
                })
                .catch((errors: any) => {
                    return undefined;
                });
        };

        const onSearch = React.useCallback(async () => {
            setLoading(true);

            form.validateFields()
                .then(async (values: any) => {
                    let locationCode = values.locationCode;
                    let areaCode = values.areaCode;
                    console.log(locationCode, areaCode);
                    let userId = user.sub;
                    console.log(userId);
                    let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
                    setExceedances(data);
                    setLoading(false);
                })
                .catch((errors: any) => {
                    return undefined;
                });
        }, [form, user]);

        const filterAreas = React.useCallback(
            (locationCode: string) => {
                const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
                setFilteredAreas(filteredAreas);
            },
            [areas],
        );

        const handleLocationChange = React.useCallback(
            (value: string) => {
                form.setFieldsValue({ areaCode: '' });
                filterAreas(value);
            },
            [filterAreas, form],
        );

        const onSelectChange = React.useCallback(
            (selectedExceedances: any) => {
                let exceedances = exceedances0.find((x) => x.id === selectedExceedances);
                setSelectedExceedances(selectedExceedances!);
            },
            [exceedances0],
        );

        const resetFilter = () => {
            props.form.resetFields();
            search();
        };

        const updateTag = (values: ExceedancesVm) => {
            let updateCommand = new UpdateTagDataCommand();
            updateCommand.id = values.id;
            updateCommand.value = values.taskValue;
            updateCommand.comment = values.comment;

            reportsClient.updateTagData(updateCommand);
            message.success('Successfully updated');
        };

        const sendToPOD = React.useCallback(async () => {
            let updateCommand = new ShiftSupervisorExcUpdate();
            let exceedances = exceedances0;
            let crowId = selectedExceedances!;
            console.log('RowID', crowId);
            let i = 0;
            let selected: any = [];

            crowId.map((i) => {
                let result = exceedances.find((x) => x.id == i!);
                selected.push(result!);
            });
            console.log();

            console.log('Shift Exc', selected);
            updateCommand.exceedancesListVms = selected;
            updateCommand.exListStatus = 2;
            reportsClient.updateShiftExc(updateCommand);
            message.success('Successfully updated');
            window.location.reload();
        }, [exceedances0, selectedExceedances]);

        const sendToRM = React.useCallback(async () => {
            let updateCommand = new ShiftSupervisorExcUpdate();
            let exceedances = exceedances0;
            let crowId = selectedExceedances!;
            console.log('RowID', crowId);
            let i = 0;
            let selected: any = [];

            crowId.map((i) => {
                let result = exceedances.find((x) => x.id == i!);
                selected.push(result!);
            });
            console.log();

            console.log('Shift Exc', selected);
            updateCommand.exceedancesListVms = selected;
            updateCommand.exListStatus = 5;
            reportsClient.updateShiftExc(updateCommand);
            message.success('Successfully updated');
            window.location.reload();
        }, [exceedances0, selectedExceedances]);

        const renderStatus = (i: string, rowKey: ExceedancesListVm) => {
            if (rowKey.exListStatus! === 1) {
                return <p>Under Shift-Supervisor Review</p>;
            }
            if (rowKey.exListStatus! === 2) {
                return <p>Under Plant SPV</p>;
            }
            if (rowKey.exListStatus! === 3) {
                return <p>Under CRO</p>;
            }
            if (rowKey.exListStatus! === 4) {
                return <p>Under Supervisor</p>;
            }
            if (rowKey.exListStatus! === 5) {
                return <p>Run & Maintaince</p>;
            }
            if (rowKey.exListStatus! === 6) {
                return <p>Fixed</p>;
            }
        };

        const renderAction = (i: string, rowKey: any) => {
            return (
                <>
                    <Link to={`/exceedances/${rowKey.id!}`}>
                        <Button shape="circle" icon={<EditOutlined />} title="edit"></Button>
                    </Link>
                </>
            );
        };

        const onCloseModal = React.useCallback((): void => {
            setCommentModalVisible(false);
        }, []);

        const onOk = React.useCallback(() => {
            let comment = props.form.getFieldValue('supervisorComment');
            let exceedances = exceedances0!;
            let selected = selectedExceedancesList!;
            let filteredExc = exceedances.find((x) => x.id === selected.id);

            filteredExc!.commentBySup = comment;

            setExceedances(exceedances);

            setCommentModalVisible(false);

            console.log('Super Comment', exceedances0);
        }, [exceedances0, selectedExceedancesList, props.form]);

        const onChangeComment = (rowKey: ExceedancesListVm) => {
            const selected = exceedances0!.find((x) => x.id === rowKey.id!);

            setSelectedExceedancesList(selected!);
            setCommentModalVisible(true);
        };

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                getUser();
            }
        });

        const rowSelection = {
            selectedExceedances,
            onChange: onSelectChange,
        };
        const {
            form: {},
            locations: locations,
        } = props;
        const renderComment = (i: string, rowKey: any) => {
            return (
                <div style={{ width: '100%', display: 'flex' }}>
                    <div style={{ display: 'flex' }}>
                        <Input width="45%" disabled readOnly value={i!}></Input>
                        <Button
                            shape="circle"
                            icon={<EditOutlined />}
                            title="edit"
                            style={{ marginLeft: '10px' }}
                            onClick={() => onChangeComment(rowKey!)}
                        ></Button>
                    </div>
                </div>
            );
        };
        console.log('select Exc', selectedExceedances);
        return (
            <Spin spinning={loading}>
                <Card

                // extra={this.renderHeader()}
                >
                    <Form form={props.form}>
                        <div style={{ display: 'flex' }}>
                            <Form.Item label="Location" name="locationCode">
                                <Select style={{ width: '100px' }} onChange={handleLocationChange}>
                                    {locations.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>

                            <Form.Item label="Area" name="areaCode">
                                <Select style={{ width: '200px' }}>
                                    {filteredAreas.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item>
                                <Space.Compact style={{ marginTop: '40px', marginLeft: '20px' }}>
                                    <Button type="primary" onClick={onSearch}>
                                        Search
                                    </Button>
                                </Space.Compact>
                            </Form.Item>
                        </div>
                        <Modal
                            destroyOnHidden
                            onCancel={onCloseModal}
                            open={commentModalVisible}
                            onOk={onOk}
                            title={'Supervisor Comment'}
                        >
                            <Form.Item name="supervisorComment">
                                <Input.TextArea />
                            </Form.Item>
                        </Modal>
                    </Form>
                    <Button style={{ marginRight: '10px' }} type="primary" onClick={sendToPOD}>
                        Return back to PRA
                    </Button>
                    <Button style={{ margin: '0,10px,0,10px' }} type="primary" onClick={sendToRM}>
                        Run & Maintain
                    </Button>
                    <Table
                        dataSource={exceedances0}
                        loading={loading}
                        bordered
                        //expandRowByClick={true}
                        // pagination={paginationConfig}
                        rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                        rowSelection={rowSelection}
                    >
                        {' '}
                        <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                        <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                        <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                        <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                        <Table.Column dataIndex="commentBySup" title="Supervisor Comment" />
                        <Table.Column
                            dataIndex="commentBySup"
                            title="Comment"
                            render={(i: string, rowKey: ExceedancesListVm) => renderComment(i, rowKey)}
                        ></Table.Column>
                        <Table.Column
                            dataIndex="excListStatus"
                            title="Status"
                            render={(i: string, rowKey: ExceedancesListVm) => renderStatus(i, rowKey)}
                        ></Table.Column>
                        <Table.Column
                            title="Action"
                            width={'130px'}
                            render={(i: string, rowKey: any) => renderAction(i, rowKey)}
                        ></Table.Column>
                    </Table>
                </Card>
            </Spin>
        );
    },
);

const ShiftExceedancesTable = ShiftExceedancesTableInner;

export default ShiftExceedancesTable;
