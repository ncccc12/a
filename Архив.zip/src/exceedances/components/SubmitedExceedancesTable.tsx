import { message } from '../../common/antdFeedback';
import { EditOutlined } from '@ant-design/icons';
import React from 'react';
import { Card, Spin, Form, Button, Table } from 'antd';
import { reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
} from '../../services/Client';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const SubmitededExceedancesTableInner = React.forwardRef<{ form: import('antd').FormInstance }, Props>(
    (externalProps, ref) => {
        const [injectedForm] = Form.useForm();
        React.useImperativeHandle(ref, () => ({ form: injectedForm }), [injectedForm]);
        const props = {
            ...externalProps,
            form: injectedForm,
        } as typeof externalProps & { form: typeof injectedForm };
        const { form, areas } = props;

        const [loading, setLoading] = React.useState<boolean>(false);
        const [datas, setDatas] = React.useState<any[]>([]);
        const [topTags, setTopTags] = React.useState<DeviceTag[]>([]);
        const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
        const [exceedances, setExceedances] = React.useState<ExceedancesListVm[]>([]);
        const [selectedExceedances, setSelectedExceedances] = React.useState<ExceedancesListVm[]>([]);
        const [user, setUser] = React.useState<User>({} as any);
        const [areaCode, setAreaCode] = React.useState<string[]>([]);

        const getUser = async () => {
            const data: User = await authService.getUser();
            setUser(data);

            getUserArea(data.sub);
            search();
        };

        const getUserArea = async (value: any) => {
            let area: UserVm = await usersClient.getUsersArea(value);
            //let areaCode:string[] = area.areaCodes!
            setAreaCode(area.areaCodes!);
        };

        const search = async () => {
            setLoading(true);
            let userId = user.sub;
            let data = await reportsClient.getSubmitedExceedancesQuery(userId);
            setExceedances(data);
            setLoading(false);
        };

        const handleLocationChange = (value: string) => {
            form.setFieldsValue({ areaCode: '' });
            filterAreas(value);
        };

        const filterAreas = (locationCode: string) => {
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            setFilteredAreas(filteredAreas);
        };

        const onSelectChange = (selectedExceedances: any) => {
            setSelectedExceedances(selectedExceedances);
        };

        const resetFilter = () => {
            props.form.resetFields();
            search();
        };

        const updateTag = (values: ExceedancesVm) => {
            let updateCommand = new UpdateTagDataCommand();
            updateCommand.id = values.id;
            updateCommand.value = values.taskValue;
            updateCommand.comment = values.comment;

            reportsClient.updateTagData(updateCommand);
            message.success('Successfully updated');
        };

        const renderStatus = (i: string, rowKey: ExceedancesListVm) => {
            console.log('Rowkeuuu', i, rowKey);
            if (rowKey.exListStatus! === 1) {
                return <p>Under Shift-Supervisor Review</p>;
            }
            if (rowKey.exListStatus! === 2) {
                return <p>Under Plant SPV</p>;
            }
            if (rowKey.exListStatus! === 3) {
                return <p>Under CRO</p>;
            }
            if (rowKey.exListStatus! === 4) {
                return <p>Under Supervisor</p>;
            }
            if (rowKey.exListStatus! === 5) {
                return <p>Run & Maintaince</p>;
            }
            if (rowKey.exListStatus! === 6) {
                return <p>Fixed</p>;
            }
        };

        const renderAction = (i: string, rowKey: any) => {
            return (
                <>
                    <Link to={`/exceedances/${rowKey.id!}`}>
                        <Button shape="circle" icon={<EditOutlined />} title="edit"></Button>
                    </Link>
                </>
            );
        };

        const isMounted = React.useRef(false);

        React.useEffect(() => {
            if (!isMounted.current) {
                isMounted.current = true;
                getUser();
            }
        });

        return (
            <Spin spinning={loading}>
                <Card

                // extra={this.renderHeader()}
                >
                    <Table
                        dataSource={exceedances}
                        loading={loading}
                        bordered
                        //expandRowByClick={true}
                        // pagination={paginationConfig}
                        rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                        //rowSelection={rowSelection}
                    >
                        {' '}
                        <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                        <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                        <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                        <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                        <Table.Column dataIndex="commentBySup" title="Supervisor Comment" />
                        <Table.Column
                            dataIndex="excListStatus"
                            title="Status"
                            render={(i: string, rowKey: ExceedancesListVm) => renderStatus(i, rowKey)}
                        ></Table.Column>
                        <Table.Column
                            title="Action"
                            width={'130px'}
                            render={(i: string, rowKey: any) => renderAction(i, rowKey)}
                        ></Table.Column>
                    </Table>
                </Card>
            </Spin>
        );
    },
);

const SubmitededExceedancesTable = SubmitededExceedancesTableInner;

export default SubmitededExceedancesTable;
