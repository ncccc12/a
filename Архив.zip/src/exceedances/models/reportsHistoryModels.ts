import dayjs, { type Dayjs } from '@dayjs';
import { FilterDto } from './types';

export interface ReportsHistoryFilterFormModel extends FilterDto {
    logSheetId?: number;
    areaId?: number;
    locationId?: number;
    statusCodes?: number[];
    startDate?: Dayjs;
    endDate?: Dayjs;
    hasExceedance: number;
    hasCompliance: number;
}
