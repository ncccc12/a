import { ReportsHistoryFilterFormModel } from '../models/reportsHistoryModels';

const CHANGE_FILTER_FORM = 'CHANGE_FILTER_FORM';
const CHANGE_PAGE = 'CHANGE_PAGE';
const RESET_FILTER_FORM = 'RESET_FILTER_FORM';
const EXPAND_FILTER_FORM = 'EXPAND_FILTER_FORM';
const CHANGE_PAGE_SIZE = 'CHANGE_PAGE_SIZE';

interface ChangeFilterAction {
    type: typeof CHANGE_FILTER_FORM;
    filters: ReportsHistoryFilterFormModel;
}

export const changeFilterForm = (form: ReportsHistoryFilterFormModel): ChangeFilterAction => {
    return {
        type: CHANGE_FILTER_FORM,
        filters: form,
    };
};

interface ChangePageAction {
    type: typeof CHANGE_PAGE;
    page: number;
}

export const changePage = (page: number): ChangePageAction => {
    return {
        type: CHANGE_PAGE,
        page,
    };
};

interface ResetFilterFormAction {
    type: typeof RESET_FILTER_FORM;
}

export const resetFilterForm = (): ResetFilterFormAction => {
    return {
        type: RESET_FILTER_FORM,
    };
};

interface ExpandFilterFormAction {
    type: typeof EXPAND_FILTER_FORM;
}

export const expandFilterForm = (): ExpandFilterFormAction => {
    return {
        type: EXPAND_FILTER_FORM,
    };
};

interface ChangePageSizeAction {
    type: typeof CHANGE_PAGE_SIZE;
    pageSize: number;
}

export const changePageSize = (pageSize: number): ChangePageSizeAction => {
    return {
        type: CHANGE_PAGE_SIZE,
        pageSize,
    };
};

type ListActionTypes =
    | ChangeFilterAction
    | ChangePageAction
    | ResetFilterFormAction
    | ExpandFilterFormAction
    | ChangePageSizeAction;

export interface ReportsHistoryFilterFormState {
    filterForm: ReportsHistoryFilterFormModel;
    isFilterFormExpanded: boolean;
}

const initialFormState = {
    hasExceedance: 0,
    hasCompliance: 0,
    isActive: 0,
    current: 1,
    pageSize: 10,
};

const initialState: ReportsHistoryFilterFormState = {
    filterForm: initialFormState,
    isFilterFormExpanded: false,
};

const reportsHistoryFilterFormDuck = (
    state: ReportsHistoryFilterFormState = initialState,
    action: ListActionTypes,
): ReportsHistoryFilterFormState => {
    switch (action.type) {
        case CHANGE_FILTER_FORM:
            return {
                ...state,
                filterForm: { ...state.filterForm, ...action.filters },
            };
        case CHANGE_PAGE:
            const updatedFilterForm = { ...state.filterForm };
            updatedFilterForm.current = action.page;

            return { ...state, filterForm: updatedFilterForm };
        case RESET_FILTER_FORM:
            return { ...state, filterForm: initialFormState };
        case EXPAND_FILTER_FORM:
            const currentState = state.isFilterFormExpanded;

            return { ...state, isFilterFormExpanded: !currentState };
        case CHANGE_PAGE_SIZE:
            const filterForm = { ...state.filterForm };
            filterForm.current = 1;
            filterForm.pageSize = action.pageSize;

            return { ...state, filterForm };

        default:
            return state;
    }
};

export default reportsHistoryFilterFormDuck;
