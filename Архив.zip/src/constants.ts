import type { SelectProps } from 'antd';

export const AllYesNoSelectOptions: NonNullable<SelectProps['options']> = [
    {
        value: 0,
        title: 'All',
    },
    {
        value: 1,
        title: 'Yes',
    },

    {
        value: -1,
        title: 'No',
    },
];
