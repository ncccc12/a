import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '');

    return {
        base: env.VITE_BASE_PATH || '/',
        plugins: [react()],
        resolve: {
            alias: {
                '@dayjs': fileURLToPath(new URL('./src/dayjs.ts', import.meta.url)),
            },
        },
        server: {
            port: 3000,
        },
        preview: {
            port: 3000,
        },
        build: {
            outDir: 'build',
        },
    };
});
