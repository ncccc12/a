import React from 'react';
import { Spin, Row, Col, Button, message } from 'antd';
import moment from 'moment';
import { cloneDeep } from 'lodash';
import ScheduleConfigForm, { ConfigFormModel } from '../components/ScheduleConfigForm';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import generateScheduleSrv from '../GenerateScheduleService';

import { groupsClient, schedulesClient } from '../../services';
import { GroupSimpleVm, GroupConfigDto, UpdateScheduleConfigCommand } from '../../services/Client';

import { ScheduleConfig } from '../types';
import CalendarTable from '../components/CalendarTable';
import '../ScheduleForm.css';
import { withRouter, RouteComponentProps } from 'react-router-dom';


type Props = {
    id: number;
} & RouteComponentProps<any>;
type State = {
    scheduleConfig?: ScheduleConfig;
    groups: GroupSimpleVm[];
    loading: boolean;
    formChanged: boolean;
};

class EditScheduleConfigContainer extends React.Component<Props, State> {
    configFormRef: any;
    months: moment.Moment[] = [];
    srcConfig: ScheduleConfig | undefined;

    constructor(props: Props) {
        super(props);
        this.state = {
            loading: true,
            groups: [],
            formChanged: false,
        };
    }

    async componentDidMount() {
        let groups = await groupsClient.getGroupsSimple();
        let configVm = await schedulesClient.getScheduleConfig(this.props.id);
        let config = generateScheduleSrv.mapVmToScheduleConfig(configVm);
        this.srcConfig = cloneDeep(config);

        this.months = [];
        for (let i = 0; i < 12; i++) {
            const currMonth = moment([config.year!, i, 1]);
            this.months.push(currMonth);
        }

        this.setState({ groups, scheduleConfig: config }, () => {
            this.setForm();
        });
    }

    setForm = () => {
        const config = this.state.scheduleConfig;
        const form = this.configFormRef.props.form as WrappedFormUtils<any>;

        let formModel: ConfigFormModel = {
            areaCode: config!.areaCode,
            locationCode: config!.locationCode,
            rotationType: config!.rotationType,
            scheduleConfigName: config!.scheduleConfigName,
            year: config!.year,
            datePeriod: config!.datePeriod,
            // group1DayShift: config!.dayShiftFirst1 === 1,
            // group2DayShift: config!.dayShiftFirst1 === 2,
            // group3DayShift: config!.dayShiftFirst2 === 3,
            // group4DayShift: config!.dayShiftFirst2 === 4,
            group1: config!.group1!.code,
            group2: config!.group2!.code,
            group3: config!.group3!.code,
            group4: config!.group4!.code,
        };

        form.setFieldsValue(formModel);
    };

    updateSchedule = async () => {
        const { scheduleConfig } = this.state;

        try {
            this.setState({ loading: true });
            let command = new UpdateScheduleConfigCommand();
            command.id = this.props.id;
            command.configName = scheduleConfig!.scheduleConfigName;
            command.rotationTypeCode = scheduleConfig!.rotationType;

            let group1 = new GroupConfigDto();
            group1.code = scheduleConfig!.group1!.code;
            group1.schedule = scheduleConfig!.group1!.schedule!.join('');

            let group2 = new GroupConfigDto();
            group2.code = scheduleConfig!.group2!.code;
            group2.schedule = scheduleConfig!.group2!.schedule!.join('');

            let group3 = new GroupConfigDto();
            group3.code = scheduleConfig!.group3!.code;
            group3.schedule = scheduleConfig!.group3!.schedule!.join('');

            let group4 = new GroupConfigDto();
            group4.code = scheduleConfig!.group4!.code;
            group4.schedule = scheduleConfig!.group4!.schedule!.join('');

            command.group1 = group1;
            command.group2 = group2;
            command.group3 = group3;
            command.group4 = group4;

            // command.dayShiftFirst1 = scheduleConfig!.dayShiftFirst1;
            // command.dayShiftFirst2 = scheduleConfig!.dayShiftFirst2;
            command.datePeriod = [
                scheduleConfig!.datePeriod![0].utc(true),
                scheduleConfig!.datePeriod![1].utc(true),
            ] as any;

            await schedulesClient.updateScheduleConfig(command);
            this.props.history.push('/scheduleManager/scheduleConfigs');
            message.success('Operation successfully completed');
        } finally {
            this.setState({ loading: false });
        }
    };

    generateSchedule = () => {
        const form = this.configFormRef.props.form as WrappedFormUtils<any>;
        const { groups } = this.state;

        form.validateFields((err: any, values: ConfigFormModel) => {
            if (err) {
                this.setState({
                    scheduleConfig: undefined,
                });

                return;
            }

            let config = generateScheduleSrv.mapFormToScheduleConfig(values, groups);
            let copyConfig = cloneDeep(this.srcConfig);

            config.group1!.schedule = copyConfig!.group1!.schedule;
            config.group2!.schedule = copyConfig!.group2!.schedule;
            config.group3!.schedule = copyConfig!.group3!.schedule;
            config.group4!.schedule = copyConfig!.group4!.schedule;

            generateScheduleSrv.generateSchedule(config, true);

            this.setState({
                scheduleConfig: config,
                formChanged: false,
            });
        });
    };

    resetSchedule = () => {
        this.setState({ scheduleConfig: this.srcConfig }, () => {
            this.setForm();
        });
    };

    handleLoadingChange = (loading: boolean) => {
        this.setState({ loading });
    };

    handleFormChange = () => {
        if (!this.state.formChanged) {
            this.setState({ formChanged: true });
        }
    };

    render() {
        const { loading, groups, scheduleConfig, formChanged } = this.state;

        return (
            <Spin spinning={loading}>
                <ScheduleConfigForm
                    wrappedComponentRef={(ref: any) => (this.configFormRef = ref)}
                    isEdit={true}
                    groups={groups}
                    onFormChange={this.handleFormChange}
                    onLoadingChange={this.handleLoadingChange}
                ></ScheduleConfigForm>
                <br />
                <Row>
                    <Col span={12} style={{ textAlign: 'left' }}>
                        <Button type="primary" onClick={this.generateSchedule}>
                            Generate schedule
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.resetSchedule}>
                            Reset
                        </Button>
                    </Col>
                    {scheduleConfig && formChanged === false && (
                        <Col span={12} style={{ textAlign: 'right' }}>
                            <Button
                                style={{ backgroundColor: '#52c41a', color: '#fff' }}
                                type="link"
                                onClick={this.updateSchedule}
                            >
                                Update schedule
                            </Button>
                        </Col>
                    )}
                </Row>
                <br />

                {scheduleConfig && <CalendarTable scheduleConfig={scheduleConfig} isEdit={true} />}
            </Spin>
        );
    }
}

export default withRouter(EditScheduleConfigContainer);
