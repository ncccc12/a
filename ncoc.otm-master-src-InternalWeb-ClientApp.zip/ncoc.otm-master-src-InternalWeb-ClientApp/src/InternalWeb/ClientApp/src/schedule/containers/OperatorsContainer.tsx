import React from 'react';
import { Spin, Row, Select, Table, Form, Button, Divider, message } from 'antd';
import { dictionaryClient, employeesClient, groupsClient } from '../../services/index';
import {
    DictionaryDto,
    AreaVm,
    EmployeeVm,
    AddNewEmployeeCommand,
    UpdateEmployeeCommand,
    GetEmployeesQuery,
    GroupVm,
    GetGroupsQuery,
} from '../../services/Client';
import { FormComponentProps } from 'antd/lib/form';
import OperatorDrawer, { OperatorForm } from '../components/OperatorDrawer';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import ButtonGroup from 'antd/lib/button/button-group';

type SearchForm = {
    locationCode: string;
    areaCode: string;
    groupCode: string;
    isActive: number[];
};

type Props = {} & FormComponentProps;
type State = {
    loading: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    groups: GroupVm[];
    filteredAreas: AreaVm[];
    filteredGroups: GroupVm[];
    employees: EmployeeVm[];
    isOperatorDrawerShown: boolean;
};

const OperatorsContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        operatorFormRef: any;

        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                locations: [],
                areas: [],
                groups: [],
                filteredAreas: [],
                filteredGroups: [],
                employees: [],
                isOperatorDrawerShown: false,
            };
        }

        async componentDidMount() {
            await this.loadData();
            this.search();
        }

        loadData = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();

            let groupsQuery = new GetGroupsQuery();
            groupsQuery.isActive = [1];
            let groups = await groupsClient.getGroups(groupsQuery);

            this.setState({ locations, areas, groups });
        };

        handleLocationChange = (value: string) => {
            const { areas } = this.state;

            const filteredAreas = areas.filter(r => r.locationCode === value);
            this.setState({ filteredAreas });

            this.props.form.setFieldsValue({
                areaCode: '',
            });
        };

        handleAreaChange = (value: string) => {
            const { groups } = this.state;

            const filteredGroups = groups.filter(r => r.areaCode === value);

            this.setState({ filteredGroups });
            this.props.form.setFieldsValue({
                groupCode: '',
            });
        };

        search = () => {
            this.props.form.validateFields(async (err: any, values: SearchForm) => {
                this.setState({ loading: true });

                try {
                    var query = new GetEmployeesQuery();
                    query.init(values);

                    let employees = await employeesClient.getEmployees(query);
                    this.setState({ employees });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        submitForm = () => {
            const form = this.operatorFormRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: OperatorForm) => {
                if (err) return;

                try {
                    this.setState({ loading: true });

                    if (values.id) {
                        let updateCommand = new UpdateEmployeeCommand();
                        updateCommand.init(values);
                        await employeesClient.updateEmployee(updateCommand);
                    } else {
                        // add new
                        let command = new AddNewEmployeeCommand();
                        command.init(values);
                        await employeesClient.addNewEmployee(command);
                    }

                    message.success('Successful');
                    this.setState({ isOperatorDrawerShown: false });
                    this.search();
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        openDrawer = (r: EmployeeVm | undefined) => {
            const form = this.operatorFormRef.props.form as WrappedFormUtils<any>;
            this.setState({ isOperatorDrawerShown: true }, () => {
                if (r) {
                    let operatorForm: OperatorForm = {
                        id: r.id!,
                        areaCode: r.areaCode!,
                        groupCode: r.groupCode!,
                        firstName: r.firstName!,
                        lastName: r.lastName!,
                        position: r.position!,
                        locationCode: r.locationCode!,
                        isActive: r.isActive!,
                    };

                    form.setFieldsValue({
                        ...operatorForm,
                    });
                } else {
                    form.resetFields();
                    form.setFieldsValue({ isActive: true });
                }
            });
        };

        renderActions = (r: EmployeeVm) => {
            return <Button icon="edit" shape="circle" title="edit" onClick={() => this.openDrawer(r)} />;
        };

        render() {
            const {
                loading,
                locations,
                filteredAreas,
                filteredGroups,
                employees,
                isOperatorDrawerShown,
                areas,
                groups,
            } = this.state;
            const {
                form: { getFieldDecorator },
            } = this.props;

            const selectStyle = {
                width: 150,
            };

            return (
                <Spin spinning={loading}>
                    <Row>
                        <Form labelAlign="left" layout="inline">
                            <Form.Item label="Location">
                                {getFieldDecorator('locationCode')(
                                    <Select style={selectStyle} onChange={this.handleLocationChange}>
                                        {locations.map(r => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item label="Area">
                                {getFieldDecorator('areaCode')(
                                    <Select style={selectStyle} onChange={this.handleAreaChange}>
                                        {filteredAreas.map(r => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item label="Group">
                                {getFieldDecorator('groupCode')(
                                    <Select style={selectStyle}>
                                        {filteredGroups.map(r => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item label="Is active">
                                {getFieldDecorator('isActive', { initialValue: [1] })(
                                    <Select style={selectStyle} mode="multiple">
                                        <Select.Option key="y" value={1}>
                                            Yes
                                        </Select.Option>
                                        <Select.Option key="n" value={0}>
                                            No
                                        </Select.Option>
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Form>
                    </Row>
                    <Divider />
                    <Row>
                        <Table
                            dataSource={employees}
                            title={() => <Button onClick={() => this.openDrawer(undefined)}>Add new</Button>}
                            rowKey={r => r.id + ''}
                            bordered
                        >
                            <Table.Column dataIndex="location" title="Location"></Table.Column>
                            <Table.Column dataIndex="area" title="Area"></Table.Column>
                            <Table.Column dataIndex="groupName" title="Group Name"></Table.Column>
                            <Table.Column dataIndex="lastName" title="Last Name"></Table.Column>
                            <Table.Column dataIndex="firstName" title="First Name"></Table.Column>
                            <Table.Column dataIndex="position" title="Position"></Table.Column>
                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                            ></Table.Column>
                            <Table.Column title="Actions" render={r => this.renderActions(r)}></Table.Column>
                        </Table>
                    </Row>

                    <OperatorDrawer
                        visible={isOperatorDrawerShown}
                        wrappedComponentRef={(compRef: any) => (this.operatorFormRef = compRef)}
                        locations={locations}
                        areas={areas}
                        groups={groups}
                        onSubmit={this.submitForm}
                        onClose={() => this.setState({ isOperatorDrawerShown: false })}
                    />
                </Spin>
            );
        }
    },
);

export default OperatorsContainer;
