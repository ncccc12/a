import React from 'react';
import { Table, Button, message, Spin } from 'antd';
import {
    LogSheetsClient,
    LogsheetListItemVm,
    TimeOptionDto,
    UpdateLogsheetScheduleCommand,
    GetLogsheetsQuery,
} from '../../services/Client';
import LogsheetModal from '../LogsheetModal';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import { LogsheetScheduleForm } from '../types';
import moment from 'moment';
import axios from '../../common/axiosConfig';

const { Column, ColumnGroup } = Table;

type Props = {};
type State = {
    loading: boolean;
    logsheets: LogsheetListItemVm[];
    selectedLogsheet?: LogsheetListItemVm;
    logsheetModalShown: boolean;
};

class ScheduleManagerContainer extends React.Component<Props, State> {
    client = new LogSheetsClient(undefined, axios);
    logsheetModalRef: any;
    timeFormat = 'HH:mm';

    constructor(props: Props) {
        super(props);
        this.state = {
            loading: false,
            logsheetModalShown: false,
            logsheets: [],
        };
    }

    async componentDidMount() {
        await this.loadData();
    }

    loadData = async () => {
        this.setState({ loading: true });
        const data = await this.client.getLogsheets(new GetLogsheetsQuery());
        this.setState({ logsheets: data, loading: false });
    };

    renderActions = (logsheet: LogsheetListItemVm) => {
        return (
            <>
                <Button
                    title="Edit"
                    icon="edit"
                    shape="circle"
                    disabled={!logsheet.schedule}
                    onClick={() => this.openLogsheetModal(logsheet)}
                ></Button>
            </>
        );
    };

    renderScheduleTitle = () => {
        return (
            <>
                <b>Updated schedule</b> <br />
                <span>(will be applied on next day)</span>
            </>
        );
    };

    openLogsheetModal = (logsheet: LogsheetListItemVm) => {
        this.setState({
            logsheetModalShown: true,
            selectedLogsheet: logsheet,
        });
    };

    closeLogsheetModal = () => {
        this.setState({ logsheetModalShown: false });
    };

    submit = () => {
        const modalForm = this.logsheetModalRef.props.form as WrappedFormUtils<any>;
        const { selectedLogsheet } = this.state;

        modalForm.validateFields(async (err: any, values: LogsheetScheduleForm) => {
            if (err) return;


            try {
                const { keys, id } = values;
                let command = new UpdateLogsheetScheduleCommand();
                command.timeOptions = [];
                command.id = id;

                keys.forEach(k => {
                    let vOpt = values.timeOptions[k];
                    vOpt.time = vOpt.time.format('HH:mm');
                    let option = new TimeOptionDto();
                    option.init(vOpt);
                    command.timeOptions!.push(option);
                });

                await this.client.updateLogsheetSchedule(command);
                await this.loadData();

                this.setState({ logsheetModalShown: false });
                message.success(`${selectedLogsheet!.name} successfully updated`);
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    renderTimes = (times: TimeOptionDto[]) => {
        return times && times.map(r => moment(r.time, this.timeFormat).format(this.timeFormat)).join(', ');
    };

    render() {
        const { logsheets, selectedLogsheet, logsheetModalShown } = this.state;

        return (
            <Spin spinning={this.state.loading}>
                <Table rowKey={r => r.id + ''} dataSource={logsheets} bordered>
                    <Column title="Location" dataIndex="location"></Column>
                    <Column title="Area" dataIndex="area"></Column>
                    <Column title="Logsheet" dataIndex="name"></Column>
                    <ColumnGroup title="Current schedule">
                        <Column title="Type" align="center" dataIndex="schedule.type"></Column>
                        <Column
                            title="Times"
                            align="center"
                            dataIndex="schedule.timeOptions"
                            render={this.renderTimes}
                        ></Column>
                    </ColumnGroup>
                    <ColumnGroup title={this.renderScheduleTitle}>
                        <Column title="Type" align="center" dataIndex="updatedSchedule.type"></Column>
                        <Column
                            title="Times"
                            align="center"
                            dataIndex="updatedSchedule.timeOptions"
                            render={this.renderTimes}
                        ></Column>
                    </ColumnGroup>
                    <Column title="Actions" align="center" render={this.renderActions}></Column>
                </Table>

                <LogsheetModal
                    key={logsheetModalShown ? 1 : 0}
                    visible={logsheetModalShown}
                    wrappedComponentRef={(compRef: any) => (this.logsheetModalRef = compRef)}
                    logsheet={selectedLogsheet}
                    loading={this.state.loading}
                    onOk={this.submit}
                    onCancel={this.closeLogsheetModal}
                ></LogsheetModal>
            </Spin>
        );
    }
}

export default ScheduleManagerContainer;
