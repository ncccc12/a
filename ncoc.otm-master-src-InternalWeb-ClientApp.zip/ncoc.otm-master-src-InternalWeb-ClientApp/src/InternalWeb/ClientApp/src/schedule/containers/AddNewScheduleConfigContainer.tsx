import React from 'react';
import { Spin, Row, Col, Button, message } from 'antd';
import ScheduleConfigForm, { ConfigFormModel } from '../components/ScheduleConfigForm';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import generateScheduleSrv from '../GenerateScheduleService';
import { groupsClient, schedulesClient } from '../../services';
import { GroupSimpleVm, AddScheduleConfigCommand, GroupConfigDto } from '../../services/Client';
import { ScheduleConfig } from '../types';
import CalendarTable from '../components/CalendarTable';
import { withRouter, RouteComponentProps } from 'react-router-dom';

type Props = {} & RouteComponentProps<any>;
type State = {
    scheduleConfig?: ScheduleConfig | undefined;
    groups: GroupSimpleVm[];
    loading: boolean;
    formChanged: boolean;
};

class AddNewScheduleConfigContainer extends React.Component<Props, State> {
    configFormRef: any;
    
    constructor(props: Props) {
        super(props);
        this.state = {
            loading: true,
            groups: [],
            formChanged: false,
        };
    }

    componentDidMount() {
        this.loadDictionaries();
    }

    loadDictionaries = async () => {
        let groups = await groupsClient.getGroupsSimple();
        this.setState({ groups });
    };

    saveSchedule = async () => {
        this.generateSchedule();
        const { scheduleConfig } = this.state;

        try {
            this.setState({ loading: true });
            let command = new AddScheduleConfigCommand();
            command.areaCode = scheduleConfig!.areaCode;
            command.configName = scheduleConfig!.scheduleConfigName;
            command.rotationTypeCode = scheduleConfig!.rotationType;
            command.year = scheduleConfig!.year;

            let group1 = new GroupConfigDto();
            group1.code = scheduleConfig!.group1!.code;
            group1.schedule = scheduleConfig!.group1!.schedule!.join('');

            let group2 = new GroupConfigDto();
            group2.code = scheduleConfig!.group2!.code;
            group2.schedule = scheduleConfig!.group2!.schedule!.join('');

            let group3 = new GroupConfigDto();
            group3.code = scheduleConfig!.group3!.code;
            group3.schedule = scheduleConfig!.group3!.schedule!.join('');

            let group4 = new GroupConfigDto();
            group4.code = scheduleConfig!.group4!.code;
            group4.schedule = scheduleConfig!.group4!.schedule!.join('');

            command.group1 = group1;
            command.group2 = group2;
            command.group3 = group3;
            command.group4 = group4;

            // command.dayShiftFirst1 = scheduleConfig!.dayShiftFirst1;
            // command.dayShiftFirst2 = scheduleConfig!.dayShiftFirst2;
            command.datePeriod = [
                scheduleConfig!.datePeriod![0].utc(true),
                scheduleConfig!.datePeriod![1].utc(true),
            ] as any;

            await schedulesClient.addScheduleConfig(command);
            this.props.history.push('/scheduleManager/scheduleConfigs');
            message.success('Operation successfully completed');
        } finally {
            this.setState({ loading: false });
        }
    };

    generateSchedule = () => {
        const form = this.configFormRef.props.form as WrappedFormUtils<any>;
        const { groups } = this.state;

        form.validateFields((err: any, values: ConfigFormModel) => {
            
            if (err) {
                this.setState({
                    scheduleConfig: undefined,
                });
                return;
            }

            let config = generateScheduleSrv.mapFormToScheduleConfig(values, groups);
            generateScheduleSrv.generateSchedule(config);

           

            this.setState({
                scheduleConfig: config,
                formChanged: false,
            });
        });
    };

    resetSchedule = () => {
        const form = this.configFormRef.props.form as WrappedFormUtils<any>;
        form.resetFields();
        this.setState({ scheduleConfig: undefined });
    };

    handleLoadingChange = (loading: boolean) => {
        this.setState({ loading });
    };

    handleFormChange = () => {
        if (!this.state.formChanged) {
            this.setState({ formChanged: true });
        }
    };

    render() {
        const { loading, groups, scheduleConfig, formChanged } = this.state;

        return (
            <Spin spinning={loading}>
                <ScheduleConfigForm
                    wrappedComponentRef={(ref: any) => (this.configFormRef = ref)}
                    groups={groups}
                    onFormChange={this.handleFormChange}
                    onLoadingChange={this.handleLoadingChange}
                ></ScheduleConfigForm>
                <br />
                <Row>
                    <Col span={12} style={{ textAlign: 'left' }}>
                        <Button type="primary" onClick={this.generateSchedule}>
                            Generate schedule
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.resetSchedule}>
                            Reset
                        </Button>
                    </Col>
                    {scheduleConfig && formChanged === false && (
                        <Col span={12} style={{ textAlign: 'right' }}>
                            <Button
                                style={{ backgroundColor: '#52c41a', color: '#fff' }}
                                type="link"
                                onClick={this.saveSchedule}
                            >
                                Add new schedule
                            </Button>
                        </Col>
                    )}
                </Row>
                <br />

                {scheduleConfig && <CalendarTable scheduleConfig={scheduleConfig} />}
            </Spin>
        );
    }
}

export default withRouter(AddNewScheduleConfigContainer);
