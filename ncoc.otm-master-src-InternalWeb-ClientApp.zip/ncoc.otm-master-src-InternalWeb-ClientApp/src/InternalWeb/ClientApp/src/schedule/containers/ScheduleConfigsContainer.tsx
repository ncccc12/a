import React from 'react';
import { Table, Button, Spin, Tag } from 'antd';
import { Link, RouteComponentProps, withRouter } from 'react-router-dom';
import { DictionaryDto, AreaVm, ScheduleConfigRowVm, GetScheduleConfigsQuery } from '../../services/Client';
import { dictionaryClient, schedulesClient } from '../../services';
import moment from 'moment';
import SchedulesFilterForm, { ScheduleSearchForm } from '../components/SchedulesFilterForm';
import { AppState } from '../../store/reducers';
import {
    ScheduleManagerState,
    changeScheduleConfigFilterForm,
    resetScheduleConfigFilterForm,
    changeReportScheduleConfigFilterForm,
    resetReportScheduleConfigFilterForm,
} from '../ducks/ScheduleMangerDuck';
import { connect } from 'react-redux';
import { WrappedFormUtils } from 'antd/lib/form/Form';

const { Column } = Table;
// export type ScheduleConfigSearchForm = {
//     locationCode: string;
//     areaCode: string;
//     datePeriod: moment.Moment[];
//     isActive: number[];
// };

const mapStateToProps = (state: AppState): ScheduleManagerState => ({
    scheduleConfigFilterForm: state.ScheduleManagerDuck.scheduleConfigFilterForm,
    reportScheduleConfigFilterForm: state.ScheduleManagerDuck.reportScheduleConfigFilterForm,
});

const mapDispatchToProps = {
    changeScheduleConfigFilterForm,
    resetScheduleConfigFilterForm,
    changeReportScheduleConfigFilterForm,
    resetReportScheduleConfigFilterForm,
};

type Props = {
    isReportPage?: boolean;
} & RouteComponentProps<any> &
    typeof mapDispatchToProps &
    ReturnType<typeof mapStateToProps>;

type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    scheduleConfigs: ScheduleConfigRowVm[];
    loading: boolean;
};

const ScheduleConfigsContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(
    class extends React.Component<Props, State> {
        filterFormRef: any;

        constructor(props: Props) {
            super(props);
            this.state = {
                loading: true,
                locations: [],
                areas: [],
                scheduleConfigs: [],
                filteredAreas: [],
            };
        }

        async componentDidMount() {
            await this.loadDictionaries();
            this.search();
        }

        initFilter = (ref: any) => {
            if (ref) {
                this.filterFormRef = ref;
                this.search();
            }
        };

        search = async () => {
            this.setState({ loading: true });
            const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: ScheduleSearchForm) => {
                let query = new GetScheduleConfigsQuery();
                query.locationCode = values.locationCode;
                query.areaCode = values.areaCode;
                query.datePeriod = values.datePeriod?.map((r) => r.utc(true).toDate());
                query.isActive = values.isActive;
                const data = await schedulesClient.getScheduleConfigs(query);

                this.setState({ scheduleConfigs: data, loading: false });
            });
        };

        loadDictionaries = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();
            // let logsheets = await dictionaryClient.getLogsheets();

            this.setState({ locations, areas });
        };

        resetFilter = () => {
            const { isReportPage, resetReportScheduleConfigFilterForm, resetScheduleConfigFilterForm } = this.props;
            if (isReportPage) {
                resetReportScheduleConfigFilterForm();
            } else {
                resetScheduleConfigFilterForm();
            }

            this.setState({}, () => {
                this.search();
            });
        };

        renderActions = (config: ScheduleConfigRowVm) => {
            const { isReportPage, history } = this.props;
            return (
                <>
                    {!isReportPage && (
                        <Button
                            style={{ marginLeft: 5 }}
                            icon="edit"
                            title="Edit"
                            onClick={() => history.push(`/scheduleManager/scheduleConfigs/${config.id}`)}
                        ></Button>
                    )}

                    {isReportPage && (
                        <Button
                            style={{ marginLeft: 5 }}
                            onClick={() => history.push(`/reports/schedule-configs/${config.id}`)}
                        >
                            {' '}
                            View report{' '}
                        </Button>
                    )}
                </>
            );
        };

        renderDatePeriod = (period: Date[]) => {
            let date1 = moment(period[0]).format('DD.MM.YYYY');
            let date2 = moment(period[1]).format('DD.MM.YYYY');

            return (
                <span>
                    {date1} - {date2}
                </span>
            );
        };

        renderGroups = (groups: string[]): JSX.Element[] => {
            return groups.map((r) => {
                return (
                    <Tag key={r} color="blue">
                        {r}
                    </Tag>
                );
            });
        };

        renderSchedules = (schedules: string[]) => {
            return schedules.map((r) => {
                return (
                    <Tag key={r} color="#108ee9">
                        {r}
                    </Tag>
                );
            });
        };

        render() {
            const { loading, scheduleConfigs, locations, areas } = this.state;
            const {
                isReportPage,
                scheduleConfigFilterForm,
                reportScheduleConfigFilterForm,
                changeReportScheduleConfigFilterForm,
                changeScheduleConfigFilterForm,
            } = this.props;
           
            let filterFrom = scheduleConfigFilterForm!;
            let changeFilterFormAction: any = changeScheduleConfigFilterForm;
            if (isReportPage) {
                filterFrom = reportScheduleConfigFilterForm!;
                changeFilterFormAction = changeReportScheduleConfigFilterForm;
            }

            return (
                <Spin spinning={loading}>
                    <SchedulesFilterForm
                        searchForm={filterFrom}
                        areas={areas}
                        locations={locations}
                        wrappedComponentRef={this.initFilter}
                        onSearch={this.search}
                        onReset={this.resetFilter}
                        onChange={changeFilterFormAction}
                    />
                    <Table
                        rowKey={(r: any) => r.id + ''}
                        dataSource={scheduleConfigs}
                        bordered
                        title={() =>
                            !isReportPage && (
                                <Link to="/scheduleManager/scheduleConfigs/new">
                                    <Button>Add new</Button>{' '}
                                </Link>
                            )
                        }
                    >
                        <Column title="Location" dataIndex="locationName"></Column>
                        <Column title="Area" dataIndex="areaName"></Column>

                        <Column title="Name" align="center" dataIndex="name"></Column>
                        <Column title="Year" align="center" dataIndex="year"></Column>
                        <Column title="Rotation type" align="center" dataIndex="rotationType"></Column>
                        <Column
                            title="Date period"
                            align="center"
                            dataIndex="datePeriod"
                            render={this.renderDatePeriod}
                        ></Column>
                        <Column title="Groups" align="center" dataIndex="groups" render={this.renderGroups}></Column>
                        <Column title="Schedules" dataIndex="schedules" render={this.renderSchedules}></Column>
                        <Column
                            dataIndex="isActive"
                            title="Is Active"
                            render={(isActive) => (isActive ? 'Yes' : 'No')}
                        ></Column>
                        <Column title="Actions" align="center" render={(row) => this.renderActions(row)}></Column>
                    </Table>
                </Spin>
            );
        }
    },
);

export default withRouter(ScheduleConfigsContainer);
