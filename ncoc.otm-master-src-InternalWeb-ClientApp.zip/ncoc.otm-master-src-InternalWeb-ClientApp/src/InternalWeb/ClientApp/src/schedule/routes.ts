import { RouteProps } from 'react-router';
import SchedulesContainer from './containers/SchedulesContainer';
import NewSchedulePage from './pages/NewSchedulePage';
import ScheduleConfigsPage from './pages/ScheduleConfigsPage';
import NewScheduleConfigPage from './pages/NewScheduleConfigPage';
import EditScheduleConfigPage from './pages/EditScheduleConfigPage';
import EditSchedulePage from './pages/EditSchedulePage';
import OperatorsPage from './pages/OperatorsPage';

const routes: RouteProps[] = [
    // {
    //     path: '/scheduleManager',
    //     component: ScheduleManagerPage,
    //     exact: true,
    // },
    {
        path: '/scheduleManager/scheduleConfigs',
        component: ScheduleConfigsPage,
        exact: true,
    },
    {
        path: '/scheduleManager/scheduleConfigs/new',
        component: NewScheduleConfigPage,
        exact: true,
    },
    {
        path: '/scheduleManager/scheduleConfigs/:id',
        component: EditScheduleConfigPage,
        exact: true,
    },
    {
        path: '/scheduleManager/schedules',
        component: SchedulesContainer,
        exact: true,
    },
    {
        path: '/scheduleManager/schedules/new',
        component: NewSchedulePage,
        exact: true,
    },
    {
        path: '/scheduleManager/schedules/:id',
        component: EditSchedulePage,
        exact: true,
    },
    {
        path: '/scheduleManager/operators',
        component: OperatorsPage,
        exact: true,
    },
];

export default routes;
