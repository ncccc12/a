import React from 'react';
import { Form, Modal, TimePicker, Button, Icon } from 'antd';
import { FormComponentProps, FormProps } from 'antd/lib/form';
import { LogsheetListItemVm } from '../services/Client';
import moment from 'moment';
import './ConfigureScheduleModal.css';

type Props = {
    visible: boolean;
    logsheet?: LogsheetListItemVm;
    loading: boolean;
    onOk: () => void;
    onCancel: () => void;
} & FormComponentProps;

type State = {
    keys: number[];
};

const LogsheetModal = Form.create<Props>()(
    class extends React.Component<Props, State> {
        id = 0;
        timeFormat = 'HH:mm';

        constructor(props: Props) {
            super(props);

            this.state = {
                keys: [],
            };
        }

        componentDidMount() {
            const logsheet = this.props.logsheet;
            if (!logsheet) return;

            this.initTimeOptions();
        }

        initTimeOptions = () => {
            const { form, logsheet } = this.props;

            const keys: number[] = [];

            this.id = logsheet!.schedule!.timeOptions!.length;
            let timeOptions: any[] = [];

            for (let i = 0; i < this.id; i++) {
                let opt = logsheet!.schedule!.timeOptions![i];
                keys.push(i);
                timeOptions.push({
                    id: opt.id,
                    time: moment(opt.time, this.timeFormat),
                });
            }

            this.setState({ keys: keys }, () => {
                form.setFieldsValue({
                    timeOptions,
                });
            });
        };

        addTime = () => {
            const { form } = this.props;
            const keys: number[] = form.getFieldValue('keys');
            const nextKeys = keys.concat(this.id++);

            form.setFieldsValue({
                keys: nextKeys,
            });
        };

        removeTime = (k: number) => {
            const { form } = this.props;
            const keys: number[] = form.getFieldValue('keys');

            if (keys.length === 1) return;

            form.setFieldsValue({
                keys: keys.filter(r => r !== k),
            });
        };

        render() {
            const {
                visible,
                logsheet,
                form: { getFieldDecorator, getFieldValue },
            } = this.props;

            getFieldDecorator('keys', { initialValue: this.state.keys });
            const keys: number[] = getFieldValue('keys');

            const formItemLayoutWithOutLabel: FormProps = {
                wrapperCol: {
                    span: 16,
                    offset: 8,
                },
            };

            const formItemLayout: FormProps = {
                labelCol: {
                    span: 8,
                },
                wrapperCol: {
                    span: 16,
                },
            };

            getFieldDecorator('id', { initialValue: logsheet && logsheet.id });

            return (
                <Modal
                    visible={visible}
                    title="Edit logsheet"
                    okText="Save"
                    className="config-schedule-modal"
                    confirmLoading={this.props.loading}
                    onOk={this.props.onOk}
                    onCancel={this.props.onCancel}
                >
                    <Form layout="horizontal" {...formItemLayout} labelAlign="left">
                        <Form.Item label="Logsheet name">{logsheet && logsheet.name}</Form.Item>
                        <Form.Item label="Schedule type">{logsheet && logsheet.schedule!.type}</Form.Item>
                        {keys.map((r, idx) => {
                            getFieldDecorator(`timeOptions[${r}].id`);

                            return (
                                <Form.Item
                                    key={r}
                                    label={idx === 0 ? 'Times' : ''}
                                    {...(idx === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                >
                                    {getFieldDecorator(`timeOptions[${r}].time`, {
                                        rules: [{ required: true, message: 'time is required' }],
                                    })(
                                        <TimePicker
                                            minuteStep={5}
                                            style={{ marginRight: 8, width: 180 }}
                                            format={this.timeFormat}
                                        />,
                                    )}
                                    {keys.length > 1 ? (
                                        <Icon
                                            className="dynamic-delete-button"
                                            type="minus-circle-o"
                                            title="Remove"
                                            onClick={() => this.removeTime(r)}
                                        />
                                    ) : null}
                                </Form.Item>
                            );
                        })}

                        <Form.Item {...formItemLayoutWithOutLabel}>
                            <Button type="dashed" onClick={this.addTime} style={{ width: 180 }}>
                                <Icon type="plus" /> Add time
                            </Button>
                        </Form.Item>
                    </Form>
                </Modal>
            );
        }
    },
);

export default LogsheetModal;
