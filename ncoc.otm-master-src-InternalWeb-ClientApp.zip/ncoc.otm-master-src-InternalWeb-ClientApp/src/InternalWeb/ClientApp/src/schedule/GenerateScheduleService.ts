import moment from 'moment';

import { RotationCalendarType, RotationTypes } from './constants';
import { ScheduleConfig, GroupConfig } from './types';
import {
    ScheduleConfigVm,
    GroupConfigDto,
    GroupSimpleVm,
    ScheduleConfigReportVm,
    ReportGroupConfigDto,
} from '../services/Client';
import { ConfigFormModel } from './components/ScheduleConfigForm';
import { ReportScheduleConfig, ReportGroupConfig } from '../repots/types';

class GenerateScheduleService {
    mapFormToScheduleConfig = (values: ConfigFormModel, groups: GroupSimpleVm[]): ScheduleConfig => {
        let config: ScheduleConfig = {
            areaCode: values.areaCode,
            datePeriod: values.datePeriod,
            locationCode: values.locationCode,
            rotationType: values.rotationType,
            scheduleConfigName: values.scheduleConfigName,
            year: values.year,
            group1: {
                code: values.group1!,
                dayShift: values.group1DayShift,
                name: values.group1 && groups.find((r) => r.code === values.group1)!.name,
            },
            group2: {
                code: values.group2!,
                dayShift: values.group2DayShift,
                name: values.group2 && groups.find((r) => r.code === values.group2)!.name,
            },
            group3: {
                code: values.group3!,
                dayShift: values.group3DayShift,
                name: values.group3 && groups.find((r) => r.code === values.group3)!.name,
            },
            group4: {
                code: values.group4!,
                dayShift: values.group4DayShift,
                name: values.group4 && groups.find((r) => r.code === values.group4)!.name,
            },
            // dayShiftFirst1: values.group1DayShift ? 1 : 2,
            // dayShiftFirst2: values.group3DayShift ? 3 : 4,
            switchShift: values.switchShift,
            isManual: values.isManual,
        };

        return config;
    };

    mapVmToScheduleConfig(vm: ScheduleConfigVm): ScheduleConfig {
        let config: ScheduleConfig = {
            areaCode: vm.areaCode,
            locationCode: vm.locationCode,
            rotationType: vm.rotationTypeCode,
            scheduleConfigName: vm.name,
            year: vm.year,
            group1: this.mapDtoToGroupConfig(vm.groups![0]),
            group2: this.mapDtoToGroupConfig(vm.groups![1]),
            group3: this.mapDtoToGroupConfig(vm.groups![2]),
            group4: this.mapDtoToGroupConfig(vm.groups![3]),
            datePeriod: [moment(vm.startDate), moment(vm.endDate)],
            // dayShiftFirst1: vm.dayShiftFirst1!,
            // dayShiftFirst2: vm.dayShiftFirst2!,
        };

        return config;
    }

    mapDtoToGroupConfig = (dto: GroupConfigDto): GroupConfig => {
        let group: GroupConfig = {
            code: dto.code!,
            name: dto.name,
            schedule: dto.schedule!.split('').map((r) => Number(r)),
        };

        return group;
    };

    mapVmToReportScheduleConfig(vm: ScheduleConfigReportVm): ReportScheduleConfig {
        let config: ReportScheduleConfig = {
            id: vm.id,
            areaCode: vm.areaCode,
            areaName: vm.areaName,
            locationCode: vm.locationCode,
            locationName: vm.locationName,
            rotationType: vm.rotationTypeCode,
            scheduleConfigName: vm.name,
            year: vm.year,
            group1: this.mapDtoToReportGroupConfig(vm.groups![0]),
            group2: this.mapDtoToReportGroupConfig(vm.groups![1]),
            group3: this.mapDtoToReportGroupConfig(vm.groups![2]),
            group4: this.mapDtoToReportGroupConfig(vm.groups![3]),
            datePeriod: [moment(vm.startDate), moment(vm.endDate)],
            // dayShiftFirst1: vm.dayShiftFirst1!,
            // dayShiftFirst2: vm.dayShiftFirst2!,
        };

        return config;
    }

    mapDtoToReportGroupConfig = (dto: ReportGroupConfigDto): ReportGroupConfig => {
        let group: ReportGroupConfig = {
            code: dto.code!,
            name: dto.name,
            schedule: dto.schedule!.split('').map((r) => Number(r)),
            reportSchedule: dto.reportSchedule!.split('').map((r) => Number(r)),
        };

        return group;
    };

    getEmptyScheduleArr(startDateIdx: number, endDateIdx: number, isLeapYear: boolean): number[] {
        const result: number[] = [];
        const daysInYear = isLeapYear ? 366 : 365;

        for (let i = 0; i < daysInYear; i++) {
            if (i >= startDateIdx && i <= endDateIdx) {
                result.push(RotationCalendarType.Rest);
            } else {
                result.push(RotationCalendarType.None);
            }
        }

        return result;
    }

    generateSchedule(config: ScheduleConfig, updateOnlyFutureDates: boolean = false) {
        const startDateIdx = config.datePeriod![0].dayOfYear() - 1;
        const endDateIdx = config.datePeriod![1].dayOfYear() - 1;
        const isLeapYear = config.datePeriod![1].isLeapYear();

        if (updateOnlyFutureDates) {
            let futureDateIdx = Math.max(moment().dayOfYear(), startDateIdx);

            this.resetSchedulePeriod(futureDateIdx, endDateIdx, config.group1!.schedule!);
            this.resetSchedulePeriod(futureDateIdx, endDateIdx, config.group2!.schedule!);
            this.resetSchedulePeriod(futureDateIdx, endDateIdx, config.group3!.schedule!);
            this.resetSchedulePeriod(futureDateIdx, endDateIdx, config.group4!.schedule!);

            if (config.isManual) return;

            // merge
            const schedulesObj = this.updateSchedule(config);
            this.mergeTwoSchedules(config.group1!.schedule!, schedulesObj.schedule1, futureDateIdx);
            this.mergeTwoSchedules(config.group2!.schedule!, schedulesObj.schedule2, futureDateIdx);
            this.mergeTwoSchedules(config.group3!.schedule!, schedulesObj.schedule3, futureDateIdx);
            this.mergeTwoSchedules(config.group4!.schedule!, schedulesObj.schedule4, futureDateIdx);
        } else {
            config.group1!.schedule = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
            config.group2!.schedule = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
            config.group3!.schedule = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
            config.group4!.schedule = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);

            if (config.isManual) return;

            const schedulesObj = this.updateSchedule(config);

            // total update
            config.group1!.schedule = schedulesObj.schedule1;
            config.group2!.schedule = schedulesObj.schedule2;
            config.group3!.schedule = schedulesObj.schedule3;
            config.group4!.schedule = schedulesObj.schedule4;
        }
    }

    mergeTwoSchedules(destSchedule: number[], srcSchedule: number[], startMergeIdx: number) {
        for (let i = startMergeIdx; i < destSchedule.length; i++) {
            destSchedule[i] = srcSchedule[i];
        }
    }

    resetSchedulePeriod(starDatetIdx: number, endDateIdx: number, schedule: number[]): void {
        for (let i = starDatetIdx; i <= endDateIdx; i++) {
            schedule[i] = RotationCalendarType.Rest;
        }
    }

    getDayLimit(rotationType: string): number {
        let dayLimit: number;
        if (rotationType === RotationTypes.Rotation28) {
            dayLimit = 28;
        } else if (rotationType === RotationTypes.Rotation14) {
            dayLimit = 14;
        } else if (rotationType === RotationTypes.Rotation21) {
            dayLimit = 21;
        } else if (rotationType === RotationTypes.Rotation42) {
            dayLimit = 42;
        } else {
            dayLimit = 7;
        }

        return dayLimit;
    }

    updateSchedule(
        config: ScheduleConfig,
    ): {
        schedule1: number[];
        schedule2: number[];
        schedule3: number[];
        schedule4: number[];
    } {
        let schedule1: number[] = [];
        let schedule2: number[] = [];
        let schedule3: number[] = [];
        let schedule4: number[] = [];

        const startDateIdx = config.datePeriod![0].dayOfYear() - 1;
        const endDateIdx = config.datePeriod![1].dayOfYear() - 1;
        const isLeapYear = moment([config!.year!, 0, 1]).isLeapYear();

        schedule1 = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
        schedule2 = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
        schedule3 = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);
        schedule4 = this.getEmptyScheduleArr(startDateIdx, endDateIdx, isLeapYear);

        const dayLimit = this.getDayLimit(config.rotationType!);

     

        this.fillSchedule(startDateIdx, endDateIdx, 0, schedule1, dayLimit, config.switchShift);
        this.fillSchedule(startDateIdx, endDateIdx, dayLimit / 2, schedule4, dayLimit, config.switchShift);
        this.fillSchedule(startDateIdx, endDateIdx, -1 * (dayLimit / 2), schedule2, dayLimit, config.switchShift);
        this.fillSchedule(startDateIdx, endDateIdx, -1 * dayLimit, schedule3, dayLimit, config.switchShift);

        return {
            schedule1,
            schedule2,
            schedule3,
            schedule4,
        };
    }

    private fillSchedule(
        startDateIdx: number,
        endDateIdx: number,
        count: number,
        schedule: number[],
        dayLimit: number,
        isSwitch: boolean = false,
    ) {
        const { Day, Night } = RotationCalendarType;
        let first = isSwitch ? Night : Day;
        let second = isSwitch ? Day : Night;
        
        for (let i = startDateIdx; i <= endDateIdx; i++) {
            count++;

            if (count >= 1) {
                schedule[i] = count <= dayLimit / 2 ? first : second;
            }

            if (count === dayLimit) {
                // rest
                count *= -1;
            }
        }
    }

    // updateSchedule(
    //     schedule1: number[],
    //     schedule2: number[],
    //     params: Params,
    //     startDate: moment.Moment,
    //     endDate: moment.Moment,
    //     isFirst: boolean = true,
    // ): {
    //     schedule1: number[];
    //     schedule2: number[];
    // } {
    //     const startIdx = this.getStartIndex(startDate, endDate!);
    //     const endIdx = endDate!.dayOfYear() - 1;
    //     const { Day, Night } = RotationCalendarType;
    //     this.resetSchedulePeriod(startIdx, endIdx, schedule1);
    //     this.resetSchedulePeriod(startIdx, endIdx, schedule2);

    //     let count = 0;
    //     const dayLimit = this.getDayLimit(params.rotationType!);

    //     if (params.startWith === StartsWithTypes.DayOnly) {
    //         for (let i = startIdx; i <= endIdx; i++) {
    //             if (count > dayLimit) {
    //                 isFirst = !isFirst;
    //                 count = 0;
    //             }

    //             if (isFirst) {
    //                 schedule1[i] = Day;
    //             } else {
    //                 schedule2[i] = Day;
    //             }

    //             count++;
    //         }
    //     } else if (
    //         ([RotationTypes.Rotation28, RotationTypes.Rotation14] as string[]).includes(params.rotationType!) &&
    //         ([StartsWithTypes.DayFirst, StartsWithTypes.NightFirst] as string[]).includes(params.startWith!)
    //     ) {
    //         let isDayFirst: boolean;

    //         for (let i = startIdx; i <= endIdx; i++) {
    //             if (count > dayLimit) {
    //                 isFirst = !isFirst;
    //                 count = 0;
    //             }
    //             isDayFirst = count < (dayLimit + 1) / 2;
    //             isDayFirst = params.startWith === StartsWithTypes.DayFirst ? isDayFirst : !isDayFirst;

    //             if (isFirst) {
    //                 schedule1[i] = isDayFirst ? Day : Night;
    //             } else {
    //                 schedule2[i] = isDayFirst ? Day : Night;
    //             }

    //             count++;
    //         }
    //     } else if (
    //         params.rotationType === RotationTypes.Rotation7 &&
    //         ([StartsWithTypes.DayShiftRestNightShift, StartsWithTypes.NightShiftRestDayShift] as string[]).includes(
    //             params.startWith!,
    //         )
    //     ) {
    //         let isDayFirst: boolean = params.startWith === StartsWithTypes.DayShiftRestNightShift;

    //         for (let i = startIdx; i <= endIdx; i++) {
    //             if (count > dayLimit) {
    //                 isFirst = !isFirst;

    //                 if (isFirst) {
    //                     isDayFirst = !isDayFirst;
    //                 }

    //                 count = 0;
    //             }
    //             if (isDayFirst) {
    //                 if (isFirst) {
    //                     schedule1[i] = Day;
    //                 } else {
    //                     schedule2[i] = Day;
    //                 }
    //             } else {
    //                 if (isFirst) {
    //                     schedule1[i] = Night;
    //                 } else {
    //                     schedule2[i] = Night;
    //                 }
    //             }

    //             count++;
    //         }
    //     }

    //     return { schedule1, schedule2 };
    // }

    // generateSchedule(
    //     params: Params,
    // ): {
    //     schedule1: number[];
    //     schedule2: number[];
    // } {
    //     const startIdx = this.getStartIndex(params.startDate!, params.endDate!);
    //     const endIdx = params.endDate!.dayOfYear() - 1;
    //     const isLeapYear = params.endDate!.isLeapYear();
    //     const schedule1: number[] = this.getEmptyScheduleArr(startIdx, endIdx, isLeapYear);
    //     const schedule2: number[] = this.getEmptyScheduleArr(startIdx, endIdx, isLeapYear);

    //     if (params.isManual) {
    //         return { schedule1, schedule2 };
    //     }

    //     return this.updateSchedule(schedule1, schedule2, params, params.startDate!, params.endDate!);
    // }

    // getGroupSchedules(
    //     params: GroupParams,
    // ): Array<{
    //     schedule1: number[];
    //     schedule2: number[];
    // }> {
    //     const paramArr: Params[] = [];

    //     for (const grpParam of params!.groups!) {
    //         if (!grpParam) {
    //             continue;
    //         }

    //         const param: Params = {
    //             startDate: grpParam.startDate,
    //             endDate: grpParam.endDate,
    //             isManual: grpParam.isManual,
    //             startWith: grpParam.startWith,
    //             rotationType: params.rotationType,
    //         };

    //         paramArr.push(param);
    //     }

    //     // get schedules for each group
    //     const groupSchedules: Array<{
    //         schedule1: number[];
    //         schedule2: number[];
    //     }> = [];

    //     for (const param of paramArr) {
    //         const groupSchedule = this.generateSchedule(param);
    //         groupSchedules.push(groupSchedule);
    //     }

    //     return groupSchedules;
    // }

    getDaysInMonth(month: moment.Moment): number[] {
        const days: number[] = [];

        for (let i = 1; i <= month.daysInMonth(); i++) {
            days.push(i);
        }

        return days;
    }
}

const generateScheduleSrv = new GenerateScheduleService();
export default generateScheduleSrv;
