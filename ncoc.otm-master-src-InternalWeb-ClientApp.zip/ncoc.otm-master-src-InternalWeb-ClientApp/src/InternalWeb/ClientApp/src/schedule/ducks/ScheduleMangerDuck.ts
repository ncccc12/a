import { ScheduleSearchForm } from '../components/SchedulesFilterForm';

// actions
const CHANGE_SCHEDULE_FILTER_FORM = 'CHANGE_SCHEDULE_FILTER_FORM';
const RESET_SCHEDULE_FILTER_FORM = 'RESET_SCHEDULE_FILTER_FORM';

const CHANGE_SCHEDULE_CONFIG_FILTER_FORM = 'CHANGE_SCHEDULE_CONFIG_FILTER_FORM';
const RESET_SCHEDULE_CONFIG_FILTER_FORM = 'RESET_SCHEDULE_CONFIG_FILTER_FORM';

const CHANGE_REPORT_SCHEDULE_CONFIG_FILTER_FORM = 'CHANGE_REPORT__SCHEDULE_CONFIG_FILTER_FORM';
const RESET_REPORT_SCHEDULE_CONFIG_FILTER_FORM = 'RESET_REPORT_SCHEDULE_CONFIG_FILTER_FORM';

interface ChangeScheduleFilterAction {
    type: typeof CHANGE_SCHEDULE_FILTER_FORM;
    filters: ScheduleSearchForm;
}

export const changeScheduleFilterForm = (form: ScheduleSearchForm): ChangeScheduleFilterAction => {
    return {
        type: CHANGE_SCHEDULE_FILTER_FORM,
        filters: form,
    };
};

interface ResetScheduleFilterFormAction {
    type: typeof RESET_SCHEDULE_FILTER_FORM;
}

export const resetScheduleFilterForm = (): ResetScheduleFilterFormAction => {
    return {
        type: RESET_SCHEDULE_FILTER_FORM,
    };
};

// schedule config

interface ChangeScheduleConfigFilterAction {
    type: typeof CHANGE_SCHEDULE_CONFIG_FILTER_FORM;
    filters: ScheduleSearchForm;
}

export const changeScheduleConfigFilterForm = (form: ScheduleSearchForm): ChangeScheduleConfigFilterAction => {
    return {
        type: CHANGE_SCHEDULE_CONFIG_FILTER_FORM,
        filters: form,
    };
};

interface ResetScheduleConfigFilterFormAction {
    type: typeof RESET_SCHEDULE_CONFIG_FILTER_FORM;
}

export const resetScheduleConfigFilterForm = (): ResetScheduleConfigFilterFormAction => {
    return {
        type: RESET_SCHEDULE_CONFIG_FILTER_FORM,
    };
};

// report schedule config

interface ChangeReportScheduleConfigFilterAction {
    type: typeof CHANGE_REPORT_SCHEDULE_CONFIG_FILTER_FORM;
    filters: ScheduleSearchForm;
}

export const changeReportScheduleConfigFilterForm = (
    form: ScheduleSearchForm,
): ChangeReportScheduleConfigFilterAction => {
    return {
        type: CHANGE_REPORT_SCHEDULE_CONFIG_FILTER_FORM,
        filters: form,
    };
};

interface ResetReportScheduleConfigFilterFormAction {
    type: typeof RESET_REPORT_SCHEDULE_CONFIG_FILTER_FORM;
}

export const resetReportScheduleConfigFilterForm = (): ResetReportScheduleConfigFilterFormAction => {
    return {
        type: RESET_REPORT_SCHEDULE_CONFIG_FILTER_FORM,
    };
};

type FilterActionTypes =
    | ChangeScheduleFilterAction
    | ResetScheduleFilterFormAction
    | ChangeScheduleConfigFilterAction
    | ResetScheduleConfigFilterFormAction
    | ChangeReportScheduleConfigFilterAction
    | ResetReportScheduleConfigFilterFormAction;

// state

export interface ScheduleManagerState {
    scheduleFilterForm?: ScheduleSearchForm;
    scheduleConfigFilterForm?: ScheduleSearchForm;
    reportScheduleConfigFilterForm?: ScheduleSearchForm;
    //
}

const initialFormState: ScheduleSearchForm = {
    areaCode: '',
    locationCode: '',
    isActive: [1],
    datePeriod: [],
};

const initialState: ScheduleManagerState = {
    scheduleFilterForm: { ...initialFormState },
    scheduleConfigFilterForm: { ...initialFormState },
    reportScheduleConfigFilterForm: { ...initialFormState },
};

// duck
const ScheduleManagerDuck = (state = initialState, action: FilterActionTypes): ScheduleManagerState => {
    switch (action.type) {
        case 'CHANGE_SCHEDULE_FILTER_FORM':
            return { ...state, scheduleFilterForm: { ...state.scheduleFilterForm, ...action.filters } };

        case 'RESET_SCHEDULE_FILTER_FORM':
            return { ...state, scheduleFilterForm: { ...initialFormState } };

        case 'CHANGE_SCHEDULE_CONFIG_FILTER_FORM':
            return { ...state, scheduleConfigFilterForm: { ...state.scheduleConfigFilterForm, ...action.filters } };

        case 'RESET_SCHEDULE_CONFIG_FILTER_FORM':
            return { ...state, scheduleConfigFilterForm: { ...initialFormState } };

        case 'CHANGE_REPORT__SCHEDULE_CONFIG_FILTER_FORM':
            return {
                ...state,
                reportScheduleConfigFilterForm: { ...state.reportScheduleConfigFilterForm, ...action.filters },
            };

        case 'RESET_REPORT_SCHEDULE_CONFIG_FILTER_FORM':
            return { ...state, reportScheduleConfigFilterForm: { ...initialFormState } };
        default:
            return state;
    }
};

export default ScheduleManagerDuck;
