import {  DatePicker, Form, Modal, Select } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import moment from 'moment';
import React from 'react';
import {Item, RotationCalendarTypes} from '../constants';
//import { Item, RotationCalendarTypes } from '../constant';

const Option = Select.Option;
const FormItem = Form.Item;

type Props = {
    visible: boolean;
    startDate: moment.Moment;
    endDate: moment.Moment;
    onOk: (e: any) => void;
    onCancel: (e: any) => void;
} & FormComponentProps;

export const EditSelectedDatesModal = Form.create<Props>()(
    class extends React.Component<Props> {
        static displayName: string = 'EditSelectedDatesModal';
        rowConf: any = {
            style: {
                width: 300,
            },
        };

        render(): JSX.Element {
            const { onOk, visible, onCancel, startDate, endDate } = this.props;
            const { getFieldDecorator } = this.props.form;

            return (
                <Modal
                    title="Edit selected dates"
                    visible={visible}
                    centered={true}
                    width={400}
                    onOk={onOk}
                    onCancel={onCancel}
                >
                    <Form layout="inline" labelCol={{ span: 8 }} labelAlign="left">
                        <FormItem label="Start date" {...this.rowConf}>
                            <DatePicker disabled={true} value={startDate} />
                        </FormItem>
                        <FormItem label="End date" {...this.rowConf}>
                            <DatePicker disabled={true} value={endDate} />
                        </FormItem>

                        <FormItem label="Shift type" {...this.rowConf}>
                            {getFieldDecorator('shiftType', { initialValue: RotationCalendarTypes[0].value })(
                                <Select style={{ width: 195 }}>
                                    {RotationCalendarTypes.map((type: Item) => {
                                        return (
                                            <Option key={type.value} value={type.value}>
                                                {type.text}
                                            </Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </FormItem>
                        {/* <FormItem labelCol={{ span: 12 }} label="Calculate remaining" {...this.rowConf}>
                            {getFieldDecorator('calculateRemaining', {
                                valuePropName: 'checked',
                            })(<Checkbox />)}
                        </FormItem> */}
                    </Form>
                </Modal>
            );
        }
    },
);
