export enum RotationCalendarType {
    Rest = 0,
    Day,
    Night,
    None,
}

export enum RotationTypes {
    Rotation42 = 'ROT42',
    Rotation28 = 'ROT28',
    Rotation14 = 'ROT14',
    Rotation21 = 'ROT21',
}


export const RotationCalendarTypes: Item[] = [
    { value: 0, text: 'Rest' },
    { value: 1, text: 'Day' },
    { value: 2, text: 'Night' },
];

export interface Item {
    value: any;
    text: string;
}
