import React from 'react';
import { Form, Row, Col, Select, Input, Checkbox, DatePicker, Card } from 'antd';
import { FormComponentProps, FormItemProps } from 'antd/lib/form';
import { dictionaryClient } from '../../services';
import { AreaVm, DictionaryDto, GroupSimpleVm } from '../../services/Client';
import moment, { Moment } from 'moment';

export interface ConfigFormModel {
    areaCode?: string;
    datePeriod?: moment.Moment[];
    group1?: string;
    group1DayShift?: boolean;
    group2?: string;
    group2DayShift?: boolean;
    group3?: string;
    group3DayShift?: boolean;
    group4?: string;
    group4DayShift?: boolean;
    locationCode?: string;
    rotationType?: string;
    scheduleConfigName?: string;
    year?: number;
    isManual?: boolean;
    switchShift?: boolean;
}

type Props = {
    groups: GroupSimpleVm[];
    isEdit?: boolean;
    onFormChange: (e: any) => void;
    onLoadingChange(loading: boolean): void;
} & FormComponentProps<any>;

type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    filteredGroups: GroupSimpleVm[];
    rotationTypes: DictionaryDto[];
};

const ScheduleConfigForm = Form.create<Props>()(
    class extends React.Component<Props, State> {
        years: number[] = [];

        constructor(props: Props) {
            super(props);
            this.state = {
                locations: [],
                areas: [],
                filteredAreas: [],
                filteredGroups: [],
                rotationTypes: [],
            };
        }

        componentDidMount() {
            this.loadDictionaries();

            let currYear = moment().year();
            this.years.push(...[currYear, currYear + 1]);
        }

        loadDictionaries = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();
            let rotationTypes = await dictionaryClient.getDictionary('RotationTypes');
            this.setState({ locations, areas, rotationTypes });

            this.filterDics();
            this.props.onLoadingChange(false);
        };

        filterDics = () => {
            const { form } = this.props;
            const locationCode = form.getFieldValue('locationCode');
            const areaCode = form.getFieldValue('areaCode');
            this.filterAreas(locationCode);
            this.filterGroups(areaCode);
        };

        handleLocationChange = (locationCode: string) => {
            const { form } = this.props;

            this.filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
                group1: undefined,
                group2: undefined,
                group3: undefined,
                group4: undefined,
            });

            this.props.onFormChange(undefined);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.state;
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        handleAreaChange = (areaCode: string) => {
            const { form } = this.props;

            this.filterGroups(areaCode);
            form.setFieldsValue({
                group1: undefined,
                group2: undefined,
                group3: undefined,
                group4: undefined,
            });

            this.props.onFormChange(undefined);
        };

        filterGroups = (areaCode: string) => {
            const { groups } = this.props;
            const filteredGroups = groups.filter((r) => r.areaCode === areaCode);
            this.setState({ filteredGroups });
        };

        // handleDayShiftChange = (val: CheckboxChangeEvent) => {
        //     if (val.target.checked) {
        //         const { form } = this.props;

        //         switch (val.target.id) {
        //             case 'group1DayShift':
        //                 form.setFieldsValue({
        //                     group2DayShift: false,
        //                 });
        //                 break;
        //             case 'group2DayShift':
        //                 form.setFieldsValue({
        //                     group1DayShift: false,
        //                 });
        //                 break;
        //             case 'group3DayShift':
        //                 form.setFieldsValue({
        //                     group4DayShift: false,
        //                 });
        //                 break;
        //             case 'group4DayShift':
        //                 form.setFieldsValue({
        //                     group3DayShift: false,
        //                 });
        //                 break;

        //             default:
        //                 break;
        //         }
        //     }
        // };

        handleYearChange = (year: number) => {
            this.props.form.setFieldsValue({
                datePeriod: undefined,
            });

            this.props.onFormChange(undefined);
        };

        disableDate = (date: moment.Moment | null): boolean => {
            let year = this.props.form.getFieldValue('year');

            return !!date && (date.year() < year || date.year() > year);
        };

        validateDatePeriod = (rule: any, value: moment.Moment[], callback: any) => {
            if (this.props.isEdit && value[1].endOf('day') <= moment().endOf('day')) {
                callback('End date cannot be smaller or equal to current date');
            }

            callback();
        };

        render() {
            const { locations, filteredAreas, filteredGroups, rotationTypes } = this.state;
            const {
                form: { getFieldDecorator },
                form,
                isEdit,
            } = this.props;

            const formItemProps: FormItemProps = {
                labelCol: { span: 7 },
            };

            let groups = form.getFieldsValue(['group1', 'group2', 'group3', 'group4']);
            let groupVals: string[] = [];
            Object.keys(groups).forEach((key) => {
                groupVals.push(groups[key]);
            });

            let groupOptions = filteredGroups.map((r) => (
                <Select.Option key={r.id} value={r.code} disabled={groupVals.includes(r.code!)}>
                    {r.name}
                </Select.Option>
            ));

            groupOptions.unshift(
                <Select.Option key={-1} value={undefined}>
                    -
                </Select.Option>,
            );

            // let startPeriod = moment([2020, 7, 29]);
            // let endPeriod = moment().endOf('year');

            return (
                <Form onChange={this.props.onFormChange} labelAlign="left" className="schedule-form" layout="inline">
                    <Row gutter={24} type="flex">
                        <Col span={6}>
                            <Form.Item label="Location" {...formItemProps}>
                                {getFieldDecorator('locationCode', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Location is required',
                                        },
                                    ],
                                    // initialValue: 'OPF',
                                })(
                                    <Select disabled={isEdit} onChange={this.handleLocationChange}>
                                        {locations.map((r) => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>
                            <Form.Item label="Area" {...formItemProps}>
                                {getFieldDecorator('areaCode', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Area is required',
                                        },
                                    ],
                                    // initialValue: 'OPF_GAS',
                                })(
                                    <Select disabled={isEdit} onChange={this.handleAreaChange}>
                                        {filteredAreas.map((r) => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>
                        </Col>

                        <Col span={8}>
                            <Form.Item label="Year" {...formItemProps}>
                                {getFieldDecorator('year', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Year is required',
                                        },
                                    ],
                                    initialValue: moment().year(),
                                })(
                                    <Select disabled={isEdit} onChange={this.handleYearChange}>
                                        {this.years.map((r) => (
                                            <Select.Option key={r} value={r}>
                                                {r}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>
                            <Form.Item label="Rotation type" {...formItemProps}>
                                {getFieldDecorator('rotationType', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Rotation type is required',
                                        },
                                    ],
                                    // initialValue: 'ROT42',
                                })(
                                    <Select onChange={this.props.onFormChange}>
                                        {rotationTypes.map((r) => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>
                        </Col>

                        <Col span={8}>
                            <Form.Item label="Config name" {...formItemProps}>
                                {getFieldDecorator('scheduleConfigName', {
                                    rules: [
                                        {
                                            required: true,
                                            whitespace: true,
                                            message: 'Name is required',
                                        },
                                    ],
                                    // initialValue: 'New algo conf',
                                })(<Input />)}
                            </Form.Item>
                            <Form.Item label="Date period" {...formItemProps}>
                                {getFieldDecorator('datePeriod', {
                                    rules: [
                                        { type: 'array', required: true, message: 'Date period is required' },
                                        {
                                            validator: this.validateDatePeriod,
                                        },
                                    ],
                                    // initialValue: [startPeriod, endPeriod],
                                })(
                                    <DatePicker.RangePicker
                                        disabledDate={this.disableDate}
                                        style={{ width: '100%' }}
                                        onChange={this.props.onFormChange}
                                    />,
                                )}
                            </Form.Item>
                        </Col>

                        <Col span={8}>
                            <Card>
                                <Row type="flex">
                                    <Form.Item label="Group 1" {...formItemProps} style={{ width: '60%' }}>
                                        {getFieldDecorator('group1', {
                                            rules: [
                                                {
                                                    required: true,
                                                    message: 'Group is required',
                                                },
                                            ],
                                            // initialValue: 'GROUP1',
                                        })(
                                            <Select disabled={isEdit} onChange={this.props.onFormChange}>
                                                {groupOptions}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                    {/* <Form.Item {...formItemProps}>
                                        {getFieldDecorator('group1DayShift', {
                                            valuePropName: 'checked',
                                            initialValue: true,
                                        })(<Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>)}
                                    </Form.Item> */}
                                </Row>

                                <Row type="flex">
                                    <Form.Item label="Group 2" {...formItemProps} style={{ width: '60%' }}>
                                        {getFieldDecorator('group2', {
                                            rules: [
                                                {
                                                    required: true,
                                                    message: 'Group is required',
                                                },
                                            ],
                                            // initialValue: 'PGP_group',
                                        })(
                                            <Select disabled={isEdit} onChange={this.props.onFormChange}>
                                                {groupOptions}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                    {/* <Form.Item {...formItemProps}>
                                        {getFieldDecorator('group2DayShift', { valuePropName: 'checked' })(
                                            <Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>,
                                        )}
                                    </Form.Item> */}
                                </Row>
                            </Card>
                        </Col>

                        <Col span={8}>
                            <Card>
                                <Row type="flex">
                                    <Form.Item label="Group 3" {...formItemProps} style={{ width: '60%' }}>
                                        {getFieldDecorator('group3', {
                                            rules: [
                                                {
                                                    required: true,
                                                    message: 'Group is required',
                                                },
                                            ],
                                            // initialValue: 'gggpgp22',
                                        })(
                                            <Select disabled={isEdit} onChange={this.props.onFormChange}>
                                                {groupOptions}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                    {/* <Form.Item {...formItemProps}>
                                        {getFieldDecorator('group3DayShift', {
                                            valuePropName: 'checked',
                                            initialValue: true,
                                        })(<Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>)}
                                    </Form.Item> */}
                                </Row>
                                <Row type="flex">
                                    <Form.Item label="Group 4" {...formItemProps} style={{ width: '60%' }}>
                                        {getFieldDecorator('group4', {
                                            rules: [
                                                {
                                                    required: true,
                                                    message: 'Group is required',
                                                },
                                            ],
                                            // initialValue: 'TestGroup',
                                        })(
                                            <Select disabled={isEdit} onChange={this.props.onFormChange}>
                                                {groupOptions}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                    {/* <Form.Item {...formItemProps}>
                                        {getFieldDecorator('group4DayShift', { valuePropName: 'checked' })(
                                            <Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>,
                                        )}
                                    </Form.Item> */}
                                </Row>
                            </Card>
                        </Col>

                        <Col span={8}>
                            <Form.Item {...formItemProps}>
                                {getFieldDecorator('switchShift', {
                                    valuePropName: 'checked',
                                    // initialValue: true,
                                })(<Checkbox>Switch Day/Night shift</Checkbox>)}
                            </Form.Item>
                            <Form.Item {...formItemProps}>
                                {getFieldDecorator('isManual', {
                                    valuePropName: 'checked',
                                    // initialValue: true,
                                })(<Checkbox>Is manual</Checkbox>)}
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            );
        }
    },
);

export default ScheduleConfigForm;
