import React from 'react';
import { Typography, Card } from 'antd';
import EditScheduleConfigContainer from '../containers/EditScheduleConfigContainer';
import { RouteComponentProps } from 'react-router';

type Params = {
    id: string;
};

export default (props: RouteComponentProps<Params>) => (
    <Card>
        <Typography.Title>Edit schedule config</Typography.Title>
        <EditScheduleConfigContainer id={parseInt(props.match.params.id)} />
    </Card>
);
