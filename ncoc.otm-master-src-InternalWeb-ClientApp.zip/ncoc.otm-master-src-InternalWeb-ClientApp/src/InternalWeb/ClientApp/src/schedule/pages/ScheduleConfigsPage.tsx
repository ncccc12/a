import React from 'react';
import ScheduleConfigsContainer from '../containers/ScheduleConfigsContainer';
import { Typography, Card } from 'antd';

export default () => (
    <Card>
        <Typography.Title>Schedule configs</Typography.Title>
        <ScheduleConfigsContainer />
    </Card>
);
