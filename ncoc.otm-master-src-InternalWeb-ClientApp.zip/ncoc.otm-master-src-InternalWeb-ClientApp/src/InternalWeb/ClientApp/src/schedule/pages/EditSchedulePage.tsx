import React from 'react';
import EditScheduleContainer from '../containers/EditScheduleContainer';
import { Typography, Card } from 'antd';
import { RouteComponentProps } from 'react-router';

type Params = {
    id: string;
};

export default (props: RouteComponentProps<Params>) => (
    <Card>
        <Typography.Title>Edit schedule</Typography.Title>
        <EditScheduleContainer id={parseInt(props.match.params.id)} />
    </Card>
);
