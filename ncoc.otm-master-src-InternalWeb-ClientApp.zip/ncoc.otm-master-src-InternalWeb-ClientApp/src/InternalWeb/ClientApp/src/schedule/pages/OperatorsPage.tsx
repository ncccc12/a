import React from 'react';
import { Typography, Card } from 'antd';
import OperatorsContainer from '../containers/OperatorsContainer';

export default () => (
    <Card>
        <Typography.Title>Operators</Typography.Title>
        <OperatorsContainer />
    </Card>
);
