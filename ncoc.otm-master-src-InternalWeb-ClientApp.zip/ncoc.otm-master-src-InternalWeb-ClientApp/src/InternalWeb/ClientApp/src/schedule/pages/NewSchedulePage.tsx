import React from 'react';
import AddNewScheduleContainer from '../containers/AddNewScheduleContainer';
import { Typography, Card } from 'antd';

export default () => (
    <Card>
        <Typography.Title>New schedule</Typography.Title>
        <AddNewScheduleContainer />
    </Card>
);
