import React from 'react';
import ScheduleManagerContainer from '../containers/ScheduleManagerContainer';
import { Typography, Card } from 'antd';

export default () => (
    <Card>
        <Typography.Title>Schedule manager</Typography.Title>
        <ScheduleManagerContainer />
    </Card>
);
