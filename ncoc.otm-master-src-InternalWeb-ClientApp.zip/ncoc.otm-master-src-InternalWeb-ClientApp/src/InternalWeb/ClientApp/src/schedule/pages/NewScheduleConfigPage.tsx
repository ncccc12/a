import React from 'react';
import { Typography, Card } from 'antd';
import AddNewScheduleConfigContainer from '../containers/AddNewScheduleConfigContainer';

export default () => (
    <Card>
        <Typography.Title>New schedule config</Typography.Title>
        <AddNewScheduleConfigContainer />
    </Card>
);
