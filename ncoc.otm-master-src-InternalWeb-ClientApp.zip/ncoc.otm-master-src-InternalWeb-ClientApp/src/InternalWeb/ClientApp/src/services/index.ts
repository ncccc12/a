import AxiosConfig from '../common/axiosConfig';
import {
    DictionaryClient,
    LogSheetsClient,
    ReportsClient,
    EmployeesClient,
    GroupsClient,
    SchedulesClient,
    UsersClient,
    UnitOfMeasurementsClient,
    ListTypesClient, LogsheetTimeHistoriesClient
} from './Client';

export const dictionaryClient = new DictionaryClient(undefined, AxiosConfig);
export const employeesClient = new EmployeesClient(undefined, AxiosConfig);
export const logSheetsClient = new LogSheetsClient(undefined, AxiosConfig);
export const reportsClient = new ReportsClient(undefined, AxiosConfig);
export const groupsClient = new GroupsClient(undefined, AxiosConfig);
export const schedulesClient = new SchedulesClient(undefined, AxiosConfig);
export const usersClient = new UsersClient(undefined, AxiosConfig);
export const unitOfMeasureClient = new UnitOfMeasurementsClient(undefined, AxiosConfig);
export const listTypesClient = new ListTypesClient(undefined, AxiosConfig);
export const logsheetTimeHistoriesClient = new LogsheetTimeHistoriesClient(undefined, AxiosConfig);
