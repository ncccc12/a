import React from 'react';
import { BulletChart } from '@opd/g2plot-react';

const config = {
    rangeMax: 100,
    forceFit: true,
    title: {
        visible: true,
        text: 'Daily progress of completed log sheets',
    },
    legend: {
        visible: true,
        custom: true,
        items: [
            {
                value: 'Completed',
                marker: {
                    symbol: 'square',
                    fill: '#5B8FF9',
                },
            },
            {
                value: 'Remaining',
                marker: {
                    symbol: 'square',
                    fill: '#FFDBA2',
                },
            },
        ],
    },
};

export default () => {
    return (
        <BulletChart
            measureField=""
            rangeField=""
            targetField=""
            //rangeMax={100}
            //forceFit={true}
            legend={{
                visible: true,
            }}
            height={150}
            data={[
                {
                    title: 'Completed',
                    ranges: [100],
                    measures: [50],
                    targets: [100],
                },
            ]}
        />
    );
};
