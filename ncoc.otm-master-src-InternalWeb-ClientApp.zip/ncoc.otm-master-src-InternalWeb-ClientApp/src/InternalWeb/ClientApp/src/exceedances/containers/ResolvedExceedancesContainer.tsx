import React from 'react';
import { Row, Col, Typography } from 'antd';
import ResolvedExceedancesTable from '../components/ResolvedExceedancesTable';

const ResolvedExceedancesContainer: React.FC = () => {
    return (
        <Row gutter={24}>
            <Col md={32}>
                <ResolvedExceedancesTable />
            </Col>
        </Row>
    );
};

export default ResolvedExceedancesContainer;
