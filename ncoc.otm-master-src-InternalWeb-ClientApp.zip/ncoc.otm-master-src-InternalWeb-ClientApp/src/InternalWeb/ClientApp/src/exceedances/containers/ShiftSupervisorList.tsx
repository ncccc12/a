import React from 'react';
import { Row, Col } from 'antd';
import ExceedancesTable from '../components/ExceedancesTable';
import { AreaVm, DictionaryDto } from '../../services/Client';
import { dictionaryClient } from '../../services';
import ResolvedExceedancesTable from '../components/ResolvedExceedancesTable';
import SubmitededExceedancesTable from '../components/SubmitedExceedancesTable';
import ShiftExceedancesTable from '../components/ShiftExceedancesTable';

type Props = {};
type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

class ShiftSupervisorList extends React.Component<Props, State> {
    /**
     *
     */
    constructor(props: Props) {
        super(props);

        this.state = {
            areas: [],
            locations: [],
        };
    }

    componentDidMount() {
        this.loadDictionaries();
    }

    loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        this.setState({ locations, areas });
    };

    render() {
        const { locations, areas } = this.state;

        return (
            <div style={{height:'100%'}}>
                <Row gutter={24}>
                    <Col md={32}>
                        <ShiftExceedancesTable locations={locations} areas={areas}  />
                    </Col>
                </Row>
            </div>
        );
    }
}

export default ShiftSupervisorList;