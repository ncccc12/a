import React from 'react';
import { Row, Col } from 'antd';
import RunMaintainTable from '../components/RunMaintainTable';

const RunMaintainContainer: React.FC = () => {
    return (
        <div style={{ height: '100%' }}>
            <Row gutter={24}>
                <Col md={32}>
                    <RunMaintainTable />
                </Col>
            </Row>
        </div>
    );
};

export default RunMaintainContainer;
