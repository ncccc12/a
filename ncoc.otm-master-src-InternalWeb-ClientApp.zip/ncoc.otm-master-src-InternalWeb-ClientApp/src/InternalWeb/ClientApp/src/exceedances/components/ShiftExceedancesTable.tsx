import React from 'react';
import { Card, Spin, Form, Select, Button, Table, Input, message, Modal } from 'antd';
import { reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
    ShiftSupervisorExcUpdate,
} from '../../services/Client';
import { FormComponentProps } from 'antd/lib/form';
import ButtonGroup from 'antd/lib/button/button-group';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    topTags: DeviceTag[];
    filteredAreas: AreaVm[];
    exceedances: ExceedancesListVm[];
    selectedExceedances: number[];
    selectedExceedancesList: ExceedancesListVm;
    user: User;
    areaCode: string[];
    commentModalVisible: boolean;
    sendVisible: boolean;
    exceedancesListStatus: number;
};

const ShiftExceedancesTable = Form.create<Props>()(
    class SubmitededExceedancesTable extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                datas: [],
                topTags: [],
                filteredAreas: [],
                exceedances: [],
                selectedExceedances: [],
                selectedExceedancesList: {} as any,
                user: {} as any,
                areaCode: [],
                commentModalVisible: false,
                sendVisible: false,
                exceedancesListStatus: 0,
            };
        }

        componentDidMount() {
            this.getUser();
        }
        componentDidUpdate(prevProps: Readonly<Props>, prevState: Readonly<State>, snapshot?: any): void {
            // this.getUserArea(this.state.user.sub)
        }
        getUser = async () => {
            const data: User = await authService.getUser();
            this.setState({ user: data });
            console.log(data);
            this.getUserArea(data.sub);
            this.search();
        };

        getUserArea = async (value: any) => {
            let area: UserVm = await usersClient.getUsersArea(value);
            //let areaCode:string[] = area.areaCodes!
            this.setState({ areaCode: area.areaCodes! });
        };
        search = async () => {
            this.setState({ loading: true });
            const { form } = this.props;
            form.validateFields(async (errors: any, values: any) => {
                const { form } = this.props;
                let userId = this.state.user.sub;
                let locationCode = values.locationCode;
                let areaCode = values.areaCode;
                let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
                this.setState({ exceedances: data, loading: false });
            });
        };

        onSearch = async () => {
            this.setState({ loading: true });
            const { form } = this.props;

            form.validateFields(async (errors: any, values: any) => {
                let locationCode = values.locationCode;
                let areaCode = values.areaCode;
                console.log(locationCode, areaCode);
                let userId = this.state.user.sub;
                console.log(userId);
                let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
                this.setState({ exceedances: data, loading: false });
            });
        };

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        onSelectChange = (selectedExceedances: any) => {
            let exceedances = this.state.exceedances.find((x) => x.id === selectedExceedances);
            this.setState({ selectedExceedances: selectedExceedances! });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };
        updateTag = (values: ExceedancesVm) => {
            let updateCommand = new UpdateTagDataCommand();
            updateCommand.id = values.id;
            updateCommand.value = values.taskValue;
            updateCommand.comment = values.comment;

            reportsClient.updateTagData(updateCommand);
            message.success('Successfully updated');
        };
        sendToPOD = async () => {
            let updateCommand = new ShiftSupervisorExcUpdate();
            let exceedances = this.state.exceedances;
            let crowId = this.state.selectedExceedances!;
            console.log('RowID', crowId);
            let i = 0;
            let selected: any = [];

            crowId.map((i) => {
                let result = exceedances.find((x) => x.id == i!);
                selected.push(result!);
            });
            console.log();

            console.log('Shift Exc', selected);
            updateCommand.exceedancesListVms = selected;
            updateCommand.exListStatus = 2;
            reportsClient.updateShiftExc(updateCommand);
            message.success('Successfully updated');
            window.location.reload();
        };
        sendToRM = async () => {
            let updateCommand = new ShiftSupervisorExcUpdate();
            let exceedances = this.state.exceedances;
            let crowId = this.state.selectedExceedances!;
            console.log('RowID', crowId);
            let i = 0;
            let selected: any = [];

            crowId.map((i) => {
                let result = exceedances.find((x) => x.id == i!);
                selected.push(result!);
            });
            console.log();

            console.log('Shift Exc', selected);
            updateCommand.exceedancesListVms = selected;
            updateCommand.exListStatus = 5;
            reportsClient.updateShiftExc(updateCommand);
            message.success('Successfully updated');
            window.location.reload();
        };
        renderStatus = (i: string, rowKey: ExceedancesListVm) => {
            if (rowKey.exListStatus! === 1) {
                return <p>Under Shift-Supervisor Review</p>;
            }
            if (rowKey.exListStatus! === 2) {
                return <p>Under Plant SPV</p>;
            }
            if (rowKey.exListStatus! === 3) {
                return <p>Under CRO</p>;
            }
            if (rowKey.exListStatus! === 4) {
                return <p>Under Supervisor</p>;
            }
            if (rowKey.exListStatus! === 5) {
                return <p>Run & Maintaince</p>;
            }
            if (rowKey.exListStatus! === 6) {
                return <p>Fixed</p>;
            }
        };

        renderAction = (i: string, rowKey: any) => {
            return (
                <>
                    <Link to={`/exceedances/${rowKey.id!}`}>
                        <Button shape="circle" icon="edit" title="edit"></Button>
                    </Link>
                </>
            );
        };
        onCloseModal = (): void => {
            this.setState({ commentModalVisible: false });
        };
        onOk = () => {
            let comment = this.props.form.getFieldValue('supervisorComment');
            let exceedances = this.state.exceedances!;
            let selected = this.state.selectedExceedancesList!;
            let filteredExc = exceedances.find((x) => x.id === selected.id);

            filteredExc!.commentBySup = comment;

            this.setState({ exceedances: exceedances });

            this.setState({ commentModalVisible: false });

            console.log('Super Comment', this.state.exceedances);
        };
        onChangeComment = (rowKey: ExceedancesListVm) => {
            const form = this.props.form;
            const selected = this.state.exceedances!.find((x) => x.id === rowKey.id!);

            this.setState({ selectedExceedancesList: selected! });
            this.setState({ commentModalVisible: true });
        };

        render() {
            const { loading, datas, topTags } = this.state;
            const { selectedExceedances } = this.state;
            const rowSelection = {
                selectedExceedances,
                onChange: this.onSelectChange,
            };
            const {
                form: { getFieldDecorator },
                locations,
            } = this.props;
            const renderComment = (i: string, rowKey: any) => {
                return (
                    <div style={{ width: '100%', display: 'flex' }}>
                        <Form style={{ display: 'flex' }}>
                            <Form.Item>
                                <Input width="45%" disabled readOnly value={i!}></Input>
                            </Form.Item>
                            <Button
                                shape="circle"
                                icon="edit"
                                title="edit"
                                style={{ marginLeft: '10px' }}
                                onClick={() => this.onChangeComment(rowKey!)}
                            ></Button>
                        </Form>
                    </div>
                );
            };
            console.log('select Exc', selectedExceedances);
            return (
                <Spin spinning={loading}>
                    <Card

                    // extra={this.renderHeader()}
                    >
                        <Form>
                            <div style={{ display: 'flex' }}>
                                <Form.Item label="Location">
                                    {getFieldDecorator('locationCode')(
                                        <Select style={{ width: '100px' }} onChange={this.handleLocationChange}>
                                            {locations.map((r) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    )}
                                </Form.Item>

                                <Form.Item label="Area">
                                    {getFieldDecorator('areaCode')(
                                        <Select style={{ width: '200px' }}>
                                            {this.state.filteredAreas.map((r) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    )}
                                </Form.Item>
                                <Form.Item>
                                    <ButtonGroup style={{ marginTop: '40px', marginLeft: '20px' }}>
                                        <Button type="primary" onClick={this.onSearch}>
                                            Search
                                        </Button>
                                    </ButtonGroup>
                                </Form.Item>
                            </div>
                            <Modal
                                destroyOnClose
                                onCancel={this.onCloseModal}
                                visible={this.state.commentModalVisible}
                                onOk={this.onOk}
                                title={'Supervisor Comment'}
                            >
                                <Form.Item>{getFieldDecorator('supervisorComment')(<Input.TextArea />)}</Form.Item>
                            </Modal>
                        </Form>
                        <Button style={{ marginRight: '10px' }} type="primary" onClick={this.sendToPOD}>
                            Return back to PRA
                        </Button>
                        <Button style={{ margin: '0,10px,0,10px' }} type="primary" onClick={this.sendToRM}>
                            Run & Maintain
                        </Button>
                        <Table
                            dataSource={this.state.exceedances}
                            loading={this.state.loading}
                            bordered
                            //expandRowByClick={true}
                            // pagination={paginationConfig}
                            rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                            rowSelection={rowSelection}
                        >
                            {' '}
                            <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                            <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                            <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                            <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                            <Table.Column dataIndex="commentBySup" title="Supervisor Comment" />
                            <Table.Column
                                dataIndex="commentBySup"
                                title="Comment"
                                render={(i: string, rowKey: ExceedancesListVm) => renderComment(i, rowKey)}
                            ></Table.Column>
                            <Table.Column
                                dataIndex="excListStatus"
                                title="Status"
                                render={(i: string, rowKey: ExceedancesListVm) => this.renderStatus(i, rowKey)}
                            ></Table.Column>
                            <Table.Column
                                title="Action"
                                width={'130px'}
                                render={(i: string, rowKey: any) => this.renderAction(i, rowKey)}
                            ></Table.Column>
                        </Table>
                    </Card>
                </Spin>
            );
        }
    },
);

export default ShiftExceedancesTable;
