import React from 'react';
import { Drawer, Form, Input, Select, Tag, InputNumber, Button, Switch, Table } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import { DictionaryDto, ExceedancesVm, ListTypeValueVm } from '../../services/Client';
import { group } from 'console';

export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    groups: ExceedancesVm;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredLisTypeValues: ListTypeValueVm[];
    selectedDataTypeCode: string;
};

const DiscCommentDrawer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredLisTypeValues: [],
                selectedDataTypeCode: '',
            };
        }

        componentDidUpdate(prevProps: Props, prevState: State) {
            const { form } = this.props;

            if (!prevProps.visible && this.props.visible) {
                let listTypeCode = form.getFieldValue('listTypeCode');
                let dataTypeCode = form.getFieldValue('dataTypeCode');
            } else if (!this.props.visible && this.state.selectedDataTypeCode !== '') {
                this.setState({ selectedDataTypeCode: '' });
            }
        }

        render() {
            const {
                visible,
                form: { getFieldDecorator },
                form,
            } = this.props;

            const { filteredLisTypeValues, selectedDataTypeCode } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            getFieldDecorator('id');
            let id = form.getFieldValue('id');
            getFieldDecorator('groupId');
            getFieldDecorator('taskValueId');
            getFieldDecorator('groupName');
            let groupNames = form.getFieldValue('groupName');
            getFieldDecorator('taskName');
            let taskNames = form.getFieldValue('taskName');
            getFieldDecorator('logsheetName');
            let title = 'Edit Tag';

            return (
                <Drawer title={title} visible={visible} width={700} onClose={this.props.onClose}>
                    <Form labelAlign="left" {...formItemLayout}>
                        <Table dataSource={this.props.groups.disciplineComment} style={{ marginBottom: '25px' }}>
                            <Table.Column title="Commented By" dataIndex="comment"></Table.Column>
                            <Table.Column title="Reviewd By(Discipline)" dataIndex="disciplineId"></Table.Column>
                            <Table.Column title="Commented By(Name)" dataIndex="disciplineUser"></Table.Column>
                        </Table>
                        <Form.Item label="Task Name">
                            {getFieldDecorator('taskName')(<Input.TextArea readOnly />)}
                        </Form.Item>
                        <Form.Item label="Task Value">
                            {getFieldDecorator('taskValue')(<Input.TextArea readOnly />)}
                        </Form.Item>
                        <Form.Item label="Comment by Sypervisor">
                            {getFieldDecorator('comment')(<Input.TextArea />)}
                        </Form.Item>
                        <Form.Item label="Comment by Discipline">
                            {getFieldDecorator('discComment')(<Input.TextArea />)}
                        </Form.Item>
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default DiscCommentDrawer;
