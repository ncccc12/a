import React from 'react';
import SupervisorsListContainer from '../containers/SupervisorsListContainer';

export default () => <SupervisorsListContainer/>