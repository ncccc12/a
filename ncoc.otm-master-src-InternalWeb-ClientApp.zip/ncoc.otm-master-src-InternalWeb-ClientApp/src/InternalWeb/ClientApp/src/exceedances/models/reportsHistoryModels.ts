import moment from 'moment';
import { FilterDto } from './types';

export interface ReportsHistoryFilterFormModel extends FilterDto {
    logSheetId?: number;
    areaId?: number;
    locationId?: number;
    statusCodes?: number[];
    startDate?: moment.Moment;
    endDate?: moment.Moment;
    hasExceedance: number;
    hasCompliance: number;
}
