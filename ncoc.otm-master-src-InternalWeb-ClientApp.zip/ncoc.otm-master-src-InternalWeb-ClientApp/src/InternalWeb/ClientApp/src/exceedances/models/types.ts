// export interface DictionaryDto {
//     id: number;
//     code: string;
//     name: string;
// }

export interface FilterDto {
    current: number;
    pageSize: number;
}
