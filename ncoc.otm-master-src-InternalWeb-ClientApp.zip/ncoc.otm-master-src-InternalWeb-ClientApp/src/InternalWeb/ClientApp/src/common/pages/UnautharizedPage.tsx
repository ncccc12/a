import { Button, Result } from 'antd';
import React from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { ApplicationPaths } from '../components/api-authorization/ApiAuthorizationConstants';

type Props = {} & RouteComponentProps<any>;

class UnautharizedPage extends React.Component<Props, any> {
    updateRoles = () => {
        window.location.href = `${ApplicationPaths.Login}`;
    };

    render() {
        return (
            <Result
                status="403"
                title="403"
                subTitle="Sorry, you are not authorized to access this page."
                extra={
                    <>
                        <Button type="primary" onClick={() => this.props.history.push('/')}>
                            Back Home
                        </Button>
                        <Button style={{ marginLeft: 5 }} type="primary" onClick={this.updateRoles}>
                            Update roles
                        </Button>
                    </>
                }
            />
        );
    }
}

export default UnautharizedPage;
