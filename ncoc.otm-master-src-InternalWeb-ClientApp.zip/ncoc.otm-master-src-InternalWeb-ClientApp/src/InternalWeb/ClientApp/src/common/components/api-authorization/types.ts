export interface User {
    [propName: string]: any;
    role: string[];
}
