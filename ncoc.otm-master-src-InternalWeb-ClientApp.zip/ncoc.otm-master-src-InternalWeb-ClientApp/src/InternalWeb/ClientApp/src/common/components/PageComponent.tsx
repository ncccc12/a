import React from 'react';
import { Card, Typography } from 'antd';

type Props = {
    title: string;
    [propName: string]: any;
};

export default (props: Props) => (
    <Card title={<Typography.Title>{props.title}</Typography.Title>}>{props.children}</Card>
);
