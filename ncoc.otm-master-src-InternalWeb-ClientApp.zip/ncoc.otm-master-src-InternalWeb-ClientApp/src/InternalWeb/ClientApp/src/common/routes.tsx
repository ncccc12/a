import { RouteProps } from 'react-router-dom';

import UnautharizedPage from './pages/UnautharizedPage';
const routes: RouteProps[] = [
    {
        path: '/Unautharized',
        component: UnautharizedPage,
        exact: true,
    },
];

export default routes;
