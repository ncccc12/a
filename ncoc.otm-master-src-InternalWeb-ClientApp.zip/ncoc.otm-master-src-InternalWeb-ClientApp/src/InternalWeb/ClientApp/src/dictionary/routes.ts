import { CrewsPage, UsersPage } from './pages';
import { RouteProps } from 'react-router';

const routes: RouteProps[] = [
    {
        path: '/dictionary/crews',
        component: CrewsPage,
        exact: true,
    },
    {
        path: '/admin/users',
        component: UsersPage,
        exact: true,
    },
];

export default routes;
