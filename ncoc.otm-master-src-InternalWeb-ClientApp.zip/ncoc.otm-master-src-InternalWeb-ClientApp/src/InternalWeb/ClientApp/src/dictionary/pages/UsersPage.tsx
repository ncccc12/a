import React from 'react';
import { Typography, Card } from 'antd';
import UsersContainer from '../containers/UsersContainer';

export default () => (
    <Card>
        <Typography.Title>Users</Typography.Title>
        <UsersContainer />
    </Card>
);
