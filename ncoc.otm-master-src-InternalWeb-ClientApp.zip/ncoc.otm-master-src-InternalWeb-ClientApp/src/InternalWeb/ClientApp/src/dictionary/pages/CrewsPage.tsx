import React from 'react';
import { Typography, Card } from 'antd';
import CrewsContainer from '../containers/CrewsContainer';

export default () => (
    <Card>
        <Typography.Title>Crews</Typography.Title>
        <CrewsContainer />
    </Card>
);
