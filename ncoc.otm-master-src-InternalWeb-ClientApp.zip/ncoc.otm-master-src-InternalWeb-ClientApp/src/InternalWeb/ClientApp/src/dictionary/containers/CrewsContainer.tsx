import React from 'react';
import { Spin, Row, Form, Select, Button, Divider, Table, message } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import ButtonGroup from 'antd/lib/button/button-group';
import { dictionaryClient, groupsClient } from '../../services';
import {
    DictionaryDto,
    AreaVm,
    GetGroupsQuery,
    GroupVm,
    AddNewGroupCommand,
    UpdateGroupCommand,
} from '../../services/Client';
import CrewDrawer, { GroupForm } from '../components/CrewDrawer';
import { WrappedFormUtils } from 'antd/lib/form/Form';

type SearchForm = {
    locationCode: string;
    areaCode: string;
    isActive: number[];
};

type Props = {} & FormComponentProps<any>;
type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    groups: GroupVm[];
    filteredAreas: AreaVm[];
    loading: boolean;
    isCrewDrawerShown: boolean;
};

const CrewsContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        crewFormRef: any;

        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                locations: [],
                areas: [],
                filteredAreas: [],
                groups: [],
                isCrewDrawerShown: false,
            };
        }

        async componentDidMount() {
            await this.loadData();
            this.search();
        }

        loadData = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();

            this.setState({ locations, areas });
        };

        handleLocationChange = (value: string) => {
            const { areas } = this.state;

            const filteredAreas = areas.filter(r => r.locationCode === value);
            this.setState({ filteredAreas });

            this.props.form.setFieldsValue({
                areaCode: '',
            });
        };

        search = () => {
            this.props.form.validateFields(async (err: any, values: SearchForm) => {
                this.setState({ loading: true });

                try {
                    var query = new GetGroupsQuery();
                    query.init(values);
                    let groups = await groupsClient.getGroups(query);
                    this.setState({ groups });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        submitForm = () => {
            const form = this.crewFormRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: GroupForm) => {
                
                if (err) return;

                try {
                    this.setState({ loading: true });

                    if (values.id) {
                        let updateCommand = new UpdateGroupCommand();
                        updateCommand.init(values);

                        await groupsClient.updateGroup(updateCommand);
                    } else {
                        // add new
                        let command = new AddNewGroupCommand();
                        command.init(values);

                        await groupsClient.addNewGroup(command);
                    }

                    message.success('Successful');
                    this.setState({ isCrewDrawerShown: false });
                    this.search();
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        renderActions = (r: GroupVm) => {
            return <Button icon="edit" shape="circle" title="edit" onClick={() => this.openDrawer(r)} />;
        };

        openDrawer = (r: GroupVm | undefined) => {
            const form = this.crewFormRef.props.form as WrappedFormUtils<any>;
            this.setState(
                {
                    isCrewDrawerShown: true,
                },
                () => {
                    if (r) {
                        let groupForm: GroupForm = {
                            id: r.id!,
                            areaCode: r.areaCode!,
                            locationCode: r.locationCode!,
                            name: r.name!,
                            code: r.code!,
                            description: r.description!,
                            isActive: r.isActive!,
                        };

                        form.setFieldsValue({
                            ...groupForm,
                        });
                    } else {
                        form.resetFields();
                        form.setFieldsValue({ isActive: true });
                    }
                },
            );
        };

        render() {
            const { loading, locations, filteredAreas, groups, isCrewDrawerShown, areas } = this.state;
            const {
                form: { getFieldDecorator },
            } = this.props;

            const selectStyle = {
                width: 150,
            };

            return (
                <Spin spinning={loading}>
                    <Row>
                        <Form labelAlign="left" layout="inline">
                            <Form.Item label="Location">
                                {getFieldDecorator('locationCode')(
                                    <Select style={selectStyle} onChange={this.handleLocationChange}>
                                        {locations.map(r => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item label="Area">
                                {getFieldDecorator('areaCode')(
                                    <Select style={selectStyle}>
                                        {filteredAreas.map(r => (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item label="Is active">
                                {getFieldDecorator('isActive', { initialValue: [] })(
                                    <Select style={selectStyle} mode="multiple">
                                        <Select.Option key="y" value={1}>
                                            Yes
                                        </Select.Option>
                                        <Select.Option key="n" value={0}>
                                            No
                                        </Select.Option>
                                    </Select>,
                                )}
                            </Form.Item>

                            <Form.Item>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Form>
                    </Row>
                    <Divider />
                    <Row>
                        <Table
                            dataSource={groups}
                            title={() => <Button onClick={() => this.openDrawer(undefined)}>Add new</Button>}
                            rowKey={r => r.id + ''}
                            bordered
                        >
                            <Table.Column dataIndex="locationName" title="Location"></Table.Column>
                            <Table.Column dataIndex="areaName" title="Area"></Table.Column>
                            <Table.Column dataIndex="name" title="Name"></Table.Column>
                            <Table.Column dataIndex="code" title="Code"></Table.Column>
                            <Table.Column dataIndex="description" title="Description"></Table.Column>
                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                            ></Table.Column>
                            <Table.Column title="Actions" render={r => this.renderActions(r)}></Table.Column>
                        </Table>
                    </Row>
                    <Row>
                        <CrewDrawer
                            visible={isCrewDrawerShown}
                            wrappedComponentRef={(compRef: any) => (this.crewFormRef = compRef)}
                            locations={locations}
                            areas={areas}
                            onSubmit={this.submitForm}
                            onClose={() => this.setState({ isCrewDrawerShown: false })}
                        />
                    </Row>
                </Spin>
            );
        }
    },
);

export default CrewsContainer;
