import { GroupDto, TaskDto } from '../services/Client';
import { DeviceTag } from './containers/LogsheetDetailsContainer';

class LogsheetsService {
    mapTaskDtoToDeviceType = (device: GroupDto, t: TaskDto) => {
        let deviceTag: DeviceTag = {
            groupId: device.id,
            groupName: device.name,
            id: t.id,
            name: t.name,
            description: t.description,
            minValue: t.minValue,
            maxValue: t.maxValue,
            listTypeCode: t.listTypeCode,
            listTypeName: t.listTypeName,
            listTypeValues: (t.listTypeValues && t.listTypeValues.map((r) => r.name)) || [],
            unitOfMeasurementName: t.unitOfMeasurementName,
            unitOfMeasurementCode: t.unitOfMeasurementCode,
            dataTypeName: t.dataTypeName,
            dataTypeCode: t.dataTypeCode,
            isRequired: t.isRequired,
            changeStatus: t.changeStatus,

            taskValueId: t.taskValue && t.taskValue.id,
            value: t.taskValue && t.taskValue.value,
            comment: t.taskValue && t.taskValue.comment,
            isExceed: t.taskValue && t.taskValue.isExceeded,
            hasAttachments: t.taskValue && !!t.taskValue.attachment,
            attachment: t.taskValue && t.taskValue.attachment,
            isSkipped: t.taskValue && t.taskValue.isSkipped,
            order: t.order,
        };

        return deviceTag;
    };
}

const logsheetService = new LogsheetsService();
export default logsheetService;
