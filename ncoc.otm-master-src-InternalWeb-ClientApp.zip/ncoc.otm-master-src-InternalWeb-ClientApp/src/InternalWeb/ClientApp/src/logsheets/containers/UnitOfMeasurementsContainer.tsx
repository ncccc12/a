import React from 'react';
import { Spin, Form, Button, Table, message, Select } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import PageComponent from '../../common/components/PageComponent';
import { unitOfMeasureClient } from '../../services';
import {
    DictionaryDto,
    GetUnitOfMeasurementsQuery,
    UpdateUnitOfMeasurementCommand,
    AddUnitOfMeasurementCommand,
} from '../../services/Client';
import UnitOfMeasurementDrawer, { UnitOfMeasureForm } from '../components/UnitOfMeasurementDrawer';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import ButtonGroup from 'antd/lib/button/button-group';

type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    unitOfMeasurements: DictionaryDto[];
    unitOfMeasureDrawerShown: boolean;
};

const UnitOfMeasurementsContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        unitOfMeasureRef: any;

        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                unitOfMeasurements: [],
                unitOfMeasureDrawerShown: false,
            };
        }

        componentDidMount() {
            this.search();
        }

        search = () => {
            this.props.form.validateFields(async (err: any, values: { isActive: number[] }) => {
                this.setState({ loading: true });
                
                try {
                    let query = new GetUnitOfMeasurementsQuery();
                    query.isActive = values.isActive;
                    let uoms = await unitOfMeasureClient.get(query);

                    this.setState({ unitOfMeasurements: uoms });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        openUnitOMeasureDrawer = (row: DictionaryDto | undefined) => {
            const form = this.unitOfMeasureRef.props.form as WrappedFormUtils<any>;
            this.setState({ unitOfMeasureDrawerShown: true }, () => {
                if (row) {
                    let groupForm: UnitOfMeasureForm = {
                        id: row.id!,
                        name: row.name!,
                        code: row.code!,
                        description: row.description!,
                        isActive: row.isActive!,
                    };

                    form.setFieldsValue({
                        ...groupForm,
                    });
                } else {
                    form.resetFields();
                    form.setFieldsValue({ isActive: true });
                }
            });
        };

        submitForm = () => {
            const form = this.unitOfMeasureRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: UnitOfMeasureForm) => {
                if (err) return;

                try {
                    this.setState({ loading: true });

                    if (values.id) {
                        let updateCommand = new UpdateUnitOfMeasurementCommand();
                        updateCommand.init(values);

                        await unitOfMeasureClient.update(updateCommand);
                    } else {
                        let addCommand = new AddUnitOfMeasurementCommand();
                        addCommand.init(values);

                        await unitOfMeasureClient.add(addCommand);
                    }

                    message.success('Successful');
                    this.setState({ unitOfMeasureDrawerShown: false });
                    this.search();
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        renderActions = (row: DictionaryDto) => {
            return (
                <Button
                    icon="edit"
                    shape="circle"
                    title="Edit"
                    onClick={() => this.openUnitOMeasureDrawer(row)}
                ></Button>
            );
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        render() {
            const { loading, unitOfMeasurements, unitOfMeasureDrawerShown } = this.state;
            const {
                form: { getFieldDecorator },
            } = this.props;

            return (
                <PageComponent title={'Unit of measurements'}>
                    <Spin spinning={loading}>
                        <Form labelAlign="left" layout="inline">
                            <Form.Item label="Is active">
                                {getFieldDecorator('isActive', { initialValue: [1] })(
                                    <Select style={{ width: 150 }} mode="multiple">
                                        <Select.Option key="y" value={1}>
                                            Yes
                                        </Select.Option>
                                        <Select.Option key="n" value={0}>
                                            No
                                        </Select.Option>
                                    </Select>,
                                )}
                            </Form.Item>
                            <Form.Item>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Form>

                        <Table
                            rowKey={(r) => r.id + ''}
                            dataSource={unitOfMeasurements}
                            title={() => (
                                <Button type="primary" onClick={() => this.openUnitOMeasureDrawer(undefined)}>
                                    Add new
                                </Button>
                            )}
                        >
                            <Table.Column dataIndex="name" title="Name"></Table.Column>
                            <Table.Column dataIndex="code" title="Code"></Table.Column>
                            <Table.Column dataIndex="description" title="Description"></Table.Column>
                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                            ></Table.Column>
                            <Table.Column title="Actions" render={(r) => this.renderActions(r)}></Table.Column>
                        </Table>
                        <UnitOfMeasurementDrawer
                            visible={unitOfMeasureDrawerShown}
                            wrappedComponentRef={(compRef: any) => (this.unitOfMeasureRef = compRef)}
                            onSubmit={this.submitForm}
                            onClose={() => this.setState({ unitOfMeasureDrawerShown: false })}
                        />
                    </Spin>
                </PageComponent>
            );
        }
    },
);

export default UnitOfMeasurementsContainer;
