import React from 'react';
import { Spin, Form, Button, Table, message, Tag, Row, Select } from 'antd';
import PageComponent from '../../common/components/PageComponent';
import {
    DictionaryDto,
    GetListTypesQuery,
    ListTypeVm,
    UpdateListTypeCommand,
    AddListTypeCommand,
} from '../../services/Client';
import { FormComponentProps } from 'antd/lib/form';
import { listTypesClient } from '../../services';
import ListTypesDrawer, { ListTypeForm } from '../components/ListTypesDrawer';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import ListTypeValuesModal from '../components/ListTypeValuesModal';
import ButtonGroup from 'antd/lib/button/button-group';


type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    listTypes: ListTypeVm[];
    listTypeDrawerShown: boolean;
    valuesModalShown: boolean;
    selectedListType: ListTypeVm | undefined;
};

const ListTypesContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        listTypeCompRef: any;

        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                listTypes: [],
                listTypeDrawerShown: false,
                valuesModalShown: false,
                selectedListType: undefined,
            };
        }

        componentDidMount() {
            this.search();
        }

        search = () => {
            this.props.form.validateFields(async (err: any, values: { isActive: number[] }) => {
                this.setState({ loading: true });

                try {
                    let query = new GetListTypesQuery();
                    query.isActive = values.isActive;
                    let listTypes = await listTypesClient.get(query);

                    this.setState({ listTypes });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        openListTypesDrawer = (row: DictionaryDto | undefined) => {
            const form = this.listTypeCompRef.props.form as WrappedFormUtils<any>;
            this.setState({ listTypeDrawerShown: true }, () => {
                if (row) {
                    let groupForm: ListTypeForm = {
                        id: row.id!,
                        name: row.name!,
                        code: row.code!,
                        description: row.description!,
                        isActive: row.isActive!,
                    };

                    form.setFieldsValue({
                        ...groupForm,
                    });
                } else {
                    form.resetFields();
                    form.setFieldsValue({ isActive: true });
                }
            });
        };

        renderActions = (row: DictionaryDto) => {
            return (
                <>
                    <Button icon="edit" title="Edit" onClick={() => this.openListTypesDrawer(row)}></Button>
                </>
            );
        };

        openListTypeValuesModal = (listType: ListTypeVm) => {
            this.setState({ selectedListType: listType, valuesModalShown: true });
        };

        renderValues = (listType: ListTypeVm) => {
            return (
                <Button
                    style={{ height: '100%', minHeight: 50 }}
                    title="Edit values"
                    type="dashed"
                    onClick={() => this.openListTypeValuesModal(listType)}
                >
                    <Row type="flex" style={{ width: 185 }}>
                        {listType.listTypeValues!.map((r) => {
                            let color = r.isExceed ? 'red' : 'blue';
                            color = r.isActive ? color : '';

                            return (
                                <Tag key={r.id} color={color}>
                                    {r.name}
                                </Tag>
                            );
                        })}
                    </Row>
                </Button>
            );
        };

        submitForm = () => {
            const form = this.listTypeCompRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: ListTypeForm) => {
                if (err) return;

                try {
                    this.setState({ loading: true });

                    if (values.id) {
                        let updateCommand = new UpdateListTypeCommand();
                        updateCommand.init(values);

                        await listTypesClient.update(updateCommand);
                    } else {
                        let addCommand = new AddListTypeCommand();
                        addCommand.init(values);

                        await listTypesClient.add(addCommand);
                    }

                    message.success('Successful');
                    this.setState({ listTypeDrawerShown: false });
                    this.search();
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        handleModalReload = () => {
            this.search();
            this.setState({ valuesModalShown: false });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        render() {
            const { loading, listTypes, listTypeDrawerShown, valuesModalShown, selectedListType } = this.state;
            const {
                form: { getFieldDecorator },
            } = this.props;

            return (
                <PageComponent title={'List types'}>
                    <Spin spinning={loading}>
                        <Form labelAlign="left" layout="inline">
                            <Form.Item label="Is active">
                                {getFieldDecorator('isActive', { initialValue: [1] })(
                                    <Select style={{ width: 150 }} mode="multiple">
                                        <Select.Option key="y" value={1}>
                                            Yes
                                        </Select.Option>
                                        <Select.Option key="n" value={0}>
                                            No
                                        </Select.Option>
                                    </Select>,
                                )}
                            </Form.Item>
                            <Form.Item>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Form>

                        <Table
                            rowKey={(r) => r.id + ''}
                            dataSource={listTypes}
                            title={() => (
                                <Button type="primary" onClick={() => this.openListTypesDrawer(undefined)}>
                                    Add new
                                </Button>
                            )}
                        >
                            <Table.Column dataIndex="name" title="Name"></Table.Column>
                            <Table.Column dataIndex="code" title="Code"></Table.Column>
                            <Table.Column dataIndex="description" title="Description"></Table.Column>
                            <Table.Column title="Values" render={this.renderValues}></Table.Column>
                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                            ></Table.Column>
                            <Table.Column title="Actions" render={(r) => this.renderActions(r)}></Table.Column>
                        </Table>
                        <ListTypesDrawer
                            visible={listTypeDrawerShown}
                            wrappedComponentRef={(compRef: any) => (this.listTypeCompRef = compRef)}
                            onSubmit={this.submitForm}
                            onClose={() => this.setState({ listTypeDrawerShown: false })}
                        />
                        <ListTypeValuesModal
                            visible={valuesModalShown}
                            listType={selectedListType!}
                            onReload={this.handleModalReload}
                            onClose={() => this.setState({ valuesModalShown: false })}
                        ></ListTypeValuesModal>
                    </Spin>
                </PageComponent>
            );
        }
    },
);

export default ListTypesContainer;
