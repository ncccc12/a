import React from 'react';
import LogsheetsContainer from '../containers/LogsheetsContainer';

import { Typography, Card } from 'antd';

export default () => (
    <Card>
        <Typography.Title>Logsheets</Typography.Title>
        <LogsheetsContainer />
    </Card>
);
