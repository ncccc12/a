import { SearchForm } from '../components/LogsheetsFilterForm';

// actions
const CHANGE_FILTER_FORM = 'LOGSHEETS_CHANGE_FILTER_FORM';
const RESET_FILTER_FORM = 'LOGSHEETS_RESET_FILTER_FORM';

interface ChangeFilterAction {
    type: typeof CHANGE_FILTER_FORM;
    filters: SearchForm;
}

export const changeFilterForm = (form: SearchForm): ChangeFilterAction => {
    return {
        type: CHANGE_FILTER_FORM,
        filters: form,
    };
};

interface ResetFilterFormAction {
    type: typeof RESET_FILTER_FORM;
}

export const resetFilterForm = (): ResetFilterFormAction => {
    return {
        type: RESET_FILTER_FORM,
    };
};

type FilterActionTypes = ChangeFilterAction | ResetFilterFormAction;

// state

export interface LogsheetsFilterFormState {
    filterForm: SearchForm;
    //
}

const initialFormState: SearchForm = {
    areaCode: '',
    isActive: [1],
    locationCode: '',
};

const initialState: LogsheetsFilterFormState = {
    filterForm: initialFormState,
};

// duck

const LogsheetsFilterDuck = (state = initialState, action: FilterActionTypes): LogsheetsFilterFormState => {
    switch (action.type) {
        case 'LOGSHEETS_CHANGE_FILTER_FORM':
            return { ...state, filterForm: { ...state.filterForm, ...action.filters } };

        case 'LOGSHEETS_RESET_FILTER_FORM':
            return { filterForm: initialFormState };

        default:
            return state;
    }
};

export default LogsheetsFilterDuck;
