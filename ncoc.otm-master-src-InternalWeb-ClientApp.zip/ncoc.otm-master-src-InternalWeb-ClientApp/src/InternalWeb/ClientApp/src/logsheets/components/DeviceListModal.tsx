import React from 'react';
import { Modal, Table, Button, Popconfirm, Alert } from 'antd';
import { GroupDto } from '../../services/Client';
import { orderBy } from 'lodash';

type Props = {
    visible: boolean;
    parentGroup: GroupDto;
    onOk: () => void;
    onAddDevice: (parentGroup: GroupDto) => void;
    onDeleteDevice: (groupdId: number) => void;
    onChangeIndex: (groupdId: number, upDown:number) => void;
    onReorderSave:()=>void;
};
type State = {};

class DeviceListModal extends React.Component<Props, State> {
    render() {
        const { visible, parentGroup } = this.props;
        let devices = parentGroup && parentGroup.childGroups!.filter(r => r.isDevice);
        // if(parentGroup?.order===0){
        //    parentGroup.childGroups?.map(x=>x.order=x.id)
        // }

        return (
            <Modal visible={visible} title="Devices" width={800} onCancel={this.props.onOk} onOk={this.props.onOk}>
                <div>
                    <Alert
                        message="Warning"
                        description={<span>After deleteing device, tags will be deleted accordingly.</span>}
                        type="warning"
                        showIcon
                    />
                </div>
                <Button
                type='primary'
                onClick={()=> this.props.onReorderSave()}
                >Save</Button>
                <Table
                    dataSource={devices}
                    rowKey={r => r.id + ''}
                    title={() => <Button onClick={() => this.props.onAddDevice(parentGroup!)}>Add new device</Button>}
                    
                    
                >
                    <Table.Column
                    
                        title="Actions"
                        render={(row: GroupDto) => (<>
                            <Button
                            shape="circle"
                            icon="up-circle"
                            title="edit"
                            onClick={() => this.props.onChangeIndex(row!.id!, 1)}
                        ></Button>{' '}
                       <Button
                            shape="circle"
                            icon="down-circle"
                            title="edit"
                            onClick={() => this.props.onChangeIndex(row!.id!, 2)}
                        ></Button>
                        </>
                        )}
                    ></Table.Column>
                    <Table.Column
                        title="Is Active"
                        dataIndex="isActive"
                        render={(isActive: boolean) => (isActive ? 'Yes' : 'No')}
                    ></Table.Column>
                    <Table.Column 
                    title="ID" 
                    dataIndex="id"
                    sortDirections={['descend']}
                    
                    
                    
                    ></Table.Column>
                    <Table.Column 
                    title="Order" 
                    dataIndex="order"
                    sortDirections={['descend']}
                    
                    
                    
                    
                    ></Table.Column>
                    <Table.Column title="Name" dataIndex="name"></Table.Column>
                    <Table.Column
                        title="Actions"
                        render={(row: GroupDto) => (
                            <Popconfirm
                                title="Are you sure delete this tag?"
                                onConfirm={() => this.props.onDeleteDevice(row!.id!)}
                                okText="Yes"
                                cancelText="No"
                            >
                                <Button shape="circle" style={{ color: 'red' }} title="delete" icon="delete"></Button>
                            </Popconfirm>
                        )}
                    ></Table.Column>
                </Table>
            </Modal>
        );
    }
}

export default DeviceListModal;
