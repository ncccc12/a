import React from 'react';
import { Form, Drawer, Button, Switch, Input } from 'antd';
import { FormComponentProps } from 'antd/lib/form';

export type ListTypeValueForm = {
    listTypeId: number;
    id: number;
    name: string;
    code: string;
    description: string;
    isExceed: boolean;
    isActive: boolean;
};

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps;
type State = {};

const ListTypeValueDrawer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        render() {
            const {
                visible,
                form,
                form: { getFieldDecorator },
            } = this.props;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            getFieldDecorator('id');
            let id = form.getFieldValue('id');

            getFieldDecorator('listTypeId');

            return (
                <Drawer
                    title={id ? 'Edit list type value' : 'Add list type value'}
                    visible={visible}
                    width={500}
                    destroyOnClose={true}
                    onClose={this.props.onClose}
                >
                    <Form labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Name">
                            {getFieldDecorator('name', {
                                rules: [
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Name is required',
                                    },
                                ],
                            })(<Input />)}
                        </Form.Item>
                        <Form.Item label="Code">
                            {getFieldDecorator('code', {
                                rules: [
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Code is required',
                                    },
                                ],
                            })(<Input disabled={id} />)}
                        </Form.Item>
                        <Form.Item label="Description">
                            {getFieldDecorator('description')(<Input.TextArea autoSize={{ minRows: 4 }} />)}
                        </Form.Item>
                        <Form.Item label="Is exceed">
                            {getFieldDecorator('isExceed', { valuePropName: 'checked' })(<Switch />)}
                        </Form.Item>
                        <Form.Item label="Is active">
                            {getFieldDecorator('isActive', { valuePropName: 'checked' })(<Switch />)}
                        </Form.Item>
                    </Form>
                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button onClick={this.props.onSubmit} type="primary">
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default ListTypeValueDrawer;
