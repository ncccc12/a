import React from 'react';
import { Form, Select, Button } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import { AreaVm, DictionaryDto } from '../../services/Client';
import ButtonGroup from 'antd/lib/button/button-group';

export type SearchForm = {
    locationCode: string;
    areaCode: string;
    isActive: number[];
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    searchForm: SearchForm;
    onSearch: () => void;
    onReset: () => void;
    onChange: (values: SearchForm) => void;
} & FormComponentProps<any>;
type State = {
    filteredAreas: AreaVm[];
};

const LogsheetsFilterForm = Form.create<Props>({
    mapPropsToFields(props: Props): any {
        return {
            locationCode: Form.createFormField({
                value: props.searchForm.locationCode,
            }),
            areaCode: Form.createFormField({
                value: props.searchForm.areaCode,
            }),
            isActive: Form.createFormField({
                value: props.searchForm.isActive,
            }),
        };
    },
    onValuesChange(props: Props, values: SearchForm): void {
        props.onChange(values);
    },
})(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredAreas: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            const { areas } = this.props;

            if (!prevProps.areas.length && areas.length) {
                const {
                    searchForm: { locationCode },
                } = this.props;

                if (locationCode) {
                    this.filterAreas(locationCode);
                }
            }
        }

        filterAreas = (value: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === value);
            this.setState({ filteredAreas });
        };

        handleLocationChange = (value: string) => {
            this.filterAreas(value);
            this.props.form.setFieldsValue({
                areaCode: '',
            });
        };

        // resetFilter = () => {
        //     this.props.form.resetFields();
        //     this.props.onSearch();
        // };

        render() {
            const {
                form: { getFieldDecorator },
            } = this.props;
            const { locations } = this.props;
            const { filteredAreas } = this.state;

            const selectStyle = {
                width: 150,
            };

            return (
                <Form labelAlign="left" layout="inline">
                    <Form.Item label="Location">
                        {getFieldDecorator('locationCode')(
                            <Select style={selectStyle} onChange={this.handleLocationChange}>
                                {locations.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>

                    <Form.Item label="Area">
                        {getFieldDecorator('areaCode')(
                            <Select style={selectStyle}>
                                {filteredAreas.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>

                    <Form.Item label="Is active">
                        {getFieldDecorator('isActive', { initialValue: [1] })(
                            <Select style={selectStyle} mode="multiple">
                                <Select.Option key="y" value={1}>
                                    Yes
                                </Select.Option>
                                <Select.Option key="n" value={0}>
                                    No
                                </Select.Option>
                            </Select>,
                        )}
                    </Form.Item>

                    <Form.Item>
                        <ButtonGroup>
                            <Button type="primary" onClick={this.props.onSearch}>
                                Search
                            </Button>
                            <Button onClick={this.props.onReset}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Form>
            );
        }
    },
);

export default LogsheetsFilterForm;
