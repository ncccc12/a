import React from 'react';
import { Button, Modal, Table, message } from 'antd';
import { ListTypeValueVm, ListTypeVm, AddListTypeValueCommand, UpdateListTypeValueCommand } from '../../services/Client';
import ListTypeValueDrawer, { ListTypeValueForm } from './ListTypeValueDrawer';
import { WrappedFormUtils } from 'antd/lib/form/Form';
import { listTypesClient } from '../../services';

type Props = {
    visible: boolean;
    listType: ListTypeVm | undefined;
    onClose: () => void;
    onReload: () => void;
};
type State = {
    listTypeValueDrawerShown: boolean;
    loading: boolean;
};

class ListTypeValuesModal extends React.Component<Props, State> {
    listTypeValueRef: any;

    constructor(props: Props) {
        super(props);

        this.state = {
            listTypeValueDrawerShown: false,
            loading: false,
        };
    }

    openListTypeValueDrawer = (row: ListTypeValueVm | undefined) => {
        const form = this.listTypeValueRef.props.form as WrappedFormUtils<any>;
        const { listType } = this.props;

        this.setState({ listTypeValueDrawerShown: true }, () => {
            if (row) {
                let valueForm: ListTypeValueForm = {
                    listTypeId: listType?.id!,
                    id: row.id!,
                    name: row.name!,
                    code: row.code!,
                    description: row.description!,
                    isExceed: row.isExceed!,
                    isActive: row.isActive!,
                };

                form.setFieldsValue({
                    ...valueForm,
                });
            } else {
                form.resetFields();
                form.setFieldsValue({ isActive: true, listTypeId: listType?.id! });
            }
        });
    };

    renderActions = (row: ListTypeValueVm) => {
        return (
            <Button icon="edit" shape="circle" title="Edit" onClick={() => this.openListTypeValueDrawer(row)}></Button>
        );
    };

    submitForm = () => {
        const form = this.listTypeValueRef.props.form as WrappedFormUtils<any>;
        form.validateFields(async (err: any, values: ListTypeValueForm) => {
            if (err) return;

            try {
                this.setState({ loading: true });

                if (values.id) {
                    let updateCommand = new UpdateListTypeValueCommand();
                    updateCommand.init(values);
                    await listTypesClient.updateListTypeValue(updateCommand);
                } else {
                    let addCommand = new AddListTypeValueCommand();
                    addCommand.init(values);

                    await listTypesClient.addListTypeValue(addCommand);
                }

                message.success('Successful');
                this.setState({ listTypeValueDrawerShown: false });
                this.props.onReload();
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    render() {
        const { visible, listType } = this.props;
        const { listTypeValueDrawerShown, loading } = this.state;

        return (
            <>
                <Modal
                    visible={visible}
                    title={`List type: ${listType?.name} values`}
                    width={1000}
                    footer={null}
                    confirmLoading={loading}
                    onCancel={this.props.onClose}
                >
                    <Table
                        rowKey={(r) => r.id + ''}
                        dataSource={listType?.listTypeValues}
                        title={() => (
                            <Button type="primary" onClick={() => this.openListTypeValueDrawer(undefined)}>
                                Add new
                            </Button>
                        )}
                    >
                        <Table.Column dataIndex="name" title="Name"></Table.Column>
                        <Table.Column dataIndex="code" title="Code"></Table.Column>
                        <Table.Column dataIndex="description" title="Description"></Table.Column>
                        <Table.Column
                            dataIndex="isExceed"
                            title="Is exceed"
                            render={(isExceed: boolean) => <span>{isExceed ? 'Yes' : 'No'}</span>}
                        ></Table.Column>
                        <Table.Column
                            dataIndex="isActive"
                            title="Is Active"
                            render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                        ></Table.Column>
                        <Table.Column title="Actions" render={(r) => this.renderActions(r)}></Table.Column>
                    </Table>
                </Modal>
                <ListTypeValueDrawer
                    visible={listTypeValueDrawerShown}
                    wrappedComponentRef={(compRef: any) => (this.listTypeValueRef = compRef)}
                    onSubmit={this.submitForm}
                    onClose={() => this.setState({ listTypeValueDrawerShown: false })}
                ></ListTypeValueDrawer>
            </>
        );
    }
}

export default ListTypeValuesModal;
