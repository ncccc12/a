import React from 'react';
import { Drawer, Form, Input, Button, Switch } from 'antd';
import { FormComponentProps } from 'antd/lib/form';

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {};

const GroupDrawer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        render() {
            const {
                visible,
                form: { getFieldDecorator },
                form,
            } = this.props;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            getFieldDecorator('id');
            getFieldDecorator('parentGroup.id');

            let id = form.getFieldValue('id');
            let isDevice = form.getFieldValue('isDevice');
            form.getFieldDecorator('isParentLogsheet');

            let title = '';
            if (id) {
                title = isDevice ? 'Edit device' : 'Edit group';
            } else {
                title = isDevice ? 'Add device' : 'Add group';
            }

            return (
                <Drawer title={title} visible={visible} width={700} onClose={this.props.onClose}>
                    <Form labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Parent group">
                            {getFieldDecorator('parentGroup.name')(<Input readOnly />)}
                        </Form.Item>
                        <Form.Item label={isDevice ? 'Device name' : 'Group name'}>
                            {getFieldDecorator('groupName', {
                                rules: [
                                    {
                                        required: true,
                                        message: 'Name is required',
                                    },
                                ],
                            })(<Input />)}
                        </Form.Item>
                        <Form.Item label="Is Device">
                            {getFieldDecorator('isDevice', { valuePropName: 'checked' })(<Switch disabled />)}
                        </Form.Item>
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default GroupDrawer;
