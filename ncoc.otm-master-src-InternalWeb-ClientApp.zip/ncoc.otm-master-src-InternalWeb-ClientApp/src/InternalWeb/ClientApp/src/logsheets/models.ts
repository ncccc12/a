export enum DataTypes {
    Text = 'TEXT',
    Number = 'NUMBER',
    List = 'LIST',
}
