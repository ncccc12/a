import { OptionProps } from 'antd/lib/select';

export const AllYesNoSelectOptions: OptionProps[] = [
    {
        value: 0,
        title: 'All',
    },
    {
        value: 1,
        title: 'Yes',
    },

    {
        value: -1,
        title: 'No',
    },
];
