import moment from "moment";

export interface ReportScheduleConfig {
    id?: number;
    group1?: ReportGroupConfig;
    group2?: ReportGroupConfig;
    group3?: ReportGroupConfig;
    group4?: ReportGroupConfig;

    areaCode?: string;
    areaName?: string;
    datePeriod?: moment.Moment[];
    locationCode?: string;
    locationName?: string;
    rotationType?: string;
    scheduleConfigName?: string;
    year?: number;
    // dayShiftFirst1: number;
    // dayShiftFirst2: number;
}

export interface ReportGroupConfig {
    code: string;
    name?: string;
    dayShift?: boolean;
    schedule?: number[];
    reportSchedule?: number[];
}
