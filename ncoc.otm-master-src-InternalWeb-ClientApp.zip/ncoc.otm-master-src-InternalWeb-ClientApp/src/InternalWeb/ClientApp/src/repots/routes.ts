import ReportsHistoryPage from './pages/ReportsHistoryPage';
import ReportsDailyPage from './pages/ReportsDailyPage';
import ReportsViewHistoryDetailsPage from './pages/ReportsViewHistoryDetailsPage';
import ScheduleConfigsPage from './pages/ScheduleConfigsPage';
import ScheduleConfigReportPage from './pages/ReportScheduleConfigPage';
import ReportByDevicePage from './pages/ReportByDevicePage';

import { RouteProps } from 'react-router';
import OilSsrsReport from './pages/OilSsrsReport';

const routes: RouteProps[] = [
    {
        path: '/reports/general/:id',
        component: ReportsViewHistoryDetailsPage,
        exact: true,
    },
    {
        path: '/reports/general',
        component: ReportsHistoryPage,
        exact: true,
    },
    {
        path: '/reports/daily',
        component: ReportsDailyPage,
        exact: true,
    },
    {
        path: '/reports/schedule-configs',
        component: ScheduleConfigsPage,
        exact: true,
    },
    {
        path: '/reports/schedule-configs/:id',
        component: ScheduleConfigReportPage,
        exact: true,
    },
    {
        path: '/reports/by-device',
        component: ReportByDevicePage,
        exact: true,
    },
    {
        path: '/reports/technological-oil',
        component: OilSsrsReport,
        exact: true,
    },
];

export default routes;
