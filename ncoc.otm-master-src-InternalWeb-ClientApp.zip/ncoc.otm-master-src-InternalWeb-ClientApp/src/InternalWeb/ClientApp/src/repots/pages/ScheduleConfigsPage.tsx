import React from 'react';
import { Card, Typography } from 'antd';
import ScheduleConfigsContainer from '../../schedule/containers/ScheduleConfigsContainer';

export default () => (
    <Card title={<Typography.Title>Schedule configs</Typography.Title>}>
        <ScheduleConfigsContainer isReportPage  />
    </Card>
);