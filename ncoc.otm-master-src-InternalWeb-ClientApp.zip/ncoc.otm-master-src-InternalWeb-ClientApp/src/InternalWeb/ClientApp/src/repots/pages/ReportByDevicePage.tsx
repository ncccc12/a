import React from 'react';
import { Card, Typography } from 'antd';
import ReportByDeviceContainer from '../containers/ReportByDeviceContainer';

export default () => (
    <Card title={<Typography.Title>Report by device/tag</Typography.Title>}>
        <ReportByDeviceContainer></ReportByDeviceContainer>
    </Card>
);
