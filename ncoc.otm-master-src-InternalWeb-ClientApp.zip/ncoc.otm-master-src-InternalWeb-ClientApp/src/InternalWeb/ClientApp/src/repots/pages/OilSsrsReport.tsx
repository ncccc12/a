import React, { useEffect, useState } from 'react';
import { Card, Skeleton } from 'antd';
import { reportsClient } from '../../services';

const OilSsrsReport = () => {
    const [reportContent, setReportContent] = useState<string | null>(null);

    useEffect(() => {
        const fetchReport = async () => {
            try {
                const response = await reportsClient.getOilReport();
                const arrayBuffer = await response.data.arrayBuffer();
                const base64String = btoa(
                    new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), ''),
                );
                setReportContent(base64String);
            } catch (error) {
                console.error('Error fetching report:', error);
            }
        };

        fetchReport();
    }, []);

    return (
        <Card title="Technological reglament exceedances" style={{ height: '100vh' }}>
            {reportContent ? (
                <iframe
                    title="Technological reglament exceedances"
                    src={`data:application/pdf;base64,${reportContent}`}
                    width="100%"
                    height="800"
                />
            ) : (
                <Skeleton active />
            )}
        </Card>
    );
};

export default OilSsrsReport;
