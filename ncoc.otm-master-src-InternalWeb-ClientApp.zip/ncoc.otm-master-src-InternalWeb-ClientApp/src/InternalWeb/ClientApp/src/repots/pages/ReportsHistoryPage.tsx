import React from 'react';
import HistoryContainer from '../containers/ReportsHistoryContainer';

export default () => <HistoryContainer />;
