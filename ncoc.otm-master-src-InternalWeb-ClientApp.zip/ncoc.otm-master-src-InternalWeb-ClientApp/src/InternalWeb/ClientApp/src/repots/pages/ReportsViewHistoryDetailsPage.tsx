import React from 'react';
import ReportsViewHistoryDetailsContainer from '../containers/ReportsViewHistoryDetailsContainer';
import { RouteComponentProps } from 'react-router';

type Params = {
    id: string;
};

export default (props: RouteComponentProps<Params>): JSX.Element => (
    <ReportsViewHistoryDetailsContainer id={parseInt(props.match.params.id)} />
);
