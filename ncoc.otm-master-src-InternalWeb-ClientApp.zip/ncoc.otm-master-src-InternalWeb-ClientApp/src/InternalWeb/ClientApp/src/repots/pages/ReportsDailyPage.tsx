import React from 'react';
import DailyContainer from '../containers/ReportsDailyContainer';
import { Card, Typography } from 'antd';

export default () => (
    <Card title={<Typography.Title>Daily reports</Typography.Title>}>
        <DailyContainer />
    </Card>
);
