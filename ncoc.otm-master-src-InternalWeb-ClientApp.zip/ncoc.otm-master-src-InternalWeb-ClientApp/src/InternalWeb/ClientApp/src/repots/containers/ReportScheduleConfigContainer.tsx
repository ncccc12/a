import React from 'react';
import { reportsClient } from '../../services';
import ScheduleConfigDetails from '../components/ScheduleConfigDetails';
import { Spin } from 'antd';
import ReportCalendarTable from '../components/ReportCalendarTable';
import { ReportScheduleConfig } from '../types';
import generateScheduleSrv from '../../schedule/GenerateScheduleService';

type Props = {
    id: number;
};
type State = {
    reportScheduleConfig?: ReportScheduleConfig;
    loading: boolean;
};

class ReportScheduleConfigContainer extends React.Component<Props, State> {
    configFormRef: any;

    constructor(props: Props) {
        super(props);
        this.state = {
            loading: true,
        };
    }

    async componentDidMount() {
        let configVm = await reportsClient.getScheduleConfig(this.props.id);
        let reportConfig = generateScheduleSrv.mapVmToReportScheduleConfig(configVm);

        this.setState({ reportScheduleConfig: reportConfig, loading: false });
    }

    render() {
        const { loading, reportScheduleConfig } = this.state;

        

        return (
            <Spin spinning={loading}>
                <ScheduleConfigDetails scheduleConfig={reportScheduleConfig} />
                {reportScheduleConfig && <ReportCalendarTable scheduleConfig={reportScheduleConfig} />}
            </Spin>
        );
    }
}

export default ReportScheduleConfigContainer;
