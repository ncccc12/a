import React from 'react';
import { Form, DatePicker, Button } from 'antd';
import { FormComponentProps } from 'antd/lib/form';

import fileDownload from 'js-file-download'
import { reportsClient } from '../../services';

type Props = {} & FormComponentProps;

type State = {
    isLoading: boolean;
}

const ReportsDailyContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                isLoading: false
            }
        }

        handleFormSubmit = (e: any) => {
            e.preventDefault();
            this.props.form.validateFields(async (errors, values) => {
                if (errors) {
                    return;
                }
                this.setState({
                    isLoading: true
                })
                const response = await reportsClient.getReportByPeriod(values);
                fileDownload(response.data, response.fileName!);
                this.setState({ isLoading: false })
            });
        };
        render(): JSX.Element {
            const { getFieldDecorator } = this.props.form;

            return (
                <Form layout="inline" onSubmit={this.handleFormSubmit}>
                    <Form.Item label="Date">
                        {getFieldDecorator('date', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Please select date',
                                },
                            ],
                        })(<DatePicker />)}
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType="submit" loading={this.state.isLoading} type="primary">
                            Export
                        </Button>
                    </Form.Item>
                </Form>
            );
        }
    },
);

export default ReportsDailyContainer;
