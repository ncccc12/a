import React from 'react';
import { Button, Form, Select, Spin } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import { dictionaryClient, logSheetsClient, reportsClient } from '../../services';
import { LogsheetDictionaryVm, DeviceVm, GetReportByDeviceQuery, GetTagsQuery, TagVm, DictionaryDto, AreaVm  } from '../../services/Client';
import ButtonGroup from 'antd/lib/button/button-group';
import { DatePicker } from 'antd';
import fileDownload from 'js-file-download';
import moment from 'moment';

type FilterForm = {
    logsheetId: number;
    deviceIds: number[];
    tagIds: number[];
    datePeriod: moment.Moment[];
};

type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    logsheets: LogsheetDictionaryVm[];
    devices: DeviceVm[];
    filteredDevices: DeviceVm[];
    tags: TagVm[];
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const { RangePicker } = DatePicker;

const ReportByDeviceContainer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                logsheets: [],
                devices: [],
                filteredDevices: [],
                tags: [],
                locations: [],
                areas: []
            };
        }

        componentDidMount() {
            this.loadData();
        }

        loadData = async () => {
            let logsheets = await dictionaryClient.getLogsheets();
            const locations = await dictionaryClient.getLocations();
            const areas = await dictionaryClient.getAreas();

            this.setState({ logsheets, locations, areas });
        };

        handleLogsheetChange = async (id: number) => {
            let devices = await logSheetsClient.getDevices(id);
            this.setState({ filteredDevices: devices });
          
            const { form } = this.props;
            form.setFieldsValue({
                deviceIds: []
            })
        };

        handleDeviceChange = async (deviceIds: number[]) => {
            
            let query = new GetTagsQuery();
            query.deviceIds = deviceIds;
            let tags = await logSheetsClient.getTags(query);
            this.setState({tags});
        }

        generateReport = () => {
            const { form } = this.props;
            form.validateFields(async (err: any, values: FilterForm) => {
                

                if (err) return;

                try {
                    this.setState({ loading: true });
                    let query = new GetReportByDeviceQuery();
                    query.logsheetId = values.logsheetId;
                    query.deviceIds = values.deviceIds;
                    query.tagIds = values.tagIds || [];
                    query.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                    let response = await reportsClient.getReportByDevice(query);
                    fileDownload(response.data, response.fileName!);
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        resetFilter = () => {
            const { form } = this.props;
            form.resetFields();
        };

        render() {
            const { loading,  filteredDevices, tags, locations, areas } = this.state;
            const {
                form: { getFieldDecorator, getFieldValue },
            } = this.props;

            const selectStyle = {
                width: 250,
            };

            const selectedLocationId = getFieldValue('locationId');
            const selectedAreaCode = getFieldValue('areaCode');
            
            let {logsheets} = this.state;
            if (selectedAreaCode !== undefined) {
                logsheets = logsheets.filter((item: LogsheetDictionaryVm) => item.areaCode === selectedAreaCode);
            }

            return (
                <Spin spinning={loading}>
                    <Form labelAlign="left" layout="inline">
                        <Form.Item label="Location">
                                {getFieldDecorator('locationId')(
                                    <Select style={{width:150}} placeholder="Select location">
                                        {locations.map((item: DictionaryDto) => (
                                            <Select.Option key={item.id} value={item.id}>
                                                {item.name}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                )}
                        </Form.Item>
                        <Form.Item
                            label="Area"
                            help="Please select location first"
                        >
                            {getFieldDecorator('areaCode')(
                                <Select placeholder="Select area">
                                    {areas
                                        .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                        .map((item: AreaVm) => (
                                            <Select.Option key={item.id} value={item.code}>
                                                {item.name}
                                            </Select.Option>
                                        ))}
                                </Select>,
                            )}
                        </Form.Item>
                        <Form.Item label="Logsheet">
                            {getFieldDecorator('logsheetId', {
                                rules: [
                                    {
                                        required: true,
                                        message: 'Logsheet is required',
                                    },
                                ],
                            })(
                                <Select
                                    style={{ width: 450 }}
                                    showSearch
                                    optionFilterProp="children"
                                    onChange={this.handleLogsheetChange}
                                >
                                    {logsheets.map((r) => (
                                        <Select.Option key={r.id} value={r.id} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>

                        <Form.Item label="Devices">
                            {getFieldDecorator('deviceIds')(
                                <Select style={selectStyle} mode="multiple" showSearch optionFilterProp="children" onChange={this.handleDeviceChange}>
                                    {filteredDevices.map((r) => (
                                        <Select.Option key={r.id} value={r.id} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>

                          <Form.Item label="Tags">
                            {getFieldDecorator('tagIds')(
                                <Select style={selectStyle} mode="multiple" showSearch optionFilterProp="children">
                                    {tags.map((r) => (
                                        <Select.Option key={r.id} value={r.id} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>

                        <Form.Item label="Date period">
                            {getFieldDecorator('datePeriod', {
                                rules: [
                                    {
                                        required: true,
                                        message: 'Date period is required',
                                    },
                                ],
                            })(<RangePicker />)}
                        </Form.Item>
                      

                        {/* <Form.Item label="Is active">
                            {getFieldDecorator('isActive', { initialValue: [] })(
                                <Select mode="multiple">
                                    <Select.Option key="y" value={1}>
                                        Yes
                                    </Select.Option>
                                    <Select.Option key="n" value={0}>
                                        No
                                    </Select.Option>
                                </Select>,
                            )}
                        </Form.Item> */}

                        <Form.Item>
                            <ButtonGroup>
                                <Button type="primary" onClick={this.generateReport}>
                                    Generate report
                                </Button>
                                <Button onClick={this.resetFilter}>Reset</Button>
                            </ButtonGroup>
                        </Form.Item>
                    </Form>
                </Spin>
            );
        }
    },
);

export default ReportByDeviceContainer;
