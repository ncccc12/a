import React, { Fragment } from 'react';
import moment from 'moment';
import { Row, Tag } from 'antd';
import generateScheduleSrv from '../../schedule/GenerateScheduleService';
import { ReportScheduleConfig, ReportGroupConfig } from '../types';
import { RotationCalendarType } from '../../schedule/constants';
import TimeHistoriesModal from '../components/TimeHistoriesModal';
import { reportsClient } from '../../services';
import { ReportDailyInfoVm, ScheduleReportInfos } from '../../services/Client';

type Props = {
    scheduleConfig: ReportScheduleConfig;
};
type State = {
    months: moment.Moment[];
    timeHistoryModalShown: boolean;
    dailytimeHistories: ReportDailyInfoVm[];
};

class ReportCalendarTable extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);

        this.state = {
            months: [],
            timeHistoryModalShown: false,
            dailytimeHistories: [],
        };
    }

    componentDidMount() {
        const { scheduleConfig } = this.props;
        let months: moment.Moment[] = [];

        for (let i = 0; i < 12; i++) {
            const currMonth = moment([scheduleConfig.year!, i, 1]);
            months.push(currMonth);
        }

        this.setState({ months });
    }

    openGroupDetailsModal = async (groupCode: string, monthDate: moment.Moment) => {
        const { scheduleConfig } = this.props;
        let normDate = monthDate.utc(true).toDate();
        let timeHistories = await reportsClient.getGroupReportInfoByDay(scheduleConfig.id, groupCode, normDate);

        this.setState({ timeHistoryModalShown: true, dailytimeHistories: timeHistories });
    };

    openDetailsModal = async (monthDate: moment.Moment) => {
        const { scheduleConfig } = this.props;
        let normDate = monthDate.utc(true).toDate();
        let timeHistories = await reportsClient.getReportInfoByDay(scheduleConfig.id, normDate);

        this.setState({ timeHistoryModalShown: true, dailytimeHistories: timeHistories });
    };

    getGroupItemRow(group: ReportGroupConfig, month: moment.Moment): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            const monthDate: moment.Moment = moment([month.year(), month.month(), day]);
            const monthDayOfYear: number = monthDate.dayOfYear();

            let dayType: string = '';
            switch (group.schedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let tags = [];
            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.NotFilled) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'g'} color="grey">
                        E
                    </Tag>,
                );
            }

            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.HasExceedance) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'r'} color="red">
                        {'>'}
                    </Tag>,
                );
            }

            if ((group.reportSchedule![monthDayOfYear - 1] & ScheduleReportInfos.Filled) > 0) {
                tags.push(
                    <Tag key={monthDayOfYear - 1 + 'gr'} color="green">
                        OK
                    </Tag>,
                );
            }

            switch (group.reportSchedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let className = 'editable ';

            className = dayType ? className + ' ' : className;

            return (
                <td
                    key={monthDayOfYear + ' ' + group.code}
                    className={className}
                    onDoubleClick={() => this.openGroupDetailsModal(group.code, monthDate)}
                >
                    <Row type="flex" justify="center" align="middle">
                        {tags}
                    </Row>
                </td>
            );
        });
    }

    getGroupRows(month: moment.Moment): JSX.Element {
        const { scheduleConfig } = this.props;

        return (
            <Fragment key={month.month() + '_'}>
                <tr>
                    <td rowSpan={2}>Group 1/2</td>
                    <td>{scheduleConfig!.group1!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group1!, month)}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group2!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group2!, month)}
                </tr>
                <tr>
                    <td rowSpan={2}>Group 3/4</td>
                    <td>{scheduleConfig!.group3!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group3!, month)}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group4!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group4!, month)}
                </tr>
            </Fragment>
        );
    }

    /**
     * ex. 1, 2, 3, 4...
     * @param month - object month(january, febr, ...)
     */
    getMonthHeaderTHs(month: moment.Moment): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            let monthDate =  moment([month.year(), month.month(), day]);
         
            return (
                <th key={day} onDoubleClick={() => this.openDetailsModal(monthDate)}>
                    {day}
                </th>
            );
        });
    }

    getMonthRows(): JSX.Element[] {
        const { months } = this.state;
        const rows: JSX.Element[] = [];

        
        months.forEach((month: moment.Moment) => {
            const monthRow: JSX.Element = (
                <tr key={month.month()} style={{ height: 40 }}>
                    <th rowSpan={2 * 2 + 1}>{month.month() + 1}</th>
                    <th colSpan={2}>{moment.months(month.month())}</th>
                    {this.getMonthHeaderTHs(month)}
                </tr>
            );

            const groupRows: JSX.Element = this.getGroupRows(month);

            rows.push(monthRow);
            rows.push(groupRows);
        });

        return rows;
    }

    render() {
        const { timeHistoryModalShown, dailytimeHistories } = this.state;

        return (
            <Row className="schedule-config">
                <Row justify="end" type="flex">
                    <div>
                        <Tag color="grey">E</Tag> - Not filled
                        <Tag color="red" style={{ marginLeft: 15 }}>
                            {'>'}
                        </Tag>
                        - Has exceedance
                        <Tag color="green" style={{ marginLeft: 15 }}>
                            OK
                        </Tag>
                        - Filled
                    </div>
                </Row>
                <br />

                <table>
                    <tbody>{this.getMonthRows()}</tbody>
                </table>
                <TimeHistoriesModal
                    visible={timeHistoryModalShown}
                    dailyTimeHistories={dailytimeHistories}
                    onOk={() => {}}
                    onCancel={() => {
                        this.setState({ timeHistoryModalShown: false });
                    }}
                />
            </Row>
        );
    }
}

export default ReportCalendarTable;
