import React from 'react';
import { Drawer, Form, Select, Button } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import { EmployeeVm, GroupVm } from '../../services/Client';

export type SelectEmployeeForm = {
    groupCode: string;
    employeeId: number;
}

type Props = {
    visible: boolean;
    groups: GroupVm[];
    employees: EmployeeVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {
    filteredEmployees: EmployeeVm[];
};

const SelectEmployeeDrawer = Form.create<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredEmployees: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            if (!prevProps.visible && this.props.visible) {
                const { form } = this.props;

                let groupCode = form.getFieldValue('groupCode');
                this.filterEmployees(groupCode);
            }
        }

        filterEmployees = (code: string) => {
            const { employees } = this.props;

            let filteredEmployees = employees.filter((r) => r.groupCode === code);
            this.setState({ filteredEmployees });
        };

        handleGroupChange = (code: string) => {
            const { form } = this.props;

            this.filterEmployees(code);
            form.setFieldsValue({
                employeeId: undefined,
            });
        };

        render() {
            const {
                visible,
                form: { getFieldDecorator },
                groups,
            } = this.props;

            const { filteredEmployees } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            return (
                <Drawer title="Select Employee" visible={visible} width={700} onClose={this.props.onClose}>
                    <Form labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Group">
                            {getFieldDecorator('groupCode', {
                                rules: [
                                    {
                                        required: true,
                                    },
                                ],
                            })(
                                <Select onChange={this.handleGroupChange}>
                                    {groups.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>

                        <Form.Item label="Employee">
                            {getFieldDecorator('employeeId', {
                                rules: [
                                    {
                                        required: true,
                                    },
                                ],
                            })(
                                <Select>
                                    {filteredEmployees.map((r) => {
                                        return (
                                            <Select.Option key={r.id} value={r.id}>
                                                {r.lastName + ' ' + r.firstName}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default SelectEmployeeDrawer;
