import { Button, Collapse, Form, Icon, Select } from 'antd';
import { FormComponentProps } from 'antd/lib/form';
import { OptionProps } from 'antd/lib/select';
import React from 'react';
import { AllYesNoSelectOptions } from '../../constants';
// import { AdminFolderFilterForm, FolderStructure } from '../../models';
import PeriodDatePicker from './PeriodDatePicker';
import { ReportsHistoryFilterFormModel } from '../models/reportsHistoryModels';
import { DictionaryDto, AreaVm, LogSheetVm } from '../../services/Client';
const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

type Props = {
    total?: number;
    filterForm: ReportsHistoryFilterFormModel;
    isFilterFormExpanded: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logSheetsOptions: LogSheetVm[];
    onChange: (values: ReportsHistoryFilterFormModel) => void;
    onSubmit: (e: any) => void;
    onReset: () => void;
    onExpand: () => void;
} & FormComponentProps;

const FilterPanel = Form.create<Props>({
    mapPropsToFields(props: Props): any {
        return {
            logSheetId: Form.createFormField({
                value: props.filterForm.logSheetId,
            }),
            areaId: Form.createFormField({
                value: props.filterForm.areaId,
            }),
            locationId: Form.createFormField({
                value: props.filterForm.locationId,
            }),
            startDate: Form.createFormField({
                value: props.filterForm.startDate,
            }),
            endDate: Form.createFormField({
                value: props.filterForm.endDate,
            }),
            hasExceedance: Form.createFormField({
                value: props.filterForm.hasExceedance,
            }),
            hasCompliance: Form.createFormField({
                value: props.filterForm.hasCompliance,
            }),
        };
    },
    onValuesChange(props: Props, values: ReportsHistoryFilterFormModel): void {
        props.onChange(values);
    },
})(
    (props: Props): JSX.Element => {
        const activeKey = props.isFilterFormExpanded ? '1' : '';
        const { getFieldDecorator, getFieldValue } = props.form;
        const allYesNoOptions = AllYesNoSelectOptions.map((item: OptionProps) => (
            <Select.Option key={item.value} value={item.value}>
                {item.title}
            </Select.Option>
        ));
        const selectedLocationId = getFieldValue('locationId');
        const selectedAreaId = getFieldValue('areaId');
        let logSheets = props.logSheetsOptions;
        if (selectedLocationId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.locationId === selectedLocationId);
        }
        if (selectedAreaId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.areaId === selectedAreaId);
        }
        const logSheetsOptions = logSheets.map((item: LogSheetVm) => (
            <Select.Option key={item.id} value={item.id}>
                {item.name}
            </Select.Option>
        ));

        return (
            <Collapse
                onChange={props.onExpand}
                accordion={true}
                defaultActiveKey={activeKey}
                expandIconPosition="right"
                style={{ marginBottom: '10px' }}
            >
                <Collapse.Panel
                    header={
                        <b>
                            <Icon type="search" /> Search panel
                        </b>
                    }
                    key="1"
                    extra={<b style={{ color: '#1890ff' }}>Found {props.total} items</b>}
                >
                    <Form layout="horizontal" onSubmit={props.onSubmit}>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Location"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {getFieldDecorator('locationId')(
                                            <Select placeholder="Select location">
                                                {props.locations.map((item: DictionaryDto) => (
                                                    <Select.Option key={item.id} value={item.id}>
                                                        {item.name}
                                                    </Select.Option>
                                                ))}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                </div>
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Area"
                                        labelAlign="left"
                                        {...formItemLayout}
                                        help="Please select location first"
                                    >
                                        {getFieldDecorator('areaId')(
                                            <Select placeholder="Select area">
                                                {props.areas
                                                    .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                                    .map((item: AreaVm) => (
                                                        <Select.Option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </Select.Option>
                                                    ))}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Log sheet"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {getFieldDecorator('logSheetId')(
                                            <Select
                                                placeholder="Select log sheet"
                                                showSearch
                                                filterOption={(input: string, option: any) => {
                                                    return (
                                                        option.props.children
                                                            .toLowerCase()
                                                            .indexOf(input.toLowerCase()) >= 0
                                                    );
                                                }}
                                            >
                                                {logSheetsOptions}
                                            </Select>,
                                        )}
                                    </Form.Item>
                                </div>
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Schedule date"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        <PeriodDatePicker
                                            form={props.form}
                                            startDateFieldName="startDate"
                                            endDateFieldName="endDate"
                                        />
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Has exceedance?"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {getFieldDecorator('hasExceedance')(<Select>{allYesNoOptions}</Select>)}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Has compliance?"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {getFieldDecorator('hasCompliance')(<Select>{allYesNoOptions}</Select>)}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 pull-right">
                                    <Button.Group className="pull-right">
                                        <Button type="primary" htmlType="submit">
                                            Search
                                        </Button>
                                        <Button onClick={props.onReset}>Reset</Button>
                                    </Button.Group>
                                </div>
                            </div>
                        </div>
                    </Form>
                </Collapse.Panel>
            </Collapse>
        );
    },
);
export default FilterPanel;
