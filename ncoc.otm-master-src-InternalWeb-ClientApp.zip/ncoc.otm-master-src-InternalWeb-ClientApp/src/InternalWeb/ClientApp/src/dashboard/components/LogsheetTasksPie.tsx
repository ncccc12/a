import React from 'react';
import { Spin, Card, DatePicker, Form, Select, Button, Row, Col, Typography } from 'antd';
import { PieChart } from '@opd/g2plot-react';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, GetTimeHistoriesStatusesCountQuery } from '../../services/Client';
import moment from 'moment';

import { FormComponentProps } from 'antd/lib/form';
import ButtonGroup from 'antd/lib/button/button-group';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    filteredAreas: AreaVm[];
};

const LogsheetTasksPie = Form.create<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                datas: [],
                filteredAreas: [],
            };
        }

        colorMapping = (status: any) => {
            if (status.x === 'Completed') {
                return '#a0d911';
            }
            return '#FF0000';
        };

        config = {
            title: {
                visible: true,
                text: '',
            },
            description: {
                visible: true,
                text: '',
            },
            legend: {
                flipPage: false,
            },
            height: 250,
            forceFit: true,
            radius: 1,
            colorField: 'x',
            angleField: 'y',
            color: (status: any) => this.colorMapping(status),
        };

        componentDidMount() {
            this.search();
        }

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        search = async () => {
            this.setState({ loading: true });
            const { form } = this.props;

            form.validateFields(async (errors: any, values: any) => {
                let period = values.datePeriod?.map((r: moment.Moment) => r.utc(true).toDate());
                let query = new GetTimeHistoriesStatusesCountQuery();
                query.datePeriod = period || [];
                query.areaCode = values.areaCode;
                query.locationCode = values.locationCode;

                let result = await logsheetTimeHistoriesClient.getTimeHistoriesStatusesCount(query);

                result.forEach(async (result) => {
                    if (result.statusId === 1) {
                    }
                });
                let datas = result.map((r) => {
                    return {
                        x: r.statusName,
                        y: r.count,
                    };
                });
                this.setState({ loading: false, datas });
            });
        };

        renderHeader = () => {
            const { filteredAreas } = this.state;
            const {
                form: { getFieldDecorator },
                locations,
            } = this.props;

            return (
                <>
                    <Form layout="inline" labelAlign="left">
                        <Row type="flex" justify="space-between">
                            <Typography.Title level={4}>Tasks status</Typography.Title>
                            <Form.Item style={{ margin: 0 }}>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Row>
                        <Row gutter={24}>
                            <Col md={12}>
                                <Form.Item
                                    style={{ width: '100%' }}
                                    wrapperCol={{ span: 14 }}
                                    labelCol={{ span: 10 }}
                                    label="Location"
                                >
                                    {getFieldDecorator('locationCode')(
                                        <Select onChange={this.handleLocationChange}>
                                            {locations.map((r) => {
                                                return (
                                                    <Select.Option key={r.code} value={r.code}>
                                                        {r.name}
                                                    </Select.Option>
                                                );
                                            })}
                                        </Select>,
                                    )}
                                </Form.Item>
                            </Col>
                            <Col md={12}>
                                <Form.Item
                                    label="Area"
                                    style={{ width: '100%' }}
                                    wrapperCol={{ span: 14 }}
                                    labelCol={{ span: 10 }}
                                >
                                    {getFieldDecorator('areaCode')(
                                        <Select>
                                            {filteredAreas.map((r) => {
                                                return (
                                                    <Select.Option key={r.code} value={r.code}>
                                                        {r.name}
                                                    </Select.Option>
                                                );
                                            })}
                                        </Select>,
                                    )}
                                </Form.Item>
                            </Col>

                            <Col md={24}>
                                <Form.Item label="Date period" style={{ width: '100%' }}>
                                    {getFieldDecorator('datePeriod', {
                                        initialValue: [moment().startOf('day'), moment().startOf('day')],
                                    })(
                                        <DatePicker.RangePicker
                                            ranges={{
                                                Today: [moment(), moment()],
                                                'This week': [moment().startOf('week'), moment().endOf('week')],
                                                'This Month': [moment().startOf('month'), moment().endOf('month')],
                                                'This year': [moment().startOf('year'), moment().endOf('year')],
                                            }}
                                        />,
                                    )}
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </>
            );
        };

        render() {
            const { loading, datas } = this.state;

            return (
                <Spin spinning={loading}>
                    <Card title={this.renderHeader()}>{!loading && <PieChart {...this.config} data={datas} />}</Card>
                </Spin>
            );
        }
    },
);

export default LogsheetTasksPie;
