import React from 'react';
import { Row, Col } from 'antd';
import PendingLogsheetTasks from './components/PendingLogsheetTasks';
import ExceedanceComplineceChart from './components/ExceedanceComplineceChart';
import LogsheetTasksPie from './components/LogsheetTasksPie';
import DailyStatusProgress from './components/DailyStatusProgress';
import { AreaVm, DictionaryDto } from '../services/Client';
import { dictionaryClient } from '../services';

type Props = {};
type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

class DashboardContainer extends React.Component<Props, State> {
    /**
     *
     */
    constructor(props: Props) {
        super(props);

        this.state = {
            areas: [],
            locations: [],
        };
    }

    componentDidMount() {
        this.loadDictionaries();
    }

    loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        this.setState({ locations, areas });
    };

    render() {
        const { locations, areas } = this.state;

        return (
            <>
                <Row gutter={24}>
                    <Col md={16}>
                        <PendingLogsheetTasks locations={locations} areas={areas} />
                    </Col>
                    <Col md={8}>
                        <LogsheetTasksPie locations={locations} areas={areas} />

                        <DailyStatusProgress locations={locations} areas={areas} />
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col md={24}>
                        <ExceedanceComplineceChart locations={locations} areas={areas} />
                    </Col>
                </Row>
            </>
        );
    }
}

export default DashboardContainer;
