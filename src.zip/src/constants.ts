export const AllYesNoSelectOptions = [
    {
        value: 0,
        title: 'All',
    },
    {
        value: 1,
        title: 'Yes',
    },

    {
        value: -1,
        title: 'No',
    },
] as const;
