import React from 'react';
import { Spin, Card, Select, Button, Row, Col, Typography } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import { PieChart } from '@opd/g2plot-react';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, GetTimeHistoriesStatusesCountQuery } from '../../services/Client';
import moment from 'moment';

import { FormComponentProps } from '@ant-design/compatible/lib/form';
const ButtonGroup = Button.Group;

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    filteredAreas: AreaVm[];
};

const LogsheetTasksPieComponent: React.FC<Props> = ({ form, areas, locations }) => {

    const [loading, setLoading] = React.useState<boolean>(false);
    const [datas, setDatas] = React.useState<any[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const colorMapping = (status: any) => {
        if (status.x === 'Completed') {
            return '#a0d911';
        }
        return '#FF0000';
    };

    const config = React.useRef({
        title: {
            visible: true,
            text: '',
        },
        description: {
            visible: true,
            text: '',
        },
        legend: {
            flipPage: false,
        },
        height: 250,
        forceFit: true,
        radius: 1,
        colorField: 'x',
        angleField: 'y',
        color: (status: any) => colorMapping(status),
    });

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    }, [filterAreas, form]);

    const search = React.useCallback(async () => {
        setLoading(true);

        form.validateFields(async (errors: any, values: any) => {
            let period = values.datePeriod?.map((r: moment.Moment) => r.utc(true).toDate());
            let query = new GetTimeHistoriesStatusesCountQuery();
            query.datePeriod = period || [];
            query.areaCode = values.areaCode;
            query.locationCode = values.locationCode;

            let result = await logsheetTimeHistoriesClient.getTimeHistoriesStatusesCount(query);

            result.forEach(async (result) => {
                if (result.statusId === 1) {
                }
            });
            let datas = result.map((r) => {
                return {
                    x: r.statusName,
                    y: r.count,
                };
            });
            setLoading(false);
            setDatas(datas);
        });
    }, [form]);

    const resetFilter = React.useCallback(() => {
        form.resetFields();
        search();
    }, [form, search]);

    const renderHeader = () => {
        const { getFieldDecorator } = form;

        return <>
            <Form layout="inline" labelAlign="left">
                <Row justify="space-between">
                    <Typography.Title level={4}>Tasks status</Typography.Title>
                    <Form.Item style={{ margin: 0 }}>
                        <ButtonGroup>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Row>
                <Row gutter={24}>
                    <Col md={12}>
                        <Form.Item
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 14 }}
                            labelCol={{ span: 10 }}
                            label="Location"
                        >
                            {getFieldDecorator('locationCode')(
                                <Select onChange={handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>
                    <Col md={12}>
                        <Form.Item
                            label="Area"
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 14 }}
                            labelCol={{ span: 10 }}
                        >
                            {getFieldDecorator('areaCode')(
                                <Select>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>

                    <Col md={24}>
                        <Form.Item label="Date period" style={{ width: '100%' }}>
                            {getFieldDecorator('datePeriod', {
                                initialValue: [moment().startOf('day'), moment().startOf('day')],
                            })(
                                <DatePicker.RangePicker
                                    ranges={{
                                        Today: [moment(), moment()],
                                        'This week': [moment().startOf('week'), moment().endOf('week')],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'This year': [moment().startOf('year'), moment().endOf('year')],
                                    }}
                                />,
                            )}
                        </Form.Item>
                    </Col>
                </Row>
            </Form>
        </>;
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    return (
        <Spin spinning={loading}>
            <Card title={renderHeader()}>{!loading && <PieChart {...config.current} data={datas} />}</Card>
        </Spin>
    );
};

const LogsheetTasksPie = Form.create<Props>()(
    LogsheetTasksPieComponent,
);

export default LogsheetTasksPie;
