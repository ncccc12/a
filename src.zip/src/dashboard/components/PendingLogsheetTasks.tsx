import React from 'react';
import { Row, Card, List, Col, Select, Button, Spin, Typography } from 'antd';
import { Form } from '@ant-design/compatible';
import moment from 'moment';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, LogsheestTaskVm } from '../../services/Client';
const ButtonGroup = Button.Group;
import { FormComponentProps } from '@ant-design/compatible/lib/form';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;
type State = {
    pendingTasks: LogsheestTaskVm[];

    filteredAreas: AreaVm[];
    loading: boolean;
};

const PendingLogsheetTasksComponent: React.FC<Props> = ({ form, areas, locations }) => {

    const [pendingTasks, setPendingTasks] = React.useState<LogsheestTaskVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [loading, setLoading] = React.useState<boolean>(false);

    const search = React.useCallback(async () => {
        form.validateFields(async (err: any, values: any) => {
            setLoading(true);

            let pendingTasks = await logsheetTimeHistoriesClient.getPendingLogsheetTasks(
                values.locationCode,
                values.areaCode,
            );

            setPendingTasks(pendingTasks);
            setLoading(false);
        });
    }, [form]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    }, [filterAreas, form]);

    const resetFilter = React.useCallback(() => {
        form.resetFields();
        search();
    }, [form, search]);

    const renderHeader = () => {
        const { getFieldDecorator } = form;

        return <>
            <Typography.Title level={4}>Pending tasks</Typography.Title>
            <Form layout="inline">
                <Form.Item label="Location">
                    {getFieldDecorator('locationCode')(
                        <Select style={{ width: 250 }} onChange={handleLocationChange}>
                            {locations.map((r) => {
                                return (
                                    <Select.Option key={r.code} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Area">
                    {getFieldDecorator('areaCode')(
                        <Select style={{ width: 250 }}>
                            {filteredAreas.map((r) => {
                                return (
                                    <Select.Option key={r.code} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item>
                    <ButtonGroup>
                        <Button type="primary" onClick={search}>
                            Search
                        </Button>
                        <Button onClick={resetFilter}>Reset</Button>
                    </ButtonGroup>
                </Form.Item>
            </Form>
        </>;
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    return (
        <Spin spinning={loading}>
            <Card title={renderHeader()} style={{ height: '100%', minHeight: 730 }}>
                <List
                    dataSource={pendingTasks}
                    pagination={{ pageSize: 8 }}
                    renderItem={(r) => (
                        <List.Item>
                            <List.Item.Meta
                                title={
                                    <Row>
                                        <Col md={20}>{r.logsheetName}</Col>
                                        <Col>{moment(r.dateTime).format('DD-MM-YYYY HH:mm')}</Col>
                                    </Row>
                                }
                                description={
                                    <Row>
                                        <Col>
                                            Location: {r.location}/{r.area}
                                        </Col>
                                        {/* <Col>Responsible: {r.crewName}</Col> */}
                                    </Row>
                                }
                            />
                        </List.Item>
                    )}
                />
            </Card>
        </Spin>
    );
};

const PendingLogsheetTasks = Form.create<Props>()(
    PendingLogsheetTasksComponent,
);

export default PendingLogsheetTasks;
