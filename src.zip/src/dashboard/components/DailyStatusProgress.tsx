import React from 'react';
import { Spin, Card, Row, Col, Select, Button, Typography } from 'antd';
import { Form } from '@ant-design/compatible';
import { GaugeChart } from '@opd/g2plot-react';
import { AreaVm, DictionaryDto, GetTimeHistoriesStatusesCountQuery } from '../../services/Client';
import moment from 'moment';
import { logsheetTimeHistoriesClient } from '../../services';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
const ButtonGroup = Button.Group;

// const config = {
//     rangeMax: 100,
//     forceFit: true,
//     title: {
//         visible: true,
//         text: 'Daily progress of completed log sheets',
//     },
//     legend: {
//         visible: true,
//         custom: true,
//         items: [
//             {
//                 value: 'Completed',
//                 marker: {
//                     symbol: 'square',
//                     fill: '#5B8FF9',
//                 },
//             },
//             {
//                 value: 'Remaining',
//                 marker: {
//                     symbol: 'square',
//                     fill: '#FFDBA2',
//                 },
//             },
//         ],
//     },
// };

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    filledPercent: number;
    filteredAreas: AreaVm[];
};

const DailyStatusProgressComponent: React.FC<Props> = ({ form, areas, locations }) => {

    const [loading, setLoading] = React.useState<boolean>(false);
    const [filledPercent, setFilledPercent] = React.useState<number>(0);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const search = React.useCallback(async () => {
        setLoading(true);

        form.validateFields(async (errors: any, values: any) => {
            let query = new GetTimeHistoriesStatusesCountQuery();
            let today = moment().startOf('day').utc(true).toDate();
            query.datePeriod = [today, today];
            query.locationCode = values.locationCode;
            query.areaCode = values.areaCode;

            let result = await logsheetTimeHistoriesClient.getTimeHistoriesStatusesCount(query);
            let total = 0;
            let filled = 0;
            result.forEach((r) => {
                total += r.count!;

                if (r.statusCode === 'COMPLETED' || r.statusCode === 'VALUES_UPLOADED') {
                    filled += r.count!;
                }
            });

            let filledPercent = (filled * 100) / total;

            setLoading(false);
            setFilledPercent(filledPercent);
        });
    }, [form]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    }, [filterAreas, form]);

    const resetFilter = React.useCallback(() => {
        form.resetFields();
        search();
    }, [form, search]);

    const renderHeader = () => {
        const { getFieldDecorator } = form;

        return <>
            <Form layout="inline" labelAlign="left">
                <Row justify="space-between">
                    <Typography.Title level={4}>Daily progress</Typography.Title>
                    <Form.Item style={{ margin: 0 }}>
                        <ButtonGroup>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Row>
                <Row gutter={24}>
                    <Col md={12}>
                        <Form.Item
                            label="Location"
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 14 }}
                            labelCol={{ span: 10 }}
                        >
                            {getFieldDecorator('locationCode')(
                                <Select onChange={handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>
                    <Col md={12}>
                        <Form.Item
                            label="Area"
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 18 }}
                            labelCol={{ span: 6 }}
                        >
                            {getFieldDecorator('areaCode')(
                                <Select>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>
                </Row>
            </Form>
        </>;
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    return (
        <Spin spinning={loading}>
            <Card title={renderHeader()} style={{ minHeight: 363 }}>
                {/* <BulletChart
                    autoFit={true}
                    measureField=""
                    rangeField=""
                    targetField=""
                    legend={{
                        visible: true,
                    }}
                    height={150}
                    data={[
                        {
                            title: 'Completed',
                            ranges: [100],
                            measures: [50],
                            targets: [100],
                        },
                    ]}
                /> */}
                <GaugeChart
                    autoFit={true}
                    height={350}
                    percent={filledPercent / 100}
                    range={{
                        ticks: [0, 1],
                        color: ['#30BF78', '#E8EDF3'],
                    }}
                    indicator={{
                        pointer: { style: { stroke: '#D0D0D0' } },
                        pin: { style: { stroke: '#D0D0D0' } },
                    }}
                    axis={{
                        label: {
                            formatter: (v: string) => Number(v) * 100 + '%',
                        },
                    }}
                />
            </Card>
        </Spin>
    );
};

const DailyStatusProgress = Form.create<Props>()(
    DailyStatusProgressComponent,
);

export default DailyStatusProgress;
