import React from 'react';
import { Card, List, Col, Spin, Row, Select, Button, Typography } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import moment from 'moment';
import { LineChart } from '@opd/g2plot-react';
import { reportsClient } from '../../services';
import { DeviceTag, DictionaryDto, AreaVm, GetExceedanceComplianceCountQuery } from '../../services/Client';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
const ButtonGroup = Button.Group;

const dateFormat = 'DD-MM-YYYY';

const config = {
    title: {
        visible: true,
        text: '',
    },
    description: {
        visible: true,
        text: '',
    },
    legend: {
        flipPage: false,
    },
    forceFit: true,
    height: 376,
    xField: 'x',
    yField: 'y',
    seriesField: 'series',
    color: ['#5B8FF9', '#5AD8A6'],
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    topTags: DeviceTag[];
    filteredAreas: AreaVm[];
};

const ExceedanceComplinceChartComponent: React.FC<Props> = ({ form, areas, locations }) => {

    const [loading, setLoading] = React.useState<boolean>(false);
    const [datas, setDatas] = React.useState<any[]>([]);
    const [topTags, setTopTags] = React.useState<DeviceTag[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const search = React.useCallback(async () => {
        setLoading(true);
        form.validateFields(async (errors: any, values: any) => {
            let query = new GetExceedanceComplianceCountQuery();
            query.datePeriod = values.datePeriod?.map((r: moment.Moment) => r.utc(true).toDate()) || [];
            query.locationCode = values.locationCode;
            query.areaCode = values.areaCode;
            let data = await reportsClient.getExceedanceComplianceCount(query);

            let datas = data.complinceExceedanceItems!.map((r) => {
                return {
                    series: r.type,
                    x: moment(r.date).format(dateFormat),
                    y: r.count,
                };
            });

            setDatas(datas);
            setTopTags(data.topTags!);
            setLoading(false);
        });
    }, [form]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    }, [filterAreas, form]);

    const resetFilter = React.useCallback(() => {
        form.resetFields();
        search();
    }, [form, search]);

    const renderHeader = () => {
        const { getFieldDecorator } = form;

        return (
            <Form layout="inline" labelAlign="left">
                <Row gutter={24}>
                    <Col md={6}>
                        <Form.Item
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 14 }}
                            labelCol={{ span: 10 }}
                            label="Location"
                        >
                            {getFieldDecorator('locationCode')(
                                <Select onChange={handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>
                    <Col md={5}>
                        <Form.Item
                            label="Area"
                            style={{ width: '100%' }}
                            wrapperCol={{ span: 14 }}
                            labelCol={{ span: 10 }}
                        >
                            {getFieldDecorator('areaCode')(
                                <Select>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                    </Col>
                    <Col md={7}>
                        <Form.Item style={{ width: '100%' }}>
                            {getFieldDecorator('datePeriod', {
                                initialValue: [moment().startOf('day'), moment().startOf('day')],
                            })(
                                <DatePicker.RangePicker
                                    ranges={{
                                        Today: [moment(), moment()],
                                        'This week': [moment().startOf('week'), moment().endOf('week')],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'This year': [moment().startOf('year'), moment().endOf('year')],
                                    }}
                                />,
                            )}
                        </Form.Item>
                    </Col>
                    <Col md={6}>
                        <Form.Item>
                            <ButtonGroup>
                                <Button type="primary" onClick={search}>
                                    Search
                                </Button>
                                <Button onClick={resetFilter}>Reset</Button>
                            </ButtonGroup>
                        </Form.Item>
                    </Col>
                </Row>
            </Form>
        );
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    return (
        <Spin spinning={loading}>
            <Card
                title={<Typography.Title level={3}>Exceedance/Compliance tasks status</Typography.Title>}
                extra={renderHeader()}
            >
                <Col span={18}>{!loading && <LineChart {...config} data={datas} />}</Col>
                <Col span={6}>
                    <List
                        header={<b> Top 10 sensors with exceedance: </b>}
                        dataSource={topTags}
                        renderItem={(item) => (
                            <List.Item>{`${item.deviceName}/${item.tagName}(${item.exceedanceCount})`}</List.Item>
                        )}
                    ></List>
                </Col>
            </Card>
        </Spin>
    );
};

const ExceedanceComplinceChart = Form.create<Props>()(
    ExceedanceComplinceChartComponent,
);

export default ExceedanceComplinceChart;
