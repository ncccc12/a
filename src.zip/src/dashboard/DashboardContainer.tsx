import React from 'react';
import { Row, Col } from 'antd';
import PendingLogsheetTasks from './components/PendingLogsheetTasks';
import ExceedanceComplineceChart from './components/ExceedanceComplineceChart';
import LogsheetTasksPie from './components/LogsheetTasksPie';
import DailyStatusProgress from './components/DailyStatusProgress';
import { AreaVm, DictionaryDto } from '../services/Client';
import { dictionaryClient } from '../services';

type Props = {};
type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const DashboardContainer: React.FC<Props> = () => {
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadDictionaries();
        }
    });

    return <>
        <Row gutter={24}>
            <Col md={16}>
                <PendingLogsheetTasks locations={locations} areas={areas} />
            </Col>
            <Col md={8}>
                <LogsheetTasksPie locations={locations} areas={areas} />

                <DailyStatusProgress locations={locations} areas={areas} />
            </Col>
        </Row>
        <Row gutter={24}>
            <Col md={24}>
                <ExceedanceComplineceChart locations={locations} areas={areas} />
            </Col>
        </Row>
    </>;
};

export default DashboardContainer;
