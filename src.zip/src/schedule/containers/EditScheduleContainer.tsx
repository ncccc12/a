import React from 'react';
import { ScheduleConfig } from '../types';
import moment from 'moment';
import { Spin, Row, Col, Button, message } from 'antd';
import ScheduleForm, { ScheduleFormModel } from '../components/ScheduleForm';
import CalendarTable from '../components/CalendarTable';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import { schedulesClient } from '../../services';
import generateScheduleSrv from '../GenerateScheduleService';
import { ScheduleVm, UpdateScheduleCommand, TimeOptionDto } from '../../services/Client';
import { cloneDeep } from 'lodash';
import { RouteComponentProps, withRouter } from 'react-router-dom';

type Props = {
    id: number;
} & RouteComponentProps<any>;
type State = {
    loading: boolean;
    scheduleConfig?: ScheduleConfig;
    formChanged: boolean;
};

const EditScheduleContainer: React.FC<Props> = props => {
    const {
        id
    } = props;

    const [loading, setLoading] = React.useState<boolean>(true);
    const [formChanged, setFormChanged] = React.useState<boolean>(false);
    const [scheduleConfig, setScheduleConfig] = React.useState<ScheduleConfig>();
    const formRef = React.useRef<any>(undefined);
    const srcFormModel = React.useRef<ScheduleFormModel | undefined>(undefined);

    const loadData = async () => {
        const form = formRef.current.props.form as WrappedFormUtils<any>;
        let schedule = await schedulesClient.getSchedule(id);

        let formModel = mapVmToScheduleForm(schedule);
        srcFormModel.current = cloneDeep(formModel);
        form.setFieldsValue(formModel);

        let config = await schedulesClient.getScheduleConfig(schedule.scheduleConfigId);
        let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

        setScheduleConfig(scheduleConfig);
    };

    const mapVmToScheduleForm = (vm: ScheduleVm): ScheduleFormModel => {
        let scheduleForm: ScheduleFormModel = {
            id: vm.id!,
            areaCode: vm.areaCode!,
            locationCode: vm.locationCode!,
            logsheetId: vm.logsheetId!,
            year: vm.year!,
            scheduleConfigId: vm.scheduleConfigId!,
            scheduleName: vm.name!,
            scheduleTypeCode: vm.scheduleTypeCode! as any,
            datePeriod: [moment(vm.startDate), moment(vm.endDate)],
            timeOptions: vm.timeOptions!.map((r) => {
                return {
                    id: r.id!,
                    time: moment(r.time, 'HH:mm'),
                };
            }),
            weekDayCodes: vm.weekDayCodes,
            selectedPeriods: vm.selectedPeriods?.map(r => {
                let period = r.map(r => moment(r));
                return period;
            }),
            date : moment(vm.date)
        };

        return scheduleForm;
    };

    const handleLoadingChange = React.useCallback(() => {
        setLoading(false);
    }, []);

    const viewSchedule = React.useCallback(() => {
        const form = formRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {
            if (err) return;

            let config = await schedulesClient.getScheduleConfig(values.scheduleConfigId);
            let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

            setScheduleConfig(scheduleConfig);
            setFormChanged(false);
        });
    }, []);

    const handleFormChange = React.useCallback(() => {
        if (!formChanged) {
            setFormChanged(true);
        }
    }, [formChanged]);

    const resetDefaults = React.useCallback(() => {
        const form = formRef.current.props.form as WrappedFormUtils<any>;
        form.setFieldsValue(srcFormModel.current!);
    }, []);

    const updateSchedule = React.useCallback(() => {
        const form = formRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {

            if (err) return;

            try {
                setLoading(true);
                let command = new UpdateScheduleCommand();
                command.id = values.id;
                command.date = values.date && values.date.utc(true).set({hour: 0, minute: 0, second: 0, millisecond: 0}).toDate() as any;
                command.name = values.scheduleName;
                command.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                command.scheduleConfigId = values.scheduleConfigId;
                command.scheduleTypeCode = values.scheduleTypeCode;
                command.timeOptions = values.timeOptions!.map((r) => {
                    let dto = new TimeOptionDto();
                    dto.id = r.id;
                    dto.time = r.time.format('HH:mm');

                    return dto;
                });
                command.weekDayCodes = values.weekDayCodes;

                await schedulesClient.updateSchedule(command);
                message.success('Operation successfully completed');
                props.history.push('/scheduleManager/schedules');
            } finally {
                setLoading(false);
            }
        });
    }, [props.history]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadData();
        }
    });

    const datePeriod = formRef.current && formRef.current.props.form.getFieldValue('datePeriod');

    return (
        <Spin spinning={loading}>
            <ScheduleForm
                isEdit={true}
                srcFormModel={srcFormModel.current}
                onFormChange={handleFormChange}
                wrappedComponentRef={(ref: any) => (formRef.current = ref)}
                onLoadingChange={handleLoadingChange}
            />
            <br />
            <Row>
                <Col span={12} style={{ textAlign: 'left' }}>
                    <Button type="primary" onClick={viewSchedule}>
                        View Schedule
                    </Button>
                    <Button style={{ marginLeft: 8 }} onClick={resetDefaults}>
                        Reset
                    </Button>
                </Col>

                {scheduleConfig && formChanged === false && (
                    <Col span={12} style={{ textAlign: 'right' }}>
                        <Button
                            type="link"
                            style={{ backgroundColor: '#52c41a', color: '#fff' }}
                            onClick={updateSchedule}
                        >
                            Update schedule
                        </Button>
                    </Col>
                )}
            </Row>
            <br />
            {scheduleConfig && (
                <CalendarTable scheduleConfig={scheduleConfig} datePeriod={datePeriod} readonly={true} />
            )}
        </Spin>
    );
};

export default withRouter(EditScheduleContainer);
