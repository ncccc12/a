import React from 'react';
import { Table, Button, message, Spin } from 'antd';
import {
    LogSheetsClient,
    LogsheetListItemVm,
    TimeOptionDto,
    UpdateLogsheetScheduleCommand,
    GetLogsheetsQuery,
} from '../../services/Client';
import LogsheetModal from '../LogsheetModal';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import { LogsheetScheduleForm } from '../types';
import moment from 'moment';
import axios from '../../common/axiosConfig';

const { Column, ColumnGroup } = Table;

type Props = {};
type State = {
    loading: boolean;
    logsheets: LogsheetListItemVm[];
    selectedLogsheet?: LogsheetListItemVm;
    logsheetModalShown: boolean;
};

const ScheduleManagerContainer: React.FC<Props> = () => {
    const [loading, setLoading] = React.useState<boolean>(false);
    const [logsheetModalShown, setLogsheetModalShown] = React.useState<boolean>(false);
    const [logsheets, setLogsheets] = React.useState<LogsheetListItemVm[]>([]);
    const [selectedLogsheet, setSelectedLogsheet] = React.useState<LogsheetListItemVm>();
    const client = React.useRef(new LogSheetsClient(undefined, axios));
    const logsheetModalRef = React.useRef<any>(undefined);
    const timeFormat = React.useRef('HH:mm');

    const loadData = React.useCallback(async () => {
        setLoading(true);
        const data = await client.current.getLogsheets(new GetLogsheetsQuery());
        setLogsheets(data);
        setLoading(false);
    }, []);

    const openLogsheetModal = React.useCallback((logsheet: LogsheetListItemVm) => {
        setLogsheetModalShown(true);
        setSelectedLogsheet(logsheet);
    }, []);

    const renderActions = React.useCallback((logsheet: LogsheetListItemVm) => {
        return <>
            <Button
                title="Edit"
                icon="edit"
                shape="circle"
                disabled={!logsheet.schedule}
                onClick={() => openLogsheetModal(logsheet)}
            ></Button>
        </>;
    }, [openLogsheetModal]);

    const renderScheduleTitle = React.useCallback(() => {
        return (
            <>
                <b>Updated schedule</b> <br />
                <span>(will be applied on next day)</span>
            </>
        );
    }, []);

    const closeLogsheetModal = React.useCallback(() => {
        setLogsheetModalShown(false);
    }, []);

    const submit = React.useCallback(() => {
        const modalForm = logsheetModalRef.current.props.form as WrappedFormUtils<any>;

        modalForm.validateFields(async (err: any, values: LogsheetScheduleForm) => {
            if (err) return;


            try {
                const { keys, id } = values;
                let command = new UpdateLogsheetScheduleCommand();
                command.timeOptions = [];
                command.id = id;

                keys.forEach(k => {
                    let vOpt = values.timeOptions[k];
                    vOpt.time = vOpt.time.format('HH:mm');
                    let option = new TimeOptionDto();
                    option.init(vOpt);
                    command.timeOptions!.push(option);
                });

                await client.current.updateLogsheetSchedule(command);
                await loadData();

                setLogsheetModalShown(false);
                message.success(`${selectedLogsheet!.name} successfully updated`);
            } finally {
                setLoading(false);
            }
        });
    }, [loadData, selectedLogsheet]);

    const renderTimes = React.useCallback((times: TimeOptionDto[]) => {
        return times && times.map(r => moment(r.time, timeFormat.current).format(timeFormat.current)).join(', ');
    }, []);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            void loadData();
        }
    }, []);

    return (
        <Spin spinning={loading}>
            <Table rowKey={r => r.id + ''} dataSource={logsheets} bordered>
                <Column title="Location" dataIndex="location"></Column>
                <Column title="Area" dataIndex="area"></Column>
                <Column title="Logsheet" dataIndex="name"></Column>
                <ColumnGroup title="Current schedule">
                    <Column title="Type" align="center" dataIndex="schedule.type"></Column>
                    <Column
                        title="Times"
                        align="center"
                        dataIndex="schedule.timeOptions"
                        render={renderTimes}
                    ></Column>
                </ColumnGroup>
                <ColumnGroup title={renderScheduleTitle}>
                    <Column title="Type" align="center" dataIndex="updatedSchedule.type"></Column>
                    <Column
                        title="Times"
                        align="center"
                        dataIndex="updatedSchedule.timeOptions"
                        render={renderTimes}
                    ></Column>
                </ColumnGroup>
                <Column title="Actions" align="center" render={renderActions}></Column>
            </Table>

            <LogsheetModal
                key={logsheetModalShown ? 1 : 0}
                visible={logsheetModalShown}
                wrappedComponentRef={(compRef: any) => (logsheetModalRef.current = compRef)}
                logsheet={selectedLogsheet}
                loading={loading}
                onOk={submit}
                onCancel={closeLogsheetModal}
            ></LogsheetModal>
        </Spin>
    );
};

export default ScheduleManagerContainer;
