import { Modal, Select } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import moment from 'moment';
import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import {Item, RotationCalendarTypes} from '../constants';
//import { Item, RotationCalendarTypes } from '../constant';

const Option = Select.Option;
const FormItem = Form.Item;

type Props = {
    visible: boolean;
    startDate: moment.Moment;
    endDate: moment.Moment;
    onOk: (e: any) => void;
    onCancel: (e: any) => void;
} & FormComponentProps;

const EditSelectedDatesModalComponent: React.FC<Props> = props => {
    const {
        onOk,
        visible,
        onCancel,
        startDate,
        endDate
    } = props;

    const rowConf = React.useRef<any>({
        style: {
            width: 300,
        },
    });

    const { getFieldDecorator: getFieldDecorator } = props.form;

    return (
        <Modal
            title="Edit selected dates"
            open={visible}
            centered={true}
            width={400}
            onOk={onOk}
            onCancel={onCancel}
        >
            <Form layout="inline" labelCol={{ span: 8 }} labelAlign="left">
                <FormItem label="Start date" {...rowConf.current}>
                    <DatePicker disabled={true} value={startDate} />
                </FormItem>
                <FormItem label="End date" {...rowConf.current}>
                    <DatePicker disabled={true} value={endDate} />
                </FormItem>

                <FormItem label="Shift type" {...rowConf.current}>
                    {getFieldDecorator('shiftType', { initialValue: RotationCalendarTypes[0].value })(
                        <Select style={{ width: 195 }}>
                            {RotationCalendarTypes.map((type: Item) => {
                                return (
                                    <Option key={type.value} value={type.value}>
                                        {type.text}
                                    </Option>
                                );
                            })}
                        </Select>,
                    )}
                </FormItem>
                {/* <FormItem labelCol={{ span: 12 }} label="Calculate remaining" {...this.rowConf}>
                    {getFieldDecorator('calculateRemaining', {
                        valuePropName: 'checked',
                    })(<Checkbox />)}
                </FormItem> */}
            </Form>
        </Modal>
    );
};

EditSelectedDatesModalComponent.displayName = 'EditSelectedDatesModal';

export const EditSelectedDatesModal = Form.create<Props>()(
    withLegacyFormRef(EditSelectedDatesModalComponent),
);
