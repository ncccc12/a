import React from 'react';
import { withLegacyFormRef } from '../common/components/antd';
import { Modal, Button } from 'antd';
import { Form, Icon } from '@ant-design/compatible';
import { TimePicker } from '../common/components/antd';
import { FormComponentProps, FormProps } from '@ant-design/compatible/lib/form';
import { LogsheetListItemVm } from '../services/Client';
import moment from 'moment';
import './ConfigureScheduleModal.css';

type Props = {
    visible: boolean;
    logsheet?: LogsheetListItemVm;
    loading: boolean;
    onOk: () => void;
    onCancel: () => void;
} & FormComponentProps;

type State = {
    keys: number[];
};

const LogsheetModalComponent: React.FC<Props> = props => {
    const {
        logsheet,
        form
    } = props;

    const [keys0, setKeys] = React.useState<number[]>([]);
    const id = React.useRef(0);
    const timeFormat = React.useRef('HH:mm');

    const initTimeOptions = () => {
        const keys: number[] = [];

        id.current = logsheet!.schedule!.timeOptions!.length;
        let timeOptions: any[] = [];

        for (let i = 0; i < id.current; i++) {
            let opt = logsheet!.schedule!.timeOptions![i];
            keys.push(i);
            timeOptions.push({
                id: opt.id,
                time: moment(opt.time, timeFormat.current),
            });
        }

        setKeys(keys);
        form.setFieldsValue({
            timeOptions,
        });
    };

    const addTime = React.useCallback(() => {
        const keys: number[] = form.getFieldValue('keys');
        const nextKeys = keys.concat(id.current++);

        form.setFieldsValue({
            keys: nextKeys,
        });
    }, [form]);

    const removeTime = (k: number) => {
        const keys: number[] = form.getFieldValue('keys');

        if (keys.length === 1) return;

        form.setFieldsValue({
            keys: keys.filter(r => r !== k),
        });
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            if (!logsheet) return;

            initTimeOptions();
        }
    });

    const {
        visible: visible,
        logsheet: logsheet0,
        form: { getFieldDecorator: getFieldDecorator, getFieldValue: getFieldValue },
    } = props;

    getFieldDecorator('keys', { initialValue: keys0 });
    const keys: number[] = getFieldValue('keys');

    const formItemLayoutWithOutLabel: FormProps = {
        wrapperCol: {
            span: 16,
            offset: 8,
        },
    };

    const formItemLayout: FormProps = {
        labelCol: {
            span: 8,
        },
        wrapperCol: {
            span: 16,
        },
    };

    getFieldDecorator('id', { initialValue: logsheet0 && logsheet0.id });

    return (
        <Modal
            open={visible}
            title="Edit logsheet"
            okText="Save"
            className="config-schedule-modal"
            confirmLoading={props.loading}
            onOk={props.onOk}
            onCancel={props.onCancel}
        >
            <Form layout="horizontal" {...formItemLayout} labelAlign="left">
                <Form.Item label="Logsheet name">{logsheet0 && logsheet0.name}</Form.Item>
                <Form.Item label="Schedule type">{logsheet0 && logsheet0.schedule!.type}</Form.Item>
                {keys.map((r, idx) => {
                    getFieldDecorator(`timeOptions[${r}].id`);

                    return (
                        <Form.Item
                            key={r}
                            label={idx === 0 ? 'Times' : ''}
                            {...(idx === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                        >
                            {getFieldDecorator(`timeOptions[${r}].time`, {
                                rules: [{ required: true, message: 'time is required' }],
                            })(
                                <TimePicker
                                    minuteStep={5}
                                    style={{ marginRight: 8, width: 180 }}
                                    format={timeFormat.current}
                                />,
                            )}
                            {keys.length > 1 ? (
                                <Icon
                                    className="dynamic-delete-button"
                                    type="minus-circle-o"
                                    title="Remove"
                                    onClick={() => removeTime(r)}
                                />
                            ) : null}
                        </Form.Item>
                    );
                })}

                <Form.Item {...formItemLayoutWithOutLabel}>
                    <Button type="dashed" onClick={addTime} style={{ width: 180 }}>
                        <Icon type="plus" /> Add time
                    </Button>
                </Form.Item>
            </Form>
        </Modal>
    );
};

const LogsheetModal = Form.create<Props>()(
    withLegacyFormRef(LogsheetModalComponent),
);

export default LogsheetModal;
