import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Row, Col, Select, Input, Checkbox, Card } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import { FormComponentProps, FormItemProps } from '@ant-design/compatible/lib/form';
import { dictionaryClient } from '../../services';
import { AreaVm, DictionaryDto, GroupSimpleVm } from '../../services/Client';
import moment, { Moment } from 'moment';

export interface ConfigFormModel {
    areaCode?: string;
    datePeriod?: moment.Moment[];
    group1?: string;
    group1DayShift?: boolean;
    group2?: string;
    group2DayShift?: boolean;
    group3?: string;
    group3DayShift?: boolean;
    group4?: string;
    group4DayShift?: boolean;
    locationCode?: string;
    rotationType?: string;
    scheduleConfigName?: string;
    year?: number;
    isManual?: boolean;
    switchShift?: boolean;
}

type Props = {
    groups: GroupSimpleVm[];
    isEdit?: boolean;
    onFormChange: (e: any) => void;
    onLoadingChange(loading: boolean): void;
} & FormComponentProps<any>;

type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    filteredGroups: GroupSimpleVm[];
    rotationTypes: DictionaryDto[];
};

const ScheduleConfigFormComponent: React.FC<Props> = props => {
    const {
        onLoadingChange,
        form,
        onFormChange,
        groups
    } = props;

    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredGroups, setFilteredGroups] = React.useState<GroupSimpleVm[]>([]);
    const [rotationTypes, setRotationTypes] = React.useState<DictionaryDto[]>([]);
    const years = React.useRef<number[]>([]);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        let rotationTypes = await dictionaryClient.getDictionary('RotationTypes');
        setLocations(locations);
        setAreas(areas);
        setRotationTypes(rotationTypes);

        filterDics();
        onLoadingChange(false);
    };

    const filterDics = () => {
        const locationCode = form.getFieldValue('locationCode');
        const areaCode = form.getFieldValue('areaCode');
        filterAreas(locationCode);
        filterGroups(areaCode);
    };

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((locationCode: string) => {
        filterAreas(locationCode);
        form.setFieldsValue({
            areaCode: '',
            group1: undefined,
            group2: undefined,
            group3: undefined,
            group4: undefined,
        });

        onFormChange(undefined);
    }, [filterAreas, form, onFormChange]);

    const filterGroups = React.useCallback((areaCode: string) => {
        const filteredGroups = groups.filter((r) => r.areaCode === areaCode);
        setFilteredGroups(filteredGroups);
    }, [groups]);

    const handleAreaChange = React.useCallback((areaCode: string) => {
        filterGroups(areaCode);
        form.setFieldsValue({
            group1: undefined,
            group2: undefined,
            group3: undefined,
            group4: undefined,
        });

        onFormChange(undefined);
    }, [filterGroups, form, onFormChange]);

    const handleYearChange = React.useCallback((year: number) => {
        props.form.setFieldsValue({
            datePeriod: undefined,
        });

        onFormChange(undefined);
    }, [onFormChange, props.form]);

    const disableDate = React.useCallback((date: moment.Moment | null): boolean => {
        let year = props.form.getFieldValue('year');

        return !!date && (date.year() < year || date.year() > year);
    }, [props.form]);

    const validateDatePeriod = React.useCallback((rule: any, value: moment.Moment[], callback: any) => {
        if (props.isEdit && value[1].endOf('day') <= moment().endOf('day')) {
            callback('End date cannot be smaller or equal to current date');
        }

        callback();
    }, [props.isEdit]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadDictionaries();

            let currYear = moment().year();
            years.current.push(...[currYear, currYear + 1]);
        }
    });

    const {
        form: { getFieldDecorator: getFieldDecorator },
        form: form0,
        isEdit: isEdit,
    } = props;

    const formItemProps: FormItemProps = {
        labelCol: { span: 7 },
    };

    let groups0 = form0.getFieldsValue(['group1', 'group2', 'group3', 'group4']);
    let groupVals: string[] = [];
    Object.keys(groups0).forEach((key) => {
        groupVals.push(groups0[key]);
    });

    let groupOptions = filteredGroups.map((r) => (
        <Select.Option key={r.id} value={r.code} disabled={groupVals.includes(r.code!)}>
            {r.name}
        </Select.Option>
    ));

    groupOptions.unshift(
        <Select.Option key={-1} value={undefined}>
            -
        </Select.Option>,
    );

    // let startPeriod = moment([2020, 7, 29]);
    // let endPeriod = moment().endOf('year');

    return (
        <Form onChange={props.onFormChange} labelAlign="left" className="schedule-form" layout="inline">
            <Row gutter={24}>
                <Col span={6}>
                    <Form.Item label="Location" {...formItemProps}>
                        {getFieldDecorator('locationCode', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Location is required',
                                },
                            ],
                            // initialValue: 'OPF',
                        })(
                            <Select disabled={isEdit} onChange={handleLocationChange}>
                                {locations.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                    <Form.Item label="Area" {...formItemProps}>
                        {getFieldDecorator('areaCode', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Area is required',
                                },
                            ],
                            // initialValue: 'OPF_GAS',
                        })(
                            <Select disabled={isEdit} onChange={handleAreaChange}>
                                {filteredAreas.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item label="Year" {...formItemProps}>
                        {getFieldDecorator('year', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Year is required',
                                },
                            ],
                            initialValue: moment().year(),
                        })(
                            <Select disabled={isEdit} onChange={handleYearChange}>
                                {years.current.map((r) => (
                                    <Select.Option key={r} value={r}>
                                        {r}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                    <Form.Item label="Rotation type" {...formItemProps}>
                        {getFieldDecorator('rotationType', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Rotation type is required',
                                },
                            ],
                            // initialValue: 'ROT42',
                        })(
                            <Select onChange={props.onFormChange}>
                                {rotationTypes.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item label="Config name" {...formItemProps}>
                        {getFieldDecorator('scheduleConfigName', {
                            rules: [
                                {
                                    required: true,
                                    whitespace: true,
                                    message: 'Name is required',
                                },
                            ],
                            // initialValue: 'New algo conf',
                        })(<Input />)}
                    </Form.Item>
                    <Form.Item label="Date period" {...formItemProps}>
                        {getFieldDecorator('datePeriod', {
                            rules: [
                                { type: 'array', required: true, message: 'Date period is required' },
                                {
                                    validator: validateDatePeriod,
                                },
                            ],
                            // initialValue: [startPeriod, endPeriod],
                        })(
                            <DatePicker.RangePicker
                                disabledDate={disableDate}
                                style={{ width: '100%' }}
                                onChange={props.onFormChange}
                            />,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Card>
                        <Row>
                            <Form.Item label="Group 1" {...formItemProps} style={{ width: '60%' }}>
                                {getFieldDecorator('group1', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Group is required',
                                        },
                                    ],
                                    // initialValue: 'GROUP1',
                                })(
                                    <Select disabled={isEdit} onChange={props.onFormChange}>
                                        {groupOptions}
                                    </Select>,
                                )}
                            </Form.Item>
                            {/* <Form.Item {...formItemProps}>
                                {getFieldDecorator('group1DayShift', {
                                    valuePropName: 'checked',
                                    initialValue: true,
                                })(<Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>)}
                            </Form.Item> */}
                        </Row>

                        <Row>
                            <Form.Item label="Group 2" {...formItemProps} style={{ width: '60%' }}>
                                {getFieldDecorator('group2', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Group is required',
                                        },
                                    ],
                                    // initialValue: 'PGP_group',
                                })(
                                    <Select disabled={isEdit} onChange={props.onFormChange}>
                                        {groupOptions}
                                    </Select>,
                                )}
                            </Form.Item>
                            {/* <Form.Item {...formItemProps}>
                                {getFieldDecorator('group2DayShift', { valuePropName: 'checked' })(
                                    <Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>,
                                )}
                            </Form.Item> */}
                        </Row>
                    </Card>
                </Col>

                <Col span={8}>
                    <Card>
                        <Row>
                            <Form.Item label="Group 3" {...formItemProps} style={{ width: '60%' }}>
                                {getFieldDecorator('group3', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Group is required',
                                        },
                                    ],
                                    // initialValue: 'gggpgp22',
                                })(
                                    <Select disabled={isEdit} onChange={props.onFormChange}>
                                        {groupOptions}
                                    </Select>,
                                )}
                            </Form.Item>
                            {/* <Form.Item {...formItemProps}>
                                {getFieldDecorator('group3DayShift', {
                                    valuePropName: 'checked',
                                    initialValue: true,
                                })(<Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>)}
                            </Form.Item> */}
                        </Row>
                        <Row>
                            <Form.Item label="Group 4" {...formItemProps} style={{ width: '60%' }}>
                                {getFieldDecorator('group4', {
                                    rules: [
                                        {
                                            required: true,
                                            message: 'Group is required',
                                        },
                                    ],
                                    // initialValue: 'TestGroup',
                                })(
                                    <Select disabled={isEdit} onChange={props.onFormChange}>
                                        {groupOptions}
                                    </Select>,
                                )}
                            </Form.Item>
                            {/* <Form.Item {...formItemProps}>
                                {getFieldDecorator('group4DayShift', { valuePropName: 'checked' })(
                                    <Checkbox onChange={this.handleDayShiftChange}>Day shift first</Checkbox>,
                                )}
                            </Form.Item> */}
                        </Row>
                    </Card>
                </Col>

                <Col span={8}>
                    <Form.Item {...formItemProps}>
                        {getFieldDecorator('switchShift', {
                            valuePropName: 'checked',
                            // initialValue: true,
                        })(<Checkbox>Switch Day/Night shift</Checkbox>)}
                    </Form.Item>
                    <Form.Item {...formItemProps}>
                        {getFieldDecorator('isManual', {
                            valuePropName: 'checked',
                            // initialValue: true,
                        })(<Checkbox>Is manual</Checkbox>)}
                    </Form.Item>
                </Col>
            </Row>
        </Form>
    );
};

const ScheduleConfigForm = Form.create<Props>()(
    withLegacyFormRef(ScheduleConfigFormComponent),
);

export default ScheduleConfigForm;
