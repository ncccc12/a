import React, { Fragment } from 'react';
import { Row } from 'antd';
import { ScheduleConfig, GroupConfig } from '../types';
import moment from 'moment';
import generateScheduleSrv from '../GenerateScheduleService';
import { RotationCalendarType } from '../constants';
import './CalendarTable.css';
import { EditSelectedDatesModal } from '../modals/EditSelectedDatesModal';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';

type Props = {
    scheduleConfig: ScheduleConfig;

    /** When editing schedule config disable edit past days */
    isEdit?: boolean;

    /**Disable mouse events(editing calendar) */
    readonly?: boolean;

    /** required when using in schedule container, to view only */
    datePeriod?: moment.Moment[];
};
type State = {
    startDate?: moment.Moment;
    endDate?: moment.Moment;
    isSelecting: boolean;
    modalShown: boolean;
};

const CalendarTable: React.FC<Props> = props => {
    const {
        scheduleConfig
    } = props;

    const [isSelecting, setIsSelecting] = React.useState<boolean>(false);
    const [modalShown, setModalShown] = React.useState<boolean>(false);
    const [startDate, setStartDate] = React.useState<moment.Moment>();
    const [endDate, setEndDate] = React.useState<moment.Moment>();
    const selectedClass = React.useRef('selected');
    const months = React.useRef<moment.Moment[]>([]);
    const currentRow = React.useRef<HTMLElement | null>(null);
    const editDatesModalRef = React.useRef<any>(undefined);
    const selectedGroup = React.useRef<GroupConfig>(undefined);

    const handleMouseDown = (e: React.MouseEvent, date: moment.Moment, group: GroupConfig) => {
        setIsSelecting(true);
        setStartDate(date);
        setEndDate(date);

        (e.currentTarget as HTMLElement).classList.add(selectedClass.current);
        currentRow.current = (e.currentTarget as HTMLElement).parentElement;
        selectedGroup.current = group;
    };

    const handleMouseEnter = (e: React.MouseEvent, date: moment.Moment) => {
        if (isSelecting) {
            const row: HTMLElement = (e.currentTarget as HTMLElement).parentElement!;
            const target = e.currentTarget as HTMLElement;

            // if cell isn't visited yet
            if (currentRow.current === row && !target.classList.contains(selectedClass.current)) {
                target.classList.add(selectedClass.current);
                setEndDate(date);
            } else {
                // cell is visited or another row
                showModal();
                clearSelected(target.parentElement!.parentElement!);
            }
        }
    };

    const handleMouseUp = (e: React.MouseEvent, date: moment.Moment) => {
        if (isSelecting) {
            setIsSelecting(false);
            setEndDate(date);

            showModal();
            const tbody: HTMLElement = (e.currentTarget as HTMLElement).parentElement!.parentElement!;
            clearSelected(tbody);
        }
    };

    function showModal(): void {
        if (startDate! > endDate!) {
            setStartDate(endDate);
            setEndDate(startDate);
        }
        setIsSelecting(false);
        setModalShown(true);
    }

    function clearSelected(tbody: HTMLElement): void {
        const elements: HTMLCollectionOf<Element> = tbody.getElementsByClassName(selectedClass.current);

        for (const element of Array.from(elements)) {
            element.classList.remove(selectedClass.current);
        }
    }

    const handleModalOk = React.useCallback(() => {
        const form = editDatesModalRef.current.props.form as WrappedFormUtils<any>;
        form.validateFields((err: any, values: { shiftType: RotationCalendarType }) => {
            if (err) return;

            const { shiftType } = values;
            const startIdx = startDate!.dayOfYear() - 1;
            const endIdx = endDate!.dayOfYear() - 1;

            for (let i = startIdx; i <= endIdx; i++) {
                selectedGroup.current!.schedule![i] = shiftType!;
            }

            setModalShown(false);
        });
    }, [endDate, startDate]);

    function getGroupItemRow(group: GroupConfig, month: moment.Moment, color: string): JSX.Element[] {
        let today = moment();

        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            const monthDate: moment.Moment = moment([month.year(), month.month(), day]);
            const monthDayOfYear: number = monthDate.dayOfYear();

            let datePeriod: moment.Moment[] | undefined = scheduleConfig!.datePeriod;
            if (props.datePeriod) {
                datePeriod = props.datePeriod;
            }

            const isEditable: boolean | undefined =
                group.schedule![monthDayOfYear - 1] !== RotationCalendarType.None &&
                group &&
                datePeriod &&
                datePeriod![0] &&
                datePeriod![1] &&
                monthDate.isBetween(datePeriod![0], datePeriod![1], 'day', "[]");

            let isInactive: boolean = !!props.isEdit && today.startOf('day') > monthDate.startOf('day');

            let dayType: string = '';
            switch (group.schedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let className = isInactive ? 'editable inactive ' : 'editable ';
            className = dayType ? className + color : className;

            if (!isEditable) className = 'disabled';

            let mouseListeners: any = {
                onMouseDown: (e: any) => handleMouseDown(e, monthDate, group),
                onMouseEnter: (e: any) => handleMouseEnter(e, monthDate),
                onMouseUp: (e: any) => handleMouseUp(e, monthDate),
            };

            if (isEditable === false || isInactive || props.readonly) {
                mouseListeners = {};
            }

            return (
                <td key={monthDayOfYear + ' ' + group.code} className={className} {...mouseListeners}>
                    {dayType}
                </td>
            );
        });
    }

    function getGroupRows(month: moment.Moment): JSX.Element {
        return (
            <Fragment key={month.month() + '_'}>
                <tr>
                    <td rowSpan={2}>Group 1/2</td>
                    <td>{scheduleConfig!.group1!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group1!, month, 'gold')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group2!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group2!, month, 'blue')}
                </tr>
                <tr>
                    <td rowSpan={2}>Group 3/4</td>
                    <td>{scheduleConfig!.group3!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group3!, month, 'red')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group4!.name}</td>
                    {getGroupItemRow(scheduleConfig!.group4!, month, 'green')}
                </tr>
            </Fragment>
        );
    }

    function getMonthHeaderTHs(date: moment.Moment): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(date).map((day: number) => <th key={day}>{day}</th>);
    }

    function getMonthRows(): JSX.Element[] {
        months.current = [];

        for (let i = 0; i < 12; i++) {
            const currMonth = moment([scheduleConfig.year!, i, 1]);
            months.current.push(currMonth);
        }

        const rows: JSX.Element[] = [];

        months.current.forEach((month: moment.Moment) => {
            const monthRow: JSX.Element = (
                <tr key={month.month()} style={{ height: 40 }}>
                    <th rowSpan={2 * 2 + 1}>{month.month() + 1}</th>
                    <th colSpan={2}>{moment.months(month.month())}</th>
                    {getMonthHeaderTHs(month)}
                </tr>
            );

            const groupRows: JSX.Element = getGroupRows(month);

            rows.push(monthRow);
            rows.push(groupRows);
        });

        return rows;
    }

    return (
        <Row className="schedule-config">
            <table>
                <tbody>{scheduleConfig && getMonthRows()}</tbody>
            </table>

            <EditSelectedDatesModal
                wrappedComponentRef={(ref: any) => {
                    editDatesModalRef.current = ref;
                }}
                visible={modalShown}
                startDate={startDate!}
                endDate={endDate!}
                onOk={handleModalOk}
                onCancel={() => setModalShown(false)}
            />
        </Row>
    );
};

export default CalendarTable;
