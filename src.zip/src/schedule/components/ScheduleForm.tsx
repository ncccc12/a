import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Select, Input, Row, Col, Button, Tag } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import { FormComponentProps, FormItemProps } from '@ant-design/compatible/lib/form';
import { DictionaryDto, LogsheetDictionaryVm, AreaVm, ScheduleConfigDicVm } from '../../services/Client';
import { dictionaryClient } from '../../services';
import moment from 'moment';
import ConfigureScheduleModal, { ConfigureTimeFormModel } from '../modals/ConfigureScheduleModal';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import { clone } from 'lodash';

type ScheudleType = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY';

export interface ScheduleFormModel {
    id: number;
    locationCode: string;
    areaCode: string;
    logsheetId: number;
    scheduleName: string;
    year: number;
    datePeriod: moment.Moment[];
    scheduleTypeCode: ScheudleType;
    scheduleConfigId: number;
    timeOptions: Array<{ id: number; time: moment.Moment }>;
    weekDayCodes?: string[];
    date?: moment.Moment;

    selectedPeriods?: Array<moment.Moment[]>;
}

type Props = {
    isEdit?: boolean;
    srcFormModel?: ScheduleFormModel;
    onFormChange: (e: any) => void;
    onLoadingChange: (loading: boolean) => void;
} & FormComponentProps<any>;

type State = {
    locations: DictionaryDto[];
    logsheets: LogsheetDictionaryVm[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    filteredLogsheets: LogsheetDictionaryVm[];
    scheduleTypes: DictionaryDto[];
    scheduleConfigs: ScheduleConfigDicVm[];
    filteredScheduleConfigs: ScheduleConfigDicVm[];
    scheduleTimeModalShown: boolean;

    datePeriodDisabled?: boolean;
    scheduleConfigDisabled?: boolean;
    scheduleTypeDisabled?: boolean;

    scheduleStatus: 'Not started' | 'In progress' | 'Finished';
};

const ScheduleFormComponent: React.FC<Props> = props => {
    const {
        srcFormModel,
        onLoadingChange,
        form,
        onFormChange
    } = props;

    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [logsheets, setLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredLogsheets, setFilteredLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [scheduleTypes, setScheduleTypes] = React.useState<DictionaryDto[]>([]);
    const [scheduleConfigs, setScheduleConfigs] = React.useState<ScheduleConfigDicVm[]>([]);
    const [filteredScheduleConfigs, setFilteredScheduleConfigs] = React.useState<ScheduleConfigDicVm[]>([]);
    const [scheduleTimeModalShown, setScheduleTimeModalShown] = React.useState<boolean>(false);
    const [scheduleStatus, setScheduleStatus] = React.useState<'Not started' | 'In progress' | 'Finished'>('Not started');
    const [datePeriodDisabled, setDatePeriodDisabled] = React.useState<boolean>();
    const [scheduleConfigDisabled, setScheduleConfigDisabled] = React.useState<boolean>();
    const [scheduleTypeDisabled, setScheduleTypeDisabled] = React.useState<boolean>();
    const years = React.useRef<number[]>(Array.from({ length: 6 }, (_, index) => moment().year() + index));
    const scheduleTimeModalRef = React.useRef<any>(undefined);
    const timeFormat = React.useRef('HH:mm');

    const defaultTimes = React.useRef([
        { id: undefined, time: moment('07:00', timeFormat.current) },
        { id: undefined, time: moment('14:00', timeFormat.current) },
        { id: undefined, time: moment('19:00', timeFormat.current) },
        { id: undefined, time: moment('02:00', timeFormat.current) },
    ]);

    const initialize = async () => {
        await loadDictionaries();

        if (props.isEdit) {
            filterDictionaries();
        }
    };

    const setDsiabledFields = (formModel: ScheduleFormModel) => {
        let currDate = moment();

        let datePeriodDisabled = false;
        let scheduleConfigDisabled = false;
        let scheduleTypeDisabled = false;

        // finished
        if (currDate.isAfter(formModel.datePeriod[1], 'day')) {
            datePeriodDisabled = true;
            scheduleConfigDisabled = true;
            scheduleTypeDisabled = true;
            setScheduleStatus('Finished');
        }

        // in progress
        if (currDate.isBetween(formModel.datePeriod[0], formModel.datePeriod[1], 'day', '[]')) {
            datePeriodDisabled = false;
            scheduleConfigDisabled = true;
            scheduleTypeDisabled = true;
            setScheduleStatus('In progress');
        }

        // not started yet
        if (currDate.isBefore(formModel.datePeriod[0], 'day')) {
            datePeriodDisabled = false;
            scheduleConfigDisabled = false;
            scheduleTypeDisabled = false;
            setScheduleStatus('Not started');
        }

        setDatePeriodDisabled(datePeriodDisabled);
        setScheduleConfigDisabled(scheduleConfigDisabled);
        setScheduleTypeDisabled(scheduleTypeDisabled);
    };

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();
        let logsheets = await dictionaryClient.getLogsheets();
        let scheduleTypes = await dictionaryClient.getDictionary('ScheduleTypes');
        let scheduleConfigs = await dictionaryClient.getScheduleConfigs();
        onLoadingChange(false);

        setLocations(locations);
        setAreas(areas);
        setLogsheets(logsheets);
        setScheduleTypes(scheduleTypes);
        setScheduleConfigs(scheduleConfigs);
    };

    const filterDictionaries = () => {
        let locationCode = form.getFieldValue('locationCode');
        let areaCode = form.getFieldValue('areaCode');
        let year = form.getFieldValue('year');

        filterAreas(locationCode);
        filterLogsheets(areaCode);
        filterScheduleConfigs(areaCode, year);
    };

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((locationCode: string) => {
        filterAreas(locationCode);
        form.setFieldsValue({
            areaCode: '',
            logsheetId: undefined,
            scheduleConfigId: undefined,
        });
    }, [filterAreas, form]);

    const filterLogsheets = React.useCallback((areaCode: string) => {
        const filteredLogsheets = logsheets.filter((r) => r.areaCode === areaCode);
        setFilteredLogsheets(filteredLogsheets);
    }, [logsheets]);

    const filterScheduleConfigs = React.useCallback((areaCode: string, year: number) => {
        let filteredConfigs: ScheduleConfigDicVm[] = scheduleConfigs;

        if (areaCode) filteredConfigs = filteredConfigs.filter((r) => r.areaCode === areaCode);
        if (year) filteredConfigs = filteredConfigs.filter((r) => r.year === year);

        setFilteredScheduleConfigs(filteredConfigs);
    }, [scheduleConfigs]);

    const handlerAreaChange = React.useCallback((areaCode: string) => {
        const year = form.getFieldValue('year');
        filterLogsheets(areaCode);
        filterScheduleConfigs(areaCode, year);

        form.setFieldsValue({
            logsheetId: undefined,
            scheduleConfigId: undefined,
        });
    }, [filterLogsheets, filterScheduleConfigs, form]);

    const handleYearChange = React.useCallback((year: number) => {
        const areacode = form.getFieldValue('areaCode');

        filterScheduleConfigs(areacode, year);

        form.setFieldsValue({
            scheduleConfigId: undefined,
            datePeriod: undefined,
        });

        onFormChange(undefined);
    }, [filterScheduleConfigs, form, onFormChange]);

    const disableDate = React.useCallback((current: moment.Moment | null): boolean => {
        let year = props.form.getFieldValue('year');

        return current!.year() !== year;
    }, [props.form]);

    const saveScheduleConfig = React.useCallback(() => {
        const timeForm = scheduleTimeModalRef.current.props.form as WrappedFormUtils<any>;

        let scheduleTypeCode: ScheudleType = form.getFieldValue('scheduleTypeCode');

        timeForm.validateFields((err: any, values: ConfigureTimeFormModel) => {
            if (err) return;

            // change form datePeriod
            if (scheduleTypeCode === 'MONTHLY') {
                let startDate: moment.Moment | undefined, endDate: moment.Moment | undefined;

                values.selectedPeriods?.forEach((r) => {
                    if (!startDate || r[0].isBefore(startDate, 'day')) startDate = r[0];

                    if (!endDate || r[1].isAfter(endDate, 'day')) endDate = r[1];
                });

                form.setFieldsValue({
                    datePeriod: [startDate, endDate],
                });
            }

            if (scheduleTypeCode === 'YEARLY') {
                form.setFieldsValue({
                    date: values.date,
                });
            }

            form.setFieldsValue({
                timeOptions: values.timeOptions,
                weekDayCodes: values.weekDayCodes,
                selectedPeriods: values.selectedPeriods,
            });

            setScheduleTimeModalShown(false);
            onFormChange(undefined);
        });
    }, [form, onFormChange]);

    const validateEndDate = React.useCallback((rule: any, value: moment.Moment[], callback: any) => {
        if (props.isEdit && moment().isAfter(value[1], 'day')) {
            callback('End date cannot be smaller than current date');
        }

        callback();
    }, [props.isEdit]);

    const validateStartDate = React.useCallback((rule: any, value: moment.Moment[], callback: any) => {
        if (props.isEdit) {
            let currDate = moment().endOf('day');

            // schedule in progress
            if (currDate.isBetween(srcFormModel!.datePeriod[0], srcFormModel!.datePeriod[1], 'day', '[]')) {
                if (!value[0].isSame(srcFormModel!.datePeriod[0], 'day')) {
                    callback('Schedule in progress, start date cannot be changed');
                }

                callback();
            }

            // schedule not started yet
            else if (currDate.isBefore(srcFormModel!.datePeriod[0], 'day')) {
                if (currDate.isSameOrAfter(value[0], 'day')) {
                    callback('Schedule is not started yet, start date cannot be changed to current or past date');
                }
            }

            callback();
        }

        callback();
    }, [srcFormModel, props.isEdit]);

    const openScheduleModal = React.useCallback(() => {
        setScheduleTimeModalShown(true);
    }, []);

    const initScheduleModal = React.useCallback((compRef: any) => {
        if (compRef) {
            scheduleTimeModalRef.current = compRef;
            const timeForm = scheduleTimeModalRef.current.props.form as WrappedFormUtils<any>;
            let selectedPeriods = props.form.getFieldValue('selectedPeriods');
            let date = props.form.getFieldValue('date');

            timeForm.setFieldsValue({
                selectedPeriods: clone(selectedPeriods),
                date,
            });
        }
    }, [props.form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
            void initialize();
        } else {
            if (!prevProps.srcFormModel && props.srcFormModel) {
                setDsiabledFields(props.srcFormModel!);
            }
        }

        previousPropsRef.current = props;
    });

    const {
        form: { getFieldDecorator: getFieldDecorator },
        form: form0,
        isEdit: isEdit,
    } = props;

    const formItemProps: FormItemProps = {
        labelCol: { span: 6 },
    };

    // let tomorrow = moment().add(1, 'day');
    // let endDate = moment().add(10, 'day');

    getFieldDecorator('weekDayCodes');

    const timeOptions: any[] = form0.getFieldValue('timeOptions');
    getFieldDecorator('id');

    const scheduleTypeCode: ScheudleType = form0.getFieldValue('scheduleTypeCode');
    const weekDayCodes = form0.getFieldValue('weekDayCodes');
    const year = form0.getFieldValue('year');

    getFieldDecorator('selectedPeriods');

    getFieldDecorator('date');

    return <>
        <Form
            labelAlign="left"
            className="schedule-form"
            layout="inline"
            onChange={props.onFormChange}
        >
            <Row gutter={24}>
                <Col span={8}>
                    <Form.Item label="Location" {...formItemProps}>
                        {getFieldDecorator('locationCode', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Location is required',
                                },
                            ],
                            // initialValue: 'OPF',
                        })(
                            <Select disabled={isEdit} onChange={handleLocationChange}>
                                {locations.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label="Area" {...formItemProps}>
                        {getFieldDecorator('areaCode', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Area is required',
                                },
                            ],
                            // initialValue: 'OPF_GAS',
                        })(
                            <Select disabled={isEdit} onChange={handlerAreaChange}>
                                {filteredAreas.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label="Logsheet" {...formItemProps}>
                        {getFieldDecorator('logsheetId', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Logsheet is required',
                                },
                            ],
                            // initialValue: 16,
                        })(
                            <Select disabled={isEdit}>
                                {filteredLogsheets.map((r) => (
                                    <Select.Option key={r.id} value={r.id} title={r.name}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item label="Schedule name" {...formItemProps}>
                        {getFieldDecorator('scheduleName', {
                            rules: [
                                {
                                    required: true,
                                    whitespace: true,
                                    message: 'Name is required',
                                },
                            ],
                            // initialValue: 'Schedule 1',
                        })(<Input />)}
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label="Year" {...formItemProps}>
                        {getFieldDecorator('year', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Year is required',
                                },
                            ],
                            initialValue: moment().year(),
                        })(
                            <Select disabled={isEdit} onChange={handleYearChange}>
                                {years.current.map((r) => (
                                    <Select.Option key={r} value={r}>
                                        {r}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label="Date period" {...formItemProps}>
                        {getFieldDecorator('datePeriod', {
                            rules: [
                                {
                                    type: 'array',
                                    required: true,
                                    message: 'Period is required',
                                },
                                {
                                    validator: validateEndDate,
                                },
                                {
                                    validator: validateStartDate,
                                },
                            ],
                            // initialValue: [tomorrow, endDate],
                        })(
                            <DatePicker.RangePicker
                                style={{ width: '100%' }}
                                disabled={datePeriodDisabled}
                                disabledDate={disableDate}
                                onChange={props.onFormChange}
                            />,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Form.Item label="Schedule config" {...formItemProps}>
                        {getFieldDecorator('scheduleConfigId', {
                            rules: [
                                {
                                    required: true,
                                    message: 'Schedule config is required',
                                },
                            ],
                            // initialValue: 7,
                        })(
                            <Select disabled={scheduleConfigDisabled} onChange={props.onFormChange}>
                                {filteredScheduleConfigs.map((r) => (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                </Col>

                <Col span={8}>
                    <Row justify="space-between">
                        <Form.Item label="Schedule type" style={{ width: '53%' }} labelCol={{ span: 11 }}>
                            {getFieldDecorator('scheduleTypeCode', {
                                rules: [
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Schedule type is required',
                                    },
                                ],
                                // initialValue: 'MONTHLY',
                            })(
                                <Select disabled={scheduleTypeDisabled}>
                                    {scheduleTypes.map((r) => (
                                        <Select.Option key={r.code} value={r.code} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>

                        <Form.Item>
                            {getFieldDecorator('timeOptions', {
                                initialValue: [...defaultTimes.current],
                                rules: [
                                    {
                                        type: 'array',
                                        required: true,
                                        message: 'Time configuration is required',
                                    },
                                ],
                            })(
                                <Button
                                    // disabled={scheduleTypeDisabled}
                                    style={{ width: '100%' }}
                                    onClick={openScheduleModal}
                                >
                                    Configure schedule
                                </Button>,
                            )}
                        </Form.Item>
                    </Row>
                </Col>
                <Col span={8}>
                    <Form.Item label="Schedule status" {...formItemProps}>
                        <Tag color="blue">{scheduleStatus}</Tag>
                    </Form.Item>
                </Col>
            </Row>
        </Form>

        {scheduleTimeModalShown && (
            <ConfigureScheduleModal
                visible={scheduleTimeModalShown}
                scheduleTypeCode={scheduleTypeCode}
                wrappedComponentRef={initScheduleModal}
                timeOptions={timeOptions}
                weekDayCodes={weekDayCodes}
                year={year}
                disabled={scheduleTypeDisabled}
                onOk={saveScheduleConfig}
                onCancel={() => setScheduleTimeModalShown(false)}
            />
        )}
    </>;
};

const ScheduleForm = Form.create<Props>()(
    withLegacyFormRef(ScheduleFormComponent),
);

export default ScheduleForm;
