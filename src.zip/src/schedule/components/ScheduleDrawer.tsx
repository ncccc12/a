import React from 'react';
import { Drawer, Select } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { DictionaryDto, AreaVm, LogsheetDictionaryVm } from '../../services/Client';

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logsheets: LogsheetDictionaryVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredAreas: AreaVm[];
    filteredLogsheets: LogsheetDictionaryVm[];
};

const ScheduleDrawerComponent: React.FC<Props> = props => {
    const {
        form,
        areas,
        logsheets
    } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [filteredLogsheets, setFilteredLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter(r => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((locationCode: string) => {
        filterAreas(locationCode);
        form.setFieldsValue({
            areaCode: '',
            logsheetId: undefined,
        });
    }, [filterAreas, form]);

    const filterLogsheets = React.useCallback((areaCode: string) => {
        const filteredLogsheets = logsheets.filter(r => r.areaCode === areaCode);
        setFilteredLogsheets(filteredLogsheets);
    }, [logsheets]);

    const handlerAreaChange = React.useCallback((areaCode: string) => {
        filterLogsheets(areaCode);
        form.setFieldsValue({
            logsheetId: undefined,
        });
    }, [filterLogsheets, form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            if (prevProps.visible === false && props.visible) {
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    filterAreas(locationCode);
                }, 1000);
            }
        }

        previousPropsRef.current = props;
    });

    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },

        locations: locations,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 7,
        },
        wrapperCol: {
            span: 17,
        },
    };

    return (
        <Drawer open={visible} title="Add new" width={700} destroyOnHidden onClose={props.onClose}>
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Location">
                    {getFieldDecorator('locationCode', {
                        rules: [
                            {
                                required: true,
                                message: 'Location is required',
                            },
                        ],
                    })(
                        <Select onChange={handleLocationChange}>
                            {locations.map(r => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Area">
                    {getFieldDecorator('areaCode', {
                        rules: [
                            {
                                required: true,
                                message: 'Area is required',
                            },
                        ],
                    })(
                        <Select onChange={handlerAreaChange}>
                            {filteredAreas.map(r => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Logsheet">
                    {getFieldDecorator('logsheetId', {
                        rules: [
                            {
                                required: true,
                                message: 'Logsheet is required',
                            },
                        ],
                    })(
                        <Select>
                            {filteredLogsheets.map(r => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
            </Form>
        </Drawer>
    );
};

const ScheduleDrawer = Form.create<Props>()(
    ScheduleDrawerComponent,
);

export default ScheduleDrawer;
