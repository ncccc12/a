import React from 'react';
import { Row, Col } from 'antd';
import ExceedancesTable from '../components/ExceedancesTable';
import { AreaVm, DictionaryDto } from '../../services/Client';
import { dictionaryClient } from '../../services';
import ResolvedExceedancesTable from '../components/ResolvedExceedancesTable';
import SubmitededExceedancesTable from '../components/SubmitedExceedancesTable';
import ShiftExceedancesTable from '../components/ShiftExceedancesTable';

type Props = {};
type State = {
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const ShiftSupervisorList: React.FC<Props> = () => {
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadDictionaries();
        }
    });

    return (
        <div style={{height:'100%'}}>
            <Row gutter={24}>
                <Col md={32}>
                    <ShiftExceedancesTable locations={locations} areas={areas}  />
                </Col>
            </Row>
        </div>
    );
};

export default ShiftSupervisorList;