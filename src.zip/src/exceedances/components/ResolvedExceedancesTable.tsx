import React, { useEffect, useState } from 'react';
import { Card, Spin, Button, Table, Typography, Col, Row } from 'antd';
import { Form } from '@ant-design/compatible';
import { reportsClient } from '../../services';
import { ExceedanceListStatus, ExceedancesListVm } from '../../services/Client';
import { Link } from 'react-router-dom';

type Props = {};

const ResolvedExceedancesTable: React.FC<Props> = () => {
    const [loading, setLoading] = useState(false);
    const [exceedances, setExceedances] = useState<ExceedancesListVm[]>([]);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });

    useEffect(() => {
        search();
    }, []);

    const search = async (page = 1, pageSize = 10) => {
        setLoading(true);
        let data = await reportsClient.getResolvedExceedancesQuery(
            [ExceedanceListStatus.SendToPlantSPV, ExceedanceListStatus.SendToSupervisorReview],
            page,
            pageSize,
        );
        setExceedances(data.data ?? []);
        setPagination({
            current: page,
            pageSize: pageSize,
            total: data.total ?? 0,
        });
        setLoading(false);
    };

    const renderStatus = (i: string, rowKey: ExceedancesListVm) => {
        if (rowKey.exListStatus! === 1) return <p>Under Shift-Supervisor Review</p>;
        if (rowKey.exListStatus! === 2) return <p>Under Plant SPV</p>;
        if (rowKey.exListStatus! === 3) return <p>Under CRO</p>;
        if (rowKey.exListStatus! === 4) return <p>Under Supervisor</p>;
        if (rowKey.exListStatus! === 5) return <p>Run & Maintaince</p>;
    };

    const renderAction = (i: string, rowKey: any) => {
        return (
            <>
                <Link to={`/exceedances/${rowKey.id!}`}>
                    <Button shape="circle" icon="edit" title="edit"></Button>
                </Link>
            </>
        );
    };

    const handleTableChange = (paginationConfig: any) => {
        search(paginationConfig.current, paginationConfig.pageSize);
    };

    return (
        <Card>
            <Row>
                <Col>
                    <Typography.Title>Resolved Exceedance</Typography.Title>
                </Col>
            </Row>

            <Table
                dataSource={exceedances}
                loading={loading}
                bordered
                rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                pagination={{
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    total: pagination.total,
                    showSizeChanger: true,
                    showQuickJumper: true,
                }}
                onChange={handleTableChange}
            >
                <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                <Table.Column dataIndex="excListStatus" title="Status" render={renderStatus}></Table.Column>
                <Table.Column title="Action" width={'130px'} render={renderAction}></Table.Column>
            </Table>
        </Card>
    );
};

export default ResolvedExceedancesTable;
