import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Input, Select, Tag, InputNumber, Button, Switch } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { DictionaryDto, ExceedancesVm, ListTypeValueVm } from '../../services/Client';


export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    groups: ExceedancesVm
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredLisTypeValues: ListTypeValueVm[];
    selectedDataTypeCode: string;
};

const CommentDrawerComponent: React.FC<Props> = props => {
    const {
        form
    } = props;

    const [filteredLisTypeValues, setFilteredLisTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [selectedDataTypeCode, setSelectedDataTypeCode] = React.useState<string>('');
    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            if (!prevProps.visible && props.visible) {
                let listTypeCode = form.getFieldValue('listTypeCode');
                let dataTypeCode = form.getFieldValue('dataTypeCode');

            } else if (!props.visible && selectedDataTypeCode !== '') {
                setSelectedDataTypeCode('');
            }
        }

        previousPropsRef.current = props;
    });

    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },
        form: form0,
        groups: groups,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };


    getFieldDecorator('id');
    let id = form0.getFieldValue('id');
    getFieldDecorator('groupId');
    getFieldDecorator('taskValueId');
    getFieldDecorator('groupName');
    let groupNames = form0.getFieldValue('groupName')
    getFieldDecorator('taskName');
    let taskNames = form0.getFieldValue('taskName')
    getFieldDecorator('logsheetName')
    let title = 'edit tag'

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Logsheet Name">
                    {getFieldDecorator('logsheetName')(
                        <Input.TextArea readOnly   />
                    )}
                </Form.Item>
                <Form.Item label="Group/Device  name">
                    {getFieldDecorator('groupName', {
                    })(<Input readOnly />)}
                </Form.Item>
                <Form.Item label="Task Name">
                    {getFieldDecorator('taskName')(<Input.TextArea readOnly   />)}
                </Form.Item>
                <Form.Item label="Task Value">
                    {getFieldDecorator('taskValue')(<Input.TextArea readOnly   />)}
                </Form.Item>
                <Form.Item label="Comment">
                            {getFieldDecorator('comment')(<Input.TextArea />)}
                </Form.Item>
                    
                
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const CommentDrawer = Form.create<Props>()(
    withLegacyFormRef(CommentDrawerComponent),
);

export default CommentDrawer;
