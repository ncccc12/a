import React from 'react';
import { Card, Spin, Select, Button, Table, Input, message, Modal } from 'antd';
import { Form } from '@ant-design/compatible';
import { reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
    ShiftSupervisorExcUpdate,
} from '../../services/Client';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
const ButtonGroup = Button.Group;
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    topTags: DeviceTag[];
    filteredAreas: AreaVm[];
    exceedances: ExceedancesListVm[];
    selectedExceedances: number[];
    selectedExceedancesList: ExceedancesListVm;
    user: User;
    areaCode: string[];
    commentModalVisible: boolean;
    sendVisible: boolean;
    exceedancesListStatus: number;
};

const ShiftExceedancesTableComponent: React.FC<Props> = props => {
    const {
        form,
        areas
    } = props;

    const [loading, setLoading] = React.useState<boolean>(false);
    const [datas, setDatas] = React.useState<any[]>([]);
    const [topTags, setTopTags] = React.useState<DeviceTag[]>([]);
    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);
    const [exceedances0, setExceedances] = React.useState<ExceedancesListVm[]>([]);
    const [selectedExceedances, setSelectedExceedances] = React.useState<number[]>([]);
    const [selectedExceedancesList, setSelectedExceedancesList] = React.useState<ExceedancesListVm>({} as any);
    const [user, setUser] = React.useState<User>({} as any);
    const [areaCode, setAreaCode] = React.useState<string[]>([]);
    const [commentModalVisible, setCommentModalVisible] = React.useState<boolean>(false);
    const [sendVisible, setSendVisible] = React.useState<boolean>(false);
    const [exceedancesListStatus, setExceedancesListStatus] = React.useState<number>(0);

    const getUser = async () => {
        const data: User = await authService.getUser();
        setUser(data);
        console.log(data);
        getUserArea(data.sub);
        search();
    };

    const getUserArea = async (value: any) => {
        let area: UserVm = await usersClient.getUsersArea(value);
        //let areaCode:string[] = area.areaCodes!
        setAreaCode(area.areaCodes!);
    };

    const search = async () => {
        setLoading(true);
        form.validateFields(async (errors: any, values: any) => {
            let userId = user.sub;
            let locationCode = values.locationCode;
            let areaCode = values.areaCode;
            let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
            setExceedances(data);
            setLoading(false);
        });
    };

    const onSearch = React.useCallback(async () => {
        setLoading(true);

        form.validateFields(async (errors: any, values: any) => {
            let locationCode = values.locationCode;
            let areaCode = values.areaCode;
            console.log(locationCode, areaCode);
            let userId = user.sub;
            console.log(userId);
            let data = await reportsClient.getShiftSupervisorExc(userId, locationCode, areaCode);
            setExceedances(data);
            setLoading(false);
        });
    }, [form, user]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    }, [filterAreas, form]);

    const onSelectChange = React.useCallback((selectedExceedances: any) => {
        let exceedances = exceedances0.find((x) => x.id === selectedExceedances);
        setSelectedExceedances(selectedExceedances!);
    }, [exceedances0]);

    const resetFilter = () => {
        props.form.resetFields();
        search();
    };

    const updateTag = (values: ExceedancesVm) => {
        let updateCommand = new UpdateTagDataCommand();
        updateCommand.id = values.id;
        updateCommand.value = values.taskValue;
        updateCommand.comment = values.comment;

        reportsClient.updateTagData(updateCommand);
        message.success('Successfully updated');
    };

    const sendToPOD = React.useCallback(async () => {
        let updateCommand = new ShiftSupervisorExcUpdate();
        let exceedances = exceedances0;
        let crowId = selectedExceedances!;
        console.log('RowID', crowId);
        let i = 0;
        let selected: any = [];

        crowId.map((i) => {
            let result = exceedances.find((x) => x.id == i!);
            selected.push(result!);
        });
        console.log();

        console.log('Shift Exc', selected);
        updateCommand.exceedancesListVms = selected;
        updateCommand.exListStatus = 2;
        reportsClient.updateShiftExc(updateCommand);
        message.success('Successfully updated');
        window.location.reload();
    }, [exceedances0, selectedExceedances]);

    const sendToRM = React.useCallback(async () => {
        let updateCommand = new ShiftSupervisorExcUpdate();
        let exceedances = exceedances0;
        let crowId = selectedExceedances!;
        console.log('RowID', crowId);
        let i = 0;
        let selected: any = [];

        crowId.map((i) => {
            let result = exceedances.find((x) => x.id == i!);
            selected.push(result!);
        });
        console.log();

        console.log('Shift Exc', selected);
        updateCommand.exceedancesListVms = selected;
        updateCommand.exListStatus = 5;
        reportsClient.updateShiftExc(updateCommand);
        message.success('Successfully updated');
        window.location.reload();
    }, [exceedances0, selectedExceedances]);

    const renderStatus = (i: string, rowKey: ExceedancesListVm) => {
        if (rowKey.exListStatus! === 1) {
            return <p>Under Shift-Supervisor Review</p>;
        }
        if (rowKey.exListStatus! === 2) {
            return <p>Under Plant SPV</p>;
        }
        if (rowKey.exListStatus! === 3) {
            return <p>Under CRO</p>;
        }
        if (rowKey.exListStatus! === 4) {
            return <p>Under Supervisor</p>;
        }
        if (rowKey.exListStatus! === 5) {
            return <p>Run & Maintaince</p>;
        }
        if (rowKey.exListStatus! === 6) {
            return <p>Fixed</p>;
        }
    };

    const renderAction = (i: string, rowKey: any) => {
        return (
            <>
                <Link to={`/exceedances/${rowKey.id!}`}>
                    <Button shape="circle" icon="edit" title="edit"></Button>
                </Link>
            </>
        );
    };

    const onCloseModal = React.useCallback((): void => {
        setCommentModalVisible(false);
    }, []);

    const onOk = React.useCallback(() => {
        let comment = props.form.getFieldValue('supervisorComment');
        let exceedances = exceedances0!;
        let selected = selectedExceedancesList!;
        let filteredExc = exceedances.find((x) => x.id === selected.id);

        filteredExc!.commentBySup = comment;

        setExceedances(exceedances);

        setCommentModalVisible(false);

        console.log('Super Comment', exceedances0);
    }, [exceedances0, selectedExceedancesList, props.form]);

    const onChangeComment = (rowKey: ExceedancesListVm) => {
        const selected = exceedances0!.find((x) => x.id === rowKey.id!);

        setSelectedExceedancesList(selected!);
        setCommentModalVisible(true);
    };

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
            getUser();
        } else {
            // this.getUserArea(this.state.user.sub)
        }

        previousPropsRef.current = props;
    });

    const rowSelection = {
        selectedExceedances,
        onChange: onSelectChange,
    };
    const {
        form: { getFieldDecorator: getFieldDecorator },
        locations: locations,
    } = props;
    const renderComment = (i: string, rowKey: any) => {
        return (
            <div style={{ width: '100%', display: 'flex' }}>
                <Form style={{ display: 'flex' }}>
                    <Form.Item>
                        <Input width="45%" disabled readOnly value={i!}></Input>
                    </Form.Item>
                    <Button
                        shape="circle"
                        icon="edit"
                        title="edit"
                        style={{ marginLeft: '10px' }}
                        onClick={() => onChangeComment(rowKey!)}
                    ></Button>
                </Form>
            </div>
        );
    };
    console.log('select Exc', selectedExceedances);
    return (
        <Spin spinning={loading}>
            <Card

            // extra={this.renderHeader()}
            >
                <Form>
                    <div style={{ display: 'flex' }}>
                        <Form.Item label="Location">
                            {getFieldDecorator('locationCode')(
                                <Select style={{ width: '100px' }} onChange={handleLocationChange}>
                                    {locations.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>

                        <Form.Item label="Area">
                            {getFieldDecorator('areaCode')(
                                <Select style={{ width: '200px' }}>
                                    {filteredAreas.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            )}
                        </Form.Item>
                        <Form.Item>
                            <ButtonGroup style={{ marginTop: '40px', marginLeft: '20px' }}>
                                <Button type="primary" onClick={onSearch}>
                                    Search
                                </Button>
                            </ButtonGroup>
                        </Form.Item>
                    </div>
                    <Modal
                        destroyOnHidden
                        onCancel={onCloseModal}
                        open={commentModalVisible}
                        onOk={onOk}
                        title={'Supervisor Comment'}
                    >
                        <Form.Item>{getFieldDecorator('supervisorComment')(<Input.TextArea />)}</Form.Item>
                    </Modal>
                </Form>
                <Button style={{ marginRight: '10px' }} type="primary" onClick={sendToPOD}>
                    Return back to PRA
                </Button>
                <Button style={{ margin: '0,10px,0,10px' }} type="primary" onClick={sendToRM}>
                    Run & Maintain
                </Button>
                <Table
                    dataSource={exceedances0}
                    loading={loading}
                    bordered
                    //expandRowByClick={true}
                    // pagination={paginationConfig}
                    rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                    rowSelection={rowSelection}
                >
                    {' '}
                    <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                    <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                    <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                    <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                    <Table.Column dataIndex="commentBySup" title="Supervisor Comment" />
                    <Table.Column
                        dataIndex="commentBySup"
                        title="Comment"
                        render={(i: string, rowKey: ExceedancesListVm) => renderComment(i, rowKey)}
                    ></Table.Column>
                    <Table.Column
                        dataIndex="excListStatus"
                        title="Status"
                        render={(i: string, rowKey: ExceedancesListVm) => renderStatus(i, rowKey)}
                    ></Table.Column>
                    <Table.Column
                        title="Action"
                        width={'130px'}
                        render={(i: string, rowKey: any) => renderAction(i, rowKey)}
                    ></Table.Column>
                </Table>
            </Card>
        </Spin>
    );
};

const ShiftExceedancesTable = Form.create<Props>()(
    ShiftExceedancesTableComponent,
);

export default ShiftExceedancesTable;
