import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Card, Col, Spin, Row, Select, Button, Table, Input, message, Modal, Typography } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import moment from 'moment';
import { dictionaryClient, reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ResolvedExceedances,
    SubmitedExceedancesCommand,
} from '../../services/Client';
const ButtonGroup = Button.Group;
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import CommentDrawer from './CommentDrawer';

const ExceedancesTable: React.FC<any> = (props: any) => {
    const { form, locations, areas } = props;
    const [loading, setLoading] = useState(false);
    const [filteredAreas, setFilteredAreas] = useState<AreaVm[]>([]);
    const [exceedances, setExceedances] = useState<ExceedancesVm[]>([]);
    const [selectedExceedancesId, setSelectedExceedancesId] = useState<number[]>([]);
    const [user, setUser] = useState<User>({} as any);
    const [areaCode, setAreaCode] = useState<string[]>([]);
    const [locationCode, setLocationCode] = useState<string>('');
    const [drawVisible, setDrawVisible] = useState(false);
    const [sendVisible, setSendVisible] = useState(false);
    const [selectedExceedances, setSelectedExceedances] = useState<ExceedancesVm>({} as any);
    const [UserRoles, setUserRoles] = useState<string[]>([]);
    const exceedanceDrawerRef = useRef<any>(null);

    useEffect(() => {
        getUser();
        // eslint-disable-next-line
    }, []);

    const getUser = async () => {
        const data: User = await authService.getUser();
        setUser(data);
        await getUserArea(data.sub);
        onSearch();
    };

    const getUserArea = async (value: any) => {
        let area: UserVm = await usersClient.getUsersArea(value);
        setUserRoles(area.roles!);
        setAreaCode(area.areaCodes!);
        setLocationCode(area.locationCode!);
    };

    const onSearch = useCallback(() => {
        setLoading(true);
        form.validateFields(async (errors: any, values: any) => {
            let datePeriod: Date[] = values.datePeriod?.map((r: moment.Moment) => r.utc(true).toDate()) || [];
            let startDate = datePeriod[0];
            let endDate = datePeriod[1];
            let locationCode = values.locationCode;
            let areaCode = values.areaCode;
            let data = await reportsClient.getExceedances(locationCode, areaCode, startDate, endDate);
            setExceedances(data);
            setLoading(false);
        });
    }, [form, user]);

    const handleLocationChange = (value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    };

    const filterAreas = (locationCode: string) => {
        const filtered = areas.filter((r: AreaVm) => r.locationCode === locationCode);
        setFilteredAreas(filtered);
    };

    const onSelectChange = (selected: any) => {
        let result = exceedances.find((x) => x.id === selected);
        setSelectedExceedancesId(selected);
        setSelectedExceedances(result!);
    };

    const resetFilter = () => {
        form.resetFields();
        onSearch();
    };

    const onChange = (rowKey: ExceedancesVm) => {
        const formRef = exceedanceDrawerRef.current?.props.form;
        if (rowKey) {
            const { ...tagValues } = rowKey;
            formRef?.setFieldsValue({ ...tagValues });
        } else {
            formRef?.resetFields();
            setSelectedExceedances(rowKey);
        }
        setSelectedExceedances(rowKey);
        setDrawVisible(true);
    };

    const resolvedExceedances = async () => {
        try {
            setLoading(true);
            const values = form.getFieldsValue(['locationCode', 'areaCode']);
            let query = new ResolvedExceedances();
            query.areaCode = values.areaCode;
            query.locationCode = values.locationCode;
            query.taskValues = selectedExceedancesId;
            query.submitedBy = user.sub;
            await reportsClient.resolvedExceedances(query);
        } finally {
            setLoading(false);
            message.success('Successfully Created');
            let url = window.location.origin;
            let finalUrl = url + '/exceedances/resolvedExceedance';
            window.location.replace(finalUrl);
        }
    };

    const onSend = () => {
        setSendVisible(true);
    };

    const onClose = () => {
        setDrawVisible(false);
    };

    const onCloseDrawer = () => {
        setSendVisible(false);
    };

    const submitTag = () => {
        const formRef = exceedanceDrawerRef.current?.props.form;
        formRef?.validateFields(async (err: any, values: ExceedancesVm) => {
            if (err) return;
            try {
                setLoading(true);
                let updateCommand = new UpdateTagDataCommand();
                updateCommand.id = values.id;
                updateCommand.value = values.taskValue;
                updateCommand.comment = values.comment;
                reportsClient.updateTagData(updateCommand);
                setTimeout(() => {
                    onSearch();
                    setDrawVisible(false);
                }, 1000);
            } finally {
                message.success('Successfully updated');
                setLoading(false);
                renderComment2(values.comment!, values);
                setExceedances(exceedances);
                getUser();
            }
        });
    };

    const submitedExceedances = async () => {
        try {
            setLoading(true);
            let comment = form.getFieldValue('supervisorComment');
            let query = new SubmitedExceedancesCommand();
            const values = form.getFieldsValue(['locationCode', 'areaCode']);
            query.areaCode = values.areaCode;
            query.locationCode = values.locationCode;
            query.taskValues = selectedExceedancesId;
            query.submitedBy = user.sub;
            query.supervisorComment = comment;
            await reportsClient.submitedExceedances(query);
        } finally {
            setLoading(false);
            let url = window.location.origin;
            let finalUrl = url + '/exceedances/submitedExceedance';
            window.location.replace(finalUrl);
        }
    };

    const renderComment2 = (i: string, rowKey: any) => (
        <div style={{ width: '100%', display: 'flex' }}>
            <Form style={{ display: 'flex' }}>
                <Form.Item>
                    <Input width="45%" disabled readOnly defaultValue={i}></Input>
                </Form.Item>
                <Button
                    shape="circle"
                    icon="edit"
                    title="edit"
                    style={{ marginLeft: '10px' }}
                    onClick={() => onChange(rowKey)}
                ></Button>
            </Form>
        </div>
    );

    const renderHeader = () => {
        const { getFieldDecorator, getFieldValue } = form;
        const locationSelected = !!getFieldValue('locationCode');
        const areaSelected = !!getFieldValue('areaCode');
        const dataLoaded = exceedances.length > 0;
        const disableActions = !(locationSelected && areaSelected && dataLoaded);
        return (
            <div>
                <Row align="middle">
                    <Col span={12}>
                        <Typography.Title> Exceedance List</Typography.Title>
                    </Col>
                    <Col span={12} style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
                        <ButtonGroup>
                            <Button type="primary" onClick={resolvedExceedances} disabled={disableActions}>
                                Under Supervisors Control
                            </Button>
                            <Button onClick={onSend} disabled={disableActions}>
                                Send to Production Shift Supervisor
                            </Button>
                        </ButtonGroup>
                    </Col>
                </Row>
                <Card>
                    <Form layout="inline">
                        <Form.Item label="Date">
                            {getFieldDecorator('datePeriod', {
                                initialValue: [moment().startOf('week'), moment().endOf('week')],
                            })(
                                <DatePicker.RangePicker
                                    ranges={{
                                        Today: [moment(), moment()],
                                        'This week': [moment().startOf('week'), moment().endOf('week')],
                                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                                        'This year': [moment().startOf('year'), moment().endOf('year')],
                                    }}
                                />,
                            )}
                        </Form.Item>
                        {UserRoles.includes('ChiefSupervisor') && (
                            <>
                                <Form.Item label="Location">
                                    {getFieldDecorator('locationCode')(
                                        <Select style={{ width: '200px' }} onChange={handleLocationChange}>
                                            {locations.map((r: any) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    )}
                                </Form.Item>
                                <Form.Item label="Area">
                                    {getFieldDecorator('areaCode')(
                                        <Select
                                            style={{ width: '200px' }}
                                            onChange={(value) => {
                                                form.setFieldsValue({ areaCode: value });
                                                onSearch();
                                            }}
                                        >
                                            {filteredAreas.map((r: any) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    )}
                                </Form.Item>
                            </>
                        )}
                        <ButtonGroup>
                            <Button type="primary" onClick={onSearch}>
                                Search
                            </Button>
                            <Button danger onClick={resetFilter}>
                                Reset
                            </Button>
                        </ButtonGroup>
                    </Form>
                </Card>
            </div>
        );
    };

    const { getFieldDecorator, getFieldValue } = form;
    getFieldDecorator('username');
    getFieldDecorator('supervisorComment');
    let superVis = getFieldValue('supervisorComment');
    const rowSelection = {
        selectedExceedancesId,
        onChange: onSelectChange,
    };
    const renderComment = (i: string, rowKey: any) => (
        <div style={{ width: '100%', display: 'flex' }}>
            <Form style={{ display: 'flex' }}>
                <Form.Item>
                    <Input width="45%" disabled readOnly value={i!}></Input>
                </Form.Item>
                <Button
                    shape="circle"
                    icon="edit"
                    title="edit"
                    style={{ marginLeft: '10px' }}
                    onClick={() => onChange(rowKey!)}
                ></Button>
            </Form>
        </div>
    );
    return (
        <Spin spinning={loading}>
            <Card>
                {renderHeader()}
                <Table
                    dataSource={exceedances}
                    loading={loading}
                    expandRowByClick={true}
                    rowKey={(i: ExceedancesVm) => i.id!.toString()}
                    rowSelection={rowSelection}
                >
                    <Table.Column dataIndex="areaName" title="Area" />
                    <Table.Column dataIndex="locationName" title="Location" />
                    <Table.Column dataIndex="logsheetName" title="Logsheet name" />
                    <Table.Column dataIndex="groupName" title="Device Name" />
                    <Table.Column dataIndex="taskName" title="Name of Point" />
                    <Table.Column
                        dataIndex="datePeriod"
                        title="Date"
                        render={(i: Date) => moment(i).format('DD-MM-YYYY')}
                    />
                    <Table.Column dataIndex="datePeriod" title="Date" render={(i: Date) => moment(i).format('HH:mm')} />
                    <Table.Column dataIndex="taskDescription" title="Allowed Range" />
                    <Table.Column dataIndex="taskValue" title="Actual Value" />
                    <Table.Column dataIndex="count" title="Count" />
                    <Table.Column
                        dataIndex="comment"
                        title="Comment"
                        render={(i: string, rowKey: ExceedancesVm) => renderComment(i, rowKey)}
                    ></Table.Column>
                </Table>
            </Card>
            <Modal
                destroyOnHidden
                onCancel={onCloseDrawer}
                open={sendVisible}
                onOk={submitedExceedances}
                title={'Supervisor Comment'}
            >
                <Form.Item>{getFieldDecorator('supervisorComment')(<Input.TextArea />)}</Form.Item>
            </Modal>
            <CommentDrawer
                visible={drawVisible}
                wrappedComponentRef={(ref: any) => (exceedanceDrawerRef.current = ref)}
                groups={selectedExceedances}
                onClose={onClose}
                onSubmit={submitTag}
            ></CommentDrawer>
        </Spin>
    );
};

export default Form.create<any>()(ExceedancesTable);
