import { DatePicker } from '../../common/components/antd';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import moment from 'moment';
import React from 'react';

type Props = {
    form: WrappedFormUtils<any>;
    startDateFieldName: string;
    endDateFieldName: string;
};

type State = {
    endOpen: boolean;
};

const PeriodDatePicker: React.FC<Props> = props => {
    const {
        endDateFieldName,
        startDateFieldName
    } = props;

    const [endOpen, setEndOpen] = React.useState<boolean>(false);

    const disabledStartDate = React.useCallback((startValue?: moment.Moment | null): boolean => {
        const { getFieldValue } = props.form;
        const endValue = getFieldValue(endDateFieldName);
        if (!startValue || !endValue) {
            return false;
        }

        return startValue.valueOf() > endValue.valueOf();
    }, [endDateFieldName, props.form]);

    const disabledEndDate = React.useCallback((endValue?: moment.Moment | null): boolean => {
        const { getFieldValue } = props.form;
        const startValue = getFieldValue(startDateFieldName);
        if (!endValue || !startValue) {
            return false;
        }

        return endValue.valueOf() <= startValue.valueOf();
    }, [startDateFieldName, props.form]);

    const handleStartOpenChange = React.useCallback((open: boolean): void => {
        if (!open) {
            setEndOpen(true);
        }
    }, []);

    const handleEndOpenChange = React.useCallback((open: boolean): void => {
        setEndOpen(open);
    }, []);

    const { getFieldDecorator: getFieldDecorator } = props.form;

    return (
        <div>
            {getFieldDecorator(props.startDateFieldName)(
                <DatePicker
                    disabledDate={disabledStartDate}
                    placeholder="Select start date"
                    onOpenChange={handleStartOpenChange}
                />,
            )}
            &nbsp;
            {getFieldDecorator(props.endDateFieldName)(
                <DatePicker
                    disabledDate={disabledEndDate}
                    placeholder="Select end date"
                    open={endOpen}
                    onOpenChange={handleEndOpenChange}
                />,
            )}
        </div>
    );
};

export default PeriodDatePicker;
