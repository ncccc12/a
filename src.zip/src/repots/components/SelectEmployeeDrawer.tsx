import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Select, Button } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { EmployeeVm, GroupVm } from '../../services/Client';

export type SelectEmployeeForm = {
    groupCode: string;
    employeeId: number;
}

type Props = {
    visible: boolean;
    groups: GroupVm[];
    employees: EmployeeVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {
    filteredEmployees: EmployeeVm[];
};

const SelectEmployeeDrawerComponent: React.FC<Props> = props => {
    const {
        form,
        employees
    } = props;

    const [filteredEmployees, setFilteredEmployees] = React.useState<EmployeeVm[]>([]);

    const filterEmployees = React.useCallback((code: string) => {
        let filteredEmployees = employees.filter((r) => r.groupCode === code);
        setFilteredEmployees(filteredEmployees);
    }, [employees]);

    const handleGroupChange = React.useCallback((code: string) => {
        filterEmployees(code);
        form.setFieldsValue({
            employeeId: undefined,
        });
    }, [filterEmployees, form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            if (!prevProps.visible && props.visible) {
                let groupCode = form.getFieldValue('groupCode');
                filterEmployees(groupCode);
            }
        }

        previousPropsRef.current = props;
    });

    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },
        groups: groups,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    return (
        <Drawer title="Select Employee" open={visible} width={700} onClose={props.onClose}>
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Group">
                    {getFieldDecorator('groupCode', {
                        rules: [
                            {
                                required: true,
                            },
                        ],
                    })(
                        <Select onChange={handleGroupChange}>
                            {groups.map((r) => {
                                return (
                                    <Select.Option key={r.code} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>

                <Form.Item label="Employee">
                    {getFieldDecorator('employeeId', {
                        rules: [
                            {
                                required: true,
                            },
                        ],
                    })(
                        <Select>
                            {filteredEmployees.map((r) => {
                                return (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.lastName + ' ' + r.firstName}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const SelectEmployeeDrawer = Form.create<Props>()(
    withLegacyFormRef(SelectEmployeeDrawerComponent),
);

export default SelectEmployeeDrawer;
