import React from 'react';
import { Button } from 'antd';
import { Form } from '@ant-design/compatible';
import { DatePicker } from '../../common/components/antd';
import { FormComponentProps } from '@ant-design/compatible/lib/form';

import fileDownload from 'js-file-download'
import { reportsClient } from '../../services';

type Props = {} & FormComponentProps;

type State = {
    isLoading: boolean;
}

const ReportsDailyContainerComponent: React.FC<Props> = props => {
    const [isLoading, setIsLoading] = React.useState<boolean>(false);

    const handleFormSubmit = React.useCallback((e: any) => {
        e.preventDefault();
        props.form.validateFields(async (errors, values) => {
            if (errors) {
                return;
            }
            setIsLoading(true)
            const response = await reportsClient.getReportByPeriod(values);
            fileDownload(response.data, response.fileName!);
            setIsLoading(false)
        });
    }, [props.form]);

    const { getFieldDecorator: getFieldDecorator } = props.form;

    return (
        <Form layout="inline" onSubmit={handleFormSubmit}>
            <Form.Item label="Date">
                {getFieldDecorator('date', {
                    rules: [
                        {
                            required: true,
                            message: 'Please select date',
                        },
                    ],
                })(<DatePicker />)}
            </Form.Item>
            <Form.Item>
                <Button htmlType="submit" loading={isLoading} type="primary">
                    Export
                </Button>
            </Form.Item>
        </Form>
    );
};

const ReportsDailyContainer = Form.create<Props>()(
    ReportsDailyContainerComponent,
);

export default ReportsDailyContainer;
