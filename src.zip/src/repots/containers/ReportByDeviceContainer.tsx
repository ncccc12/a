import React from 'react';
import { Button, Select, Spin } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { dictionaryClient, logSheetsClient, reportsClient } from '../../services';
import { LogsheetDictionaryVm, DeviceVm, GetReportByDeviceQuery, GetTagsQuery, TagVm, DictionaryDto, AreaVm  } from '../../services/Client';
const ButtonGroup = Button.Group;
import { DatePicker } from '../../common/components/antd';
import fileDownload from 'js-file-download';
import moment from 'moment';

type FilterForm = {
    logsheetId: number;
    deviceIds: number[];
    tagIds: number[];
    datePeriod: moment.Moment[];
};

type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    logsheets: LogsheetDictionaryVm[];
    devices: DeviceVm[];
    filteredDevices: DeviceVm[];
    tags: TagVm[];
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const { RangePicker } = DatePicker;

const ReportByDeviceContainerComponent: React.FC<Props> = props => {
    const {
        form
    } = props;

    const [loading, setLoading] = React.useState<boolean>(false);
    const [logsheets0, setLogsheets] = React.useState<LogsheetDictionaryVm[]>([]);
    const [devices, setDevices] = React.useState<DeviceVm[]>([]);
    const [filteredDevices, setFilteredDevices] = React.useState<DeviceVm[]>([]);
    const [tags, setTags] = React.useState<TagVm[]>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);

    const loadData = async () => {
        let logsheets = await dictionaryClient.getLogsheets();
        const locations = await dictionaryClient.getLocations();
        const areas = await dictionaryClient.getAreas();

        setLogsheets(logsheets);
        setLocations(locations);
        setAreas(areas);
    };

    const handleLogsheetChange = React.useCallback(async (id: number) => {
        let devices = await logSheetsClient.getDevices(id);
        setFilteredDevices(devices);

        form.setFieldsValue({
            deviceIds: []
        })
    }, [form]);

    const handleDeviceChange = React.useCallback(async (deviceIds: number[]) => {
        
        let query = new GetTagsQuery();
        query.deviceIds = deviceIds;
        let tags = await logSheetsClient.getTags(query);
        setTags(tags);
    }, []);

    const generateReport = React.useCallback(() => {
        form.validateFields(async (err: any, values: FilterForm) => {
            

            if (err) return;

            try {
                setLoading(true);
                let query = new GetReportByDeviceQuery();
                query.logsheetId = values.logsheetId;
                query.deviceIds = values.deviceIds;
                query.tagIds = values.tagIds || [];
                query.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                let response = await reportsClient.getReportByDevice(query);
                fileDownload(response.data, response.fileName!);
            } finally {
                setLoading(false);
            }
        });
    }, [form]);

    const resetFilter = React.useCallback(() => {
        form.resetFields();
    }, [form]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadData();
        }
    });

    const {
        form: { getFieldDecorator: getFieldDecorator, getFieldValue: getFieldValue },
    } = props;

    const selectStyle = {
        width: 250,
    };

    const selectedLocationId = getFieldValue('locationId');
    const selectedAreaCode = getFieldValue('areaCode');

    let logsheets = logsheets0;
    if (selectedAreaCode !== undefined) {
        logsheets = logsheets.filter((item: LogsheetDictionaryVm) => item.areaCode === selectedAreaCode);
    }

    return (
        <Spin spinning={loading}>
            <Form labelAlign="left" layout="inline">
                <Form.Item label="Location">
                        {getFieldDecorator('locationId')(
                            <Select style={{width:150}} placeholder="Select location">
                                {locations.map((item: DictionaryDto) => (
                                    <Select.Option key={item.id} value={item.id}>
                                        {item.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                </Form.Item>
                <Form.Item
                    label="Area"
                    help="Please select location first"
                >
                    {getFieldDecorator('areaCode')(
                        <Select placeholder="Select area">
                            {areas
                                .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                .map((item: AreaVm) => (
                                    <Select.Option key={item.id} value={item.code}>
                                        {item.name}
                                    </Select.Option>
                                ))}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Logsheet">
                    {getFieldDecorator('logsheetId', {
                        rules: [
                            {
                                required: true,
                                message: 'Logsheet is required',
                            },
                        ],
                    })(
                        <Select
                            style={{ width: 450 }}
                            showSearch
                            optionFilterProp="children"
                            onChange={handleLogsheetChange}
                        >
                            {logsheets.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>

                <Form.Item label="Devices">
                    {getFieldDecorator('deviceIds')(
                        <Select style={selectStyle} mode="multiple" showSearch optionFilterProp="children" onChange={handleDeviceChange}>
                            {filteredDevices.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>

                  <Form.Item label="Tags">
                    {getFieldDecorator('tagIds')(
                        <Select style={selectStyle} mode="multiple" showSearch optionFilterProp="children">
                            {tags.map((r) => (
                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>

                <Form.Item label="Date period">
                    {getFieldDecorator('datePeriod', {
                        rules: [
                            {
                                required: true,
                                message: 'Date period is required',
                            },
                        ],
                    })(<RangePicker />)}
                </Form.Item>
              

                {/* <Form.Item label="Is active">
                    {getFieldDecorator('isActive', { initialValue: [] })(
                        <Select mode="multiple">
                            <Select.Option key="y" value={1}>
                                Yes
                            </Select.Option>
                            <Select.Option key="n" value={0}>
                                No
                            </Select.Option>
                        </Select>,
                    )}
                </Form.Item> */}

                <Form.Item>
                    <ButtonGroup>
                        <Button type="primary" onClick={generateReport}>
                            Generate report
                        </Button>
                        <Button onClick={resetFilter}>Reset</Button>
                    </ButtonGroup>
                </Form.Item>
            </Form>
        </Spin>
    );
};

const ReportByDeviceContainer = Form.create<Props>()(
    ReportByDeviceContainerComponent,
);

export default ReportByDeviceContainer;
