import { expect, it } from 'vitest';

it('provides a browser-like test environment', () => {
    document.body.innerHTML = '<div id="root"></div>';

    expect(document.getElementById('root')).not.toBeNull();
});
