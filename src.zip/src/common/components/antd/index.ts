import React from 'react';
import generatePicker from 'antd/es/date-picker/generatePicker';
import momentGenerateConfig from 'rc-picker/es/generate/moment';
import type { Moment } from 'moment';

export const DatePicker = generatePicker<Moment>(momentGenerateConfig);
export const TimePicker = DatePicker.TimePicker;

export function withLegacyFormRef<Props extends object>(Component: React.ComponentType<Props>) {
    const WrappedComponent = React.forwardRef<{ props: Props }, Props>((props, ref) => {
        const componentProps = props as Props;
        React.useImperativeHandle(ref, () => ({ props: componentProps }), [componentProps]);
        return React.createElement(Component, componentProps);
    });

    WrappedComponent.displayName = `LegacyFormRef(${Component.displayName || Component.name || 'Component'})`;
    return WrappedComponent;
}
