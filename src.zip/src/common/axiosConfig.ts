import { notification, message } from 'antd';
import axios, { AxiosInstance } from 'axios';
import authService from './components/api-authorization/AuthorizeService';
import { ApplicationPaths, QueryParameterNames } from './components/api-authorization/ApiAuthorizationConstants';

const axiosApi = (): AxiosInstance => {
    // const options: AxiosRequestConfig = {
    //     withCredentials: true,
    //     baseURL: import.meta.env.VITE_API_URL,
    // };
    const instance = axios.create();

    instance.interceptors.request.use(
        async (config) => {
            // console.log('test', config);
            const token = await authService.getAccessToken();
            config.headers.Authorization = `Bearer ${token}`;

            return config;
        },
        (error) => {
            message.error(error.toString());
            return Promise.reject(error);
        },
    );

    // Add a response interceptor
    instance.interceptors.response.use(
        (response) => {
            return response;
        },
        (error: any) => {
            if (error.response && error.response.config.headers['custom-processing']) {
                return Promise.reject(error);
            } else if (error.response && error.response.status === 400) {
                let errors: string[] = [];

                if (typeof error.response.data === 'string') {
                    notification.error({
                        message: `Error`,
                        description: error.response.data,
                    });

                    return Promise.reject(error);
                }

                Object.keys(error.response.data).forEach((propName) => {
                    errors.push(error.response.data[propName]);
                });

                notification.error({
                    message: `Error`,
                    description: errors.join('\n'),
                });

                return Promise.reject(error);
            } else if (error.response && error.response.status === 404) {
                window.location.href = '#/NotFound';

                return Promise.reject(error);
            } else if (error.response && error.response.status === 403) {
                window.location.href = '/Unautharized';
                return Promise.reject(error);
                
            } else if (error.response && error.response.status === 401) {
                const redirectUrl = `${ApplicationPaths.Login}?${QueryParameterNames.ReturnUrl}=${encodeURI(
                    window.location.href,
                )}`;

                window.location.href = redirectUrl;

                return Promise.reject(error);
            } else {
                //  window.location.href = '#/Error';
                notification.error({
                    message: `Error`,
                    description: error.response ? error.response.data.error : 'Sorry, something went wrong',
                });

                return Promise.reject(error);
            }
        },
    );

    return instance;
};

export default axiosApi();
