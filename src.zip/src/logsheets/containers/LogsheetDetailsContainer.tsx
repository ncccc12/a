import React from 'react';
import { Card, Typography, Descriptions, Row, Button, Table, Tag, Popconfirm, message, Alert, Tabs, Spin } from 'antd';
import { logSheetsClient, dictionaryClient } from '../../services';
import { RouteComponentProps } from 'react-router';
import {
    LogSheetVm,
    GroupDto,
    DictionaryDto,
    ListTypeValueVm,
    DeleteTagCommand,
    EditTagCommand,
    AddNewTagCommand,
    AddNewLogsheetGroupCommand,
    DeleteLogsheetGroupCommand,
    AreaVm,
    EditLogsheetCommand,
    ReorderLogsheetCommand,
    GetLogsheetsQuery,
    LogsheetListItemVm,
} from '../../services/Client';
import moment from 'moment';
import TagDrawer, { TagForm } from '../components/TagDrawer';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import LogsheetDetailsForm from '../components/LogsheetDetailsForm';
import logsheetService from '../LogsheetsService';
import GroupDrawer from '../components/GroupDrawer';
import DeviceListModal from '../components/DeviceListModal';
const ButtonGroup = Button.Group;
import LogsheetDrawer, { LogsheetForm } from '../components/LogsheetDrawer';
import { SearchForm } from '../components/LogsheetsFilterForm';

export type DeviceTag = {
    groupId?: number;
    groupName?: string;
    id?: number;
    name?: string;
    description?: string;
    minValue?: number;
    maxValue?: number;
    listTypeCode?: string;
    listTypeName?: string;
    listTypeValues?: (string | undefined)[];
    unitOfMeasurementCode?: string;
    unitOfMeasurementName?: string;
    dataTypeCode?: string;
    dataTypeName?: string;
    isRequired?: boolean;
    changeStatus?: string;
  
    taskValueId?: number;
    value?: any;
    comment?: string;
    isExceed?: boolean;
    hasAttachments?: boolean;
    attachment?: any;
    isSkipped?: boolean;
    order?: number;
};

type ReorderLogsheet={
    id?: number
    groupDto?: GroupDto | undefined;
}

type GroupForm = {
    parentGroup: { id: number; name: string };
    id: number;
    groupName: string;
    isDevice: boolean;
    isParentLogsheet: boolean;
};

type Params = {
    id: string;
};

type Props = {} & RouteComponentProps<Params>;
type State = {
    logsheet?: LogSheetVm;
    tomorrowLogsheet?: LogSheetVm;
    loading: boolean;
    tagDrawerShown: boolean;
    groupDrawerShwon: boolean;
    deviceModalShown: boolean;
    dataTypes: DictionaryDto[];
    listTypes: DictionaryDto[];
    listTypeValues: ListTypeValueVm[];
    unitOfMeasurements: DictionaryDto[];
    selectedGroups: Array<{ id: number; name: string }>;
    selectedGroup?: GroupDto;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logsheetDrawerShown: boolean;
    logsheets:LogsheetListItemVm[]

};

const LogsheetDetailsContainer: React.FC<Props> = props => {
    const [loading, setLoading] = React.useState<boolean>(false);
    const [tagDrawerShown, setTagDrawerShown] = React.useState<boolean>(false);
    const [groupDrawerShwon, setGroupDrawerShwon] = React.useState<boolean>(false);
    const [deviceModalShown, setDeviceModalShown] = React.useState<boolean>(false);
    const [dataTypes, setDataTypes] = React.useState<DictionaryDto[]>([]);
    const [listTypes, setListTypes] = React.useState<DictionaryDto[]>([]);
    const [listTypeValues, setListTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [unitOfMeasurements, setUnitOfMeasurements] = React.useState<DictionaryDto[]>([]);
    const [selectedGroups, setSelectedGroups] = React.useState<Array<{ id: number; name: string }>>([]);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const [logsheets, setLogsheets] = React.useState<LogsheetListItemVm[]>([]);
    const [logsheetDrawerShown, setLogsheetDrawerShown] = React.useState<boolean>(false);
    const [selectedGroup, setSelectedGroup] = React.useState<GroupDto>();
    const [logsheet, setLogsheet] = React.useState<LogSheetVm>();
    const [tomorrowLogsheet, setTomorrowLogsheet] = React.useState<LogSheetVm>();
    const tagDrawerRef = React.useRef<any>(undefined);
    const groupDrawerRef = React.useRef<any>(undefined);
    const logsheetDrawerRef = React.useRef<any>(undefined);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
    };

    const loadData = React.useCallback(async () => {
        const id = parseInt(props.match.params.id);
        let logsheet = await logSheetsClient.getLogsheetForm(id);
        let tomorrowLogsheet = await logSheetsClient.getTomorrowLogsheetForm(id);
        let dataTypes = await dictionaryClient.getDictionary('DataTypes');
        let listTypes = await dictionaryClient.getDictionary('ListTypes');
        let listTypeValues = await dictionaryClient.getListTypeValues();
        let unitOfMeasurements = await dictionaryClient.getDictionary('UnitOfMeasurements');

        let empty = new DictionaryDto();
        empty.code = '-';
        empty.name = '-';

        unitOfMeasurements.unshift(empty);

        setLogsheet(logsheet);
        setDataTypes(dataTypes);
        setListTypes(listTypes);
        setListTypeValues(listTypeValues);
        setUnitOfMeasurements(unitOfMeasurements);
        setTomorrowLogsheet(tomorrowLogsheet);
    }, [props.match]);

    const handleDeleteTag = async (row: DeviceTag) => {
        

        try {
            setLoading(true);
            let command = new DeleteTagCommand();
            command.tagId = row.id;
            await logSheetsClient.deleteTag(command);

            message.success('Successfull');
            await loadData();
        } finally {
            setLoading(false);
        }
    };

    const openTagDrawer = (tag: DeviceTag | undefined, parentGroups: Array<{ id: number; name: string }> = []) => {
        const form = tagDrawerRef.current.props.form as WrappedFormUtils<any>;


        if (tag) {
           
            const { dataTypeName, listTypeName, unitOfMeasurementName, ...tagValues } = tag;

            form.setFieldsValue({
                ...tagValues,
            });
        } else {
            // add new
            form.resetFields();
            setSelectedGroups(parentGroups);
        }

        setSelectedGroups(parentGroups);
        setTagDrawerShown(true);
    };

    const openGroupDrawer = (
        parentGroup: { id?: number; name?: string },
        isDevice: boolean = false,
        isLogsheet: boolean = false,
    ) => {
        const form = groupDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.resetFields();
        form.setFieldsValue({
            parentGroup: { id: parentGroup.id, name: parentGroup.name },
            isDevice,
            isParentLogsheet: isLogsheet,
        });

        setGroupDrawerShwon(true);
    };

    const submitTag = React.useCallback(() => {
        const form = tagDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: TagForm) => {
            if (err) return;

            try {
                setLoading(true);

                if (values.id) {
                    let editCommand = new EditTagCommand();
                    editCommand.init(values);
                    await logSheetsClient.editTag(editCommand);
                } else {
                    // add new
                    let addNewCommand = new AddNewTagCommand();
                    addNewCommand.init(values);
                    await logSheetsClient.addNewTag(addNewCommand);
                }

                message.success('Successfully updated');
                await loadData();
                setTagDrawerShown(false);
            } finally {
                setLoading(false);
            }
        });
    }, [loadData]);

    const openLogsheetDrawer = (logsheet: LogSheetVm) => {
        const form = logsheetDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.resetFields();

        let logsheetForm: LogsheetForm = {
            id: logsheet.id,
            areaCode: logsheet.areaCode,
            locationCode: logsheet.locationCode,
            isActive: logsheet.isActive,
            name: logsheet.name,
        };

        form.setFieldsValue({
            ...logsheetForm,
        });

        setLogsheetDrawerShown(true);
    };

    const submitEditLogsheet = React.useCallback(() => {
        const form = logsheetDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: LogsheetForm) => {
            if (err) return;

            try {
                setLoading(true);
                let command = new EditLogsheetCommand();
                command.init(values);
                await logSheetsClient.editLogsheet(command);
                message.success('Successfull');
                await loadData();
                setLogsheetDrawerShown(false);
            } finally {
                setLoading(false);
            }
        });
    }, [loadData]);

    const submitGroup = React.useCallback(() => {
        const form = groupDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: GroupForm) => {

            if (err) return;

            try {
                setLoading(true);
                if (values.id) {
                } else {
                    let newCommand = new AddNewLogsheetGroupCommand();
                    newCommand.parentGroupId = values.parentGroup.id;
                    newCommand.groupName = values.groupName;
                    newCommand.isDevice = values.isDevice;
                    newCommand.isParentLogsheet = values.isParentLogsheet;
                    await logSheetsClient.addNewLogsheetGroup(newCommand);
                    message.success('Successfully updated');
                    await loadData();
                    setGroupDrawerShwon(false);
                    setDeviceModalShown(false);
                }
            } finally {
                setLoading(false);
            }
        });
    }, [loadData]);

    const search = async() => {
        //const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
        //form.validateFields(async (err: any, values: SearchForm) => {
            setLoading(true);

            try {
                let values ={
                    locationCode:undefined,
                    areaCode:undefined,
                    isActive:undefined, 
                }
                let query = new GetLogsheetsQuery();
                query.init(values);
                let logsheets = await logSheetsClient.getLogsheets(query);
                setLogsheets(logsheets);
            } finally {
                setLoading(false);
            }
        //});
    };

    const openDeviceList = (parentGroup: GroupDto) => {
        setSelectedGroup(parentGroup);
        setDeviceModalShown(true);
    };

    const deleteDevice = async (groupdId: number) => {
        let command = new DeleteLogsheetGroupCommand();
        command.groupId = groupdId;

        try {
            await logSheetsClient.deleteLogsheetGroup(command);
            message.success('Successfull');
            setDeviceModalShown(false);
            await loadData();
        } finally {
        }
    };

    const onChangeTaskOrder = (groupdId: number, parentGroup:any , upDown:number)=>{
        
        const maingroup:GroupDto = parentGroup[0]
        let  taskDto
        let  groupDto:GroupDto | undefined = undefined 
        maingroup!.childGroups!.map(
            (x:any)=>
            {x.tasks.map((i:any)=>
                {if(i.id ===groupdId)
            {
                taskDto  = i
                groupDto = x
             } 
            })
        })

             
        let firstItemIndex =groupDto!.tasks?.findIndex(x=>x.id===groupdId)
        let itemLeng = groupDto!.tasks?.length
        let firstItem = groupDto!.tasks![firstItemIndex!]
        let firstItemOrder = firstItem.order
        let selectedGroupArr= selectedGroup!

        
        if(upDown==2 && itemLeng! - 1){
            let secondItemIndex =firstItemIndex! + 1
            let secondItem = groupDto!.tasks![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
           
            groupDto!.tasks![firstItemIndex!] =secondItem
           // groupDto.tas![firstItemIndex!] = secondItem
            groupDto!.tasks![secondItemIndex!] = firstItem

            let selectedGr = maingroup.childGroups!.map((x:GroupDto)=>{if(x.id === groupDto?.id){
                x=groupDto!
            }})

            setSelectedGroup(maingroup)
           
            

            
            
            //this.setState({selectedGroup:selectedGroupArr})
           
        }
        if(upDown==1 && firstItemIndex != 0){
            let secondItemIndex =firstItemIndex! - 1
            let secondItem = groupDto!.tasks![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
           
            groupDto!.tasks![firstItemIndex!] =secondItem
           // groupDto.tas![firstItemIndex!] = secondItem
            groupDto!.tasks![secondItemIndex!] = firstItem

            let selectedGr = maingroup.childGroups!.map((x:GroupDto)=>{if(x.id === groupDto?.id){
                
                x=groupDto!
            }})

            setSelectedGroup(maingroup)
           
            
        }

        

    };

    const changeDeviceIndex = (groupdId: number, upDown:number)=>
    {
        let selectedGroupArr= selectedGroup!

        let firstItemIndex =selectedGroup?.childGroups?.findIndex(x=>x.id ===groupdId)
        let itemLeng = selectedGroup?.childGroups?.length
           
        
        let firstItem = selectedGroup!.childGroups![firstItemIndex!];
        let firstItemOrder = firstItem.order
        

        if(upDown==2 && firstItemIndex !=itemLeng! -1)
        {
            
            let secondItemIndex =firstItemIndex! + 1
            let secondItem = selectedGroup!.childGroups![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
           
            if(selectedGroupArr != undefined)
            {
            selectedGroupArr.childGroups![firstItemIndex!] = secondItem
            selectedGroupArr.childGroups![secondItemIndex!] = firstItem
            
            setSelectedGroup(selectedGroupArr)
            }
        }
        if(upDown==1 && firstItemIndex !=0)
        {
            let secondItemIndex =firstItemIndex! - 1
            let secondItem = selectedGroup!.childGroups![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
            if(selectedGroupArr != undefined)
            {
                selectedGroupArr.childGroups![firstItemIndex!] = secondItem
                selectedGroupArr.childGroups![secondItemIndex!] = firstItem
                setSelectedGroup(selectedGroupArr)
            }
        }   
    };

    const onReorderLogsheet = async ()=>{
        
        
        const id = selectedGroup?.id
        let value:ReorderLogsheet = {
            id:id, 
            groupDto: selectedGroup
        } 
        try {
            setLoading(true);
            
            let command = new ReorderLogsheetCommand();
            command.init(value)
            await logSheetsClient.reorderLogsheet(command);
            message.success('Successfull');
            await loadData();
            setDeviceModalShown(false);
        } finally {
            setLoading(false);
        }
        

    };

    function getGroupTree(
        groups: GroupDto[] | undefined,
        level: number,
        parentGroup: GroupDto | undefined
    ): JSX.Element {
        let devices = groups && groups.filter((r) => r.isDevice);

        if (devices && devices.length) {
            let devicesAndGroup = [...devices];

            if (parentGroup) devicesAndGroup.unshift(parentGroup);

            return renderTable(devicesAndGroup);
        } else {
            return <>
                {groups &&
                    groups.map((g: GroupDto) => {
                        // let tags: DeviceTag[] = g.tasks!.map(t => logsheetService.mapTaskDtoToDeviceType(g, t));

                        let hasDevices = g.childGroups && g.childGroups.some((r) => r.isDevice);
                        let lastGroup = hasDevices || (g.childGroups && g.childGroups.length === 0);
                        let hasOnlyTasks = g.childGroups?.length === 0 && g.tasks?.length;

                        return (
                            <Card
                                key={g.id}
                                type="inner"
                                title={g.name}
                                style={{ margin: '15px 0' }}
                                extra={
                                    <>
                                        <ButtonGroup>
                                            {!hasDevices && (
                                                <Button onClick={() => openGroupDrawer(g, false)}>
                                                    Add new group
                                                </Button>
                                            )}
                                            <Popconfirm
                                                title="Are you sure?"
                                                onConfirm={() => deleteDevice(g.id!)}
                                                okText="Yes"
                                                cancelText="No"
                                            >
                                                <Button danger>Remove </Button>
                                            </Popconfirm>
                                        </ButtonGroup>
                                    </>
                                }
                            >
                                {/* {tags && tags.length > 0 && this.renderTable(tags)} */}
                                {lastGroup && (
                                    <>
                                        <Button icon="unordered-list" onClick={() => openDeviceList(g)}>
                                            Devices
                                        </Button>
                                        <Button
                                            icon="plus"
                                            style={{ marginLeft: 5 }}
                                            onClick={() => openGroupDrawer(g, true)}
                                        >
                                            Add new device
                                        </Button>
                                    </>
                                )}

                                {g.childGroups &&
                                    g.childGroups.length > 0 &&
                                    getGroupTree(g.childGroups, level + 1, g)}

                                {hasOnlyTasks && renderTable([g])}
                            </Card>
                        );
                    })}
            </>;
        }
    }

    const renderTable = (groups: GroupDto[]) => {
        let tags: DeviceTag[] = groups.flatMap((r) => {
            return r.tasks!.map((t) => logsheetService.mapTaskDtoToDeviceType(r, t));
        });

        let parentGroups = groups.map((r) => {
            return {
                id: r.id!,
                name: r.name!,
            };
        });

        // let parentGroup = groups.filter(r => r.isDevice === false)[0];

        return (
            <Table
                title={() => (
                    <ButtonGroup>
                        <Button onClick={() => openTagDrawer(undefined, parentGroups)}>Add new tag</Button>
                        <Button onClick={() => onReorderLogsheet()}>Save Order</Button>
                    </ButtonGroup>
                )}
                dataSource={tags}
                rowKey={(r) => r.id + ''}
                pagination={{ hideOnSinglePage: true }}
            >
                <Table.Column
                    key="status"
                    title="Change status"
                    width={100}
                    render={(r: DeviceTag) => <b>{r.changeStatus}</b>}
                ></Table.Column>
                <Table.Column
                    
                        title="Actions"
                        render={(row: GroupDto) => (<>
                            <Button
                            shape="circle"
                            icon="up-circle"
                            title="up"
                            onClick={() => onChangeTaskOrder(row!.id!, groups, 1)}
                        ></Button>{' '}
                       <Button
                            shape="circle"
                            icon="down-circle"
                            title="down"
                            onClick={() => onChangeTaskOrder(row!.id!, groups, 2)}
                        ></Button>
                        </>
                        )}
                    ></Table.Column>
                <Table.Column dataIndex="groupName" title="Group/Device name" width={200}></Table.Column>
                <Table.Column dataIndex="name" title="Tag name" width={200}></Table.Column>
                <Table.Column dataIndex="description" title="Description" width={200}></Table.Column>
                <Table.Column dataIndex="dataTypeName" title="Data type"></Table.Column>
                <Table.Column dataIndex="listTypeName" title="List type name" width={100}></Table.Column>
                <Table.Column
                    dataIndex="listTypeValues"
                    title="List type values"
                    key="values"
                    width={150}
                    render={(vals) => (
                        <span>
                            {vals.map((r: string) => (
                                <Tag color="blue" key={r}>
                                    {r}
                                </Tag>
                            ))}
                        </span>
                    )}
                ></Table.Column>
                <Table.Column dataIndex="minValue" title="Min value"></Table.Column>
                <Table.Column dataIndex="maxValue" title="Max value"></Table.Column>
                <Table.Column dataIndex="unitOfMeasurementName" title="Unit of measurement"></Table.Column>
                <Table.Column
                    dataIndex="isRequired"
                    title="Is Required"
                    render={(isRequired: boolean) => (isRequired ? 'Yes' : 'No')}
                ></Table.Column>
                <Table.Column
                    title="Actions"
                    render={(row: DeviceTag) => (
                        <>
                            <Button
                                shape="circle"
                                icon="edit"
                                title="edit"
                                onClick={() => openTagDrawer(row, parentGroups)}
                            ></Button>{' '}
                            <Popconfirm
                                title="Are you sure delete this tag?"
                                onConfirm={() => handleDeleteTag(row)}
                                okText="Yes"
                                cancelText="No"
                            >
                                <Button
                                    shape="circle"
                                    icon="delete"
                                    style={{ color: 'red', marginTop: 5 }}
                                    title="delete"
                                ></Button>
                            </Popconfirm>
                        </>
                    )}
                ></Table.Column>
            </Table>
        );
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            void (async () => {
                await loadDictionaries();
                loadData();
                search();
            })();
        }
    }, []);

    console.log('Logsheets', logsheets)

    return <>
        <Tabs defaultActiveKey="1">
            <Tabs.TabPane tab="Current logsheet" key="1">
                <Card>
                    <Spin spinning={loading}>
                        <Row align="middle" justify="space-between">
                            <Typography.Title>Logsheet details</Typography.Title>{' '}
                            <Alert
                                message="Warning"
                                description={
                                    <span>
                                        Changes that was made to the logsheet will be applied from{' '}
                                        <b>tomorrow</b> date!
                                    </span>
                                }
                                type="warning"
                                showIcon
                            />
                        </Row>

                        {logsheet && (
                            <Card
                                title={logsheet.name}
                                extra={
                                    <>
                                        <Button
                                            onClick={() =>
                                                openGroupDrawer(
                                                    { id: logsheet.id, name: logsheet.name },
                                                    false,
                                                    true,
                                                )
                                            }
                                        >
                                            Add new groups
                                        </Button>
                                        <Button
                                            type="primary"
                                            icon="edit"
                                            style={{ marginLeft: 5 }}
                                            onClick={() => openLogsheetDrawer(logsheet)}
                                        >
                                            Edit
                                        </Button>
                                    </>
                                }
                            >
                                <Card.Meta
                                    description={
                                        <Descriptions>
                                            <Descriptions.Item label="Area">
                                                {logsheet.areaName}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Location">
                                                {logsheet.locationName}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Created">
                                                {moment(logsheet.created).format('DD.MM.YYYY HH:mm')}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Created by">
                                                {logsheet.createdBy}
                                            </Descriptions.Item>

                                            <Descriptions.Item label="Last modified">
                                                {logsheet.lastModified &&
                                                    moment(logsheet.lastModified).format('DD.MM.YYYY HH:mm')}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Last modified by">
                                                {logsheet.lastModifiedBy}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Is Activr">
                                                {logsheet.isActive ? 'Yes' : 'No'}
                                            </Descriptions.Item>
                                        </Descriptions>
                                    }
                                />
                                {logsheet && <Row>{getGroupTree(logsheet.groups, 0, undefined)}</Row>}
                            </Card>
                        )}
                    </Spin>

                    <TagDrawer
                        visible={tagDrawerShown}
                        wrappedComponentRef={(ref: any) => (tagDrawerRef.current = ref)}
                        dataTypes={dataTypes}
                        listTypes={listTypes}
                        listTypeValues={listTypeValues}
                        unitOfMeasurements={unitOfMeasurements}
                        groups={selectedGroups}
                        onSubmit={submitTag}
                        onClose={() => setTagDrawerShown(false)}
                    />
                    <GroupDrawer
                        visible={groupDrawerShwon}
                        wrappedComponentRef={(ref: any) => (groupDrawerRef.current = ref)}
                        onSubmit={submitGroup}
                        onClose={() => setGroupDrawerShwon(false)}
                    />
                    <DeviceListModal
                        visible={deviceModalShown}
                        parentGroup={selectedGroup!}
                        onDeleteDevice={(groupdId) => deleteDevice(groupdId)}
                        onChangeIndex={(groupdId, upDown) => changeDeviceIndex(groupdId, upDown)}
                        onReorderSave={()=>onReorderLogsheet()}
                        onOk={() => setDeviceModalShown(false)}
                        onAddDevice={(parentGroup: GroupDto) => openGroupDrawer(parentGroup, true)}
                    />
                </Card>
            </Tabs.TabPane>
            <Tabs.TabPane tab="Changes to update" key="2">
                <LogsheetDetailsForm logsheet={tomorrowLogsheet}></LogsheetDetailsForm>
            </Tabs.TabPane>
        </Tabs>

        <LogsheetDrawer
            visible={logsheetDrawerShown}
            areas={areas}
            locations={locations}
            wrappedComponentRef={(compRef: any) => (logsheetDrawerRef.current = compRef)}
            onSubmit={submitEditLogsheet}
            onClose={() => setLogsheetDrawerShown(false)}
        />
    </>;
};

export default LogsheetDetailsContainer;
