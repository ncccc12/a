import React from 'react';
import { Table, Spin, Row, Button, Divider, message } from 'antd';
import {
    DictionaryDto,
    AreaVm,
    GetLogsheetsQuery,
    LogsheetListItemVm,
    AddNewLogsheetCommand,
    EditLogsheetCommand,
    GroupDto,
    LogSheet,
    ReorderLogsheetCommand,
} from '../../services/Client';
import { dictionaryClient, logSheetsClient } from '../../services';
import { Link } from 'react-router-dom';
import LogsheetDrawer, { LogsheetForm } from '../components/LogsheetDrawer';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import LogsheetsFilterForm, { SearchForm } from '../components/LogsheetsFilterForm';
import { AppState } from '../../store/reducers';
import { LogsheetsFilterFormState, changeFilterForm, resetFilterForm } from '../ducks/LogsheetsFilterDuck';
import { connect } from 'react-redux';

const mapStateToProps = (state: AppState): LogsheetsFilterFormState => ({
    filterForm: state.LogsheetsFilterDuck.filterForm,
});

const mapDispatchToProps = {
    changeFilterForm,
    resetFilterForm,
};
type ReorderLogsheet={
    id?: number
    groupDto?: GroupDto | undefined;
    logSheets?:LogsheetListItemVm[]
}
type Props = {} & typeof mapDispatchToProps & LogsheetsFilterFormState;
type State = {
    loading: boolean;
    logsheets: LogsheetListItemVm[];
    logsheetDrawerShown: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const LogsheetsContainerComponent: React.FC<Props> = props => {
    const {
        resetFilterForm: resetFilterForm0,
        filterForm
    } = props;

    const [loading, setLoading] = React.useState<boolean>(false);
    const [logsheets, setLogsheets] = React.useState<LogsheetListItemVm[]>([]);
    const [logsheetDrawerShown, setLogsheetDrawerShown] = React.useState<boolean>(false);
    const [locations, setLocations] = React.useState<DictionaryDto[]>([]);
    const [areas, setAreas] = React.useState<AreaVm[]>([]);
    const logsheetDrawerRef = React.useRef<any>(undefined);
    const filterFormRef = React.useRef<any>(undefined);

    const loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        setLocations(locations);
        setAreas(areas);
    };

    const search = React.useCallback(() => {
        const form = filterFormRef.current.props.form as WrappedFormUtils<any>;
        form.validateFields(async (err: any, values: SearchForm) => {
            setLoading(true);

            try {
                let query = new GetLogsheetsQuery();
                query.init(values);
                let logsheets = await logSheetsClient.getLogsheets(query);
                setLogsheets(logsheets);
            } finally {
                setLoading(false);
            }
        });
    }, []);

    const resetFilter = React.useCallback(() => {
        resetFilterForm0();
        search();
    }, [resetFilterForm0, search]);

    const submitNewLogsheet = React.useCallback(() => {
        const form = logsheetDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: LogsheetForm) => {
            if (err) return;

            try {
                setLoading(true);

                if (values.id) {
                    let command = new EditLogsheetCommand();
                    command.init(values);
                    await logSheetsClient.editLogsheet(command);
                } else {
                    let command = new AddNewLogsheetCommand();
                    command.init(values);
                    await logSheetsClient.addNewLogsheet(command);
                }

                await search();
                message.success('Successfull');
                setLogsheetDrawerShown(false);
            } finally {
                setLoading(false);
            }
        });
    }, [search]);

    const onChangeIndex = (groupId:number , upDown:number)=>
    {
        console.log(groupId, upDown)
        let logSheets = logsheets!
        let firstItemIndex = logsheets!.findIndex(x=>x.id ==groupId!)
        let itemLeng =logsheets!.length
        let firstItem = logsheets![firstItemIndex!];
        let firstItemOrder = firstItem.order

        if(upDown==2 && firstItemIndex !=itemLeng! -1)
    {
        
        let secondItemIndex =firstItemIndex! + 1
        let secondItem = logsheets![secondItemIndex];
        firstItem.order = secondItem.order
        secondItem.order = firstItemOrder
       
        if(logSheets != undefined)
        {
            logSheets![firstItemIndex!] = secondItem
            logSheets![secondItemIndex!] = firstItem
        
        setLogsheets(logSheets)
        }
    }
    if(upDown==1 && firstItemIndex !=0)
    {
        let secondItemIndex =firstItemIndex! - 1
        let secondItem = logsheets![secondItemIndex];
        firstItem.order = secondItem.order
        secondItem.order = firstItemOrder
        
        if(logSheets != undefined)
        {
            logSheets![firstItemIndex!] = secondItem
            logSheets![secondItemIndex!] = firstItem
            setLogsheets(logSheets)
        }
    }
    };

    const onReorderLogsheet = async ()=>{
    
    
        const id = undefined;
        let logsheet= logsheets.map(x=>x)
        console.log(logsheet)
        let value:ReorderLogsheet =
        {
            logSheets:logsheet
        }
        try {
            setLoading(true);
            console.log(value)
            let command = new ReorderLogsheetCommand();
            command.init(value)
            console.log(command)
            await logSheetsClient.reorderLogsheet(command);
            message.success('Successfull');
            
            
        } finally {
            setLoading(false);
        }
        

    };

    const openLogsheetDrawer = (logsheet: LogsheetListItemVm | undefined) => {
        const form = logsheetDrawerRef.current.props.form as WrappedFormUtils<any>;

        form.resetFields();

        if (logsheet) {
            let logsheetForm: LogsheetForm = {
                id: logsheet.id,
                areaCode: logsheet.areaCode,
                locationCode: logsheet.locationCode,
                name: logsheet.name,
                isActive: logsheet.isActive,
            };
            form.setFieldsValue({
                ...logsheetForm,
            });
        }

        setLogsheetDrawerShown(true);
    };

    const initFilter = React.useCallback((ref: any) => {
        if (ref) {
            filterFormRef.current = ref;
            search();
        }
    }, [search]);

    const renderActions = (logsheet: LogsheetListItemVm) => {
        return <>
            <Link to={`/logsheets/details/${logsheet.id}`}>
                <Button icon="info-circle" title="View details"></Button>
            </Link>
            <Button
                icon="edit"
                style={{ marginLeft: 5 }}
                shape="circle"
                onClick={() => openLogsheetDrawer(logsheet)}
            ></Button>
        </>;
    };

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            void loadDictionaries();
        }
    }, []);

    console.log('Logsheets ', logsheets)

    return (
        <Spin spinning={loading}>
            <LogsheetsFilterForm
                wrappedComponentRef={initFilter}
                locations={locations}
                areas={areas}
                searchForm={filterForm}
                onSearch={search}
                onReset={resetFilter}
                onChange={props.changeFilterForm}
            />
        <Button onClick={()=>onReorderLogsheet()}> Save Order</Button>
            <Divider />

            <Row>
                <Table
                    dataSource={logsheets}
                    rowKey={(r) => r.id + ''}
                    title={() => (
                        <Button onClick={() => openLogsheetDrawer(undefined)}> Add new logsheet </Button>
                    )}
                    bordered
                >   <Table.Column
            
                title="Actions"
                render={(row: GroupDto) => (<>
                    <Button
                    shape="circle"
                    icon="up-circle"
                    title="edit"
                    onClick={() => onChangeIndex(row!.id!, 1)}
                ></Button>{' '}
               <Button
                    shape="circle"
                    icon="down-circle"
                    title="edit"
                    onClick={() => onChangeIndex(row!.id!, 2)}
                ></Button>
                </>
                )}
            ></Table.Column>
                    <Table.Column dataIndex="location" title="Location"></Table.Column>
                    <Table.Column dataIndex="area" title="Area"></Table.Column>
                    <Table.Column dataIndex="name" title="Name"></Table.Column>
                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive) => (isActive ? 'Yes' : 'No')}
                    ></Table.Column>
                    <Table.Column
                        title="Actions"
                        align="center"
                        render={(ls) => renderActions(ls)}
                    ></Table.Column>
                </Table>
            </Row>

            <LogsheetDrawer
                visible={logsheetDrawerShown}
                wrappedComponentRef={(ref: any) => (logsheetDrawerRef.current = ref)}
                locations={locations}
                areas={areas}
                onSubmit={submitNewLogsheet}
                onClose={() => setLogsheetDrawerShown(false)}
            />
        </Spin>
    );
};

const LogsheetsContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(
    LogsheetsContainerComponent,
);

export default LogsheetsContainer;
