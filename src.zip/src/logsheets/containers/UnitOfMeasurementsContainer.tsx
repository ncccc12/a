import React from 'react';
import { Spin, Button, Table, message, Select } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import PageComponent from '../../common/components/PageComponent';
import { unitOfMeasureClient } from '../../services';
import {
    DictionaryDto,
    GetUnitOfMeasurementsQuery,
    UpdateUnitOfMeasurementCommand,
    AddUnitOfMeasurementCommand,
} from '../../services/Client';
import UnitOfMeasurementDrawer, { UnitOfMeasureForm } from '../components/UnitOfMeasurementDrawer';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
const ButtonGroup = Button.Group;

type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    unitOfMeasurements: DictionaryDto[];
    unitOfMeasureDrawerShown: boolean;
};

const UnitOfMeasurementsContainerComponent: React.FC<Props> = props => {
    const [loading, setLoading] = React.useState<boolean>(false);
    const [unitOfMeasurements, setUnitOfMeasurements] = React.useState<DictionaryDto[]>([]);
    const [unitOfMeasureDrawerShown, setUnitOfMeasureDrawerShown] = React.useState<boolean>(false);
    const unitOfMeasureRef = React.useRef<any>(undefined);

    const search = React.useCallback(() => {
        props.form.validateFields(async (err: any, values: { isActive: number[] }) => {
            setLoading(true);
            
            try {
                let query = new GetUnitOfMeasurementsQuery();
                query.isActive = values.isActive;
                let uoms = await unitOfMeasureClient.get(query);

                setUnitOfMeasurements(uoms);
            } finally {
                setLoading(false);
            }
        });
    }, [props.form]);

    const openUnitOMeasureDrawer = (row: DictionaryDto | undefined) => {
        const form = unitOfMeasureRef.current.props.form as WrappedFormUtils<any>;
        setUnitOfMeasureDrawerShown(true);
        {
            if (row) {
                let groupForm: UnitOfMeasureForm = {
                    id: row.id!,
                    name: row.name!,
                    code: row.code!,
                    description: row.description!,
                    isActive: row.isActive!,
                };

                form.setFieldsValue({
                    ...groupForm,
                });
            } else {
                form.resetFields();
                form.setFieldsValue({ isActive: true });
            }
        }
    };

    const submitForm = React.useCallback(() => {
        const form = unitOfMeasureRef.current.props.form as WrappedFormUtils<any>;
        form.validateFields(async (err: any, values: UnitOfMeasureForm) => {
            if (err) return;

            try {
                setLoading(true);

                if (values.id) {
                    let updateCommand = new UpdateUnitOfMeasurementCommand();
                    updateCommand.init(values);

                    await unitOfMeasureClient.update(updateCommand);
                } else {
                    let addCommand = new AddUnitOfMeasurementCommand();
                    addCommand.init(values);

                    await unitOfMeasureClient.add(addCommand);
                }

                message.success('Successful');
                setUnitOfMeasureDrawerShown(false);
                search();
            } finally {
                setLoading(false);
            }
        });
    }, [search]);

    const renderActions = (row: DictionaryDto) => {
        return (
            <Button
                icon="edit"
                shape="circle"
                title="Edit"
                onClick={() => openUnitOMeasureDrawer(row)}
            ></Button>
        );
    };

    const resetFilter = React.useCallback(() => {
        props.form.resetFields();
        search();
    }, [search, props.form]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    const {
        form: { getFieldDecorator: getFieldDecorator },
    } = props;

    return (
        <PageComponent title={'Unit of measurements'}>
            <Spin spinning={loading}>
                <Form labelAlign="left" layout="inline">
                    <Form.Item label="Is active">
                        {getFieldDecorator('isActive', { initialValue: [1] })(
                            <Select style={{ width: 150 }} mode="multiple">
                                <Select.Option key="y" value={1}>
                                    Yes
                                </Select.Option>
                                <Select.Option key="n" value={0}>
                                    No
                                </Select.Option>
                            </Select>,
                        )}
                    </Form.Item>
                    <Form.Item>
                        <ButtonGroup>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Form>

                <Table
                    rowKey={(r) => r.id + ''}
                    dataSource={unitOfMeasurements}
                    title={() => (
                        <Button type="primary" onClick={() => openUnitOMeasureDrawer(undefined)}>
                            Add new
                        </Button>
                    )}
                >
                    <Table.Column dataIndex="name" title="Name"></Table.Column>
                    <Table.Column dataIndex="code" title="Code"></Table.Column>
                    <Table.Column dataIndex="description" title="Description"></Table.Column>
                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                    ></Table.Column>
                    <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
                </Table>
                <UnitOfMeasurementDrawer
                    visible={unitOfMeasureDrawerShown}
                    wrappedComponentRef={(compRef: any) => (unitOfMeasureRef.current = compRef)}
                    onSubmit={submitForm}
                    onClose={() => setUnitOfMeasureDrawerShown(false)}
                />
            </Spin>
        </PageComponent>
    );
};

const UnitOfMeasurementsContainer = Form.create<Props>()(
    UnitOfMeasurementsContainerComponent,
);

export default UnitOfMeasurementsContainer;
