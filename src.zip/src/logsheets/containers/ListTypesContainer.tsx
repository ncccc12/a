import React from 'react';
import { Spin, Button, Table, message, Tag, Row, Select } from 'antd';
import { Form } from '@ant-design/compatible';
import PageComponent from '../../common/components/PageComponent';
import {
    DictionaryDto,
    GetListTypesQuery,
    ListTypeVm,
    UpdateListTypeCommand,
    AddListTypeCommand,
} from '../../services/Client';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { listTypesClient } from '../../services';
import ListTypesDrawer, { ListTypeForm } from '../components/ListTypesDrawer';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import ListTypeValuesModal from '../components/ListTypeValuesModal';
const ButtonGroup = Button.Group;


type Props = {} & FormComponentProps<any>;
type State = {
    loading: boolean;
    listTypes: ListTypeVm[];
    listTypeDrawerShown: boolean;
    valuesModalShown: boolean;
    selectedListType: ListTypeVm | undefined;
};

const ListTypesContainerComponent: React.FC<Props> = props => {
    const [loading, setLoading] = React.useState<boolean>(false);
    const [listTypes, setListTypes] = React.useState<ListTypeVm[]>([]);
    const [listTypeDrawerShown, setListTypeDrawerShown] = React.useState<boolean>(false);
    const [valuesModalShown, setValuesModalShown] = React.useState<boolean>(false);
    const [selectedListType, setSelectedListType] = React.useState<ListTypeVm | undefined>(undefined);
    const listTypeCompRef = React.useRef<any>(undefined);

    const search = React.useCallback(() => {
        props.form.validateFields(async (err: any, values: { isActive: number[] }) => {
            setLoading(true);

            try {
                let query = new GetListTypesQuery();
                query.isActive = values.isActive;
                let listTypes = await listTypesClient.get(query);

                setListTypes(listTypes);
            } finally {
                setLoading(false);
            }
        });
    }, [props.form]);

    const openListTypesDrawer = (row: DictionaryDto | undefined) => {
        const form = listTypeCompRef.current.props.form as WrappedFormUtils<any>;
        setListTypeDrawerShown(true);
        {
            if (row) {
                let groupForm: ListTypeForm = {
                    id: row.id!,
                    name: row.name!,
                    code: row.code!,
                    description: row.description!,
                    isActive: row.isActive!,
                };

                form.setFieldsValue({
                    ...groupForm,
                });
            } else {
                form.resetFields();
                form.setFieldsValue({ isActive: true });
            }
        }
    };

    const renderActions = (row: DictionaryDto) => {
        return <>
            <Button icon="edit" title="Edit" onClick={() => openListTypesDrawer(row)}></Button>
        </>;
    };

    const openListTypeValuesModal = React.useCallback((listType: ListTypeVm) => {
        setSelectedListType(listType);
        setValuesModalShown(true);
    }, []);

    const renderValues = React.useCallback((listType: ListTypeVm) => {
        return (
            <Button
                style={{ height: '100%', minHeight: 50 }}
                title="Edit values"
                type="dashed"
                onClick={() => openListTypeValuesModal(listType)}
            >
                <Row style={{ width: 185 }}>
                    {listType.listTypeValues!.map((r) => {
                        let color = r.isExceed ? 'red' : 'blue';
                        color = r.isActive ? color : '';

                        return (
                            <Tag key={r.id} color={color}>
                                {r.name}
                            </Tag>
                        );
                    })}
                </Row>
            </Button>
        );
    }, [openListTypeValuesModal]);

    const submitForm = React.useCallback(() => {
        const form = listTypeCompRef.current.props.form as WrappedFormUtils<any>;
        form.validateFields(async (err: any, values: ListTypeForm) => {
            if (err) return;

            try {
                setLoading(true);

                if (values.id) {
                    let updateCommand = new UpdateListTypeCommand();
                    updateCommand.init(values);

                    await listTypesClient.update(updateCommand);
                } else {
                    let addCommand = new AddListTypeCommand();
                    addCommand.init(values);

                    await listTypesClient.add(addCommand);
                }

                message.success('Successful');
                setListTypeDrawerShown(false);
                search();
            } finally {
                setLoading(false);
            }
        });
    }, [search]);

    const handleModalReload = React.useCallback(() => {
        search();
        setValuesModalShown(false);
    }, [search]);

    const resetFilter = React.useCallback(() => {
        props.form.resetFields();
        search();
    }, [search, props.form]);

    const isMounted = React.useRef(false);

    React.useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            search();
        }
    });

    const {
        form: { getFieldDecorator: getFieldDecorator },
    } = props;

    return (
        <PageComponent title={'List types'}>
            <Spin spinning={loading}>
                <Form labelAlign="left" layout="inline">
                    <Form.Item label="Is active">
                        {getFieldDecorator('isActive', { initialValue: [1] })(
                            <Select style={{ width: 150 }} mode="multiple">
                                <Select.Option key="y" value={1}>
                                    Yes
                                </Select.Option>
                                <Select.Option key="n" value={0}>
                                    No
                                </Select.Option>
                            </Select>,
                        )}
                    </Form.Item>
                    <Form.Item>
                        <ButtonGroup>
                            <Button type="primary" onClick={search}>
                                Search
                            </Button>
                            <Button onClick={resetFilter}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Form>

                <Table
                    rowKey={(r) => r.id + ''}
                    dataSource={listTypes}
                    title={() => (
                        <Button type="primary" onClick={() => openListTypesDrawer(undefined)}>
                            Add new
                        </Button>
                    )}
                >
                    <Table.Column dataIndex="name" title="Name"></Table.Column>
                    <Table.Column dataIndex="code" title="Code"></Table.Column>
                    <Table.Column dataIndex="description" title="Description"></Table.Column>
                    <Table.Column title="Values" render={renderValues}></Table.Column>
                    <Table.Column
                        dataIndex="isActive"
                        title="Is Active"
                        render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                    ></Table.Column>
                    <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
                </Table>
                <ListTypesDrawer
                    visible={listTypeDrawerShown}
                    wrappedComponentRef={(compRef: any) => (listTypeCompRef.current = compRef)}
                    onSubmit={submitForm}
                    onClose={() => setListTypeDrawerShown(false)}
                />
                <ListTypeValuesModal
                    visible={valuesModalShown}
                    listType={selectedListType!}
                    onReload={handleModalReload}
                    onClose={() => setValuesModalShown(false)}
                ></ListTypeValuesModal>
            </Spin>
        </PageComponent>
    );
};

const ListTypesContainer = Form.create<Props>()(
    ListTypesContainerComponent,
);

export default ListTypesContainer;
