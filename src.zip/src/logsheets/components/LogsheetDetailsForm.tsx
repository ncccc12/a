import React from 'react';
import { LogSheetVm, GroupDto } from '../../services/Client';
import { Card, Skeleton, Row, Typography, Descriptions, Table, Tag } from 'antd';
import moment from 'moment';
import { DeviceTag } from '../containers/LogsheetDetailsContainer';
import logsheetService from '../LogsheetsService';

type Props = {
    logsheet?: LogSheetVm;
};

type State = {};

const LogsheetDetailsForm: React.FC<Props> = props => {
    const {
        logsheet
    } = props;

    const renderTable = (tags: DeviceTag[]) => {
        return (
            <Table dataSource={tags} rowKey={r => r.id + ''} pagination={{ hideOnSinglePage: true }}>
                <Table.Column
                    title="Update Status"
                    width={200}
                    key="status"
                    render={(r: DeviceTag) => <b>{r.changeStatus}</b>}
                ></Table.Column>
                <Table.Column dataIndex="groupName" title="Group/Device name" width={200}></Table.Column>
                <Table.Column dataIndex="name" title="Tag name" width={200}></Table.Column>
                <Table.Column dataIndex="description" title="Description" width={200}></Table.Column>
                <Table.Column dataIndex="dataTypeName" title="Data type"></Table.Column>
                <Table.Column dataIndex="listTypeName" title="List type name" width={100}></Table.Column>
                <Table.Column
                    dataIndex="listTypeValues"
                    title="List type values"
                    key="values"
                    width={150}
                    render={vals => (
                        <span>
                            {vals.map((r: string) => (
                                <Tag color="blue" key={r}>
                                    {r}
                                </Tag>
                            ))}
                        </span>
                    )}
                ></Table.Column>
                <Table.Column dataIndex="minValue" title="Min value"></Table.Column>
                <Table.Column dataIndex="maxValue" title="Max value"></Table.Column>
                <Table.Column dataIndex="unitOfMeasurementName" title="Unit of measurement"></Table.Column>
                <Table.Column
                    dataIndex="isRequired"
                    title="Is Required"
                    render={(isRequired: boolean) => (isRequired ? 'Yes' : 'No')}
                ></Table.Column>
            </Table>
        );
    };

    function getGroupTree(groups: GroupDto[] | undefined, level: number, parentTags: DeviceTag[]): JSX.Element {
        let devices = groups && groups.filter(r => r.isDevice);

        if (devices && devices.length) {
            let tags: DeviceTag[] = devices.flatMap(r => {
                return r.tasks!.map(t => logsheetService.mapTaskDtoToDeviceType(r, t));
            });

            if (parentTags && parentTags.length) {
                tags = [...parentTags, ...tags];
            }

            // render table
            return renderTable(tags);
        } else {
            return <>
                {groups &&
                    groups.map((g: GroupDto) => {
                        let tags: DeviceTag[] = g.tasks!.map(t => logsheetService.mapTaskDtoToDeviceType(g, t));

                        return (
                            <Card key={g.id} type="inner" title={g.name} style={{ margin: '15px 0' }}>
                                {/* {tags && tags.length > 0 && this.renderTable(tags)} */}

                                {g.childGroups &&
                                    g.childGroups.length > 0 &&
                                    getGroupTree(g.childGroups, level + 1, tags)}
                            </Card>
                        );
                    })}
            </>;
        }
    }

    return (
        <Card>
            <Skeleton loading={false} active>
                <Row align="middle" justify="space-between">
                    <Typography.Title>Logsheet details</Typography.Title>{' '}
                </Row>

                {logsheet && (
                    <Card title={logsheet.name}>
                        <Card.Meta
                            description={
                                <Descriptions>
                                    <Descriptions.Item label="Area">{logsheet.areaName}</Descriptions.Item>
                                    <Descriptions.Item label="Location">{logsheet.locationName}</Descriptions.Item>
                                    <Descriptions.Item label="Schedule time">
                                        {logsheet.date && moment(logsheet.date).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Created">
                                        {moment(logsheet.created).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Last modified">
                                        {moment(logsheet.lastModified).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Last modified by">
                                        {logsheet.lastModifiedBy}
                                    </Descriptions.Item>
                                </Descriptions>
                            }
                        />
                        {logsheet && <Row>{getGroupTree(logsheet.groups, 0, [])}</Row>}
                    </Card>
                )}
            </Skeleton>
        </Card>
    );
};

export default LogsheetDetailsForm;
