import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Input, Button, Switch } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {};

const GroupDrawerComponent: React.FC<Props> = props => {
    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },
        form: form,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    getFieldDecorator('id');
    getFieldDecorator('parentGroup.id');

    let id = form.getFieldValue('id');
    let isDevice = form.getFieldValue('isDevice');
    form.getFieldDecorator('isParentLogsheet');

    let title = '';
    if (id) {
        title = isDevice ? 'Edit device' : 'Edit group';
    } else {
        title = isDevice ? 'Add device' : 'Add group';
    }

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Parent group">
                    {getFieldDecorator('parentGroup.name')(<Input readOnly />)}
                </Form.Item>
                <Form.Item label={isDevice ? 'Device name' : 'Group name'}>
                    {getFieldDecorator('groupName', {
                        rules: [
                            {
                                required: true,
                                message: 'Name is required',
                            },
                        ],
                    })(<Input />)}
                </Form.Item>
                <Form.Item label="Is Device">
                    {getFieldDecorator('isDevice', { valuePropName: 'checked' })(<Switch disabled />)}
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const GroupDrawer = Form.create<Props>()(
    withLegacyFormRef(GroupDrawerComponent),
);

export default GroupDrawer;
