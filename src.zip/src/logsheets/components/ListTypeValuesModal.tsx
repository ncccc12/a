import React from 'react';
import { Button, Modal, Table, message } from 'antd';
import { ListTypeValueVm, ListTypeVm, AddListTypeValueCommand, UpdateListTypeValueCommand } from '../../services/Client';
import ListTypeValueDrawer, { ListTypeValueForm } from './ListTypeValueDrawer';
import { WrappedFormUtils } from '@ant-design/compatible/lib/form/Form';
import { listTypesClient } from '../../services';

type Props = {
    visible: boolean;
    listType: ListTypeVm | undefined;
    onClose: () => void;
    onReload: () => void;
};
type State = {
    listTypeValueDrawerShown: boolean;
    loading: boolean;
};

const ListTypeValuesModal: React.FC<Props> = props => {
    const {
        listType,
        onReload,
        visible
    } = props;

    const [listTypeValueDrawerShown, setListTypeValueDrawerShown] = React.useState<boolean>(false);
    const [loading, setLoading] = React.useState<boolean>(false);
    const listTypeValueRef = React.useRef<any>(undefined);

    const openListTypeValueDrawer = (row: ListTypeValueVm | undefined) => {
        const form = listTypeValueRef.current.props.form as WrappedFormUtils<any>;

        setListTypeValueDrawerShown(true);
        {
            if (row) {
                let valueForm: ListTypeValueForm = {
                    listTypeId: listType?.id!,
                    id: row.id!,
                    name: row.name!,
                    code: row.code!,
                    description: row.description!,
                    isExceed: row.isExceed!,
                    isActive: row.isActive!,
                };

                form.setFieldsValue({
                    ...valueForm,
                });
            } else {
                form.resetFields();
                form.setFieldsValue({ isActive: true, listTypeId: listType?.id! });
            }
        }
    };

    const renderActions = (row: ListTypeValueVm) => {
        return <Button icon="edit" shape="circle" title="Edit" onClick={() => openListTypeValueDrawer(row)}></Button>;
    };

    const submitForm = React.useCallback(() => {
        const form = listTypeValueRef.current.props.form as WrappedFormUtils<any>;
        form.validateFields(async (err: any, values: ListTypeValueForm) => {
            if (err) return;

            try {
                setLoading(true);

                if (values.id) {
                    let updateCommand = new UpdateListTypeValueCommand();
                    updateCommand.init(values);
                    await listTypesClient.updateListTypeValue(updateCommand);
                } else {
                    let addCommand = new AddListTypeValueCommand();
                    addCommand.init(values);

                    await listTypesClient.addListTypeValue(addCommand);
                }

                message.success('Successful');
                setListTypeValueDrawerShown(false);
                onReload();
            } finally {
                setLoading(false);
            }
        });
    }, [onReload]);

    return <>
        <Modal
            open={visible}
            title={`List type: ${listType?.name} values`}
            width={1000}
            footer={null}
            confirmLoading={loading}
            onCancel={props.onClose}
        >
            <Table
                rowKey={(r) => r.id + ''}
                dataSource={listType?.listTypeValues}
                title={() => (
                    <Button type="primary" onClick={() => openListTypeValueDrawer(undefined)}>
                        Add new
                    </Button>
                )}
            >
                <Table.Column dataIndex="name" title="Name"></Table.Column>
                <Table.Column dataIndex="code" title="Code"></Table.Column>
                <Table.Column dataIndex="description" title="Description"></Table.Column>
                <Table.Column
                    dataIndex="isExceed"
                    title="Is exceed"
                    render={(isExceed: boolean) => <span>{isExceed ? 'Yes' : 'No'}</span>}
                ></Table.Column>
                <Table.Column
                    dataIndex="isActive"
                    title="Is Active"
                    render={(isActive: boolean) => <span>{isActive ? 'Yes' : 'No'}</span>}
                ></Table.Column>
                <Table.Column title="Actions" render={(r) => renderActions(r)}></Table.Column>
            </Table>
        </Modal>
        <ListTypeValueDrawer
            visible={listTypeValueDrawerShown}
            wrappedComponentRef={(compRef: any) => (listTypeValueRef.current = compRef)}
            onSubmit={submitForm}
            onClose={() => setListTypeValueDrawerShown(false)}
        ></ListTypeValueDrawer>
    </>;
};

export default ListTypeValuesModal;
