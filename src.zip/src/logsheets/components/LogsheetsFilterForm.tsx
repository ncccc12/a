import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Select, Button } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { AreaVm, DictionaryDto } from '../../services/Client';
const ButtonGroup = Button.Group;

export type SearchForm = {
    locationCode: string;
    areaCode: string;
    isActive: number[];
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    searchForm: SearchForm;
    onSearch: () => void;
    onReset: () => void;
    onChange: (values: SearchForm) => void;
} & FormComponentProps<any>;
type State = {
    filteredAreas: AreaVm[];
};

const LogsheetsFilterFormComponent: React.FC<Props> = props => {
    const {
        areas,
        locations
    } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const filterAreas = React.useCallback((value: string) => {
        const filteredAreas = areas.filter((r) => r.locationCode === value);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((value: string) => {
        filterAreas(value);
        props.form.setFieldsValue({
            areaCode: '',
        });
    }, [filterAreas, props.form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            if (!prevProps.areas.length && areas.length) {
                const {
                    searchForm: { locationCode },
                } = props;

                if (locationCode) {
                    filterAreas(locationCode);
                }
            }
        }

        previousPropsRef.current = props;
    });

    const {
        form: { getFieldDecorator: getFieldDecorator },
    } = props;

    const selectStyle = {
        width: 150,
    };

    return (
        <Form labelAlign="left" layout="inline">
            <Form.Item label="Location">
                {getFieldDecorator('locationCode')(
                    <Select style={selectStyle} onChange={handleLocationChange}>
                        {locations.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>,
                )}
            </Form.Item>

            <Form.Item label="Area">
                {getFieldDecorator('areaCode')(
                    <Select style={selectStyle}>
                        {filteredAreas.map((r) => (
                            <Select.Option key={r.id} value={r.code}>
                                {r.name}
                            </Select.Option>
                        ))}
                    </Select>,
                )}
            </Form.Item>

            <Form.Item label="Is active">
                {getFieldDecorator('isActive', { initialValue: [1] })(
                    <Select style={selectStyle} mode="multiple">
                        <Select.Option key="y" value={1}>
                            Yes
                        </Select.Option>
                        <Select.Option key="n" value={0}>
                            No
                        </Select.Option>
                    </Select>,
                )}
            </Form.Item>

            <Form.Item>
                <ButtonGroup>
                    <Button type="primary" onClick={props.onSearch}>
                        Search
                    </Button>
                    <Button onClick={props.onReset}>Reset</Button>
                </ButtonGroup>
            </Form.Item>
        </Form>
    );
};

const LogsheetsFilterForm = Form.create<Props>({
    mapPropsToFields(props: Props): any {
        return {
            locationCode: Form.createFormField({
                value: props.searchForm.locationCode,
            }),
            areaCode: Form.createFormField({
                value: props.searchForm.areaCode,
            }),
            isActive: Form.createFormField({
                value: props.searchForm.isActive,
            }),
        };
    },
    onValuesChange(props: Props, values: SearchForm): void {
        props.onChange(values);
    },
})(
    withLegacyFormRef(LogsheetsFilterFormComponent),
);

export default LogsheetsFilterForm;
