import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Input, Select, Tag, InputNumber, Button, Switch, Checkbox } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { DictionaryDto, GetLogsheetsQuery, GroupDto, ListTypeValueVm, LogSheetVm, LogsheetListItemVm } from '../../services/Client';
import { DataTypes } from '../models';
import { logSheetsClient } from '../../services';
import { values } from 'lodash';

export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    dataTypes: DictionaryDto[];
    listTypes: DictionaryDto[];
    listTypeValues: ListTypeValueVm[];
    unitOfMeasurements: DictionaryDto[];
    groups: Array<{ id: number; name: string }>;
    editOnlyValues?: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredLisTypeValues: ListTypeValueVm[];
    selectedDataTypeCode: string;
    changeParentGroup: boolean;
    logsheetGroup?:GroupDto[];
    logsheets:LogsheetListItemVm[]
};

const TagDrawerComponent: React.FC<Props> = props => {
    const {
        form,
        listTypeValues
    } = props;

    const [filteredLisTypeValues, setFilteredLisTypeValues] = React.useState<ListTypeValueVm[]>([]);
    const [selectedDataTypeCode, setSelectedDataTypeCode] = React.useState<string>('');
    const [changeParentGroup, setChangeParentGroup] = React.useState<boolean>(false);
    const [logsheets, setLogsheets] = React.useState<LogsheetListItemVm[]>([]);
    const [logsheetGroup, setLogsheetGroup] = React.useState<GroupDto[]>();

    const search = async() => {
        //const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
        //form.validateFields(async (err: any, values: SearchForm) => {
            

            try {
                let values ={
                    locationCode:undefined,
                    areaCode:undefined,
                    isActive:undefined, 
                }
                let query = new GetLogsheetsQuery();
                query.init(values);
                let logsheets = await logSheetsClient.getLogsheets(query);
                console.log('func', logsheets)
                setLogsheets(logsheets);
            } finally {
                
            }
        //});
    };

    const handleListTypeChange = React.useCallback((code: string) => {
        let filteredValues = listTypeValues.filter((r) => r.listTypeCode === code);
        setFilteredLisTypeValues(filteredValues);
    }, [listTypeValues]);

    const handleDataType = (code: string, callback?: () => void) => {
        setSelectedDataTypeCode(code);
        callback?.();
    };

    const onChange = React.useCallback((e:any) => {
        console.log('checked = ', e.target.checked);
        setChangeParentGroup(e.target.checked);
      }, []);

    const getValueNode = () => {
        let valueNode;
        if (selectedDataTypeCode === DataTypes.List) {
            valueNode = (
                <Select>
                    {filteredLisTypeValues.map((r) => {
                        return (
                            <Select.Option value={r.code} key={r.code}>
                                {r.name}
                            </Select.Option>
                        );
                    })}
                </Select>
            );
        } else if (selectedDataTypeCode === DataTypes.Number) {
            valueNode = <InputNumber />;
        } else {
            valueNode = <Input />;
        }

        return valueNode;
    };

    const logsheetGroup0 = React.useCallback(async(value:number)=>{
        let groups:GroupDto[] = [];
        let finalGroup:GroupDto[]=[];
        let logsheet = await logSheetsClient.getLogsheetForm(value);
        logsheet.groups?.map((x)=>(groups!.push(x) && finalGroup.push(x)))
        if(groups != null && groups.length>0){
           groups.map(r=>r.childGroups?.map(i=>finalGroup.push(i)))
        }
        console.log(finalGroup)
        setLogsheetGroup(finalGroup)
    }, []);

    const handleLogSheetChange = React.useCallback((value: number) => {
        logsheetGroup0(value);
        props.form.setFieldsValue({
            areaCodes: [],
        });
    }, [logsheetGroup0, props.form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
            search()
        } else {
            if (!prevProps.visible && props.visible) {
                let listTypeCode = form.getFieldValue('listTypeCode');
                let dataTypeCode = form.getFieldValue('dataTypeCode');
                
                handleDataType(dataTypeCode);
                handleListTypeChange(listTypeCode);
            } else if (!props.visible && selectedDataTypeCode !== '') {
                
                setSelectedDataTypeCode('');
            }
        }

        previousPropsRef.current = props;
    });

    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },
        form: form0,
        dataTypes: dataTypes,
        listTypes: listTypes,
        unitOfMeasurements: unitOfMeasurements,
        groups: groups,
        editOnlyValues: editOnlyValues,
        
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    getFieldDecorator('id');
    let id = form0.getFieldValue('id');

    getFieldDecorator('groupId');
    getFieldDecorator('taskValueId');
    console.log('logsheet', logsheets)
    console.log('logsheetGroup', logsheetGroup)

    let title = editOnlyValues ? 'Edit tag values' : id ? 'Edit tag' : 'Add new tag';

    return (
        <Drawer title={title} open={visible} width={700} onClose={props.onClose}>
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Group/Device name" >
                    {getFieldDecorator('groupId')(
                        <Select disabled={editOnlyValues || changeParentGroup}>
                            {groups.map((r) => {
                                return (
                                    <Select.Option key={r.id} value={r.id}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Tag name">
                    {getFieldDecorator('name', {
                        rules: [
                            {
                                required: true,
                                message: 'Tag name is required',
                            },
                        ],
                    })(<Input readOnly={editOnlyValues} />)}
                </Form.Item>
                <Form.Item label="Description">
                    {getFieldDecorator('description')(<Input.TextArea readOnly={editOnlyValues} />)}
                </Form.Item>
                <Form.Item label="Data type">
                    {getFieldDecorator('dataTypeCode', {
                        rules: [
                            {
                                required: true,
                                message: 'Data type is required',
                            },
                        ],
                    })(
                        <Select
                            onChange={(code: string) => handleDataType(code)}
                            disabled={editOnlyValues}
                        >
                            {dataTypes.map((r) => {
                                return (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                );
                            })}
                        </Select>,
                    )}
                </Form.Item>
                {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.List) && (
                    <>
                        <Form.Item label="List type">
                            {getFieldDecorator('listTypeCode', {
                                rules: [
                                    {
                                        required: selectedDataTypeCode === DataTypes.List,
                                        message: 'Listy type required',
                                    },
                                ],
                            })(
                                <Select onChange={handleListTypeChange} disabled={editOnlyValues}>
                                    {listTypes.map((r) => {
                                        return (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            )}
                        </Form.Item>
                        <Form.Item label="Values">
                            {filteredLisTypeValues.map((r) => {
                                return <Tag color={r.isExceed ? 'red' : undefined}>{r.name}</Tag>;
                            })}
                        </Form.Item>
                    </>
                )}

                {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.Number) && (
                    <>
                        <Form.Item label="Min Value">
                            {getFieldDecorator('minValue')(<InputNumber readOnly={editOnlyValues} />)}
                        </Form.Item>
                        <Form.Item label="Max Value">
                            {getFieldDecorator('maxValue')(<InputNumber readOnly={editOnlyValues} />)}
                        </Form.Item>
                    </>
                )}

                {(selectedDataTypeCode === '' || selectedDataTypeCode !== DataTypes.List) && (
                    <Form.Item label="Unit of measurement">
                        {getFieldDecorator('unitOfMeasurementCode')(
                            <Select disabled={editOnlyValues}>
                                {unitOfMeasurements.map((r) => (
                                    <Select.Option key={r.code} value={r.code}>
                                        {`${r.description} (${r.name})`}
                                    </Select.Option>
                                ))}
                            </Select>,
                        )}
                    </Form.Item>
                )}

                <Form.Item label="Is required">
                    {getFieldDecorator('isRequired', { valuePropName: 'checked' })(
                        <Switch disabled={editOnlyValues} />,
                    )}
                </Form.Item>
                {!editOnlyValues && (
                    <>
                        <Form.Item label="Change Parent Group"><Checkbox 
                        checked={changeParentGroup}
                        onChange={onChange}
                        ></Checkbox></Form.Item>

                        
                    </>
                )}
                {!editOnlyValues && changeParentGroup && (
                    <>
                    <Form.Item label="LogSheet">
                    
                        <Select onChange={handleLogSheetChange}>
                            {logsheets.map((r) => (
                                <Select.Option key={r.id} value={r.id}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                   </Form.Item>
                    </>
                )}
                {!editOnlyValues && changeParentGroup && (
                    <>
                <Form.Item label='Parent Groups'>
                {getFieldDecorator('groupId')(
                     <Select >
                            {logsheetGroup?.map((r) => (
                                <Select.Option key={r.id!} value={r.id!}>
                                    {r.name!}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
                    </>
                )}

                {editOnlyValues && (
                    <>
                        <Form.Item label="Value">{getFieldDecorator('value')(getValueNode())}</Form.Item>

                        <Form.Item label="Comment">
                            {getFieldDecorator('comment')(<Input.TextArea />)}
                        </Form.Item>
                    </>
                )}
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const TagDrawer = Form.create<Props>()(
    withLegacyFormRef(TagDrawerComponent),
);

export default TagDrawer;
