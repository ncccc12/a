import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Input, Select, Button, Switch } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';
import { DictionaryDto, AreaVm } from '../../services/Client';

export type LogsheetForm = {
    id?: number;
    locationCode?: string;
    areaCode?: string;
    name?: string;
    isActive?: boolean;
};

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {
    filteredAreas: AreaVm[];
};

const LogsheetDrawerComponent: React.FC<Props> = props => {
    const {
        form,
        areas
    } = props;

    const [filteredAreas, setFilteredAreas] = React.useState<AreaVm[]>([]);

    const filterAreas = React.useCallback((locationCode: string) => {
        const filteredAreas = areas.filter(r => r.locationCode === locationCode);
        setFilteredAreas(filteredAreas);
    }, [areas]);

    const handleLocationChange = React.useCallback((locationCode: string) => {
        filterAreas(locationCode);
        form.setFieldsValue({
            areaCode: '',
        });
    }, [filterAreas, form]);

    const isMounted = React.useRef(false);
    const previousPropsRef = React.useRef(props);

    React.useEffect(() => {
        const prevProps = previousPropsRef.current;

        if (!isMounted.current) {
            isMounted.current = true;
        } else {
            if (prevProps.visible === false && props.visible) {
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    filterAreas(locationCode);
                }, 1000);
            }
        }

        previousPropsRef.current = props;
    });

    const {
        visible: visible,
        form: { getFieldDecorator: getFieldDecorator },
        form: form0,
        locations: locations,
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    getFieldDecorator('id');
    let id = form0.getFieldValue('id');

    return (
        <Drawer
            title={id ? 'Edit logsheet' : 'Add new Logsheet'}
            open={visible}
            width={700}
            onClose={props.onClose}
        >
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Location">
                    {getFieldDecorator('locationCode', {
                        rules: [
                            {
                                required: true,
                                message: 'Location is required',
                            },
                        ],
                    })(
                        <Select disabled={!!id} onChange={handleLocationChange}>
                            {locations.map(r => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Area">
                    {getFieldDecorator('areaCode', {
                        rules: [
                            {
                                required: true,
                                message: 'Area is required',
                            },
                        ],
                    })(
                        <Select>
                            {filteredAreas.map(r => (
                                <Select.Option key={r.id} value={r.code}>
                                    {r.name}
                                </Select.Option>
                            ))}
                        </Select>,
                    )}
                </Form.Item>
                <Form.Item label="Name">
                    {getFieldDecorator('name', {
                        rules: [
                            {
                                required: true,
                                whitespace: true,
                                message: 'Name is required',
                            },
                        ],
                    })(<Input />)}
                </Form.Item>

                <Form.Item label="Is active">
                    {getFieldDecorator('isActive', { valuePropName: 'checked' })(<Switch />)}
                </Form.Item>
            </Form>

            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button type="primary" onClick={props.onSubmit}>
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const LogsheetDrawer = Form.create<Props>()(
    withLegacyFormRef(LogsheetDrawerComponent),
);

export default LogsheetDrawer;
