import React from 'react';
import { withLegacyFormRef } from '../../common/components/antd';
import { Drawer, Button, Switch, Input } from 'antd';
import { Form } from '@ant-design/compatible';
import { FormComponentProps } from '@ant-design/compatible/lib/form';

export type UnitOfMeasureForm = {
    id: number;
    name: string;
    code: string;
    description: string;
    isActive: boolean;
}

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps;

type State = {};

const UnitOfMeasurementDrawerComponent: React.FC<Props> = props => {
    const {
        visible: visible,
        form: form,

        form: { getFieldDecorator: getFieldDecorator },
    } = props;

    const formItemLayout = {
        labelCol: {
            span: 10,
        },
        wrapperCol: {
            span: 14,
        },
    };

    getFieldDecorator('id');
    let id = form.getFieldValue('id');

    return (
        <Drawer
            title={id ? 'Edit unit of measurement' : 'Add unit of measurement'}
            open={visible}
            width={500}
            destroyOnHidden={true}
            onClose={props.onClose}
        >
            <Form labelAlign="left" {...formItemLayout}>
                <Form.Item label="Name">
                    {getFieldDecorator('name', {
                        rules: [
                            {
                                required: true,
                                whitespace: true,
                                message: 'Name is required',
                            },
                        ],
                    })(<Input />)}
                </Form.Item>
                <Form.Item label="Code">
                    {getFieldDecorator('code', {
                        rules: [
                            {
                                required: true,
                                whitespace: true,
                                message: 'Code is required',
                            },
                        ],
                    })(<Input />)}
                </Form.Item>
                <Form.Item label="Description">
                    {getFieldDecorator('description')(<Input.TextArea autoSize={{ minRows: 4 }} />)}
                </Form.Item>
                <Form.Item label="Is active">
                    {getFieldDecorator('isActive', { valuePropName: 'checked' })(<Switch disabled={!id} />)}
                </Form.Item>
            </Form>
            <div
                style={{
                    position: 'absolute',
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    borderTop: '1px solid #e9e9e9',
                    padding: '10px 16px',
                    background: '#fff',
                    textAlign: 'right',
                }}
            >
                <Button onClick={props.onClose} style={{ marginRight: 8 }}>
                    Cancel
                </Button>
                <Button onClick={props.onSubmit} type="primary">
                    Submit
                </Button>
            </div>
        </Drawer>
    );
};

const UnitOfMeasurementDrawer = Form.create<Props>()(
    withLegacyFormRef(UnitOfMeasurementDrawerComponent),
);

export default UnitOfMeasurementDrawer;
