# React Router 7 upgrade

- `react-router-dom` upgraded to ^7.9.4; old `@types/react-router-dom` removed.
- Converted root `Switch` to `Routes`, protected screens to `element`, and nested authentication callback routes to React Router 7.
- Replaced obsolete `withRouter` and injected `RouteComponentProps` with a local hook-backed adapter in `src/router/legacy.tsx`. This minimizes changes to existing class-based pages; consider converting these pages to `useNavigate`, `useParams`, and `useLocation` incrementally.
- OAuth callbacks remain at `/authentication/login-callback` and `/authentication/logout-callback`.
- Updated logout navigation state handling for modern React Router.

## Verification still required

No npm registry access in this environment; this is a source migration and **not a verified working build**. Run `npm install`, `npm run typecheck`, `npm run build`, and test login/logout, deep links, back/forward history, dashboard navigation and parameterized detail pages. Existing Ant Design 5 compatibility issues may also block compilation.
