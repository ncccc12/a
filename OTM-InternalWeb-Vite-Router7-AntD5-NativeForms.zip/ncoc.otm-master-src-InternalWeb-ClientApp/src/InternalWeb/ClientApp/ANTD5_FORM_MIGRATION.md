# Ant Design 5 native form migration – source-level conversion

This archive follows the Vite + React Router 7 migration and replaces all occurrences of `Form.create()` and `getFieldDecorator()` in the project source with native Ant Design 5 `Form.Item name={...}` fields.

## What changed
- 197 decorator registrations processed across 35 field-decorating source files; 152 decorator-rendered controls converted to nested `Form.Item noStyle` fields, and registrations without controls replaced. These hidden fields must be reviewed individually for initial state and submissions.
- Existing class components are provided a native `Form.useForm()` instance through `src/modern-form.tsx` instead of using `@ant-design/compatible`. Parent components retain their `wrappedComponentRef` handling.
- Callback-style validation remains bridged by the `modern-form.tsx` facade so the existing submit logic can run without a simultaneous rewrite of all event handlers. This is a transitional adapter, **not** a complete hooks-and-promise rewrite.
- Older DatePicker Moment values, dynamic nested names and validation triggers need manual runtime regression testing. Ant Design 5 uses Day.js for picker values by default.

## Required validation before release
1. `npm install` then `npm run typecheck` and `npm run build` (not available during preparation).
2. Test create/edit/filter forms, hidden fields, field validation and `wrappedComponentRef` in all screens.
3. Test DatePicker/RangePicker behavior, Moment conversions and API serialization. Upgrade to Day.js or configure compatible date pickers.
4. Inspect `Form.Item` nesting and conditional controls; validate that all required fields register while visible.
5. Verify authentication, React Router 7 navigation and API round trips against a development server.

**Status: automated source migration and syntax parse completed, not a validated production-ready conversion.**
