import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// API endpoints are same-origin in production; configure an optional proxy for local development.
export default defineConfig({
  plugins: [react()],
  base: process.env.VITE_BASE_PATH || '/',
  server: {
    port: 3000,
    proxy: process.env.VITE_API_PROXY_TARGET
      ? { '/api': { target: process.env.VITE_API_PROXY_TARGET, changeOrigin: true }, '/_configuration': { target: process.env.VITE_API_PROXY_TARGET, changeOrigin: true } }
      : undefined,
  },
  build: { outDir: 'build', sourcemap: false },
});
