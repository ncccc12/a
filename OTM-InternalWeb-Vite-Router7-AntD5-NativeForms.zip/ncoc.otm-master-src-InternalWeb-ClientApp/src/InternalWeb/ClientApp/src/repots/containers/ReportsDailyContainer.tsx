import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { DatePicker, Button} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';

import fileDownload from 'js-file-download'
import { reportsClient } from '../../services';

type Props = {} & FormComponentProps;

type State = {
    isLoading: boolean;
}

const ReportsDailyContainer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                isLoading: false
            }
        }

        handleFormSubmit = (e: any) => {
            e.preventDefault();
            this.props.form.validateFields(async (errors, values) => {
                if (errors) {
                    return;
                }
                this.setState({
                    isLoading: true
                })
                const response = await reportsClient.getReportByPeriod(values);
                fileDownload(response.data, response.fileName!);
                this.setState({ isLoading: false })
            });
        };
        render(): JSX.Element {
            

            return (
                <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} layout="inline" onFinish={() => (this.handleFormSubmit)({ preventDefault: () => undefined })}>
                    <Form.Item label="Date">
                        {<Form.Item name={'date'} noStyle rules={[
                                {
                                    required: true,
                                    message: 'Please select date',
                                },
                            ]}><DatePicker /></Form.Item>}
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType="submit" loading={this.state.isLoading} type="primary">
                            Export
                        </Button>
                    </Form.Item>
                </Form>
            );
        }
    },
);

export default ReportsDailyContainer;
