import { RouteComponentProps, withRouter } from '../../router/legacy';
import React from 'react';
import { Typography, Table, Button, Tag, Card } from 'antd';
import {
    LogSheetTimeHistoryVm,
    GetLogSheetTimeHistoryQuery,
    DictionaryDto,
    AreaVm,
    GetLogsheetsQuery,
} from '../../services/Client';
import { dictionaryClient, reportsClient, logSheetsClient } from '../../services';
import moment from 'moment';
import { PaginationProps } from 'antd/lib/pagination';
import { connect } from 'react-redux';
import {
    ReportsHistoryFilterFormState,
    changeFilterForm,
    changePage,
    changePageSize,
    expandFilterForm,
    resetFilterForm,
} from '../ducks/ReportsHistoryFilterFormDuck';
import { AppState } from '../../store/reducers';
import FilterPanel from '../components/FilterPanel';
import { Link } from 'react-router-dom';

type State = {
    isLoading: boolean;
    data: LogSheetTimeHistoryVm[];
    logSheetsOptions: LogSheetTimeHistoryVm[];
    locations: DictionaryDto[];
    areas: AreaVm[];
    total: number;
    fetchData: boolean;
};

const mapStateToProps = (state: AppState): ReportsHistoryFilterFormState => ({
    filterForm: state.reportsHistoryFilterFormDuck.filterForm,
    isFilterFormExpanded: state.reportsHistoryFilterFormDuck.isFilterFormExpanded,
});

const mapDispatchToProps = {
    changeFilterForm,
    changePage,
    resetFilterForm,
    expandFilterForm,
    changePageSize,
};

type Props = {} & typeof mapDispatchToProps & ReportsHistoryFilterFormState & RouteComponentProps<any>;

const HistoryContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                isLoading: false,
                fetchData: false,
                data: [],
                locations: [],
                logSheetsOptions: [],
                areas: [],
                total: 0,
            };
        }

        loadLogSheetsHistory = async () => {
            this.setState({ isLoading: true });
            const { filterForm } = this.props;
            var formData = new GetLogSheetTimeHistoryQuery();
            formData.init(filterForm);
            formData.startDate = filterForm.startDate?.utc(true).startOf("day").toDate();
            formData.endDate = filterForm.endDate?.utc(true).endOf("day").toDate();
           
            const result = await reportsClient.getLogSheetTimeHistories(formData);
            this.setState({
                data: result.data!,
                total: result.total!,
                isLoading: false,
            });
        };

        loadDictionaries = async () => {
            this.setState({ isLoading: true });
            const locations = await dictionaryClient.getLocations();
            const areas = await dictionaryClient.getAreas();

            let query = new GetLogsheetsQuery();

            const logSheetsOptions = await logSheetsClient.getLogsheets(query);

            this.setState({
                locations,
                areas,
                logSheetsOptions,
                isLoading: false,
            });
        };

        componentDidMount() {
            this.setState({ fetchData: true });
            this.loadDictionaries();
        }

        async componentDidUpdate(prevProps: Props, prevState: State): Promise<void> {
            if (this.state.fetchData) {
                this.setState({ fetchData: false });
                await this.loadLogSheetsHistory();
            }
        }

        handlePageChange = (page: number) => {
            this.props.changePage(page);
            this.setState({ fetchData: true });
        };

        handleSearch = (e: any): void => {
            e.preventDefault();
            this.setState({ fetchData: true });
        };

        handleReset = (): void => {
            this.props.resetFilterForm();
            this.setState({ fetchData: true });
        };

        render(): JSX.Element {
            const paginationConfig: PaginationProps = {
                current: this.props.filterForm.current,
                pageSize: 10,
                onChange: this.handlePageChange,
                total: this.state.total,
            };

            return (
                <Card title={<Typography.Title>General reports</Typography.Title>}>
                    <FilterPanel
                        onExpand={this.props.expandFilterForm}
                        onReset={this.handleReset}
                        onSubmit={this.handleSearch}
                        total={this.state.total}
                        locations={this.state.locations}
                        areas={this.state.areas}
                        logSheetsOptions={this.state.logSheetsOptions}
                        onChange={this.props.changeFilterForm}
                        isFilterFormExpanded={this.props.isFilterFormExpanded}
                        filterForm={this.props.filterForm}
                    />
                    <Table
                        dataSource={this.state.data}
                        loading={this.state.isLoading}
                        expandRowByClick={true}
                        pagination={paginationConfig}
                        rowKey={(i: LogSheetTimeHistoryVm) => i.id!.toString()}
                    >
                        <Table.Column dataIndex="id" title="#" />
                        <Table.Column dataIndex="logSheetName" title="Log sheet name" />
                        <Table.Column dataIndex="areaName" title="Area" />
                        <Table.Column dataIndex="locationName" title="Location" />
                        <Table.Column
                            key="date"
                            dataIndex="date"
                            title="Date"
                            render={(i: Date) => {
                                return moment(i).format('DD-MM-YYYY');
                            }}
                        />
                        <Table.Column
                            key="time"
                            dataIndex="date"
                            title="Time"
                            render={(i: Date) => {
                                return moment(i).format('HH:mm');
                            }}
                        />
                        <Table.Column
                            key="report"
                            title=""
                            width={100}
                            render={(i: LogSheetTimeHistoryVm) => {
                                return (
                                    <span>
                                        {i!.hasExceedance && (
                                            <Tag style={{ marginBottom: 2 }} color="red">
                                                Exceedance
                                            </Tag>
                                        )}
                                        {i!.hasCompliance && <Tag color="orange">Compliance</Tag>}
                                    </span>
                                );
                            }}
                        />
                        <Table.Column
                            key="actions"
                            title=""
                            render={(i: LogSheetTimeHistoryVm) => {
                                return (
                                    <Link to={`/reports/general/${i.id}`}>
                                        <Button type="primary">View details</Button>
                                    </Link>
                                );
                            }}
                        />
                    </Table>
                </Card>
            );
        }
    },
);

export default withRouter(HistoryContainer);
