import { DatePicker } from 'antd';
import { WrappedFormUtils } from '../../legacy-form-types';
import moment from 'moment';
import React from 'react';

type Props = {
    form: WrappedFormUtils<any>;
    startDateFieldName: string;
    endDateFieldName: string;
};

type State = {
    endOpen: boolean;
};

export default class PeriodDatePicker extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);

        this.state = {
            endOpen: false,
        };
    }

    public disabledStartDate = (startValue?: moment.Moment | null): boolean => {
        const { getFieldValue } = this.props.form;
        const endValue = getFieldValue(this.props.endDateFieldName);
        if (!startValue || !endValue) {
            return false;
        }

        return startValue.valueOf() > endValue.valueOf();
    };

    public disabledEndDate = (endValue?: moment.Moment | null): boolean => {
        const { getFieldValue } = this.props.form;
        const startValue = getFieldValue(this.props.startDateFieldName);
        if (!endValue || !startValue) {
            return false;
        }

        return endValue.valueOf() <= startValue.valueOf();
    };

    public handleStartOpenChange = (open: boolean): void => {
        if (!open) {
            this.setState({ endOpen: true });
        }
    };

    public handleEndOpenChange = (open: boolean): void => {
        this.setState({ endOpen: open });
    };

    public render(): JSX.Element {
        const { endOpen } = this.state;
        

        return (
            <div>
                {<Form.Item name={this.props.startDateFieldName} noStyle>
                    <DatePicker
                        disabledDate={this.disabledStartDate}
                        placeholder="Select start date"
                        onOpenChange={this.handleStartOpenChange}
                    />,
                </Form.Item>}
                &nbsp;
                {<Form.Item name={this.props.endDateFieldName} noStyle>
                    <DatePicker
                        disabledDate={this.disabledEndDate}
                        placeholder="Select end date"
                        open={endOpen}
                        onOpenChange={this.handleEndOpenChange}
                    />,
                </Form.Item>}
            </div>
        );
    }
}
