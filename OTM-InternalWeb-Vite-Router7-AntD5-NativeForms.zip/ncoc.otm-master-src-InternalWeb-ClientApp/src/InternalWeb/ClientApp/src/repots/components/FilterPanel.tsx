import { withModernForm, modernFormField } from '../../modern-form';
import { Button, Collapse, Select} from 'antd';
import Icon from '../../LegacyIcon';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { OptionProps } from 'antd/lib/select';
import React from 'react';
import { AllYesNoSelectOptions } from '../../constants';
// import { AdminFolderFilterForm, FolderStructure } from '../../models';
import PeriodDatePicker from './PeriodDatePicker';
import { ReportsHistoryFilterFormModel } from '../models/reportsHistoryModels';
import { DictionaryDto, AreaVm, LogSheetVm } from '../../services/Client';
const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

type Props = {
    total?: number;
    filterForm: ReportsHistoryFilterFormModel;
    isFilterFormExpanded: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logSheetsOptions: LogSheetVm[];
    onChange: (values: ReportsHistoryFilterFormModel) => void;
    onSubmit: (e: any) => void;
    onReset: () => void;
    onExpand: () => void;
} & FormComponentProps;

const FilterPanel = withModernForm<Props>({
    mapPropsToFields(props: Props): any {
        return {
            logSheetId: modernFormField({
                value: props.filterForm.logSheetId,
            }),
            areaId: modernFormField({
                value: props.filterForm.areaId,
            }),
            locationId: modernFormField({
                value: props.filterForm.locationId,
            }),
            startDate: modernFormField({
                value: props.filterForm.startDate,
            }),
            endDate: modernFormField({
                value: props.filterForm.endDate,
            }),
            hasExceedance: modernFormField({
                value: props.filterForm.hasExceedance,
            }),
            hasCompliance: modernFormField({
                value: props.filterForm.hasCompliance,
            }),
        };
    },
    onValuesChange(props: Props, values: ReportsHistoryFilterFormModel): void {
        props.onChange(values);
    },
})(
    (props: Props): JSX.Element => {
        const activeKey = props.isFilterFormExpanded ? '1' : '';
        const { getFieldValue } = props.form;
        const allYesNoOptions = AllYesNoSelectOptions.map((item: OptionProps) => (
            <Select.Option key={item.value} value={item.value}>
                {item.title}
            </Select.Option>
        ));
        const selectedLocationId = getFieldValue('locationId');
        const selectedAreaId = getFieldValue('areaId');
        let logSheets = props.logSheetsOptions;
        if (selectedLocationId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.locationId === selectedLocationId);
        }
        if (selectedAreaId !== undefined) {
            logSheets = logSheets.filter((item: LogSheetVm) => item.areaId === selectedAreaId);
        }
        const logSheetsOptions = logSheets.map((item: LogSheetVm) => (
            <Select.Option key={item.id} value={item.id}>
                {item.name}
            </Select.Option>
        ));

        return (
            <Collapse
                onChange={props.onExpand}
                accordion={true}
                defaultActiveKey={activeKey}
                expandIconPosition="right"
                style={{ marginBottom: '10px' }}
            >
                <Collapse.Panel
                    header={
                        <b>
                            <Icon type="search" /> Search panel
                        </b>
                    }
                    key="1"
                    extra={<b style={{ color: '#1890ff' }}>Found {props.total} items</b>}
                >
                    <Form onValuesChange={(props as any).__onValuesChange} form={props.form} layout="horizontal" onFinish={() => (props.onSubmit)({ preventDefault: () => undefined })}>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Location"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {<Form.Item name={'locationId'} noStyle>
                                            <Select placeholder="Select location">
                                                {props.locations.map((item: DictionaryDto) => (
                                                    <Select.Option key={item.id} value={item.id}>
                                                        {item.name}
                                                    </Select.Option>
                                                ))}
                                            </Select>,
                                        </Form.Item>}
                                    </Form.Item>
                                </div>
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Area"
                                        labelAlign="left"
                                        {...formItemLayout}
                                        help="Please select location first"
                                    >
                                        {<Form.Item name={'areaId'} noStyle>
                                            <Select placeholder="Select area">
                                                {props.areas
                                                    .filter((i: AreaVm) => i.locationId === selectedLocationId)
                                                    .map((item: AreaVm) => (
                                                        <Select.Option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </Select.Option>
                                                    ))}
                                            </Select>,
                                        </Form.Item>}
                                    </Form.Item>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Log sheet"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {<Form.Item name={'logSheetId'} noStyle>
                                            <Select
                                                placeholder="Select log sheet"
                                                showSearch
                                                filterOption={(input: string, option: any) => {
                                                    return (
                                                        option.props.children
                                                            .toLowerCase()
                                                            .indexOf(input.toLowerCase()) >= 0
                                                    );
                                                }}
                                            >
                                                {logSheetsOptions}
                                            </Select>,
                                        </Form.Item>}
                                    </Form.Item>
                                </div>
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Schedule date"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        <PeriodDatePicker
                                            form={props.form}
                                            startDateFieldName="startDate"
                                            endDateFieldName="endDate"
                                        />
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Has exceedance?"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {<Form.Item name={'hasExceedance'} noStyle><Select>{allYesNoOptions}</Select></Form.Item>}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 form-horizontal">
                                    <Form.Item
                                        className="searchFormItem"
                                        label="Has compliance?"
                                        labelAlign="left"
                                        {...formItemLayout}
                                    >
                                        {<Form.Item name={'hasCompliance'} noStyle><Select>{allYesNoOptions}</Select></Form.Item>}
                                    </Form.Item>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-6 col-xs-12 pull-right">
                                    <Button.Group className="pull-right">
                                        <Button type="primary" htmlType="submit">
                                            Search
                                        </Button>
                                        <Button onClick={props.onReset}>Reset</Button>
                                    </Button.Group>
                                </div>
                            </div>
                        </div>
                    </Form>
                </Collapse.Panel>
            </Collapse>
        );
    },
);
export default FilterPanel;
