import { RouteComponentProps } from '../../router/legacy';
import React from 'react';
import ReportsViewHistoryDetailsContainer from '../containers/ReportsViewHistoryDetailsContainer';


type Params = {
    id: string;
};

export default (props: RouteComponentProps<Params>): JSX.Element => (
    <ReportsViewHistoryDetailsContainer id={parseInt(props.match.params.id)} />
);
