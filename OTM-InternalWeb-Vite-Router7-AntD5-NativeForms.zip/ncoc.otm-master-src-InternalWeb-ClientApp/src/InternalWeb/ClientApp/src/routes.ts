import DashboardContainer from './dashboard/DashboardContainer';
import { LegacyRouteProps as RouteProps } from './router/legacy';
import ScheduleRoutes from './schedule/routes';
import DictionaryRoutes from './dictionary/routes';
import LogsheetsRoutes from './logsheets/routes';
import ReportsRoutes from './repots/routes';
import CommonRoutes from './common/routes';
import ExceedanceRoutes from './exceedances/routes'

const routes: RouteProps[] = [
    {
        path: '/',
        component: DashboardContainer,
        exact: true,
    },
    ...CommonRoutes,
    ...ReportsRoutes,
    ...ScheduleRoutes,
    ...DictionaryRoutes,
    ...LogsheetsRoutes,
    ...ExceedanceRoutes,

];

export default routes;
