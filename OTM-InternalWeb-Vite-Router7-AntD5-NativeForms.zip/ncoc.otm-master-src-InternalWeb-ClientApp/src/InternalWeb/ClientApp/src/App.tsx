import './App.css';
import './common/axiosConfig';

import React from 'react';
import { Route, Routes, BrowserRouter } from 'react-router-dom';
import routes from './routes';
import moment from 'moment';
import PageTemplate from './pages/PageTemplate';
import { Provider } from 'react-redux';
import configureStore from './store/configureStore';
import AuthorizeRoute from './common/components/api-authorization/AuthorizeRoute';
import { ApplicationPaths } from './common/components/api-authorization/ApiAuthorizationConstants';
import ApiAuthorizationRoutes from './common/components/api-authorization/ApiAuthorizationRoutes';
import { ConfigProvider } from 'antd';
import en_US from 'antd/es/locale/en_US';


const baseUrl = import.meta.env.BASE_URL;
const store = configureStore();

const custom__antd_en_US = {
    ...en_US,
    DatePicker: {
        // format datePicker date to whatever you want
        ...en_US.DatePicker,
        dateFormat: 'DD-MM-YYYY',
    },
};

class App extends React.Component {
    public componentDidMount = (): void => {
        moment.updateLocale('en', {
            week: {
                dow: 1,
            },
        } as any);
    };

    public render(): JSX.Element {
        return (
            <ConfigProvider locale={custom__antd_en_US}>
                <BrowserRouter basename={baseUrl}>
                    <Provider store={store}>
                        <PageTemplate>
                            <Routes>
                                {/* {routes.map((i, index) => (
                                <Route key={index} exact={i.exact} path={i.path} component={i.component} />
                            ))} */}
                                {/* <Route component={NotFound} /> */}

                                {routes.map((i: any) => (
                                    <Route key={i.path} path={i.path} element={<AuthorizeRoute component={i.component} />} />
                                ))}

                                <Route path={`${ApplicationPaths.ApiAuthorizationPrefix}/*`} element={<ApiAuthorizationRoutes />} />
                            </Routes>
                        </PageTemplate>
                    </Provider>
                </BrowserRouter>
            </ConfigProvider>
        );
    }
}

export default App;
// export default process.env.NODE_ENV === 'development' ? hot(App) : App;
