import { RouteComponentProps } from '../../router/legacy';
import React from 'react';
import { Card, Typography, Descriptions, Row, Button, Table, Tag, Popconfirm, message, Alert, Tabs, Spin } from 'antd';
import { logSheetsClient, dictionaryClient } from '../../services';

import {
    LogSheetVm,
    GroupDto,
    DictionaryDto,
    ListTypeValueVm,
    DeleteTagCommand,
    EditTagCommand,
    AddNewTagCommand,
    AddNewLogsheetGroupCommand,
    DeleteLogsheetGroupCommand,
    AreaVm,
    EditLogsheetCommand,
    ReorderLogsheetCommand,
    GetLogsheetsQuery,
    LogsheetListItemVm,
} from '../../services/Client';
import moment from 'moment';
import TagDrawer, { TagForm } from '../components/TagDrawer';
import { WrappedFormUtils } from '../../legacy-form-types';
import LogsheetDetailsForm from '../components/LogsheetDetailsForm';
import logsheetService from '../LogsheetsService';
import GroupDrawer from '../components/GroupDrawer';
import DeviceListModal from '../components/DeviceListModal';
import ButtonGroup from 'antd/lib/button/button-group';
import LogsheetDrawer, { LogsheetForm } from '../components/LogsheetDrawer';
import { type } from 'os';
import { SearchForm } from '../components/LogsheetsFilterForm';

export type DeviceTag = {
    groupId?: number;
    groupName?: string;
    id?: number;
    name?: string;
    description?: string;
    minValue?: number;
    maxValue?: number;
    listTypeCode?: string;
    listTypeName?: string;
    listTypeValues?: (string | undefined)[];
    unitOfMeasurementCode?: string;
    unitOfMeasurementName?: string;
    dataTypeCode?: string;
    dataTypeName?: string;
    isRequired?: boolean;
    changeStatus?: string;
  
    taskValueId?: number;
    value?: any;
    comment?: string;
    isExceed?: boolean;
    hasAttachments?: boolean;
    attachment?: any;
    isSkipped?: boolean;
    order?: number;
};

type ReorderLogsheet={
    id?: number
    groupDto?: GroupDto | undefined;
}

type GroupForm = {
    parentGroup: { id: number; name: string };
    id: number;
    groupName: string;
    isDevice: boolean;
    isParentLogsheet: boolean;
};

type Params = {
    id: string;
};

type Props = {} & RouteComponentProps<Params>;
type State = {
    logsheet?: LogSheetVm;
    tomorrowLogsheet?: LogSheetVm;
    loading: boolean;
    tagDrawerShown: boolean;
    groupDrawerShwon: boolean;
    deviceModalShown: boolean;
    dataTypes: DictionaryDto[];
    listTypes: DictionaryDto[];
    listTypeValues: ListTypeValueVm[];
    unitOfMeasurements: DictionaryDto[];
    selectedGroups: Array<{ id: number; name: string }>;
    selectedGroup?: GroupDto;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logsheetDrawerShown: boolean;
    logsheets:LogsheetListItemVm[]

};

class LogsheetDetailsContainer extends React.Component<Props, State> {
    tagDrawerRef: any;
    groupDrawerRef: any;
    logsheetDrawerRef: any;

    constructor(props: Props) {
        super(props);
        this.state = {
            loading: false,
            tagDrawerShown: false,
            groupDrawerShwon: false,
            deviceModalShown: false,
            dataTypes: [],
            listTypes: [],
            listTypeValues: [],
            unitOfMeasurements: [],
            selectedGroups: [],
            locations: [],
            areas: [],
            logsheets:[],
            logsheetDrawerShown: false,
        };
    }

    async componentDidMount() {
        await this.loadDictionaries();
        this.loadData();
        this.search()
    }

    loadDictionaries = async () => {
        let locations = await dictionaryClient.getLocations();
        let areas = await dictionaryClient.getAreas();

        this.setState({ locations, areas });
    };

    loadData = async () => {
        const id = parseInt(this.props.match.params.id);
        let logsheet = await logSheetsClient.getLogsheetForm(id);
        let tomorrowLogsheet = await logSheetsClient.getTomorrowLogsheetForm(id);
        let dataTypes = await dictionaryClient.getDictionary('DataTypes');
        let listTypes = await dictionaryClient.getDictionary('ListTypes');
        let listTypeValues = await dictionaryClient.getListTypeValues();
        let unitOfMeasurements = await dictionaryClient.getDictionary('UnitOfMeasurements');

        let empty = new DictionaryDto();
        empty.code = '-';
        empty.name = '-';

        unitOfMeasurements.unshift(empty);

        this.setState({ logsheet, dataTypes, listTypes, listTypeValues, unitOfMeasurements, tomorrowLogsheet });
    };

    handleDeleteTag = async (row: DeviceTag) => {
        

        try {
            this.setState({ loading: true });
            let command = new DeleteTagCommand();
            command.tagId = row.id;
            await logSheetsClient.deleteTag(command);

            message.success('Successfull');
            await this.loadData();
        } finally {
            this.setState({ loading: false });
        }
    };

    openTagDrawer = (tag: DeviceTag | undefined, parentGroups: Array<{ id: number; name: string }> = []) => {
        const form = this.tagDrawerRef.props.form as WrappedFormUtils<any>;
        

        if (tag) {
           
            const { dataTypeName, listTypeName, unitOfMeasurementName, ...tagValues } = tag;

            form.setFieldsValue({
                ...tagValues,
            });
        } else {
            // add new
            form.resetFields();
            this.setState({ selectedGroups: parentGroups });
        }

        this.setState({ selectedGroups: parentGroups, tagDrawerShown: true });
    };

    openGroupDrawer = (
        parentGroup: { id?: number; name?: string },
        isDevice: boolean = false,
        isLogsheet: boolean = false,
    ) => {
        const form = this.groupDrawerRef.props.form as WrappedFormUtils<any>;

        form.resetFields();
        form.setFieldsValue({
            parentGroup: { id: parentGroup.id, name: parentGroup.name },
            isDevice,
            isParentLogsheet: isLogsheet,
        });

        this.setState({ groupDrawerShwon: true });
    };

    submitTag = () => {
        const form = this.tagDrawerRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: TagForm) => {
            if (err) return;

            try {
                this.setState({ loading: true });

                if (values.id) {
                    let editCommand = new EditTagCommand();
                    editCommand.init(values);
                    await logSheetsClient.editTag(editCommand);
                } else {
                    // add new
                    let addNewCommand = new AddNewTagCommand();
                    addNewCommand.init(values);
                    await logSheetsClient.addNewTag(addNewCommand);
                }

                message.success('Successfully updated');
                await this.loadData();
                this.setState({ tagDrawerShown: false });
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    openLogsheetDrawer = (logsheet: LogSheetVm) => {
        const form = this.logsheetDrawerRef.props.form as WrappedFormUtils<any>;

        form.resetFields();

        let logsheetForm: LogsheetForm = {
            id: logsheet.id,
            areaCode: logsheet.areaCode,
            locationCode: logsheet.locationCode,
            isActive: logsheet.isActive,
            name: logsheet.name,
        };

        form.setFieldsValue({
            ...logsheetForm,
        });

        this.setState({ logsheetDrawerShown: true });
    };

    submitEditLogsheet = () => {
        const form = this.logsheetDrawerRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: LogsheetForm) => {
            if (err) return;

            try {
                this.setState({ loading: true });
                let command = new EditLogsheetCommand();
                command.init(values);
                await logSheetsClient.editLogsheet(command);
                message.success('Successfull');
                await this.loadData();
                this.setState({ logsheetDrawerShown: false });
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    submitGroup = () => {
        const form = this.groupDrawerRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: GroupForm) => {

            if (err) return;

            try {
                this.setState({ loading: true });
                if (values.id) {
                } else {
                    let newCommand = new AddNewLogsheetGroupCommand();
                    newCommand.parentGroupId = values.parentGroup.id;
                    newCommand.groupName = values.groupName;
                    newCommand.isDevice = values.isDevice;
                    newCommand.isParentLogsheet = values.isParentLogsheet;
                    await logSheetsClient.addNewLogsheetGroup(newCommand);
                    message.success('Successfully updated');
                    await this.loadData();
                    this.setState({ groupDrawerShwon: false, deviceModalShown: false });
                }
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    search = async() => {
        //const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
        //form.validateFields(async (err: any, values: SearchForm) => {
            this.setState({ loading: true });

            try {
                let values ={
                    locationCode:undefined,
                    areaCode:undefined,
                    isActive:undefined, 
                }
                let query = new GetLogsheetsQuery();
                query.init(values);
                let logsheets = await logSheetsClient.getLogsheets(query);
                this.setState({ logsheets });
            } finally {
                this.setState({ loading: false });
            }
        //});
    };
    openDeviceList = (parentGroup: GroupDto) => {
        this.setState({ selectedGroup: parentGroup, deviceModalShown: true });
    };

    deleteDevice = async (groupdId: number) => {
        let command = new DeleteLogsheetGroupCommand();
        command.groupId = groupdId;

        try {
            await logSheetsClient.deleteLogsheetGroup(command);
            message.success('Successfull');
            this.setState({ deviceModalShown: false });
            await this.loadData();
        } finally {
        }
    };
    onChangeTaskOrder =(groupdId: number, parentGroup:any , upDown:number)=>{
        
        const maingroup:GroupDto = parentGroup[0]
        let  taskDto
        let  groupDto:GroupDto | undefined = undefined 
        maingroup!.childGroups!.map(
            (x:any)=>
            {x.tasks.map((i:any)=>
                {if(i.id ===groupdId)
            {
                taskDto  = i
                groupDto = x
             } 
            })
        })

             
        let firstItemIndex =groupDto!.tasks?.findIndex(x=>x.id===groupdId)
        let itemLeng = groupDto!.tasks?.length
        let firstItem = groupDto!.tasks![firstItemIndex!]
        let firstItemOrder = firstItem.order
        let selectedGroupArr= this.state.selectedGroup!

        
        if(upDown==2 && itemLeng! - 1){
            let secondItemIndex =firstItemIndex! + 1
            let secondItem = groupDto!.tasks![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
           
            groupDto!.tasks![firstItemIndex!] =secondItem
           // groupDto.tas![firstItemIndex!] = secondItem
            groupDto!.tasks![secondItemIndex!] = firstItem

            let selectedGr = maingroup.childGroups!.map((x:GroupDto)=>{if(x.id === groupDto?.id){
                x=groupDto!
            }})

            this.setState({selectedGroup:maingroup})
           
            

            
            
            //this.setState({selectedGroup:selectedGroupArr})
           
        }
        if(upDown==1 && firstItemIndex != 0){
            let secondItemIndex =firstItemIndex! - 1
            let secondItem = groupDto!.tasks![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
           
            groupDto!.tasks![firstItemIndex!] =secondItem
           // groupDto.tas![firstItemIndex!] = secondItem
            groupDto!.tasks![secondItemIndex!] = firstItem

            let selectedGr = maingroup.childGroups!.map((x:GroupDto)=>{if(x.id === groupDto?.id){
                
                x=groupDto!
            }})

            this.setState({selectedGroup:maingroup})
           
            
        }

        

    }
    changeDeviceIndex =(groupdId: number, upDown:number)=>
    {
        let selectedGroupArr= this.state.selectedGroup!

        let firstItemIndex =this.state.selectedGroup?.childGroups?.findIndex(x=>x.id ===groupdId)
        let itemLeng = this.state.selectedGroup?.childGroups?.length
           
        
        let firstItem = this.state.selectedGroup!.childGroups![firstItemIndex!];
        let firstItemOrder = firstItem.order
        

        if(upDown==2 && firstItemIndex !=itemLeng! -1)
        {
            
            let secondItemIndex =firstItemIndex! + 1
            let secondItem = this.state.selectedGroup!.childGroups![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
           
            if(selectedGroupArr != undefined)
            {
            selectedGroupArr.childGroups![firstItemIndex!] = secondItem
            selectedGroupArr.childGroups![secondItemIndex!] = firstItem
            
            this.setState({selectedGroup:selectedGroupArr})
            }
        }
        if(upDown==1 && firstItemIndex !=0)
        {
            let secondItemIndex =firstItemIndex! - 1
            let secondItem = this.state.selectedGroup!.childGroups![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
            if(selectedGroupArr != undefined)
            {
                selectedGroupArr.childGroups![firstItemIndex!] = secondItem
                selectedGroupArr.childGroups![secondItemIndex!] = firstItem
                this.setState({selectedGroup:selectedGroupArr})
            }
        }   
    }
    onReorderLogsheet =async ()=>{
        
        
        const id = this.state.selectedGroup?.id
        let value:ReorderLogsheet = {
            id:id, 
            groupDto: this.state.selectedGroup
        } 
        try {
            this.setState({ loading: true });
            
            let command = new ReorderLogsheetCommand();
            command.init(value)
            await logSheetsClient.reorderLogsheet(command);
            message.success('Successfull');
            await this.loadData();
            this.setState({ deviceModalShown: false });
        } finally {
            this.setState({ loading: false });
        }
        

    }

    getGroupTree(groups: GroupDto[] | undefined, level: number, parentGroup: GroupDto | undefined): JSX.Element {
        let devices = groups && groups.filter((r) => r.isDevice);

        if (devices && devices.length) {
            let devicesAndGroup = [...devices];

            if (parentGroup) devicesAndGroup.unshift(parentGroup);

            return this.renderTable(devicesAndGroup);
        } else {
            return (
                <>
                    {groups &&
                        groups.map((g: GroupDto) => {
                            // let tags: DeviceTag[] = g.tasks!.map(t => logsheetService.mapTaskDtoToDeviceType(g, t));

                            let hasDevices = g.childGroups && g.childGroups.some((r) => r.isDevice);
                            let lastGroup = hasDevices || (g.childGroups && g.childGroups.length === 0);
                            let hasOnlyTasks = g.childGroups?.length === 0 && g.tasks?.length;

                            return (
                                <Card
                                    key={g.id}
                                    type="inner"
                                    title={g.name}
                                    style={{ margin: '15px 0' }}
                                    extra={
                                        <>
                                            <ButtonGroup>
                                                {!hasDevices && (
                                                    <Button onClick={() => this.openGroupDrawer(g, false)}>
                                                        Add new group
                                                    </Button>
                                                )}
                                                <Popconfirm
                                                    title="Are you sure?"
                                                    onConfirm={() => this.deleteDevice(g.id!)}
                                                    okText="Yes"
                                                    cancelText="No"
                                                >
                                                    <Button type="danger">Remove </Button>
                                                </Popconfirm>
                                            </ButtonGroup>
                                        </>
                                    }
                                >
                                    {/* {tags && tags.length > 0 && this.renderTable(tags)} */}
                                    {lastGroup && (
                                        <>
                                            <Button icon="unordered-list" onClick={() => this.openDeviceList(g)}>
                                                Devices
                                            </Button>
                                            <Button
                                                icon="plus"
                                                style={{ marginLeft: 5 }}
                                                onClick={() => this.openGroupDrawer(g, true)}
                                            >
                                                Add new device
                                            </Button>
                                        </>
                                    )}

                                    {g.childGroups &&
                                        g.childGroups.length > 0 &&
                                        this.getGroupTree(g.childGroups, level + 1, g)}

                                    {hasOnlyTasks && this.renderTable([g])}
                                </Card>
                            );
                        })}
                </>
            );
        }
    }

    renderTable = (groups: GroupDto[]) => {
        let tags: DeviceTag[] = groups.flatMap((r) => {
            return r.tasks!.map((t) => logsheetService.mapTaskDtoToDeviceType(r, t));
        });

        let parentGroups = groups.map((r) => {
            return {
                id: r.id!,
                name: r.name!,
            };
        });

        // let parentGroup = groups.filter(r => r.isDevice === false)[0];

        return (
            <Table
                title={() => (
                    <ButtonGroup>
                        <Button onClick={() => this.openTagDrawer(undefined, parentGroups)}>Add new tag</Button>
                        <Button onClick={() => this.onReorderLogsheet()}>Save Order</Button>
                    </ButtonGroup>
                )}
                dataSource={tags}
                rowKey={(r) => r.id + ''}
                pagination={{ hideOnSinglePage: true }}
            >
                <Table.Column
                    key="status"
                    title="Change status"
                    width={100}
                    render={(r: DeviceTag) => <b>{r.changeStatus}</b>}
                ></Table.Column>
                <Table.Column
                    
                        title="Actions"
                        render={(row: GroupDto) => (<>
                            <Button
                            shape="circle"
                            icon="up-circle"
                            title="up"
                            onClick={() => this.onChangeTaskOrder(row!.id!, groups, 1)}
                        ></Button>{' '}
                       <Button
                            shape="circle"
                            icon="down-circle"
                            title="down"
                            onClick={() => this.onChangeTaskOrder(row!.id!, groups, 2)}
                        ></Button>
                        </>
                        )}
                    ></Table.Column>
                <Table.Column dataIndex="groupName" title="Group/Device name" width={200}></Table.Column>
                <Table.Column dataIndex="name" title="Tag name" width={200}></Table.Column>
                <Table.Column dataIndex="description" title="Description" width={200}></Table.Column>
                <Table.Column dataIndex="dataTypeName" title="Data type"></Table.Column>
                <Table.Column dataIndex="listTypeName" title="List type name" width={100}></Table.Column>
                <Table.Column
                    dataIndex="listTypeValues"
                    title="List type values"
                    key="values"
                    width={150}
                    render={(vals) => (
                        <span>
                            {vals.map((r: string) => (
                                <Tag color="blue" key={r}>
                                    {r}
                                </Tag>
                            ))}
                        </span>
                    )}
                ></Table.Column>
                <Table.Column dataIndex="minValue" title="Min value"></Table.Column>
                <Table.Column dataIndex="maxValue" title="Max value"></Table.Column>
                <Table.Column dataIndex="unitOfMeasurementName" title="Unit of measurement"></Table.Column>
                <Table.Column
                    dataIndex="isRequired"
                    title="Is Required"
                    render={(isRequired: boolean) => (isRequired ? 'Yes' : 'No')}
                ></Table.Column>
                <Table.Column
                    title="Actions"
                    render={(row: DeviceTag) => (
                        <>
                            <Button
                                shape="circle"
                                icon="edit"
                                title="edit"
                                onClick={() => this.openTagDrawer(row, parentGroups)}
                            ></Button>{' '}
                            <Popconfirm
                                title="Are you sure delete this tag?"
                                onConfirm={() => this.handleDeleteTag(row)}
                                okText="Yes"
                                cancelText="No"
                            >
                                <Button
                                    shape="circle"
                                    icon="delete"
                                    style={{ color: 'red', marginTop: 5 }}
                                    title="delete"
                                ></Button>
                            </Popconfirm>
                        </>
                    )}
                ></Table.Column>
            </Table>
        );
    };

    render() {
        const {
            loading,
            tagDrawerShown,
            groupDrawerShwon,
            dataTypes,
            listTypes,
            listTypeValues,
            unitOfMeasurements,
            selectedGroups,
            deviceModalShown,
            selectedGroup,
            areas,
            locations,
            logsheetDrawerShown,
        } = this.state;
        const logsheet = this.state.logsheet;
        const tomorrowLogsheet = this.state.tomorrowLogsheet;
        console.log('Logsheets', this.state.logsheets)

        return (
            <>
                <Tabs defaultActiveKey="1">
                    <Tabs.TabPane tab="Current logsheet" key="1">
                        <Card>
                            <Spin spinning={loading}>
                                <Row type="flex" align="middle" justify="space-between">
                                    <Typography.Title>Logsheet details</Typography.Title>{' '}
                                    <Alert
                                        message="Warning"
                                        description={
                                            <span>
                                                Changes that was made to the logsheet will be applied from{' '}
                                                <b>tomorrow</b> date!
                                            </span>
                                        }
                                        type="warning"
                                        showIcon
                                    />
                                </Row>

                                {logsheet && (
                                    <Card
                                        title={logsheet.name}
                                        extra={
                                            <>
                                                <Button
                                                    onClick={() =>
                                                        this.openGroupDrawer(
                                                            { id: logsheet.id, name: logsheet.name },
                                                            false,
                                                            true,
                                                        )
                                                    }
                                                >
                                                    Add new groups
                                                </Button>
                                                <Button
                                                    type="primary"
                                                    icon="edit"
                                                    style={{ marginLeft: 5 }}
                                                    onClick={() => this.openLogsheetDrawer(logsheet)}
                                                >
                                                    Edit
                                                </Button>
                                            </>
                                        }
                                    >
                                        <Card.Meta
                                            description={
                                                <Descriptions>
                                                    <Descriptions.Item label="Area">
                                                        {logsheet.areaName}
                                                    </Descriptions.Item>
                                                    <Descriptions.Item label="Location">
                                                        {logsheet.locationName}
                                                    </Descriptions.Item>
                                                    <Descriptions.Item label="Created">
                                                        {moment(logsheet.created).format('DD.MM.YYYY HH:mm')}
                                                    </Descriptions.Item>
                                                    <Descriptions.Item label="Created by">
                                                        {logsheet.createdBy}
                                                    </Descriptions.Item>

                                                    <Descriptions.Item label="Last modified">
                                                        {logsheet.lastModified &&
                                                            moment(logsheet.lastModified).format('DD.MM.YYYY HH:mm')}
                                                    </Descriptions.Item>
                                                    <Descriptions.Item label="Last modified by">
                                                        {logsheet.lastModifiedBy}
                                                    </Descriptions.Item>
                                                    <Descriptions.Item label="Is Activr">
                                                        {logsheet.isActive ? 'Yes' : 'No'}
                                                    </Descriptions.Item>
                                                </Descriptions>
                                            }
                                        />
                                        {logsheet && <Row>{this.getGroupTree(logsheet.groups, 0, undefined)}</Row>}
                                    </Card>
                                )}
                            </Spin>

                            <TagDrawer
                                visible={tagDrawerShown}
                                wrappedComponentRef={(ref: any) => (this.tagDrawerRef = ref)}
                                dataTypes={dataTypes}
                                listTypes={listTypes}
                                listTypeValues={listTypeValues}
                                unitOfMeasurements={unitOfMeasurements}
                                groups={selectedGroups}
                                onSubmit={this.submitTag}
                                onClose={() => this.setState({ tagDrawerShown: false })}
                            />
                            <GroupDrawer
                                visible={groupDrawerShwon}
                                wrappedComponentRef={(ref: any) => (this.groupDrawerRef = ref)}
                                onSubmit={this.submitGroup}
                                onClose={() => this.setState({ groupDrawerShwon: false })}
                            />
                            <DeviceListModal
                                visible={deviceModalShown}
                                parentGroup={selectedGroup!}
                                onDeleteDevice={(groupdId) => this.deleteDevice(groupdId)}
                                onChangeIndex={(groupdId, upDown) => this.changeDeviceIndex(groupdId, upDown)}
                                onReorderSave={()=>this.onReorderLogsheet()}
                                onOk={() => this.setState({ deviceModalShown: false })}
                                onAddDevice={(parentGroup: GroupDto) => this.openGroupDrawer(parentGroup, true)}
                            />
                        </Card>
                    </Tabs.TabPane>
                    <Tabs.TabPane tab="Changes to update" key="2">
                        <LogsheetDetailsForm logsheet={tomorrowLogsheet}></LogsheetDetailsForm>
                    </Tabs.TabPane>
                </Tabs>

                <LogsheetDrawer
                    visible={logsheetDrawerShown}
                    areas={areas}
                    locations={locations}
                    wrappedComponentRef={(compRef: any) => (this.logsheetDrawerRef = compRef)}
                    onSubmit={this.submitEditLogsheet}
                    onClose={() => this.setState({ logsheetDrawerShown: false })}
                />
            </>
        );
    }
}

export default LogsheetDetailsContainer;
