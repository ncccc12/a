import React from 'react';
import { Table, Spin, Row, Button, Divider, message } from 'antd';
import {
    DictionaryDto,
    AreaVm,
    GetLogsheetsQuery,
    LogsheetListItemVm,
    AddNewLogsheetCommand,
    EditLogsheetCommand,
    GroupDto,
    LogSheet,
    ReorderLogsheetCommand,
} from '../../services/Client';
import { dictionaryClient, logSheetsClient } from '../../services';
import { Link } from 'react-router-dom';
import LogsheetDrawer, { LogsheetForm } from '../components/LogsheetDrawer';
import { WrappedFormUtils } from '../../legacy-form-types';
import LogsheetsFilterForm, { SearchForm } from '../components/LogsheetsFilterForm';
import { AppState } from '../../store/reducers';
import { LogsheetsFilterFormState, changeFilterForm, resetFilterForm } from '../ducks/LogsheetsFilterDuck';
import { connect } from 'react-redux';

const mapStateToProps = (state: AppState): LogsheetsFilterFormState => ({
    filterForm: state.LogsheetsFilterDuck.filterForm,
});

const mapDispatchToProps = {
    changeFilterForm,
    resetFilterForm,
};
type ReorderLogsheet={
    id?: number
    groupDto?: GroupDto | undefined;
    logSheets?:LogsheetListItemVm[]
}
type Props = {} & typeof mapDispatchToProps & LogsheetsFilterFormState;
type State = {
    loading: boolean;
    logsheets: LogsheetListItemVm[];
    logsheetDrawerShown: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
};

const LogsheetsContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(
    class extends React.Component<Props, State> {
        logsheetDrawerRef: any;
        filterFormRef: any;

        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                logsheets: [],
                logsheetDrawerShown: false,
                locations: [],
                areas: [],
            };
        }

        async componentDidMount() {
            await this.loadDictionaries();
        }

        loadDictionaries = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();

            this.setState({ locations, areas });
        };

        search = () => {
            const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
            form.validateFields(async (err: any, values: SearchForm) => {
                this.setState({ loading: true });

                try {
                    let query = new GetLogsheetsQuery();
                    query.init(values);
                    let logsheets = await logSheetsClient.getLogsheets(query);
                    this.setState({ logsheets });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };

        resetFilter = () => {
            this.props.resetFilterForm();
            this.setState({}, () => {
                this.search();
            });
        };

        submitNewLogsheet = () => {
            const form = this.logsheetDrawerRef.props.form as WrappedFormUtils<any>;

            form.validateFields(async (err: any, values: LogsheetForm) => {
                if (err) return;

                try {
                    this.setState({ loading: true });

                    if (values.id) {
                        let command = new EditLogsheetCommand();
                        command.init(values);
                        await logSheetsClient.editLogsheet(command);
                    } else {
                        let command = new AddNewLogsheetCommand();
                        command.init(values);
                        await logSheetsClient.addNewLogsheet(command);
                    }

                    await this.search();
                    message.success('Successfull');
                    this.setState({ logsheetDrawerShown: false });
                } finally {
                    this.setState({ loading: false });
                }
            });
        };
        onChangeIndex = (groupId:number , upDown:number)=>
        {
            console.log(groupId, upDown)
            let logSheets = this.state.logsheets!
            let firstItemIndex = this.state.logsheets!.findIndex(x=>x.id ==groupId!)
            let itemLeng =this.state.logsheets!.length
            let firstItem = this.state.logsheets![firstItemIndex!];
            let firstItemOrder = firstItem.order

            if(upDown==2 && firstItemIndex !=itemLeng! -1)
        {
            
            let secondItemIndex =firstItemIndex! + 1
            let secondItem = this.state.logsheets![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
           
            if(logSheets != undefined)
            {
                logSheets![firstItemIndex!] = secondItem
                logSheets![secondItemIndex!] = firstItem
            
            this.setState({logsheets:logSheets})
            }
        }
        if(upDown==1 && firstItemIndex !=0)
        {
            let secondItemIndex =firstItemIndex! - 1
            let secondItem = this.state.logsheets![secondItemIndex];
            firstItem.order = secondItem.order
            secondItem.order = firstItemOrder
            
            if(logSheets != undefined)
            {
                logSheets![firstItemIndex!] = secondItem
                logSheets![secondItemIndex!] = firstItem
                this.setState({logsheets:logSheets})
            }
        }
        }
        onReorderLogsheet = async ()=>{
        
        
            const id = undefined;
            let logsheet= this.state.logsheets.map(x=>x)
            console.log(logsheet)
            let value:ReorderLogsheet =
            {
                logSheets:logsheet
            }
            try {
                this.setState({ loading: true });
                console.log(value)
                let command = new ReorderLogsheetCommand();
                command.init(value)
                console.log(command)
                await logSheetsClient.reorderLogsheet(command);
                message.success('Successfull');
                
                
            } finally {
                this.setState({ loading: false });
            }
            
    
        }

        openLogsheetDrawer = (logsheet: LogsheetListItemVm | undefined) => {
            const form = this.logsheetDrawerRef.props.form as WrappedFormUtils<any>;

            form.resetFields();

            if (logsheet) {
                let logsheetForm: LogsheetForm = {
                    id: logsheet.id,
                    areaCode: logsheet.areaCode,
                    locationCode: logsheet.locationCode,
                    name: logsheet.name,
                    isActive: logsheet.isActive,
                };
                form.setFieldsValue({
                    ...logsheetForm,
                });
            }

            this.setState({ logsheetDrawerShown: true });
        };

        initFilter = (ref: any) => {
            if (ref) {
                this.filterFormRef = ref;
                this.search();
            }
        };

        renderActions = (logsheet: LogsheetListItemVm) => {
            return (
                <>
                    <Link to={`/logsheets/details/${logsheet.id}`}>
                        <Button icon="info-circle" title="View details"></Button>
                    </Link>
                    <Button
                        icon="edit"
                        style={{ marginLeft: 5 }}
                        shape="circle"
                        onClick={() => this.openLogsheetDrawer(logsheet)}
                    ></Button>
                </>
            );
        };

        render() {
            const { loading, logsheets, logsheetDrawerShown, locations, areas } = this.state;
            const { filterForm } = this.props;
            console.log('Logsheets ', logsheets)

            return (
                <Spin spinning={loading}>
                    <LogsheetsFilterForm
                        wrappedComponentRef={this.initFilter}
                        locations={locations}
                        areas={areas}
                        searchForm={filterForm}
                        onSearch={this.search}
                        onReset={this.resetFilter}
                        onChange={this.props.changeFilterForm}
                    />
                <Button onClick={()=>this.onReorderLogsheet()}> Save Order</Button>
                    <Divider />

                    <Row>
                        <Table
                            dataSource={logsheets}
                            rowKey={(r) => r.id + ''}
                            title={() => (
                                <Button onClick={() => this.openLogsheetDrawer(undefined)}> Add new logsheet </Button>
                            )}
                            bordered
                        >   <Table.Column
                    
                        title="Actions"
                        render={(row: GroupDto) => (<>
                            <Button
                            shape="circle"
                            icon="up-circle"
                            title="edit"
                            onClick={() => this.onChangeIndex(row!.id!, 1)}
                        ></Button>{' '}
                       <Button
                            shape="circle"
                            icon="down-circle"
                            title="edit"
                            onClick={() => this.onChangeIndex(row!.id!, 2)}
                        ></Button>
                        </>
                        )}
                    ></Table.Column>
                            <Table.Column dataIndex="location" title="Location"></Table.Column>
                            <Table.Column dataIndex="area" title="Area"></Table.Column>
                            <Table.Column dataIndex="name" title="Name"></Table.Column>
                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive) => (isActive ? 'Yes' : 'No')}
                            ></Table.Column>
                            <Table.Column
                                title="Actions"
                                align="center"
                                render={(ls) => this.renderActions(ls)}
                            ></Table.Column>
                        </Table>
                    </Row>

                    <LogsheetDrawer
                        visible={logsheetDrawerShown}
                        wrappedComponentRef={(ref: any) => (this.logsheetDrawerRef = ref)}
                        locations={locations}
                        areas={areas}
                        onSubmit={this.submitNewLogsheet}
                        onClose={() => this.setState({ logsheetDrawerShown: false })}
                    />
                </Spin>
            );
        }
    },
);

export default LogsheetsContainer;
