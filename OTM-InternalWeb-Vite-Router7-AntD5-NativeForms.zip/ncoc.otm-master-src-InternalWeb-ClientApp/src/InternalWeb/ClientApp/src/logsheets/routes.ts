import LogsheetsPage from './pages/LogsheetsPage';
import LogsheetDetailsContainer from './containers/LogsheetDetailsContainer';

import { LegacyRouteProps as RouteProps } from '../router/legacy';
import UnitOfMeasurementsContainer from '../logsheets/containers/UnitOfMeasurementsContainer';
import ListTypesContainer from '../logsheets/containers/ListTypesContainer';

const routes: RouteProps[] = [
    {
        path: '/logsheets',
        component: LogsheetsPage,
        exact: true,
    },
    {
        path: '/logsheets/details/:id',
        component: LogsheetDetailsContainer,
        exact: true,
    },
    {
        path: '/logsheets/uom',
        component: UnitOfMeasurementsContainer,
        exact: true,
    },
    {
        path: '/logsheets/list-types',
        component: ListTypesContainer,
        exact: true,
    },
];

export default routes;
