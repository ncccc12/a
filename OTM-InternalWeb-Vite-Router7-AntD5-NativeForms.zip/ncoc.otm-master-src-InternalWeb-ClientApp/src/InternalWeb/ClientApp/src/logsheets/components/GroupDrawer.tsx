import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Input, Button, Switch} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {};

const GroupDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        render() {
            const {
                visible,
                
                form,
            } = this.props;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            void 0;

            let id = form.getFieldValue('id');
            let isDevice = form.getFieldValue('isDevice');
            void 0;

            let title = '';
            if (id) {
                title = isDevice ? 'Edit device' : 'Edit group';
            } else {
                title = isDevice ? 'Add device' : 'Add group';
            }

            return (
                <Drawer title={title} visible={visible} width={700} onClose={this.props.onClose}>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Parent group">
                            {<Form.Item name={'parentGroup.name'} noStyle><Input readOnly /></Form.Item>}
                        </Form.Item>
                        <Form.Item label={isDevice ? 'Device name' : 'Group name'}>
                            {<Form.Item name={'groupName'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Name is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Is Device">
                            {<Form.Item name={'isDevice'} noStyle valuePropName={'checked'}><Switch disabled /></Form.Item>}
                        </Form.Item>
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default GroupDrawer;
