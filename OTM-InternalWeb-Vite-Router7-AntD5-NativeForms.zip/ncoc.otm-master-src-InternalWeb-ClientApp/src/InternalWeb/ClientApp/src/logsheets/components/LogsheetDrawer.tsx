import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Input, Select, Button, Switch} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { DictionaryDto, AreaVm } from '../../services/Client';

export type LogsheetForm = {
    id?: number;
    locationCode?: string;
    areaCode?: string;
    name?: string;
    isActive?: boolean;
};

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;
type State = {
    filteredAreas: AreaVm[];
};

const LogsheetDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredAreas: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            if (prevProps.visible === false && this.props.visible) {
                const { form } = this.props;
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    this.filterAreas(locationCode);
                }, 1000);
            }
        }

        handleLocationChange = (locationCode: string) => {
            const { form } = this.props;

            this.filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
            });
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;
            const filteredAreas = areas.filter(r => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        render() {
            const {
                visible,
                
                form,
                locations,
            } = this.props;

            const { filteredAreas } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            let id = form.getFieldValue('id');

            return (
                <Drawer
                    title={id ? 'Edit logsheet' : 'Add new Logsheet'}
                    visible={visible}
                    width={700}
                    onClose={this.props.onClose}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Location">
                            {<Form.Item name={'locationCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Location is required',
                                    },
                                ]}>
                                <Select disabled={!!id} onChange={this.handleLocationChange}>
                                    {locations.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Area">
                            {<Form.Item name={'areaCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Area is required',
                                    },
                                ]}>
                                <Select>
                                    {filteredAreas.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Name">
                            {<Form.Item name={'name'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Name is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>

                        <Form.Item label="Is active">
                            {<Form.Item name={'isActive'} noStyle valuePropName={'checked'}><Switch /></Form.Item>}
                        </Form.Item>
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default LogsheetDrawer;
