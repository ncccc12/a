import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Button, Switch, Input} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';

export type ListTypeValueForm = {
    listTypeId: number;
    id: number;
    name: string;
    code: string;
    description: string;
    isExceed: boolean;
    isActive: boolean;
};

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps;
type State = {};

const ListTypeValueDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        render() {
            const {
                visible,
                form,
                
            } = this.props;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            let id = form.getFieldValue('id');

            void 0;

            return (
                <Drawer
                    title={id ? 'Edit list type value' : 'Add list type value'}
                    visible={visible}
                    width={500}
                    destroyOnClose={true}
                    onClose={this.props.onClose}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Name">
                            {<Form.Item name={'name'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Name is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Code">
                            {<Form.Item name={'code'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Code is required',
                                    },
                                ]}><Input disabled={id} /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Description">
                            {<Form.Item name={'description'} noStyle><Input.TextArea autoSize={{ minRows: 4 }} /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Is exceed">
                            {<Form.Item name={'isExceed'} noStyle valuePropName={'checked'}><Switch /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Is active">
                            {<Form.Item name={'isActive'} noStyle valuePropName={'checked'}><Switch /></Form.Item>}
                        </Form.Item>
                    </Form>
                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button onClick={this.props.onSubmit} type="primary">
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default ListTypeValueDrawer;
