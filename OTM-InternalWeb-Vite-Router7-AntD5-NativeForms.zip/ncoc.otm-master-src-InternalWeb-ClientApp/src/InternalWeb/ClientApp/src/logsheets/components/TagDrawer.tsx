import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Input, Select, Tag, InputNumber, Button, Switch, Checkbox} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { DictionaryDto, GetLogsheetsQuery, GroupDto, ListTypeValueVm, LogSheetVm, LogsheetListItemVm } from '../../services/Client';
import { DataTypes } from '../models';
import { logSheetsClient } from '../../services';
import { values } from 'lodash';

export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    dataTypes: DictionaryDto[];
    listTypes: DictionaryDto[];
    listTypeValues: ListTypeValueVm[];
    unitOfMeasurements: DictionaryDto[];
    groups: Array<{ id: number; name: string }>;
    editOnlyValues?: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredLisTypeValues: ListTypeValueVm[];
    selectedDataTypeCode: string;
    changeParentGroup: boolean;
    logsheetGroup?:GroupDto[];
    logsheets:LogsheetListItemVm[]
};

const TagDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredLisTypeValues: [],
                selectedDataTypeCode: '',
                changeParentGroup:false,
                logsheets:[],
            };
        }
        componentDidMount(): void {
            this.search()
        }

        componentDidUpdate(prevProps: Props, prevState: State) {
            const { form } = this.props;
            

            if (!prevProps.visible && this.props.visible) {
                let listTypeCode = form.getFieldValue('listTypeCode');
                let dataTypeCode = form.getFieldValue('dataTypeCode');
                
                this.handleDataType(dataTypeCode);
                this.handleListTypeChange(listTypeCode);
            } else if (!this.props.visible && this.state.selectedDataTypeCode !== '') {
                
                this.setState({ selectedDataTypeCode: '' });
            }
        }

        search = async() => {
            //const form = this.filterFormRef.props.form as WrappedFormUtils<any>;
            //form.validateFields(async (err: any, values: SearchForm) => {
                
    
                try {
                    let values ={
                        locationCode:undefined,
                        areaCode:undefined,
                        isActive:undefined, 
                    }
                    let query = new GetLogsheetsQuery();
                    query.init(values);
                    let logsheets = await logSheetsClient.getLogsheets(query);
                    console.log('func', logsheets)
                    this.setState({ logsheets });
                } finally {
                    
                }
            //});
        };

        handleListTypeChange = (code: string) => {
            
            const { listTypeValues } = this.props;

            let filteredValues = listTypeValues.filter((r) => r.listTypeCode === code);
            this.setState({ filteredLisTypeValues: filteredValues });
        };

        handleDataType = (code: string, callback?: () => void) => {
            this.setState({ selectedDataTypeCode: code }, callback);
        };

        onChange = (e:any) => {
            console.log('checked = ', e.target.checked);
            this.setState({
              changeParentGroup: e.target.checked,
            });
          };
        

        getValueNode = () => {
            const { selectedDataTypeCode, filteredLisTypeValues } = this.state;
            let valueNode;
            if (selectedDataTypeCode === DataTypes.List) {
                valueNode = (
                    <Select>
                        {filteredLisTypeValues.map((r) => {
                            return (
                                <Select.Option value={r.code} key={r.code}>
                                    {r.name}
                                </Select.Option>
                            );
                        })}
                    </Select>
                );
            } else if (selectedDataTypeCode === DataTypes.Number) {
                valueNode = <InputNumber />;
            } else {
                valueNode = <Input />;
            }

            return valueNode;
        };
        handleLogSheetChange = (value: number) => {
            this.logsheetGroup(value);
            this.props.form.setFieldsValue({
                areaCodes: [],
            });
        };
        logsheetGroup = async(value:number)=>{
            let groups:GroupDto[] = [];
            let finalGroup:GroupDto[]=[];
            let logsheet = await logSheetsClient.getLogsheetForm(value);
            logsheet.groups?.map((x)=>(groups!.push(x) && finalGroup.push(x)))
            if(groups != null && groups.length>0){
               groups.map(r=>r.childGroups?.map(i=>finalGroup.push(i)))
            }
            console.log(finalGroup)
            this.setState({logsheetGroup:finalGroup})
        }
        

        render() {
            const {
                visible,
                
                form,
                dataTypes,
                listTypes,
                unitOfMeasurements,
                groups,
                editOnlyValues,
                
            } = this.props;
            const { filteredLisTypeValues, selectedDataTypeCode, logsheets } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            let id = form.getFieldValue('id');

            void 0;
            void 0;
            console.log('logsheet', logsheets)
            console.log('logsheetGroup', this.state.logsheetGroup)

            let title = editOnlyValues ? 'Edit tag values' : id ? 'Edit tag' : 'Add new tag';

            return (
                <Drawer title={title} visible={visible} width={700} onClose={this.props.onClose}>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Group/Device name" >
                            {<Form.Item name={'groupId'} noStyle>
                                <Select disabled={editOnlyValues || this.state.changeParentGroup}>
                                    {groups.map((r) => {
                                        return (
                                            <Select.Option key={r.id} value={r.id}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Tag name">
                            {<Form.Item name={'name'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Tag name is required',
                                    },
                                ]}><Input readOnly={editOnlyValues} /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Description">
                            {<Form.Item name={'description'} noStyle><Input.TextArea readOnly={editOnlyValues} /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Data type">
                            {<Form.Item name={'dataTypeCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Data type is required',
                                    },
                                ]}>
                                <Select
                                    onChange={(code: string) => this.handleDataType(code)}
                                    disabled={editOnlyValues}
                                >
                                    {dataTypes.map((r) => {
                                        return (
                                            <Select.Option key={r.id} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.List) && (
                            <>
                                <Form.Item label="List type">
                                    {<Form.Item name={'listTypeCode'} noStyle rules={[
                                            {
                                                required: selectedDataTypeCode === DataTypes.List,
                                                message: 'Listy type required',
                                            },
                                        ]}>
                                        <Select onChange={this.handleListTypeChange} disabled={editOnlyValues}>
                                            {listTypes.map((r) => {
                                                return (
                                                    <Select.Option key={r.id} value={r.code}>
                                                        {r.name}
                                                    </Select.Option>
                                                );
                                            })}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                                <Form.Item label="Values">
                                    {filteredLisTypeValues.map((r) => {
                                        return <Tag color={r.isExceed ? 'red' : undefined}>{r.name}</Tag>;
                                    })}
                                </Form.Item>
                            </>
                        )}

                        {(selectedDataTypeCode === '' || selectedDataTypeCode === DataTypes.Number) && (
                            <>
                                <Form.Item label="Min Value">
                                    {<Form.Item name={'minValue'} noStyle><InputNumber readOnly={editOnlyValues} /></Form.Item>}
                                </Form.Item>
                                <Form.Item label="Max Value">
                                    {<Form.Item name={'maxValue'} noStyle><InputNumber readOnly={editOnlyValues} /></Form.Item>}
                                </Form.Item>
                            </>
                        )}

                        {(selectedDataTypeCode === '' || selectedDataTypeCode !== DataTypes.List) && (
                            <Form.Item label="Unit of measurement">
                                {<Form.Item name={'unitOfMeasurementCode'} noStyle>
                                    <Select disabled={editOnlyValues}>
                                        {unitOfMeasurements.map((r) => (
                                            <Select.Option key={r.code} value={r.code}>
                                                {`${r.description} (${r.name})`}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                </Form.Item>}
                            </Form.Item>
                        )}

                        <Form.Item label="Is required">
                            {<Form.Item name={'isRequired'} noStyle valuePropName={'checked'}>
                                <Switch disabled={editOnlyValues} />,
                            </Form.Item>}
                        </Form.Item>
                        {!editOnlyValues && (
                            <>
                                <Form.Item label="Change Parent Group"><Checkbox 
                                checked={this.state.changeParentGroup}
                                onChange={this.onChange}
                                ></Checkbox></Form.Item>

                                
                            </>
                        )}
                        {!editOnlyValues && this.state.changeParentGroup && (
                            <>
                            <Form.Item label="LogSheet">
                            
                                <Select onChange={this.handleLogSheetChange}>
                                    {logsheets.map((r) => (
                                        <Select.Option key={r.id} value={r.id}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                           </Form.Item>
                            </>
                        )}
                        {!editOnlyValues && this.state.changeParentGroup && (
                            <>
                        <Form.Item label='Parent Groups'>
                        {<Form.Item name={'groupId'} noStyle>
                             <Select >
                                    {this.state!.logsheetGroup?.map((r) => (
                                        <Select.Option key={r.id!} value={r.id!}>
                                            {r.name!}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                            </>
                        )}

                        {editOnlyValues && (
                            <>
                                <Form.Item label="Value">{<Form.Item name={'value'} noStyle>this.getValueNode()</Form.Item>}</Form.Item>

                                <Form.Item label="Comment">
                                    {<Form.Item name={'comment'} noStyle><Input.TextArea /></Form.Item>}
                                </Form.Item>
                            </>
                        )}
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default TagDrawer;
