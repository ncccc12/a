import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Select, Button} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { AreaVm, DictionaryDto } from '../../services/Client';
import ButtonGroup from 'antd/lib/button/button-group';

export type SearchForm = {
    locationCode: string;
    areaCode: string;
    isActive: number[];
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    searchForm: SearchForm;
    onSearch: () => void;
    onReset: () => void;
    onChange: (values: SearchForm) => void;
} & FormComponentProps<any>;
type State = {
    filteredAreas: AreaVm[];
};

const LogsheetsFilterForm = withModernForm<Props>({
    mapPropsToFields(props: Props): any {
        return {
            locationCode: modernFormField({
                value: props.searchForm.locationCode,
            }),
            areaCode: modernFormField({
                value: props.searchForm.areaCode,
            }),
            isActive: modernFormField({
                value: props.searchForm.isActive,
            }),
        };
    },
    onValuesChange(props: Props, values: SearchForm): void {
        props.onChange(values);
    },
})(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredAreas: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            const { areas } = this.props;

            if (!prevProps.areas.length && areas.length) {
                const {
                    searchForm: { locationCode },
                } = this.props;

                if (locationCode) {
                    this.filterAreas(locationCode);
                }
            }
        }

        filterAreas = (value: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === value);
            this.setState({ filteredAreas });
        };

        handleLocationChange = (value: string) => {
            this.filterAreas(value);
            this.props.form.setFieldsValue({
                areaCode: '',
            });
        };

        // resetFilter = () => {
        //     this.props.form.resetFields();
        //     this.props.onSearch();
        // };

        render() {
            const {
                
            } = this.props;
            const { locations } = this.props;
            const { filteredAreas } = this.state;

            const selectStyle = {
                width: 150,
            };

            return (
                <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" layout="inline">
                    <Form.Item label="Location">
                        {<Form.Item name={'locationCode'} noStyle>
                            <Select style={selectStyle} onChange={this.handleLocationChange}>
                                {locations.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        </Form.Item>}
                    </Form.Item>

                    <Form.Item label="Area">
                        {<Form.Item name={'areaCode'} noStyle>
                            <Select style={selectStyle}>
                                {filteredAreas.map((r) => (
                                    <Select.Option key={r.id} value={r.code}>
                                        {r.name}
                                    </Select.Option>
                                ))}
                            </Select>,
                        </Form.Item>}
                    </Form.Item>

                    <Form.Item label="Is active">
                        {<Form.Item name={'isActive'} noStyle initialValue={[1]}>
                            <Select style={selectStyle} mode="multiple">
                                <Select.Option key="y" value={1}>
                                    Yes
                                </Select.Option>
                                <Select.Option key="n" value={0}>
                                    No
                                </Select.Option>
                            </Select>,
                        </Form.Item>}
                    </Form.Item>

                    <Form.Item>
                        <ButtonGroup>
                            <Button type="primary" onClick={this.props.onSearch}>
                                Search
                            </Button>
                            <Button onClick={this.props.onReset}>Reset</Button>
                        </ButtonGroup>
                    </Form.Item>
                </Form>
            );
        }
    },
);

export default LogsheetsFilterForm;
