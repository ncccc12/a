// Adapter for legacy route-aware class components; uses React Router 7 hooks.
import React from 'react';
import { useLocation, useNavigate, useParams, type Location } from 'react-router-dom';

export type RouteComponentProps<P extends Record<string, string | undefined> = any> = {
  match: { params: P; path: string; url: string; isExact: boolean };
  history: { push: (to: string, state?: unknown) => void; replace: (to: string, state?: unknown) => void; goBack: () => void; goForward: () => void };
  location: Location;
};
export type LegacyRouteProps = { path: string; component: React.ComponentType<any>; exact?: boolean };

export function useLegacyRouteProps<P extends Record<string, string | undefined> = any>(): RouteComponentProps<P> {
  const params = useParams() as P;
  const navigate = useNavigate();
  const location = useLocation();
  return {
    match: { params, path: location.pathname, url: location.pathname, isExact: true },
    history: {
      push: (to, state) => navigate(to, { state }),
      replace: (to, state) => navigate(to, { replace: true, state }),
      goBack: () => navigate(-1),
      goForward: () => navigate(1),
    },
    location,
  };
}
export function withRouter<P extends RouteComponentProps<any>>(Component: React.ComponentType<P>) {
  function RouterWrapped(props: Omit<P, keyof RouteComponentProps<any>>) {
    const routeProps = useLegacyRouteProps();
    return <Component {...({ ...props, ...routeProps } as unknown as P)} />;
  }
  RouterWrapped.displayName = `withRouter(${Component.displayName || Component.name || 'Component'})`;
  return RouterWrapped;
}
export function withRouteProps(Component: React.ComponentType<any>) {
  return function RoutedComponent() {
    const routeProps = useLegacyRouteProps();
    return <Component {...routeProps} />;
  };
}
