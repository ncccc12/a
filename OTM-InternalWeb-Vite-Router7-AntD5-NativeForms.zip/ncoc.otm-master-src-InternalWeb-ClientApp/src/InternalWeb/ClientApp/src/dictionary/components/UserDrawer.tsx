import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Input, Button, Checkbox, Row, Col, Select, Dropdown, Radio, notification, Alert} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { dictionaryClient } from '../../services';
import { AdUserVm, AreaVm, DictionaryDto, UsersClient, AccountType, DisciplinesVm } from '../../services/Client';
import { usersClient } from '../../services';
import { boolean } from 'yargs';
import { CheckboxValueType } from 'antd/es/checkbox/Group';
import Item from 'antd/lib/list/Item';
import { debounce, last } from 'lodash';

export interface UserFormModel {
    locationCode?: string;
    areaCodes?: string[];
    id: string;
    userName: string;
    lastName: string;
    firstName: string;
    email: string;
    password?: string;
    confPassword?: string;
    roles: string[];
    accountType: AccountType;
    discipline: number | undefined;
    disciplineId: number | undefined;
    nk?: string | undefined;
}

type Props = {
    visible: boolean;
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps;
type State = {
    confirmDirty: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    hasDiscipline: boolean;
    accountType: AccountType | undefined;
    filterredPersons: AdUserVm[];
    selectedPersons: AdUserVm;
    selectedNk: string;
    disciplines: DisciplinesVm[];
    selectedDiscipline: DisciplinesVm | undefined;
};

const UserDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);
            this.filterPersons = debounce(this.filterPersons, 800);
            this.state = {
                confirmDirty: false,
                locations: [],
                areas: [],
                filteredAreas: [],
                hasDiscipline: false,
                accountType: AccountType.IsExternal,
                filterredPersons: [],
                selectedPersons: {} as AdUserVm,
                selectedNk: '',
                disciplines: [],
                selectedDiscipline: undefined,
            };
        }

        async componentDidMount() {
            await this.loadData();
        }

        componentDidUpdate(prevProps: Props) {
            if (prevProps.visible === false && this.props.visible) {
                const { form } = this.props;

                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    this.filterAreas(locationCode);

                    let roless = form.getFieldValue('roles');
                    if (roless?.includes('DisciplineEnginer')) {
                        this.setState({ hasDiscipline: true });
                    } else {
                        this.setState({ hasDiscipline: false });
                    }
                }, 1000);
            }
        }

        filterAreas = (locationCode: string) => {
            const { areas } = this.state;
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        handleLocationChange = (value: string) => {
            this.filterAreas(value);
            this.props.form.setFieldsValue({
                areaCodes: [],
            });
        };

        loadData = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();

            this.setState({ locations, areas });
            let discipline = await usersClient.getDisciplines(undefined);

            this.setState({ disciplines: discipline });
        };

        handleConfirmBlur = (e: any) => {
            const { value } = e.target;
            this.setState({ confirmDirty: this.state.confirmDirty || !!value });
        };

        compareToFirstPassword = (rule: any, value: any, callback: (msg?: string) => void) => {
            const { form } = this.props;
            if (value && value !== form.getFieldValue('password')) {
                callback('Two passwords that you enter is inconsistent!');
            } else {
                callback();
            }
        };

        validateToNextPassword = (rule: any, value: any, callback: (msg?: string) => void) => {
            const { form } = this.props;
            if (value && this.state.confirmDirty) {
                form.validateFields(['confPassword'], { force: true });
            }
            callback();
        };
        unique = (checkedValues: CheckboxValueType[]) => {
            let result: any[] = [];

            for (let str of checkedValues) {
                if (!result.includes(str)) {
                    result.push(str);
                }
            }

            return result;
        };
        onChange = (checkedValues: CheckboxValueType[]) => {
            if (checkedValues.includes('Supervisor')) {
                if (!checkedValues.includes('Read')) {
                    checkedValues.push('Read');
                }
                if (!checkedValues.includes('Write')) {
                    checkedValues.push('Write');
                }
            }
            if (checkedValues.includes('DisciplineEnginer')) {
                if (!checkedValues.includes('Read')) {
                    checkedValues.push('Read');
                }
                this.setState({ hasDiscipline: true });
            }
            if (!checkedValues.includes('DisciplineEnginer')) {
                this.setState({ hasDiscipline: false });
            }
            const uniqueArr = new Set(checkedValues);

            checkedValues = Array.from(uniqueArr);
        };

        radioChange = (e: any) => {
            this.setState({ accountType: e.target.value });

            this.props.form.setFieldsValue({ ['accountType']: e.target.value });
        };
        filterPersons = async (lastname: string) => {
            if (lastname && lastname.length > 3) {
                try {
                    const UserClient = new UsersClient();
                    const result = await usersClient.getUsersFromAdByQuery(lastname);
                    this.setState({ filterredPersons: result });
                } catch (error) {
                    notification.error({
                        message: 'Error on persons search',
                    });
                }
            } else {
                this.setState({ filterredPersons: [] });
            }
        };
        onSelectNk = (value: any) => {
            this.setState({ selectedNk: value });
            const selectedUser = this.state.filterredPersons.filter((p) => p.email === value)[0];
            this.setState({
                selectedPersons: selectedUser,
            });
            this.props.form.setFieldsValue({ nk: selectedUser.nk });
            this.props.form.setFieldsValue({ ['email']: value });
            this.props.form.setFieldsValue({ firstName: selectedUser.firstName });
            this.props.form.setFieldsValue({ lastName: selectedUser.lastName });
        };

        onDisciplineChange = (value: any) => {
            this.state.disciplines.map((x) => {
                if (x.id === value) {
                    this.setState({ selectedDiscipline: x });
                }
            });
        };

        render() {
            const {
                visible,
                form,
                
            } = this.props;
            const { locations, filteredAreas, filterredPersons } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            void 0;
            void 0;
            void 0;
            void 0;
            void 0;
            void 0;
            void 0;

            let nk = form.getFieldValue('nk');
            let id = form.getFieldValue('id');
            let accType = form.getFieldValue('accountType');
            let discipline = form.getFieldValue('disciplineId');

            return (
                <Drawer
                    title={id ? 'Edit user' : 'Add new user'}
                    visible={visible}
                    width={500}
                    destroyOnClose={true}
                    onClose={this.props.onClose}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Location">
                            {<Form.Item name={'locationCode'} noStyle>
                                <Select onChange={this.handleLocationChange}>
                                    {locations.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>

                        <Form.Item label="Area">
                            {<Form.Item name={'areaCodes'} noStyle>
                                <Select mode="multiple">
                                    {filteredAreas.map((r) => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item>
                            {<Form.Item name={'accountType'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'AccountType is required',
                                    },
                                ]}>
                                <Radio.Group disabled={id} onChange={this.radioChange}>
                                    <Radio value={AccountType.IsExternal}>External</Radio>
                                    <Radio value={AccountType.IsInternal}>Internal</Radio>
                                </Radio.Group>,
                            </Form.Item>}
                        </Form.Item>
                        {this.state.accountType === 0 && (
                            <Form.Item label="User Name">
                                {<Form.Item name={'userName'} noStyle rules={[
                                        {
                                            required: true,
                                            whitespace: true,
                                            message: 'User name is required',
                                        },
                                    ]}><Input disabled={accType === AccountType.IsInternal} /></Form.Item>}
                            </Form.Item>
                        )}
                        {this.state.accountType === 1 && (
                            <Form.Item label="User NK">
                                {<Form.Item name={'userName'} noStyle rules={[
                                        {
                                            required: true,
                                            whitespace: true,
                                            message: 'User name is required',
                                        },
                                    ]}>
                                    <Select
                                        filterOption={false}
                                        allowClear
                                        showSearch
                                        placeholder={'Write User NK'}
                                        onSearch={this.filterPersons}
                                        onSelect={this.onSelectNk}
                                        disabled={id}
                                    >
                                        {filterredPersons.map((x) => (
                                            <Select.Option key={x.nk!} value={x.email!} title={x.fullName}>
                                                {x.fullName!}
                                            </Select.Option>
                                        ))}
                                    </Select>,
                                </Form.Item>}
                            </Form.Item>
                        )}
                        {this.state.accountType === 1 && this.state.selectedPersons !== null && (
                            <>
                                <span>Position:{this.state.selectedPersons!.position}</span>
                                <br />
                                <span>NK: {nk}</span>
                            </>
                        )}
                        {
                            <Form.Item label="Email">
                                {<Form.Item name={'email'} noStyle rules={[
                                        {
                                            type: 'email',
                                            message: 'The input is not valid E-mail!',
                                        },
                                        {
                                            required: true,
                                            message: 'Please input your E-mail!',
                                        },
                                    ]}>
                                    <Input
                                        disabled={this.state.accountType === 1 || accType === AccountType.IsInternal}
                                        // placeholder={this.state.selectedNk}
                                        value={this.state.selectedNk}
                                    />,
                                </Form.Item>}
                            </Form.Item>
                        }
                        {!id && this.state.accountType === AccountType.IsExternal && (
                            <>
                                <Form.Item label="Password" hasFeedback>
                                    {<Form.Item name={'password'} noStyle rules={[
                                            {
                                                required: true,
                                                whitespace: true,
                                                message: 'Password is required',
                                            },
                                            {
                                                validator: this.validateToNextPassword,
                                            },
                                        ]}><Input.Password /></Form.Item>}
                                </Form.Item>
                                <Form.Item label="Confirm password" hasFeedback>
                                    {<Form.Item name={'confPassword'} noStyle rules={[
                                            {
                                                required: true,
                                                whitespace: true,
                                                message: 'Confirm password is required',
                                            },
                                            {
                                                validator: this.compareToFirstPassword,
                                            },
                                        ]}><Input.Password onBlur={this.handleConfirmBlur} /></Form.Item>}
                                </Form.Item>
                            </>
                        )}

                        <Form.Item label="Roles">
                            {<Form.Item name={'roles'} noStyle>
                                <Checkbox.Group style={{ width: '100%' }} onChange={this.onChange}>
                                    <Row>
                                        <Col span={8}>
                                            <Checkbox value="Admin">Admin</Checkbox>
                                        </Col>
                                        <Col span={8}>
                                            <Checkbox value="Read">Read</Checkbox>
                                        </Col>
                                        <Col span={8}>
                                            <Checkbox value="Write">Write</Checkbox>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col span={12}>
                                            <Checkbox value="Supervisor">Supervisor</Checkbox>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col span={12}>
                                            <Checkbox value="ChiefSupervisor">Shift-Supervisor</Checkbox>
                                        </Col>
                                    </Row>
                                </Checkbox.Group>,
                            </Form.Item>}
                        </Form.Item>
                        {/*this.state.hasDiscipline &&(
                                <Form.Item style={{margin:'15px'}} label = "Discipline">
                                    {<Form.Item name={'disciplineId'} noStyle>
                                    <Select  placeholder="Choose Discipline..">
                                    {this.state.disciplines.map((value: DisciplinesVm) => (
                                      <Select.Option key={value.id} value={value.id!}>
                                        {value.name}
                                      </Select.Option>
                                    ))}
                                  </Select> 
                                </Form.Item>}
                                
                              </Form.Item>
                                    )*/}
                    </Form>
                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button onClick={this.props.onSubmit} type="primary">
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default UserDrawer;
