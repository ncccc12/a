import { CrewsPage, UsersPage } from './pages';
import { LegacyRouteProps as RouteProps } from '../router/legacy';

const routes: RouteProps[] = [
    {
        path: '/dictionary/crews',
        component: CrewsPage,
        exact: true,
    },
    {
        path: '/admin/users',
        component: UsersPage,
        exact: true,
    },
];

export default routes;
