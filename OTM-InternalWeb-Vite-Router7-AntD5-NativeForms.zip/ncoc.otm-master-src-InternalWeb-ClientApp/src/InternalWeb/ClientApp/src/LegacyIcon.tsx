import React from 'react';
import * as Icons from '@ant-design/icons';
// Bridge legacy Ant Design v3 <Icon type="..."/> use while screens are migrated.
const overrides: Record<string, string> = { 'bar-chart': 'BarChartOutlined', 'clock-circle': 'ClockCircleOutlined', 'file-sync': 'FileSyncOutlined' };
export default function LegacyIcon({ type, spin, ...rest }: {type: string; spin?: boolean; [key:string]: any}) {
  const name = overrides[type] || type.split('-').map(part => part.charAt(0).toUpperCase()+part.slice(1)).join('') + 'Outlined';
  const Component = (Icons as any)[name] || Icons.QuestionCircleOutlined;
  return <Component spin={spin} {...rest} />;
}
