/** Transitional class-component typing. Field rendering uses native Ant Design 5 Form.Item. */
import type { FormInstance } from 'antd';
export type WrappedFormUtils = FormInstance & {
  validateFields: (...args: any[]) => any;
  validateFieldsAndScroll: (...args: any[]) => any;
  setFieldsValue: (values: any, callback?: () => void) => void;
};
export type FormComponentProps<T = any> = { form: WrappedFormUtils };
export type FormItemProps = Record<string, any>;
export type FormProps = Record<string, any>;
