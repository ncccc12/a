import { withModernForm, modernFormField } from '../../modern-form';
import {  DatePicker, Modal, Select} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import moment from 'moment';
import React from 'react';
import {Item, RotationCalendarTypes} from '../constants';
//import { Item, RotationCalendarTypes } from '../constant';

const Option = Select.Option;
const FormItem = Form.Item;

type Props = {
    visible: boolean;
    startDate: moment.Moment;
    endDate: moment.Moment;
    onOk: (e: any) => void;
    onCancel: (e: any) => void;
} & FormComponentProps;

export const EditSelectedDatesModal = withModernForm<Props>()(
    class extends React.Component<Props> {
        static displayName: string = 'EditSelectedDatesModal';
        rowConf: any = {
            style: {
                width: 300,
            },
        };

        render(): JSX.Element {
            const { onOk, visible, onCancel, startDate, endDate } = this.props;
            

            return (
                <Modal
                    title="Edit selected dates"
                    visible={visible}
                    centered={true}
                    width={400}
                    onOk={onOk}
                    onCancel={onCancel}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} layout="inline" labelCol={{ span: 8 }} labelAlign="left">
                        <FormItem label="Start date" {...this.rowConf}>
                            <DatePicker disabled={true} value={startDate} />
                        </FormItem>
                        <FormItem label="End date" {...this.rowConf}>
                            <DatePicker disabled={true} value={endDate} />
                        </FormItem>

                        <FormItem label="Shift type" {...this.rowConf}>
                            {<Form.Item name={'shiftType'} noStyle initialValue={RotationCalendarTypes[0].value}>
                                <Select style={{ width: 195 }}>
                                    {RotationCalendarTypes.map((type: Item) => {
                                        return (
                                            <Option key={type.value} value={type.value}>
                                                {type.text}
                                            </Option>
                                        );
                                    })}
                                </Select>,
                            </Form.Item>}
                        </FormItem>
                        {/* <FormItem labelCol={{ span: 12 }} label="Calculate remaining" {...this.rowConf}>
                            {<Form.Item name={'calculateRemaining'} noStyle valuePropName={'checked'}><Checkbox /></Form.Item>}
                        </FormItem> */}
                    </Form>
                </Modal>
            );
        }
    },
);
