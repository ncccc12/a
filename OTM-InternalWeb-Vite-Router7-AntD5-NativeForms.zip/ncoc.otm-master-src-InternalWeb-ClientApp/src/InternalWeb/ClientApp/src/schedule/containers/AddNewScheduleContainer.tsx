import { RouteComponentProps, withRouter } from '../../router/legacy';
import React from 'react';
import { Spin, Row, Col, Button, message } from 'antd';
import '../ScheduleForm.css';
import ScheduleForm, { ScheduleFormModel } from '../components/ScheduleForm';
import { WrappedFormUtils } from '../../legacy-form-types';
import { schedulesClient } from '../../services';
import CalendarTable from '../components/CalendarTable';
import { ScheduleConfig } from '../types';
import generateScheduleSrv from '../GenerateScheduleService';
import { AddScheduleCommand, TimeOptionDto } from '../../services/Client';
import { cloneDeep } from 'lodash';


type Props = {} & RouteComponentProps<any>;
type State = {
    loading: boolean;
    scheduleConfig?: ScheduleConfig;
    formChanged: boolean;
};

class AddNewScheduleContainer extends React.Component<Props, State> {
    years: number[] = [];
    formRef: any;

    constructor(props: Props) {
        super(props);

        this.state = {
            loading: true,
            formChanged: false,
        };
    }

    componentDidMount() {}

    handleLoadingChange = () => {
        this.setState({ loading: false });
    };

    viewSchedule = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {
            if (err) return;

            let config = await schedulesClient.getScheduleConfig(values.scheduleConfigId);
            let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

            this.setState({ scheduleConfig, formChanged: false });
        });
    };

    reset = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;

        form.resetFields();
        this.setState({ scheduleConfig: undefined });
    };

    addNewSchedule = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {
            try {
                this.setState({ loading: true });

                let cloneDatePeriod = cloneDeep(values.datePeriod);

                let command = new AddScheduleCommand();
                command.year = values.year;
                command.date =
                    values.date &&
                    (values.date.utc(true).set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).toDate() as any);
                command.name = values.scheduleName;
                command.datePeriod = cloneDatePeriod.map((r) => r.utc(true) as any); // date
                command.logsheetId = values.logsheetId;
                command.scheduleConfigId = values.scheduleConfigId;
                command.scheduleTypeCode = values.scheduleTypeCode;
                command.selectedPeriods = values.selectedPeriods?.map((r) => {
                    let period = r.map((r) => r.utc(true).toDate());
                    return period;
                });

                command.timeOptions = values.timeOptions
                    .filter((r) => r)
                    .map((r) => {
                        let opt = new TimeOptionDto();
                        opt.id = r.id;
                        opt.time = r.time.format('HH:mm');

                        return opt;
                    });
                command.weekDayCodes = values.weekDayCodes;


                await schedulesClient.addSchedule(command);
                message.success('Operation successfully completed');
                this.props.history.push('/scheduleManager/schedules');
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    handleFormChange = () => {
        if (!this.state.formChanged) {
            this.setState({ formChanged: true });
        }
    };

    render() {
        const { loading, scheduleConfig, formChanged } = this.state;
        const datePeriod = this.formRef && this.formRef.props.form.getFieldValue('datePeriod');

        

        return (
            <Spin spinning={loading}>
                <ScheduleForm
                    onFormChange={this.handleFormChange}
                    wrappedComponentRef={(ref: any) => (this.formRef = ref)}
                    onLoadingChange={this.handleLoadingChange}
                />
                <br />
                <Row>
                    <Col span={12} style={{ textAlign: 'left' }}>
                        <Button type="primary" onClick={this.viewSchedule}>
                            View Schedule
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                            Reset
                        </Button>
                    </Col>
                    {scheduleConfig && formChanged === false && (
                        <Col span={12} style={{ textAlign: 'right' }}>
                            <Button
                                type="link"
                                style={{ backgroundColor: '#52c41a', color: '#fff' }}
                                onClick={this.addNewSchedule}
                            >
                                Add new schedule
                            </Button>
                        </Col>
                    )}
                </Row>
                <br />
                {scheduleConfig && (
                    <CalendarTable scheduleConfig={scheduleConfig} datePeriod={datePeriod} readonly={true} />
                )}
            </Spin>
        );
    }
}

export default withRouter(AddNewScheduleContainer);
