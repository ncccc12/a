import { RouteComponentProps, withRouter } from '../../router/legacy';
import React from 'react';
import { ScheduleConfig } from '../types';
import moment from 'moment';
import { Spin, Row, Col, Button, message } from 'antd';
import ScheduleForm, { ScheduleFormModel } from '../components/ScheduleForm';
import CalendarTable from '../components/CalendarTable';
import { WrappedFormUtils } from '../../legacy-form-types';
import { schedulesClient } from '../../services';
import generateScheduleSrv from '../GenerateScheduleService';
import { ScheduleVm, UpdateScheduleCommand, TimeOptionDto } from '../../services/Client';
import { cloneDeep } from 'lodash';


type Props = {
    id: number;
} & RouteComponentProps<any>;
type State = {
    loading: boolean;
    scheduleConfig?: ScheduleConfig;
    formChanged: boolean;
};

class EditScheduleContainer extends React.Component<Props, State> {
    formRef: any;
    srcFormModel: ScheduleFormModel | undefined = undefined;

    constructor(props: Props) {
        super(props);

        this.state = {
            loading: true,
            formChanged: false,
        };
    }

    componentDidMount() {
        this.loadData();
    }

    loadData = async () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;
        let schedule = await schedulesClient.getSchedule(this.props.id);

        let formModel = this.mapVmToScheduleForm(schedule);
        this.srcFormModel = cloneDeep(formModel);
        form.setFieldsValue(formModel);

        let config = await schedulesClient.getScheduleConfig(schedule.scheduleConfigId);
        let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

        this.setState({ scheduleConfig });
    };

    mapVmToScheduleForm = (vm: ScheduleVm): ScheduleFormModel => {
        let scheduleForm: ScheduleFormModel = {
            id: vm.id!,
            areaCode: vm.areaCode!,
            locationCode: vm.locationCode!,
            logsheetId: vm.logsheetId!,
            year: vm.year!,
            scheduleConfigId: vm.scheduleConfigId!,
            scheduleName: vm.name!,
            scheduleTypeCode: vm.scheduleTypeCode! as any,
            datePeriod: [moment(vm.startDate), moment(vm.endDate)],
            timeOptions: vm.timeOptions!.map((r) => {
                return {
                    id: r.id!,
                    time: moment(r.time, 'HH:mm'),
                };
            }),
            weekDayCodes: vm.weekDayCodes,
            selectedPeriods: vm.selectedPeriods?.map(r => {
                let period = r.map(r => moment(r));
                return period;
            }),
            date : moment(vm.date)
        };

        return scheduleForm;
    };

    handleLoadingChange = () => {
        this.setState({ loading: false });
    };

    viewSchedule = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {
           

            if (err) return;

            let config = await schedulesClient.getScheduleConfig(values.scheduleConfigId);
            let scheduleConfig = generateScheduleSrv.mapVmToScheduleConfig(config);

            this.setState({ scheduleConfig, formChanged: false });
        });
    };

    handleFormChange = () => {
        if (!this.state.formChanged) {
            this.setState({ formChanged: true });
        }
    };

    resetDefaults = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;
        form.setFieldsValue(this.srcFormModel!);
    };

    updateSchedule = () => {
        const form = this.formRef.props.form as WrappedFormUtils<any>;

        form.validateFields(async (err: any, values: ScheduleFormModel) => {

            if (err) return;

            try {
                this.setState({ loading: true });
                let command = new UpdateScheduleCommand();
                command.id = values.id;
                command.date = values.date && values.date.utc(true).set({hour: 0, minute: 0, second: 0, millisecond: 0}).toDate() as any;
                command.name = values.scheduleName;
                command.datePeriod = values.datePeriod.map((r) => r.utc(true).toDate());
                command.scheduleConfigId = values.scheduleConfigId;
                command.scheduleTypeCode = values.scheduleTypeCode;
                command.timeOptions = values.timeOptions!.map((r) => {
                    let dto = new TimeOptionDto();
                    dto.id = r.id;
                    dto.time = r.time.format('HH:mm');

                    return dto;
                });
                command.weekDayCodes = values.weekDayCodes;

                await schedulesClient.updateSchedule(command);
                message.success('Operation successfully completed');
                this.props.history.push('/scheduleManager/schedules');
            } finally {
                this.setState({ loading: false });
            }
        });
    };

    render() {
        const { loading, scheduleConfig, formChanged } = this.state;
        const datePeriod = this.formRef && this.formRef.props.form.getFieldValue('datePeriod');

        return (
            <Spin spinning={loading}>
                <ScheduleForm
                    isEdit={true}
                    srcFormModel={this.srcFormModel}
                    onFormChange={this.handleFormChange}
                    wrappedComponentRef={(ref: any) => (this.formRef = ref)}
                    onLoadingChange={this.handleLoadingChange}
                />
                <br />
                <Row>
                    <Col span={12} style={{ textAlign: 'left' }}>
                        <Button type="primary" onClick={this.viewSchedule}>
                            View Schedule
                        </Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.resetDefaults}>
                            Reset
                        </Button>
                    </Col>

                    {scheduleConfig && formChanged === false && (
                        <Col span={12} style={{ textAlign: 'right' }}>
                            <Button
                                type="link"
                                style={{ backgroundColor: '#52c41a', color: '#fff' }}
                                onClick={this.updateSchedule}
                            >
                                Update schedule
                            </Button>
                        </Col>
                    )}
                </Row>
                <br />
                {scheduleConfig && (
                    <CalendarTable scheduleConfig={scheduleConfig} datePeriod={datePeriod} readonly={true} />
                )}
            </Spin>
        );
    }
}

export default withRouter(EditScheduleContainer);
