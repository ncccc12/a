import { RouteComponentProps, withRouter } from '../../router/legacy';
import React from 'react';
import { Table, Button, Spin, Card, Typography } from 'antd';
import { schedulesClient, dictionaryClient } from '../../services';
import { ScheduleVm, DictionaryDto, AreaVm, LogsheetDictionaryVm, GetSchedulesQuery } from '../../services/Client';
import moment from 'moment';
import { Link } from 'react-router-dom';
import SchedulesFilterForm, { ScheduleSearchForm } from '../components/SchedulesFilterForm';
import { WrappedFormUtils } from '../../legacy-form-types';
import { AppState } from '../../store/reducers';
import { ScheduleManagerState, changeScheduleFilterForm, resetScheduleFilterForm } from '../ducks/ScheduleMangerDuck';
import { connect } from 'react-redux';

const { Column } = Table;

const mapStateToProps = (state: AppState): ScheduleManagerState => ({
    scheduleFilterForm: state.ScheduleManagerDuck.scheduleFilterForm,
});

const mapDispatchToProps = {
    changeFilterForm: changeScheduleFilterForm,
    resetFilterForm: resetScheduleFilterForm,
};

type Props = {} & RouteComponentProps<any> & typeof mapDispatchToProps & ScheduleManagerState;
type State = {
    schedules: ScheduleVm[];
    locations: DictionaryDto[];
    logsheets: LogsheetDictionaryVm[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    loading: boolean;
};

const SchedulesContainer = connect(
    mapStateToProps,
    mapDispatchToProps,
)(
    class extends React.Component<Props, State> {
        drawerCompRef: any;
        filterFormRef: any;

        constructor(props: Props) {
            super(props);
            this.state = {
                loading: true,
                schedules: [],
                locations: [],
                areas: [],
                logsheets: [],
                filteredAreas: [],
            };
        }

        async componentDidMount() {
            await this.loadDictionaries();
            this.search();
        }

        initFilter = (ref: any) => {
            if (ref) {
                this.filterFormRef = ref;
                this.search();
            }
        };

        search = async () => {
            this.setState({ loading: true });
            const form = this.filterFormRef.props.form as WrappedFormUtils<any>;

            form.validateFields(async (err: any, values: ScheduleSearchForm) => {

                let query = new GetSchedulesQuery();
                query.areaCode = values.areaCode;
                query.locationCode = values.locationCode;
                query.datePeriod = values.datePeriod?.map((r) => r.utc(true).toDate()) || [];
                query.isActive = values.isActive;
                const data = await schedulesClient.getSchedules(query);

                this.setState({ schedules: data, loading: false });
            });
        };

        loadDictionaries = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();
            let logsheets = await dictionaryClient.getLogsheets();

            this.setState({ locations, areas, logsheets });
        };

        resetFilter = () => {
            this.props.resetFilterForm();
            this.setState({}, () => {
                this.search();
            });
        };

        renderActions = (r: ScheduleVm) => {
            return (
                <>
                    <Button
                        style={{ marginLeft: 5 }}
                        icon="edit"
                        title="Edit"
                        onClick={() => this.props.history.push(`/scheduleManager/schedules/${r.id}`)}
                    ></Button>
                </>
            );
        };

        render() {
            const { schedules, loading, locations, areas } = this.state;
            const { scheduleFilterForm: filterForm } = this.props;

            return (
                <Card>
                    <Typography.Title>Schedules</Typography.Title>
                    <SchedulesFilterForm
                        searchForm={filterForm!}
                        areas={areas}
                        locations={locations}
                        wrappedComponentRef={this.initFilter}
                        onSearch={this.search}
                        onReset={this.resetFilter}
                        onChange={this.props.changeFilterForm}
                    />
                    <Spin spinning={loading}>
                        <Table
                            rowKey={(r: any) => r.id + ''}
                            dataSource={schedules}
                            bordered
                            title={() => (
                                <Link to="/scheduleManager/schedules/new">
                                    <Button>Add new</Button>{' '}
                                </Link>
                            )}
                        >
                            <Column title="Location" dataIndex="locationName"></Column>
                            <Column title="Area" dataIndex="areaName"></Column>
                            <Column title="Logsheet" dataIndex="logsheet"></Column>
                            <Column title="Name" align="center" dataIndex="name"></Column>
                            <Column title="Schedule config name" align="center" dataIndex="configName"></Column>
                            <Column
                                title="Start date"
                                align="center"
                                dataIndex="startDate"
                                render={(d) => moment(d).format('DD.MM.YYYY')}
                            ></Column>
                            <Column
                                title="End date"
                                align="center"
                                dataIndex="endDate"
                                render={(d) => moment(d).format('DD.MM.YYYY')}
                            ></Column>

                            <Column title="Schedule type" align="center" dataIndex="scheduleTypeName"></Column>

                            <Table.Column
                                dataIndex="isActive"
                                title="Is Active"
                                render={(isActive) => (isActive ? 'Yes' : 'No')}
                            ></Table.Column>
                            <Column
                                title="Actions"
                                align="center"
                                render={(r: ScheduleVm) => this.renderActions(r)}
                            ></Column>
                        </Table>
                    </Spin>
                </Card>
            );
        }
    },
);

export default withRouter(SchedulesContainer);
