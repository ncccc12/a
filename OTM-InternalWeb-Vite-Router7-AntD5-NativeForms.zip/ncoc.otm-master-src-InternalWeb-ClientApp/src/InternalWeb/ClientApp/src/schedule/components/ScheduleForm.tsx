import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Select, Input, Row, Col, DatePicker, Button, Tag} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps, FormItemProps } from '../../legacy-form-types';
import { DictionaryDto, LogsheetDictionaryVm, AreaVm, ScheduleConfigDicVm } from '../../services/Client';
import { dictionaryClient } from '../../services';
import moment from 'moment';
import ConfigureScheduleModal, { ConfigureTimeFormModel } from '../modals/ConfigureScheduleModal';
import { WrappedFormUtils } from '../../legacy-form-types';
import { clone } from 'lodash';

type ScheudleType = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY';

export interface ScheduleFormModel {
    id: number;
    locationCode: string;
    areaCode: string;
    logsheetId: number;
    scheduleName: string;
    year: number;
    datePeriod: moment.Moment[];
    scheduleTypeCode: ScheudleType;
    scheduleConfigId: number;
    timeOptions: Array<{ id: number; time: moment.Moment }>;
    weekDayCodes?: string[];
    date?: moment.Moment;

    selectedPeriods?: Array<moment.Moment[]>;
}

type Props = {
    isEdit?: boolean;
    srcFormModel?: ScheduleFormModel;
    onFormChange: (e: any) => void;
    onLoadingChange: (loading: boolean) => void;
} & FormComponentProps<any>;

type State = {
    locations: DictionaryDto[];
    logsheets: LogsheetDictionaryVm[];
    areas: AreaVm[];
    filteredAreas: AreaVm[];
    filteredLogsheets: LogsheetDictionaryVm[];
    scheduleTypes: DictionaryDto[];
    scheduleConfigs: ScheduleConfigDicVm[];
    filteredScheduleConfigs: ScheduleConfigDicVm[];
    scheduleTimeModalShown: boolean;

    datePeriodDisabled?: boolean;
    scheduleConfigDisabled?: boolean;
    scheduleTypeDisabled?: boolean;

    scheduleStatus: 'Not started' | 'In progress' | 'Finished';
};

const ScheduleForm = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        years: number[] = [];
        scheduleTimeModalRef: any;
        timeFormat = 'HH:mm';
        defaultTimes = [
            { id: undefined, time: moment('07:00', this.timeFormat) },
            { id: undefined, time: moment('14:00', this.timeFormat) },
            { id: undefined, time: moment('19:00', this.timeFormat) },
            { id: undefined, time: moment('02:00', this.timeFormat) },
        ];

        constructor(props: Props) {
            super(props);
            this.state = {
                locations: [],
                areas: [],
                logsheets: [],
                filteredAreas: [],
                filteredLogsheets: [],
                scheduleTypes: [],
                scheduleConfigs: [],
                filteredScheduleConfigs: [],
                scheduleTimeModalShown: false,
                scheduleStatus: 'Not started',
            };

            let currYear = moment().year();
            for (let year = currYear; year <= currYear + 5; year++) {
                this.years.push(year);
            }
        }

        componentDidUpdate(prevProps: Props) {
            if (!prevProps.srcFormModel && this.props.srcFormModel) {
                this.setDsiabledFields(this.props.srcFormModel!);
            }
        }

        async componentDidMount() {
            await this.loadDictionaries();

            if (this.props.isEdit) {
                this.filterDictionaries();
            }
        }

        setDsiabledFields = (formModel: ScheduleFormModel) => {
            let currDate = moment();

            let datePeriodDisabled = false;
            let scheduleConfigDisabled = false;
            let scheduleTypeDisabled = false;

            // finished
            if (currDate.isAfter(formModel.datePeriod[1], 'day')) {
                datePeriodDisabled = true;
                scheduleConfigDisabled = true;
                scheduleTypeDisabled = true;
                this.setState({ scheduleStatus: 'Finished' });
            }

            // in progress
            if (currDate.isBetween(formModel.datePeriod[0], formModel.datePeriod[1], 'day', '[]')) {
                datePeriodDisabled = false;
                scheduleConfigDisabled = true;
                scheduleTypeDisabled = true;
                this.setState({ scheduleStatus: 'In progress' });
            }

            // not started yet
            if (currDate.isBefore(formModel.datePeriod[0], 'day')) {
                datePeriodDisabled = false;
                scheduleConfigDisabled = false;
                scheduleTypeDisabled = false;
                this.setState({ scheduleStatus: 'Not started' });
            }

            this.setState({ datePeriodDisabled, scheduleConfigDisabled, scheduleTypeDisabled });
        };

        loadDictionaries = async () => {
            let locations = await dictionaryClient.getLocations();
            let areas = await dictionaryClient.getAreas();
            let logsheets = await dictionaryClient.getLogsheets();
            let scheduleTypes = await dictionaryClient.getDictionary('ScheduleTypes');
            let scheduleConfigs = await dictionaryClient.getScheduleConfigs();
            this.props.onLoadingChange(false);

            this.setState({ locations, areas, logsheets, scheduleTypes, scheduleConfigs });
        };

        filterDictionaries = () => {
            const { form } = this.props;
            let locationCode = form.getFieldValue('locationCode');
            let areaCode = form.getFieldValue('areaCode');
            let year = form.getFieldValue('year');

            this.filterAreas(locationCode);
            this.filterLogsheets(areaCode);
            this.filterScheduleConfigs(areaCode, year);
        };

        handleLocationChange = (locationCode: string) => {
            const { form } = this.props;

            this.filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
                logsheetId: undefined,
                scheduleConfigId: undefined,
            });
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.state;
            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        handlerAreaChange = (areaCode: string) => {
            const { form } = this.props;
            const year = form.getFieldValue('year');
            this.filterLogsheets(areaCode);
            this.filterScheduleConfigs(areaCode, year);

            form.setFieldsValue({
                logsheetId: undefined,
                scheduleConfigId: undefined,
            });
        };

        filterLogsheets = (areaCode: string) => {
            const { logsheets } = this.state;
            const filteredLogsheets = logsheets.filter((r) => r.areaCode === areaCode);
            this.setState({ filteredLogsheets });
        };

        filterScheduleConfigs = (areaCode: string, year: number) => {
            const { scheduleConfigs } = this.state;
            let filteredConfigs: ScheduleConfigDicVm[] = scheduleConfigs;

            if (areaCode) filteredConfigs = filteredConfigs.filter((r) => r.areaCode === areaCode);
            if (year) filteredConfigs = filteredConfigs.filter((r) => r.year === year);

            this.setState({ filteredScheduleConfigs: filteredConfigs });
        };

        handleYearChange = (year: number) => {
            const { form } = this.props;
            const areacode = form.getFieldValue('areaCode');

            this.filterScheduleConfigs(areacode, year);

            form.setFieldsValue({
                scheduleConfigId: undefined,
                datePeriod: undefined,
            });

            this.props.onFormChange(undefined);
        };

        disableDate = (current: moment.Moment | null): boolean => {
            let year = this.props.form.getFieldValue('year');

            return current!.year() !== year;
        };

        saveScheduleConfig = () => {
            const timeForm = this.scheduleTimeModalRef.props.form as WrappedFormUtils<any>;
            const { form } = this.props;

            let scheduleTypeCode: ScheudleType = form.getFieldValue('scheduleTypeCode');

            timeForm.validateFields((err: any, values: ConfigureTimeFormModel) => {
                if (err) return;

                // change form datePeriod
                if (scheduleTypeCode === 'MONTHLY') {
                    let startDate: moment.Moment | undefined, endDate: moment.Moment | undefined;

                    values.selectedPeriods?.forEach((r) => {
                        if (!startDate || r[0].isBefore(startDate, 'day')) startDate = r[0];

                        if (!endDate || r[1].isAfter(endDate, 'day')) endDate = r[1];
                    });

                    form.setFieldsValue({
                        datePeriod: [startDate, endDate],
                    });
                }

                if (scheduleTypeCode === 'YEARLY') {
                    form.setFieldsValue({
                        date: values.date,
                    });
                }

                form.setFieldsValue({
                    timeOptions: values.timeOptions,
                    weekDayCodes: values.weekDayCodes,
                    selectedPeriods: values.selectedPeriods,
                });

                this.setState({ scheduleTimeModalShown: false });
                this.props.onFormChange(undefined);
            });
        };

        validateEndDate = (rule: any, value: moment.Moment[], callback: any) => {
            if (this.props.isEdit && moment().isAfter(value[1], 'day')) {
                callback('End date cannot be smaller than current date');
            }

            callback();
        };

        validateStartDate = (rule: any, value: moment.Moment[], callback: any) => {
            if (this.props.isEdit) {
                let currDate = moment().endOf('day');
                const { srcFormModel } = this.props;

                // schedule in progress
                if (currDate.isBetween(srcFormModel!.datePeriod[0], srcFormModel!.datePeriod[1], 'day', '[]')) {
                    if (!value[0].isSame(srcFormModel!.datePeriod[0], 'day')) {
                        callback('Schedule in progress, start date cannot be changed');
                    }

                    callback();
                }

                // schedule not started yet
                else if (currDate.isBefore(srcFormModel!.datePeriod[0], 'day')) {
                    if (currDate.isSameOrAfter(value[0], 'day')) {
                        callback('Schedule is not started yet, start date cannot be changed to current or past date');
                    }
                }

                callback();
            }

            callback();
        };

        openScheduleModal = () => {
            this.setState({ scheduleTimeModalShown: true });
        };

        initScheduleModal = (compRef: any) => {
            if (compRef) {
                this.scheduleTimeModalRef = compRef;
                const timeForm = this.scheduleTimeModalRef.props.form as WrappedFormUtils<any>;
                let selectedPeriods = this.props.form.getFieldValue('selectedPeriods');
                let date = this.props.form.getFieldValue('date');

                timeForm.setFieldsValue({
                    selectedPeriods: clone(selectedPeriods),
                    date,
                });
            }
        };

        render() {
            const {
                
                form,
                isEdit,
            } = this.props;

            const {
                locations,
                filteredAreas,
                filteredLogsheets,
                filteredScheduleConfigs,
                scheduleTypes,
                scheduleTimeModalShown,
                datePeriodDisabled,
                scheduleConfigDisabled,
                scheduleTypeDisabled,
            } = this.state;

            const formItemProps: FormItemProps = {
                labelCol: { span: 6 },
            };

            // let tomorrow = moment().add(1, 'day');
            // let endDate = moment().add(10, 'day');

            void 0;

            const timeOptions: any[] = form.getFieldValue('timeOptions');
            void 0;

            const scheduleTypeCode: ScheudleType = form.getFieldValue('scheduleTypeCode');
            const weekDayCodes = form.getFieldValue('weekDayCodes');
            const year = form.getFieldValue('year');

            void 0;

            void 0;

            return (
                <>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form}
                        labelAlign="left"
                        className="schedule-form"
                        layout="inline"
                        onChange={this.props.onFormChange}
                    >
                        <Row gutter={24} type="flex">
                            <Col span={8}>
                                <Form.Item label="Location" {...formItemProps}>
                                    {<Form.Item name={'locationCode'} noStyle rules={[
                                            {
                                                required: true,
                                                message: 'Location is required',
                                            },
                                        ]} initialValue={'OPF'}>
                                        <Select disabled={isEdit} onChange={this.handleLocationChange}>
                                            {locations.map((r) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item label="Area" {...formItemProps}>
                                    {<Form.Item name={'areaCode'} noStyle rules={[
                                            {
                                                required: true,
                                                message: 'Area is required',
                                            },
                                        ]} initialValue={'OPF_GAS'}>
                                        <Select disabled={isEdit} onChange={this.handlerAreaChange}>
                                            {filteredAreas.map((r) => (
                                                <Select.Option key={r.id} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item label="Logsheet" {...formItemProps}>
                                    {<Form.Item name={'logsheetId'} noStyle rules={[
                                            {
                                                required: true,
                                                message: 'Logsheet is required',
                                            },
                                        ]} initialValue={16}>
                                        <Select disabled={isEdit}>
                                            {filteredLogsheets.map((r) => (
                                                <Select.Option key={r.id} value={r.id} title={r.name}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>

                            <Col span={8}>
                                <Form.Item label="Schedule name" {...formItemProps}>
                                    {<Form.Item name={'scheduleName'} noStyle rules={[
                                            {
                                                required: true,
                                                whitespace: true,
                                                message: 'Name is required',
                                            },
                                        ]} initialValue={'Schedule 1'}><Input /></Form.Item>}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item label="Year" {...formItemProps}>
                                    {<Form.Item name={'year'} noStyle rules={[
                                            {
                                                required: true,
                                                message: 'Year is required',
                                            },
                                        ]} initialValue={moment().year()}>
                                        <Select disabled={isEdit} onChange={this.handleYearChange}>
                                            {this.years.map((r) => (
                                                <Select.Option key={r} value={r}>
                                                    {r}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item label="Date period" {...formItemProps}>
                                    {<Form.Item name={'datePeriod'} noStyle rules={[
                                            {
                                                type: 'array',
                                                required: true,
                                                message: 'Period is required',
                                            },
                                            {
                                                validator: this.validateEndDate,
                                            },
                                            {
                                                validator: this.validateStartDate,
                                            },
                                        ]} initialValue={[tomorrow, endDate]}>
                                        <DatePicker.RangePicker
                                            style={{ width: '100%' }}
                                            disabled={datePeriodDisabled}
                                            disabledDate={this.disableDate}
                                            onChange={this.props.onFormChange}
                                        />,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>

                            <Col span={8}>
                                <Form.Item label="Schedule config" {...formItemProps}>
                                    {<Form.Item name={'scheduleConfigId'} noStyle rules={[
                                            {
                                                required: true,
                                                message: 'Schedule config is required',
                                            },
                                        ]} initialValue={7}>
                                        <Select disabled={scheduleConfigDisabled} onChange={this.props.onFormChange}>
                                            {filteredScheduleConfigs.map((r) => (
                                                <Select.Option key={r.id} value={r.id}>
                                                    {r.name}
                                                </Select.Option>
                                            ))}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>

                            <Col span={8}>
                                <Row type="flex" justify="space-between">
                                    <Form.Item label="Schedule type" style={{ width: '53%' }} labelCol={{ span: 11 }}>
                                        {<Form.Item name={'scheduleTypeCode'} noStyle rules={[
                                                {
                                                    required: true,
                                                    whitespace: true,
                                                    message: 'Schedule type is required',
                                                },
                                            ]} initialValue={'MONTHLY'}>
                                            <Select disabled={scheduleTypeDisabled}>
                                                {scheduleTypes.map((r) => (
                                                    <Select.Option key={r.code} value={r.code} title={r.name}>
                                                        {r.name}
                                                    </Select.Option>
                                                ))}
                                            </Select>,
                                        </Form.Item>}
                                    </Form.Item>

                                    <Form.Item>
                                        {<Form.Item name={'timeOptions'} noStyle rules={[
                                                {
                                                    type: 'array',
                                                    required: true,
                                                    message: 'Time configuration is required',
                                                },
                                            ]} initialValue={[...this.defaultTimes]}>
                                            <Button
                                                // disabled={scheduleTypeDisabled}
                                                style={{ width: '100%' }}
                                                onClick={this.openScheduleModal}
                                            >
                                                Configure schedule
                                            </Button>,
                                        </Form.Item>}
                                    </Form.Item>
                                </Row>
                            </Col>
                            <Col span={8}>
                                <Form.Item label="Schedule status" {...formItemProps}>
                                    <Tag color="blue">{this.state.scheduleStatus}</Tag>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>

                    {scheduleTimeModalShown && (
                        <ConfigureScheduleModal
                            visible={scheduleTimeModalShown}
                            scheduleTypeCode={scheduleTypeCode}
                            wrappedComponentRef={this.initScheduleModal}
                            timeOptions={timeOptions}
                            weekDayCodes={weekDayCodes}
                            year={year}
                            disabled={scheduleTypeDisabled}
                            onOk={this.saveScheduleConfig}
                            onCancel={() => this.setState({ scheduleTimeModalShown: false })}
                        />
                    )}
                </>
            );
        }
    },
);

export default ScheduleForm;
