import React, { Fragment } from 'react';
import { Row } from 'antd';
import { ScheduleConfig, GroupConfig } from '../types';
import moment from 'moment';
import generateScheduleSrv from '../GenerateScheduleService';
import { RotationCalendarType } from '../constants';
import './CalendarTable.css';
import { EditSelectedDatesModal } from '../modals/EditSelectedDatesModal';
import { WrappedFormUtils } from '../../legacy-form-types';

type Props = {
    scheduleConfig: ScheduleConfig;

    /** When editing schedule config disable edit past days */
    isEdit?: boolean;

    /**Disable mouse events(editing calendar) */
    readonly?: boolean;

    /** required when using in schedule container, to view only */
    datePeriod?: moment.Moment[];
};
type State = {
    startDate?: moment.Moment;
    endDate?: moment.Moment;
    isSelecting: boolean;
    modalShown: boolean;
};

class CalendarTable extends React.Component<Props, State> {
    readonly selectedClass = 'selected';
    months: moment.Moment[] = [];
    currentRow: HTMLElement | null = null;
    editDatesModalRef: any;
    selectedGroup?: GroupConfig;

    constructor(props: Props) {
        super(props);
        this.state = {
            isSelecting: false,
            modalShown: false,
        };
    }

    handleMouseDown = (e: React.MouseEvent, date: moment.Moment, group: GroupConfig) => {
        this.setState({
            isSelecting: true,
            startDate: date,
            endDate: date,
        });

        (e.currentTarget as HTMLElement).classList.add(this.selectedClass);
        this.currentRow = (e.currentTarget as HTMLElement).parentElement;
        this.selectedGroup = group;
    };

    handleMouseEnter = (e: React.MouseEvent, date: moment.Moment) => {
        if (this.state.isSelecting) {
            const row: HTMLElement = (e.currentTarget as HTMLElement).parentElement!;
            const target = e.currentTarget as HTMLElement;

            // if cell isn't visited yet
            if (this.currentRow === row && !target.classList.contains(this.selectedClass)) {
                target.classList.add(this.selectedClass);
                this.setState({ endDate: date });
            } else {
                // cell is visited or another row
                this.showModal();
                this.clearSelected(target.parentElement!.parentElement!);
            }
        }
    };

    handleMouseUp = (e: React.MouseEvent, date: moment.Moment) => {
        if (this.state.isSelecting) {
            this.setState({
                isSelecting: false,
                endDate: date,
            });

            this.showModal();
            const tbody: HTMLElement = (e.currentTarget as HTMLElement).parentElement!.parentElement!;
            this.clearSelected(tbody);
        }
    };

    showModal(): void {
        if (this.state.startDate! > this.state.endDate!) {
            this.setState({
                startDate: this.state.endDate,
                endDate: this.state.startDate,
            });
        }
        this.setState({ isSelecting: false, modalShown: true });
    }

    clearSelected(tbody: HTMLElement): void {
        const elements: HTMLCollectionOf<Element> = tbody.getElementsByClassName(this.selectedClass);

        for (const element of Array.from(elements)) {
            element.classList.remove(this.selectedClass);
        }
    }

    handleModalOk = () => {
        const form = this.editDatesModalRef.props.form as WrappedFormUtils<any>;
        form.validateFields((err: any, values: { shiftType: RotationCalendarType }) => {
            if (err) return;

            const { shiftType } = values;
            const { startDate, endDate } = this.state;
            const startIdx = startDate!.dayOfYear() - 1;
            const endIdx = endDate!.dayOfYear() - 1;

            for (let i = startIdx; i <= endIdx; i++) {
                this.selectedGroup!.schedule![i] = shiftType!;
            }

            this.setState({ modalShown: false });
        });
    };

    getGroupItemRow(group: GroupConfig, month: moment.Moment, color: string): JSX.Element[] {
        const { scheduleConfig } = this.props;
        let today = moment();

        return generateScheduleSrv.getDaysInMonth(month).map((day: number) => {
            const monthDate: moment.Moment = moment([month.year(), month.month(), day]);
            const monthDayOfYear: number = monthDate.dayOfYear();

            let datePeriod: moment.Moment[] | undefined = scheduleConfig!.datePeriod;
            if (this.props.datePeriod) {
                datePeriod = this.props.datePeriod;
            }

            const isEditable: boolean | undefined =
                group.schedule![monthDayOfYear - 1] !== RotationCalendarType.None &&
                group &&
                datePeriod &&
                datePeriod![0] &&
                datePeriod![1] &&
                monthDate.isBetween(datePeriod![0], datePeriod![1], 'day', "[]");

            let isInactive: boolean = !!this.props.isEdit && today.startOf('day') > monthDate.startOf('day');

            let dayType: string = '';
            switch (group.schedule![monthDayOfYear - 1]) {
                case RotationCalendarType.Day:
                    dayType = 'D';
                    break;
                case RotationCalendarType.Night:
                    dayType = 'N';
                    break;
                default:
                    break;
            }

            let className = isInactive ? 'editable inactive ' : 'editable ';
            className = dayType ? className + color : className;

            if (!isEditable) className = 'disabled';

            let mouseListeners: any = {
                onMouseDown: (e: any) => this.handleMouseDown(e, monthDate, group),
                onMouseEnter: (e: any) => this.handleMouseEnter(e, monthDate),
                onMouseUp: (e: any) => this.handleMouseUp(e, monthDate),
            };

            if (isEditable === false || isInactive || this.props.readonly) {
                mouseListeners = {};
            }

            return (
                <td key={monthDayOfYear + ' ' + group.code} className={className} {...mouseListeners}>
                    {dayType}
                </td>
            );
        });
    }

    getGroupRows(month: moment.Moment): JSX.Element {
        const { scheduleConfig } = this.props;

        return (
            <Fragment key={month.month() + '_'}>
                <tr>
                    <td rowSpan={2}>Group 1/2</td>
                    <td>{scheduleConfig!.group1!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group1!, month, 'gold')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group2!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group2!, month, 'blue')}
                </tr>
                <tr>
                    <td rowSpan={2}>Group 3/4</td>
                    <td>{scheduleConfig!.group3!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group3!, month, 'red')}
                </tr>
                <tr>
                    <td>{scheduleConfig!.group4!.name}</td>
                    {this.getGroupItemRow(scheduleConfig!.group4!, month, 'green')}
                </tr>
            </Fragment>
        );
    }

    /**
     * ex. 1, 2, 3, 4...
     * @param date - object month(january, febr, ...)
     */
    getMonthHeaderTHs(date: moment.Moment): JSX.Element[] {
        return generateScheduleSrv.getDaysInMonth(date).map((day: number) => <th key={day}>{day}</th>);
    }

    getMonthRows(): JSX.Element[] {
        const { scheduleConfig } = this.props;
        this.months = [];

        for (let i = 0; i < 12; i++) {
            const currMonth = moment([scheduleConfig.year!, i, 1]);
            this.months.push(currMonth);
        }

        const rows: JSX.Element[] = [];

        this.months.forEach((month: moment.Moment) => {
            const monthRow: JSX.Element = (
                <tr key={month.month()} style={{ height: 40 }}>
                    <th rowSpan={2 * 2 + 1}>{month.month() + 1}</th>
                    <th colSpan={2}>{moment.months(month.month())}</th>
                    {this.getMonthHeaderTHs(month)}
                </tr>
            );

            const groupRows: JSX.Element = this.getGroupRows(month);

            rows.push(monthRow);
            rows.push(groupRows);
        });

        return rows;
    }

    render() {
        const { scheduleConfig } = this.props;
        const { modalShown, startDate, endDate } = this.state;

        return (
            <Row className="schedule-config">
                <table>
                    <tbody>{scheduleConfig && this.getMonthRows()}</tbody>
                </table>

                <EditSelectedDatesModal
                    wrappedComponentRef={(ref: any) => {
                        this.editDatesModalRef = ref;
                    }}
                    visible={modalShown}
                    startDate={startDate!}
                    endDate={endDate!}
                    onOk={this.handleModalOk}
                    onCancel={() => this.setState({ modalShown: false })}
                />
            </Row>
        );
    }
}

export default CalendarTable;
