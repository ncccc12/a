import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Select} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { DictionaryDto, AreaVm, LogsheetDictionaryVm } from '../../services/Client';

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    logsheets: LogsheetDictionaryVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredAreas: AreaVm[];
    filteredLogsheets: LogsheetDictionaryVm[];
};

const ScheduleDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredAreas: [],
                filteredLogsheets: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            if (prevProps.visible === false && this.props.visible) {
                const { form } = this.props;
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    this.filterAreas(locationCode);
                }, 1000);
            }
        }

        handleLocationChange = (locationCode: string) => {
            const { form } = this.props;

            this.filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
                logsheetId: undefined,
            });
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;
            const filteredAreas = areas.filter(r => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        handlerAreaChange = (areaCode: string) => {
            const { form } = this.props;
            this.filterLogsheets(areaCode);
            form.setFieldsValue({
                logsheetId: undefined,
            });
        };

        filterLogsheets = (areaCode: string) => {
            const { logsheets } = this.props;
            const filteredLogsheets = logsheets.filter(r => r.areaCode === areaCode);
            this.setState({ filteredLogsheets });
        };

        render() {
            const {
                visible,
                

                locations,
            } = this.props;
            const { filteredAreas, filteredLogsheets } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 7,
                },
                wrapperCol: {
                    span: 17,
                },
            };

            return (
                <Drawer visible={visible} title="Add new" width={700} destroyOnClose onClose={this.props.onClose}>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Location">
                            {<Form.Item name={'locationCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Location is required',
                                    },
                                ]}>
                                <Select onChange={this.handleLocationChange}>
                                    {locations.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Area">
                            {<Form.Item name={'areaCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Area is required',
                                    },
                                ]}>
                                <Select onChange={this.handlerAreaChange}>
                                    {filteredAreas.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Logsheet">
                            {<Form.Item name={'logsheetId'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Logsheet is required',
                                    },
                                ]}>
                                <Select>
                                    {filteredLogsheets.map(r => (
                                        <Select.Option key={r.id} value={r.id} title={r.name}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                    </Form>
                </Drawer>
            );
        }
    },
);

export default ScheduleDrawer;
