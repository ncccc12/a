import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Select, Input, Button, Switch} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { AreaVm, DictionaryDto, GroupVm } from '../../services/Client';

export type OperatorForm = {
    id: number;
    locationCode: string;
    areaCode: string;
    lastName: string;
    firstName: string;
    position: string;
    groupCode: string;
    isActive: boolean;
};

type Props = {
    visible: boolean;
    locations: DictionaryDto[];
    areas: AreaVm[];
    groups: GroupVm[];
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps;
type State = {
    filteredAreas: AreaVm[];
    filteredGroups: GroupVm[];
};

const OperatorDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredAreas: [],
                filteredGroups: [],
            };
        }

        componentDidUpdate(prevProps: Props) {
            if (prevProps.visible === false && this.props.visible) {
                const { form } = this.props;
                setTimeout(() => {
                    const locationCode = form.getFieldValue('locationCode');
                    this.filterAreas(locationCode);

                    const areacCode = form.getFieldValue('areaCode');
                    this.filterGroups(areacCode);
                }, 1000);
            }
        }

        handleLocationChange = (locationCode: string) => {
            const { form } = this.props;

            this.filterAreas(locationCode);
            form.setFieldsValue({
                areaCode: '',
            });
        };

        handleAreaChange = (areaCode: string) => {
            this.filterGroups(areaCode);
            this.props.form.setFieldsValue({
                groupCode: '',
            });
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;
            const filteredAreas = areas.filter(r => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        filterGroups = (areaCode: string) => {
            const { groups } = this.props;
            const filteredGroups = groups.filter(r => r.areaCode === areaCode);
            this.setState({ filteredGroups });
        };

        render() {
            const {
                visible,
                form,
                locations,
                
            } = this.props;
            const { filteredAreas, filteredGroups } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };

            void 0;
            let id = form.getFieldValue('id');

            return (
                <Drawer
                    title={id ? 'Edit operator' : 'Add new operator'}
                    visible={visible}
                    width={500}
                    destroyOnClose={true}
                    onClose={this.props.onClose}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Location">
                            {<Form.Item name={'locationCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Location is required',
                                    },
                                ]}>
                                <Select onChange={this.handleLocationChange}>
                                    {locations.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Area">
                            {<Form.Item name={'areaCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Area is required',
                                    },
                                ]}>
                                <Select onChange={this.handleAreaChange}>
                                    {filteredAreas.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Group">
                            {<Form.Item name={'groupCode'} noStyle rules={[
                                    {
                                        required: true,
                                        message: 'Group is required',
                                    },
                                ]}>
                                <Select>
                                    {filteredGroups.map(r => (
                                        <Select.Option key={r.id} value={r.code}>
                                            {r.name}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Last name">
                            {<Form.Item name={'lastName'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Last name is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="First name">
                            {<Form.Item name={'firstName'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'First name is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Position">
                            {<Form.Item name={'position'} noStyle rules={[
                                    {
                                        required: true,
                                        whitespace: true,
                                        message: 'Position is required',
                                    },
                                ]}><Input /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Is active">
                            {<Form.Item name={'isActive'} noStyle valuePropName={'checked'}><Switch disabled={!id} /></Form.Item>}
                        </Form.Item>
                    </Form>
                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button onClick={this.props.onSubmit} type="primary">
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default OperatorDrawer;
