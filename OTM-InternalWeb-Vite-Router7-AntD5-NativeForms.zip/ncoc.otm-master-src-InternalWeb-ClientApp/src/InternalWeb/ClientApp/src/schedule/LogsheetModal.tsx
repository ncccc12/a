import { withModernForm, modernFormField } from '../modern-form';
import React from 'react';
import { Modal, TimePicker, Button} from 'antd';
import Icon from '../LegacyIcon';
import { Form } from 'antd';
import type { FormComponentProps, FormProps } from '../legacy-form-types';
import { LogsheetListItemVm } from '../services/Client';
import moment from 'moment';
import './ConfigureScheduleModal.css';

type Props = {
    visible: boolean;
    logsheet?: LogsheetListItemVm;
    loading: boolean;
    onOk: () => void;
    onCancel: () => void;
} & FormComponentProps;

type State = {
    keys: number[];
};

const LogsheetModal = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        id = 0;
        timeFormat = 'HH:mm';

        constructor(props: Props) {
            super(props);

            this.state = {
                keys: [],
            };
        }

        componentDidMount() {
            const logsheet = this.props.logsheet;
            if (!logsheet) return;

            this.initTimeOptions();
        }

        initTimeOptions = () => {
            const { form, logsheet } = this.props;

            const keys: number[] = [];

            this.id = logsheet!.schedule!.timeOptions!.length;
            let timeOptions: any[] = [];

            for (let i = 0; i < this.id; i++) {
                let opt = logsheet!.schedule!.timeOptions![i];
                keys.push(i);
                timeOptions.push({
                    id: opt.id,
                    time: moment(opt.time, this.timeFormat),
                });
            }

            this.setState({ keys: keys }, () => {
                form.setFieldsValue({
                    timeOptions,
                });
            });
        };

        addTime = () => {
            const { form } = this.props;
            const keys: number[] = form.getFieldValue('keys');
            const nextKeys = keys.concat(this.id++);

            form.setFieldsValue({
                keys: nextKeys,
            });
        };

        removeTime = (k: number) => {
            const { form } = this.props;
            const keys: number[] = form.getFieldValue('keys');

            if (keys.length === 1) return;

            form.setFieldsValue({
                keys: keys.filter(r => r !== k),
            });
        };

        render() {
            const {
                visible,
                logsheet,
                form: { getFieldValue },
            } = this.props;

            void 0;
            const keys: number[] = getFieldValue('keys');

            const formItemLayoutWithOutLabel: FormProps = {
                wrapperCol: {
                    span: 16,
                    offset: 8,
                },
            };

            const formItemLayout: FormProps = {
                labelCol: {
                    span: 8,
                },
                wrapperCol: {
                    span: 16,
                },
            };

            void 0;

            return (
                <Modal
                    visible={visible}
                    title="Edit logsheet"
                    okText="Save"
                    className="config-schedule-modal"
                    confirmLoading={this.props.loading}
                    onOk={this.props.onOk}
                    onCancel={this.props.onCancel}
                >
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} layout="horizontal" {...formItemLayout} labelAlign="left">
                        <Form.Item label="Logsheet name">{logsheet && logsheet.name}</Form.Item>
                        <Form.Item label="Schedule type">{logsheet && logsheet.schedule!.type}</Form.Item>
                        {keys.map((r, idx) => {
                            void 0;

                            return (
                                <Form.Item
                                    key={r}
                                    label={idx === 0 ? 'Times' : ''}
                                    {...(idx === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                >
                                    {<Form.Item name={`timeOptions[${r}].time`} noStyle rules={[{ required: true, message: 'time is required' }]}>
                                        <TimePicker
                                            minuteStep={5}
                                            style={{ marginRight: 8, width: 180 }}
                                            format={this.timeFormat}
                                        />,
                                    </Form.Item>}
                                    {keys.length > 1 ? (
                                        <Icon
                                            className="dynamic-delete-button"
                                            type="minus-circle-o"
                                            title="Remove"
                                            onClick={() => this.removeTime(r)}
                                        />
                                    ) : null}
                                </Form.Item>
                            );
                        })}

                        <Form.Item {...formItemLayoutWithOutLabel}>
                            <Button type="dashed" onClick={this.addTime} style={{ width: 180 }}>
                                <Icon type="plus" /> Add time
                            </Button>
                        </Form.Item>
                    </Form>
                </Modal>
            );
        }
    },
);

export default LogsheetModal;
