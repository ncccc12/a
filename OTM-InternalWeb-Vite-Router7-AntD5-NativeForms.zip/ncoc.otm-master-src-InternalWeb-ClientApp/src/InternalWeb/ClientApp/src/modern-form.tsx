/** Native Ant Design 5 form instance injection for existing class components.
 * Form.Item fields and validation are handled by rc-field-form (Ant Design 5).
 * Class-based screens retain their established parent-facing ref API.
 */
import React from 'react';
import { Form } from 'antd';
import type { FormInstance } from 'antd';

export type ModernForm = FormInstance & {
  validateFields: (...args: any[]) => any;
  validateFieldsAndScroll: (...args: any[]) => any;
  getFieldError: (name: any) => string[];
  setFieldsValue: (values: any, callback?: () => void) => void;
};

export const modernFormField = ({ value }: { value: unknown }) => ({ value });

interface FormOptions<P> {
  mapPropsToFields?: (props: P) => Record<string, { value: unknown }>;
  onValuesChange?: (props: P, values: any, allValues?: any) => void;
}

export function withModernForm<P extends { form: any }>(options: FormOptions<P> = {}) {
  return function <T extends React.ComponentType<P>>(Component: T): React.ComponentType<Omit<P, 'form'> & { wrappedComponentRef?: (instance: any) => void }> {
    const Wrapped = React.forwardRef<any, Omit<P, 'form'> & { wrappedComponentRef?: (instance: any) => void }>((props, forwardedRef) => {
      const [nativeForm] = Form.useForm();
      const latestProps = React.useRef(props);
      latestProps.current = props;
      const originalValidate = React.useMemo(() => nativeForm.validateFields.bind(nativeForm), [nativeForm]);
      const form = React.useMemo(() => {
        // Keep existing callback validation call sites operational; fields, store,
        // initial values and rules themselves use the current antd Form implementation.
        const facade = Object.create(nativeForm) as ModernForm;
        facade.validateFields = (...args: any[]) => {
          const callback = args.find((arg) => typeof arg === 'function');
          if (callback) {
            const names = Array.isArray(args[0]) ? args[0] : undefined;
            originalValidate(names).then((values) => callback(null, values)).catch((err) => callback(err, nativeForm.getFieldsValue(true)));
            return;
          }
          return originalValidate(...args);
        };
        facade.validateFieldsAndScroll = facade.validateFields;
        facade.setFieldsValue = (values: any, callback?: () => void) => {
          nativeForm.setFieldsValue(values);
          callback?.();
        };
        return facade;
      }, [nativeForm, originalValidate]);
      const mapped = options.mapPropsToFields?.(props as P);
      const values = mapped && Object.fromEntries(Object.entries(mapped).map(([k, v]) => [k, v?.value]));
      const serialized = JSON.stringify(values, (_key, value) => value && typeof value.toISOString === 'function' ? value.toISOString() : value);
      React.useEffect(() => { if (values) nativeForm.setFieldsValue(values); }, [serialized]);
      // Legacy onValuesChange is now registered on the native Form component.
      const classProps = { ...props, form, __onValuesChange: (changed: any, all: any) => options.onValuesChange?.(latestProps.current as P, changed, all) } as unknown as P;
      const ClassComponent = Component as any;
      return <ClassComponent {...classProps} ref={(instance: any) => {
        props.wrappedComponentRef?.(instance);
        if (typeof forwardedRef === 'function') forwardedRef(instance);
        else if (forwardedRef) forwardedRef.current = instance;
      }} />;
    });
    return Wrapped as any;
  };
}
