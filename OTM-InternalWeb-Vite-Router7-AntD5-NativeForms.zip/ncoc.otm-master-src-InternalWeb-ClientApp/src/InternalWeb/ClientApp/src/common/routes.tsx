import { LegacyRouteProps as RouteProps } from '../router/legacy';

import UnautharizedPage from './pages/UnautharizedPage';
const routes: RouteProps[] = [
    {
        path: '/Unautharized',
        component: UnautharizedPage,
        exact: true,
    },
];

export default routes;
