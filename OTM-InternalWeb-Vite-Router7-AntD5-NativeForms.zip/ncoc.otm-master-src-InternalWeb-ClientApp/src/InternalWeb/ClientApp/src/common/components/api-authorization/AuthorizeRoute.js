import React, { Component } from 'react';
import { Navigate } from 'react-router-dom';
import { withRouteProps } from '../../../router/legacy';
import { ApplicationPaths, QueryParameterNames } from './ApiAuthorizationConstants';
import authService from './AuthorizeService';

class AuthorizeRoute extends Component {
    state = { ready: false, authenticated: false };
    componentDidMount() {
        this._subscription = authService.subscribe(() => this.authenticationChanged());
        this.populateAuthenticationState();
    }
    componentWillUnmount() { authService.unsubscribe(this._subscription); }
    async populateAuthenticationState() {
        const authenticated = await authService.isAuthenticated();
        this.setState({ ready: true, authenticated });
    }
    async authenticationChanged() {
        this.setState({ ready: false, authenticated: false });
        await this.populateAuthenticationState();
    }
    render() {
        if (!this.state.ready) return null;
        if (!this.state.authenticated) {
            const redirectUrl = `${ApplicationPaths.Login}?${QueryParameterNames.ReturnUrl}=${encodeURIComponent(window.location.href)}`;
            return <Navigate to={redirectUrl} replace />;
        }
        const Screen = withRouteProps(this.props.component);
        return <Screen />;
    }
}
export default AuthorizeRoute;
