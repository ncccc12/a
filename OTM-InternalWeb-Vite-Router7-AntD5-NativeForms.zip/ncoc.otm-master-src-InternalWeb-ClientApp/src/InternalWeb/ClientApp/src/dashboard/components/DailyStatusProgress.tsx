import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Spin, Card, Row, Col, Select, Button, Typography} from 'antd';
import { Form } from 'antd';
import { GaugeChart } from '@opd/g2plot-react';
import { AreaVm, DictionaryDto, GetTimeHistoriesStatusesCountQuery } from '../../services/Client';
import moment from 'moment';
import { logsheetTimeHistoriesClient } from '../../services';
import type { FormComponentProps } from '../../legacy-form-types';
import ButtonGroup from 'antd/lib/button/button-group';

// const config = {
//     rangeMax: 100,
//     forceFit: true,
//     title: {
//         visible: true,
//         text: 'Daily progress of completed log sheets',
//     },
//     legend: {
//         visible: true,
//         custom: true,
//         items: [
//             {
//                 value: 'Completed',
//                 marker: {
//                     symbol: 'square',
//                     fill: '#5B8FF9',
//                 },
//             },
//             {
//                 value: 'Remaining',
//                 marker: {
//                     symbol: 'square',
//                     fill: '#FFDBA2',
//                 },
//             },
//         ],
//     },
// };

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    filledPercent: number;
    filteredAreas: AreaVm[];
};

const DailyStatusProgress = withModernForm<Props>()(
    class DailyStatusProgress extends React.Component<Props, State> {
        /**
         *
         */
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                filledPercent: 0,
                filteredAreas: [],
            };
        }

        componentDidMount() {
            this.search();
        }

        search = async () => {
            this.setState({ loading: true });

            const { form } = this.props;

            form.validateFields(async (errors: any, values: any) => {
                let query = new GetTimeHistoriesStatusesCountQuery();
                let today = moment().startOf('day').utc(true).toDate();
                query.datePeriod = [today, today];
                query.locationCode = values.locationCode;
                query.areaCode = values.areaCode;

                let result = await logsheetTimeHistoriesClient.getTimeHistoriesStatusesCount(query);
                let total = 0;
                let filled = 0;
                result.forEach((r) => {
                    total += r.count!;

                    if (r.statusCode === 'COMPLETED' || r.statusCode === 'VALUES_UPLOADED') {
                        filled += r.count!;
                    }
                });

                let filledPercent = (filled * 100) / total;

                this.setState({ loading: false, filledPercent });
            });
        };

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        renderHeader = () => {
            const { filteredAreas } = this.state;
            const {
                
                locations,
            } = this.props;

            return (
                <>
                    <Form onValuesChange={(props as any).__onValuesChange} form={props.form} layout="inline" labelAlign="left">
                        <Row type="flex" justify="space-between">
                            <Typography.Title level={4}>Daily progress</Typography.Title>
                            <Form.Item style={{ margin: 0 }}>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Row>
                        <Row gutter={24}>
                            <Col md={12}>
                                <Form.Item
                                    label="Location"
                                    style={{ width: '100%' }}
                                    wrapperCol={{ span: 14 }}
                                    labelCol={{ span: 10 }}
                                >
                                    {<Form.Item name={'locationCode'} noStyle>
                                        <Select onChange={this.handleLocationChange}>
                                            {locations.map((r) => {
                                                return (
                                                    <Select.Option key={r.code} value={r.code}>
                                                        {r.name}
                                                    </Select.Option>
                                                );
                                            })}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>
                            <Col md={12}>
                                <Form.Item
                                    label="Area"
                                    style={{ width: '100%' }}
                                    wrapperCol={{ span: 18 }}
                                    labelCol={{ span: 6 }}
                                >
                                    {<Form.Item name={'areaCode'} noStyle>
                                        <Select>
                                            {filteredAreas.map((r) => {
                                                return (
                                                    <Select.Option key={r.code} value={r.code}>
                                                        {r.name}
                                                    </Select.Option>
                                                );
                                            })}
                                        </Select>,
                                    </Form.Item>}
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </>
            );
        };

        render() {
            const { loading, filledPercent } = this.state;

            return (
                <Spin spinning={loading}>
                    <Card title={this.renderHeader()} style={{ minHeight: 363 }}>
                        {/* <BulletChart
                            autoFit={true}
                            measureField=""
                            rangeField=""
                            targetField=""
                            legend={{
                                visible: true,
                            }}
                            height={150}
                            data={[
                                {
                                    title: 'Completed',
                                    ranges: [100],
                                    measures: [50],
                                    targets: [100],
                                },
                            ]}
                        /> */}
                        <GaugeChart
                            autoFit={true}
                            height={350}
                            percent={filledPercent / 100}
                            range={{
                                ticks: [0, 1],
                                color: ['#30BF78', '#E8EDF3'],
                            }}
                            indicator={{
                                pointer: { style: { stroke: '#D0D0D0' } },
                                pin: { style: { stroke: '#D0D0D0' } },
                            }}
                            axis={{
                                label: {
                                    formatter: (v: string) => Number(v) * 100 + '%',
                                },
                            }}
                        />
                    </Card>
                </Spin>
            );
        }
    },
);

export default DailyStatusProgress;
