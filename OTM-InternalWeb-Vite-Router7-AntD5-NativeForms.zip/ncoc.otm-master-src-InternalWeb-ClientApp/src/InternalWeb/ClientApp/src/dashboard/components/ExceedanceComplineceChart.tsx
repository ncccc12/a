import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Card, List, Col, DatePicker, Spin, Row, Select, Button, Typography} from 'antd';
import { Form } from 'antd';
import moment from 'moment';
import { LineChart } from '@opd/g2plot-react';
import { reportsClient } from '../../services';
import { DeviceTag, DictionaryDto, AreaVm, GetExceedanceComplianceCountQuery } from '../../services/Client';
import type { FormComponentProps } from '../../legacy-form-types';
import ButtonGroup from 'antd/lib/button/button-group';

const dateFormat = 'DD-MM-YYYY';

const config = {
    title: {
        visible: true,
        text: '',
    },
    description: {
        visible: true,
        text: '',
    },
    legend: {
        flipPage: false,
    },
    forceFit: true,
    height: 376,
    xField: 'x',
    yField: 'y',
    seriesField: 'series',
    color: ['#5B8FF9', '#5AD8A6'],
};

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    topTags: DeviceTag[];
    filteredAreas: AreaVm[];
};

const ExceedanceComplinceChart = withModernForm<Props>()(
    class ExceedanceComplinceChart extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                datas: [],
                topTags: [],
                filteredAreas: [],
            };
        }

        componentDidMount() {
            this.search();
        }

        search = async () => {
            this.setState({ loading: true });
            const { form } = this.props;
            form.validateFields(async (errors: any, values: any) => {
                let query = new GetExceedanceComplianceCountQuery();
                query.datePeriod = values.datePeriod?.map((r: moment.Moment) => r.utc(true).toDate()) || [];
                query.locationCode = values.locationCode;
                query.areaCode = values.areaCode;
                let data = await reportsClient.getExceedanceComplianceCount(query);

                let datas = data.complinceExceedanceItems!.map((r) => {
                    return {
                        series: r.type,
                        x: moment(r.date).format(dateFormat),
                        y: r.count,
                    };
                });

                this.setState({ datas, topTags: data.topTags!, loading: false });
            });
        };

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        renderHeader = () => {
            const {
                
                locations,
            } = this.props;
            const { filteredAreas } = this.state;

            return (
                <Form onValuesChange={(props as any).__onValuesChange} form={props.form} layout="inline" labelAlign="left">
                    <Row gutter={24}>
                        <Col md={6}>
                            <Form.Item
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                                label="Location"
                            >
                                {<Form.Item name={'locationCode'} noStyle>
                                    <Select onChange={this.handleLocationChange}>
                                        {locations.map((r) => {
                                            return (
                                                <Select.Option key={r.code} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            );
                                        })}
                                    </Select>,
                                </Form.Item>}
                            </Form.Item>
                        </Col>
                        <Col md={5}>
                            <Form.Item
                                label="Area"
                                style={{ width: '100%' }}
                                wrapperCol={{ span: 14 }}
                                labelCol={{ span: 10 }}
                            >
                                {<Form.Item name={'areaCode'} noStyle>
                                    <Select>
                                        {filteredAreas.map((r) => {
                                            return (
                                                <Select.Option key={r.code} value={r.code}>
                                                    {r.name}
                                                </Select.Option>
                                            );
                                        })}
                                    </Select>,
                                </Form.Item>}
                            </Form.Item>
                        </Col>
                        <Col md={7}>
                            <Form.Item style={{ width: '100%' }}>
                                {<Form.Item name={'datePeriod'} noStyle initialValue={[moment().startOf('day'), moment().startOf('day')]}>
                                    <DatePicker.RangePicker
                                        ranges={{
                                            Today: [moment(), moment()],
                                            'This week': [moment().startOf('week'), moment().endOf('week')],
                                            'This Month': [moment().startOf('month'), moment().endOf('month')],
                                            'This year': [moment().startOf('year'), moment().endOf('year')],
                                        }}
                                    />,
                                </Form.Item>}
                            </Form.Item>
                        </Col>
                        <Col md={6}>
                            <Form.Item>
                                <ButtonGroup>
                                    <Button type="primary" onClick={this.search}>
                                        Search
                                    </Button>
                                    <Button onClick={this.resetFilter}>Reset</Button>
                                </ButtonGroup>
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            );
        };

        render() {
            const { loading, datas, topTags } = this.state;

            return (
                <Spin spinning={loading}>
                    <Card
                        title={<Typography.Title level={3}>Exceedance/Compliance tasks status</Typography.Title>}
                        extra={this.renderHeader()}
                    >
                        <Col span={18}>{!loading && <LineChart {...config} data={datas} />}</Col>
                        <Col span={6}>
                            <List
                                header={<b> Top 10 sensors with exceedance: </b>}
                                dataSource={topTags}
                                renderItem={(item) => (
                                    <List.Item>{`${item.deviceName}/${item.tagName}(${item.exceedanceCount})`}</List.Item>
                                )}
                            ></List>
                        </Col>
                    </Card>
                </Spin>
            );
        }
    },
);

export default ExceedanceComplinceChart;
