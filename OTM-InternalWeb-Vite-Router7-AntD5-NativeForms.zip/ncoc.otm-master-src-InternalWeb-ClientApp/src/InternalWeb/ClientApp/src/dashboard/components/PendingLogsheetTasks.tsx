import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Row, Card, List, Col, Select, Button, Spin, Typography} from 'antd';
import { Form } from 'antd';
import moment from 'moment';
import { logsheetTimeHistoriesClient } from '../../services';
import { AreaVm, DictionaryDto, LogsheestTaskVm } from '../../services/Client';
import ButtonGroup from 'antd/lib/button/button-group';
import type { FormComponentProps } from '../../legacy-form-types';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;
type State = {
    pendingTasks: LogsheestTaskVm[];

    filteredAreas: AreaVm[];
    loading: boolean;
};

const PendingLogsheetTasks = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                pendingTasks: [],
                filteredAreas: [],
                loading: false,
            };
        }

        componentDidMount(){
            this.search();
        }

        search = async () => {
            const { form } = this.props;
            form.validateFields(async (err: any, values: any) => {
                this.setState({ loading: true });

                let pendingTasks = await logsheetTimeHistoriesClient.getPendingLogsheetTasks(
                    values.locationCode,
                    values.areaCode,
                );

                this.setState({ pendingTasks, loading: false });
            });
        };

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };

        renderHeader = () => {
            const { filteredAreas } = this.state;
            const {
                
                locations,
            } = this.props;

            return (
                <>
                    <Typography.Title level={4}>Pending tasks</Typography.Title>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} layout="inline">
                        <Form.Item label="Location">
                            {<Form.Item name={'locationCode'} noStyle>
                                <Select style={{ width: 250 }} onChange={this.handleLocationChange}>
                                    {locations.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Area">
                            {<Form.Item name={'areaCode'} noStyle>
                                <Select style={{ width: 250 }}>
                                    {filteredAreas.map((r) => {
                                        return (
                                            <Select.Option key={r.code} value={r.code}>
                                                {r.name}
                                            </Select.Option>
                                        );
                                    })}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item>
                            <ButtonGroup>
                                <Button type="primary" onClick={this.search}>
                                    Search
                                </Button>
                                <Button onClick={this.resetFilter}>Reset</Button>
                            </ButtonGroup>
                        </Form.Item>
                    </Form>
                </>
            );
        };

        render() {
            const { pendingTasks, loading } = this.state;

            return (
                <Spin spinning={loading}>
                    <Card title={this.renderHeader()} style={{ height: '100%', minHeight: 730 }}>
                        <List
                            dataSource={pendingTasks}
                            pagination={{ pageSize: 8 }}
                            renderItem={(r) => (
                                <List.Item>
                                    <List.Item.Meta
                                        title={
                                            <Row>
                                                <Col md={20}>{r.logsheetName}</Col>
                                                <Col>{moment(r.dateTime).format('DD-MM-YYYY HH:mm')}</Col>
                                            </Row>
                                        }
                                        description={
                                            <Row>
                                                <Col>
                                                    Location: {r.location}/{r.area}
                                                </Col>
                                                {/* <Col>Responsible: {r.crewName}</Col> */}
                                            </Row>
                                        }
                                    />
                                </List.Item>
                            )}
                        />
                    </Card>
                </Spin>
            );
        }
    },
);

export default PendingLogsheetTasks;
