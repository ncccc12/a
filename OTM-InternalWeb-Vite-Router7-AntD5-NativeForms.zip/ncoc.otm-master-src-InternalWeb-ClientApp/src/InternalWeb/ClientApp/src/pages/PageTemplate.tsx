import { withRouter } from '../router/legacy';
import React, { useEffect, useState } from 'react';
import { Layout, Menu, Row, Button} from 'antd';
import Icon from '../LegacyIcon';
import { Link } from 'react-router-dom';
import authService from '../common/components/api-authorization/AuthorizeService';
import { ApplicationPaths } from '../common/components/api-authorization/ApiAuthorizationConstants';
import { User } from '../common/components/api-authorization/types';

const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;

const PageTemplate = withRouter((props) => {
    const { location } = props;
    const [collapsed, setCollapsed] = useState(false);
    const [user, setUser] = useState<User>({} as any);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isExceedance, setIsExceedance] = useState(false);

    useEffect(() => {
        const getUser = async () => {
            const data: User = await authService.getUser();
            setUser(data);
            const authenticated = await authService.isAuthenticated();
            setIsAuthenticated(authenticated);
        };

        getUser();
        //userRole()
    }, []);
    useEffect(() => {
        userRole();
    }, [user]);
    const userRole = () => {
        if (user?.role?.includes('Supervisor')) {
            setIsExceedance(true);
        } else if (user?.role?.includes('ChiefSupervisor')) {
            setIsExceedance(true);
        }
    };

    return (
        <Layout>
            <Sider trigger={null} width={250} style={{ height: '100vh' }} collapsible collapsed={collapsed}>
                <div
                    className="logo"
                    style={{
                        height: 32,
                        background: '#334454',
                        margin: 16,
                    }}
                />
                <Menu
                    mode="inline"
                    theme="dark"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    selectedKeys={[location.pathname]}
                    style={{ height: '100%', borderRight: 0 }}
                >
                    <Menu.Item key="/">
                        <Icon type="dashboard" />
                        <span>Dashboard</span>
                        <Link to="/"></Link>
                    </Menu.Item>
                    <SubMenu
                        key="/logsheets"
                        title={
                            <>
                                <Icon type="container" />
                                <span> LogSheets manager </span>
                            </>
                        }
                    >
                        <Menu.Item key="/logsheets">
                            <span>Logsheets</span>
                            <Link to="/logsheets"></Link>
                        </Menu.Item>
                        <Menu.Item key="/logsheets/uom">
                            <span>Unit of measure</span>
                            <Link to="/logsheets/uom"></Link>
                        </Menu.Item>

                        <Menu.Item key="/logsheets/list-types">
                            <span>List types</span>
                            <Link to="/logsheets/list-types"></Link>
                        </Menu.Item>
                    </SubMenu>

                    <SubMenu
                        key="Schedule Manager"
                        title={
                            <span>
                                <Icon type="schedule" /> <span>Schedule manager</span>
                            </span>
                        }
                    >
                        <Menu.Item key="/scheduleManager/schedules">
                            <Icon type="schedule" />
                            <span>Schedules</span>
                            <Link to="/scheduleManager/schedules"></Link>
                        </Menu.Item>
                        <Menu.Item key="/scheduleManager/scheduleConfigs">
                            <Icon type="control" />
                            <span>Schedule configs</span>
                            <Link to="/scheduleManager/scheduleConfigs"></Link>
                        </Menu.Item>

                        <Menu.Item key="/scheduleManager/operators">
                            <Icon type="team" />
                            <span>Operators</span>
                            <Link to="/scheduleManager/operators"></Link>
                        </Menu.Item>
                    </SubMenu>

                    <SubMenu
                        key="reports"
                        title={
                            <span>
                                <Icon type="bar-chart" /> <span>Reports</span>
                            </span>
                        }
                    >
                        <Menu.Item key="/reports/schedule-configs">
                            <span>Schedule configs</span>
                            <Link to="/reports/schedule-configs"></Link>
                        </Menu.Item>
                        <Menu.Item key="/reports/general">
                            <span>General</span>
                            <Link to="/reports/general"></Link>
                        </Menu.Item>
                        <Menu.Item key="/reports/daily">
                            <span>Daily</span>
                            <Link to="/reports/daily"></Link>
                        </Menu.Item>

                        <Menu.Item key="/reports/by-device">
                            <span>By devices/tags</span>
                            <Link to="/reports/by-device"></Link>
                        </Menu.Item>
                        <Menu.Item key="/reports/technological-oil">
                            <span>Technological reglament exceedances</span>
                            <Link to="/reports/technological-oil"></Link>
                        </Menu.Item>
                    </SubMenu>
                    {user?.role?.includes('Admin') && (
                        <SubMenu
                            key="log"
                            title={
                                <span>
                                    <Icon type="database" /> <span>Submited Exceedances</span>
                                </span>
                            }
                        >
                            <Menu.Item key="/exceedances/submitedExceedance">
                                <span>Submmited exceedances</span>
                                <Link to="/exceedances/submitedExceedance"></Link>
                            </Menu.Item>
                        </SubMenu>
                    )}
                    {user?.role?.includes('Admin') && (
                        <SubMenu
                            key="administration"
                            title={
                                <span>
                                    <Icon type="setting" /> <span>Administration</span>
                                </span>
                            }
                        >
                            <Menu.Item key="/admin/users">
                                <span>Users</span>
                                <Link to="/admin/users"></Link>
                            </Menu.Item>
                            <Menu.Item key="/dictionary/crews">
                                <span>Crews</span>
                                <Link to="/dictionary/crews"></Link>
                            </Menu.Item>
                        </SubMenu>
                    )}
                    {isExceedance && (
                        <SubMenu
                            key="exceedance"
                            title={
                                <span>
                                    <Icon type="history" /> <span>Exceedance</span>
                                </span>
                            }
                        >
                            <Menu.Item key="/exceedances/supervisorsList">
                                <span>Exceedance list</span>
                                <Link to="/exceedances/supervisorsList"></Link>
                            </Menu.Item>

                            {user?.role?.includes('ChiefSupervisor') && (
                                <Menu.Item key="/exceedances/shiftSupervisor">
                                    <span>Shift supervisor’s list</span>
                                    <Link to="/exceedances/shiftSupervisor"></Link>
                                </Menu.Item>
                            )}
                            <Menu.Item key="/exceedances/resolvedExceedance">
                                <span>Resolved Exceedances</span>
                                <Link to="/exceedances/resolvedExceedance"></Link>
                            </Menu.Item>
                            <Menu.Item key="/exceedances/run">
                                <span>Run & Maintain</span>
                                <Link to="/exceedances/run"></Link>
                            </Menu.Item>
                        </SubMenu>
                    )}

                    {/* <SubMenu
                        key="integration"
                        title={
                            <span>
                                <Icon type="file-sync" /> <span>Integration</span>
                            </span>
                        }
                    >
                        <Menu.Item key="/integration/pi">
                            <span>
                                PI System
                                <Badge
                                    count={<Icon type="clock-circle" style={{ color: '#f5222d', marginRight: -8 }} />}
                                >
                                    &nbsp;
                                </Badge>
                            </span>
                        </Menu.Item>
                        <Menu.Item key="/integration/sap">
                            <span>
                                SAP System
                                <Badge
                                    count={<Icon type="clock-circle" style={{ color: '#f5222d', marginRight: -8 }} />}
                                >
                                    &nbsp;
                                </Badge>
                            </span>
                        </Menu.Item>
                    </SubMenu> */}
                </Menu>
            </Sider>
            <Layout>
                <Header style={{ background: '#fff', padding: 0 }}>
                    <Row type="flex" justify="space-between" align="middle">
                        <div>
                            <Icon
                                style={{
                                    fontSize: 18,
                                    lineHeight: '64px',
                                    paddingLeft: 24,
                                    cursor: 'pointer',
                                    transition: '#1890ff',
                                }}
                                type={collapsed ? 'menu-unfold' : 'menu-fold'}
                                onClick={() => setCollapsed(!collapsed)}
                            />
                            <h2 style={{ paddingLeft: 10, display: 'inline' }}>Welcome to Admin Panel</h2>
                        </div>
                        <div style={{ paddingRight: 24 }}>
                            {isAuthenticated ? (
                                <Button type="link">
                                    <Link to={ApplicationPaths.LogOut} state={{ local: true }}>
                                        Logout
                                    </Link>
                                </Button>
                            ) : (
                                <Button type="link">
                                    <Link to={`${ApplicationPaths.Login}`}>Login</Link>
                                </Button>
                            )}
                        </div>
                    </Row>
                </Header>
                <Content
                    style={{
                        margin: '24px 16px',
                        padding: 24,
                        minHeight: 280,
                    }}
                >
                    {props.children}
                </Content>
            </Layout>
        </Layout>
    );
});

export default PageTemplate;
