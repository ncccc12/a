import {  SupervisorsListPage, SubmitedExceedancePage } from './pages';
import { LegacyRouteProps as RouteProps } from '../router/legacy';
import ResolveExceedancesListPage from './pages/ResolveExceedancesListPage';
import ExceedancesListContainer from './containers/ExceedancesListContainer';
import { ExceedancesList } from '../services/Client';
import ShiftSupervisorList from './pages/ShiftSupervisorList';
import RunMaintainListPage from './pages/RunMaintainListPage';

const routes: RouteProps[] = [
    {
        path: '/exceedances/supervisorsList',
        component: SupervisorsListPage,
        exact: true,
    },
    {
        path: '/exceedances/submitedExceedance',
        component: SubmitedExceedancePage,
        exact: true,
    },
    {
        path: '/exceedances/shiftSupervisor',
        component: ShiftSupervisorList,
        exact: true,
    },
    {
        path: '/exceedances/resolvedExceedance',
        component: ResolveExceedancesListPage,
        exact: true,
    },
    {
        path: '/exceedances/run',
        component: RunMaintainListPage,
        exact: true,
    },
    {
        path: '/exceedances/:id',
        component: ExceedancesListContainer,
        exact: true,
    },
];

export default routes;
