import { RouteComponentProps } from '../../router/legacy';
import React, { useEffect, useState } from 'react';
import { Row, Col, Spin, Alert } from 'antd';
import { AreaVm, DictionaryDto } from '../../services/Client';
import { dictionaryClient } from '../../services';

import ExceedancesListId from '../components/ExceedancesListId';

type Params = { id: string };
type Props = RouteComponentProps<Params>;

const ExceedancesListContainer: React.FC<Props> = ({ match }) => {
    const [locations, setLocations] = useState<DictionaryDto[]>([]);
    const [areas, setAreas] = useState<AreaVm[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let isMounted = true;
        const loadDictionaries = async () => {
            setLoading(true);
            setError(null);
            try {
                const [locations, areas] = await Promise.all([
                    dictionaryClient.getLocations(),
                    dictionaryClient.getAreas(),
                ]);
                if (isMounted) {
                    setLocations(locations);
                    setAreas(areas);
                }
            } catch (err) {
                if (isMounted) setError('Failed to load dictionaries');
            } finally {
                if (isMounted) setLoading(false);
            }
        };
        loadDictionaries();
        return () => {
            isMounted = false;
        };
    }, []);

    const exceedancesId = parseInt(match.params.id, 10);

    if (loading) return <Spin />;
    if (error) return <Alert type="error" message={error} />;

    return (
        <Row gutter={24}>
            <Col md={24}>
                <ExceedancesListId locations={locations} areas={areas} exceedancesListId={exceedancesId} />
            </Col>
        </Row>
    );
};

export default ExceedancesListContainer;
