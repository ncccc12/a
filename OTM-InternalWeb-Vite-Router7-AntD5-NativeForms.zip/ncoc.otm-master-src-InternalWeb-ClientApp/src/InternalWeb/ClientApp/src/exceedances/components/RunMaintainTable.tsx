import { withModernForm, modernFormField } from '../../modern-form';
import React, { useState, useEffect, useCallback } from 'react';
import { Card, Spin, Button, Table, message} from 'antd';
import { Form } from 'antd';
import moment from 'moment';
import { dictionaryClient, reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
    ExceedanceListStatus,
} from '../../services/Client';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

const RunMaintainTable = withModernForm()((props: any) => {
    const { form } = props;
    const [loading, setLoading] = useState(false);
    const [datas, setDatas] = useState<any[]>([]);
    const [topTags, setTopTags] = useState<DeviceTag[]>([]);
    const [filteredAreas, setFilteredAreas] = useState<AreaVm[]>([]);
    const [exceedances, setExceedances] = useState<ExceedancesListVm[]>([]);
    const [selectedExceedances, setSelectedExceedances] = useState<ExceedancesListVm[]>([]);
    const [user, setUser] = useState<User>({} as any);
    const [areaCode, setAreaCode] = useState<string[]>([]);
    const [locations, setLocations] = useState<DictionaryDto[]>([]);
    const [areas, setAreas] = useState<AreaVm[]>([]);
    const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });

    useEffect(() => {
        const loadDictionaries = async () => {
            const locations = await dictionaryClient.getLocations();
            const areas = await dictionaryClient.getAreas();
            setLocations(locations);
            setAreas(areas);
        };
        loadDictionaries();
    }, []);

    useEffect(() => {
        getUser();
        // eslint-disable-next-line
    }, []);

    const getUser = async () => {
        const data: User = await authService.getUser();
        setUser(data);
        await getUserArea(data.sub);
        search();
    };

    const getUserArea = async (value: any) => {
        let area: UserVm = await usersClient.getUsersArea(value);
        setAreaCode(area.areaCodes!);
    };

    const search = useCallback(async (page = 1, pageSize = 10) => {
        setLoading(true);
        const data = await reportsClient.getResolvedExceedancesQuery(
            [ExceedanceListStatus.RunMaintenance],
            page,
            pageSize,
        );
        setExceedances(data.data || []);
        setLoading(false);
    }, []);

    const handleLocationChange = (value: string) => {
        form.setFieldsValue({ areaCode: '' });
        filterAreas(value);
    };

    const filterAreas = (locationCode: string) => {
        const filtered = areas.filter((r: AreaVm) => r.locationCode === locationCode);
        setFilteredAreas(filtered);
    };

    const onSelectChange = (selected: any) => {
        setSelectedExceedances(selected);
    };

    const resetFilter = () => {
        form.resetFields();
        search();
    };

    const updateTag = (values: ExceedancesVm) => {
        let updateCommand = new UpdateTagDataCommand();
        updateCommand.id = values.id;
        updateCommand.value = values.taskValue;
        updateCommand.comment = values.comment;
        reportsClient.updateTagData(updateCommand);
        message.success('Successfully updated');
        search(pagination.current, pagination.pageSize);
    };

    const renderAction = (i: string, rowKey: any) => (
        <>
            <Link to={`/exceedances/${rowKey.id!}`}>
                <Button shape="circle" icon="edit" title="edit"></Button>
            </Link>
        </>
    );

    const renderStatus = (i: string, rowKey: ExceedancesListVm) => {
        if (rowKey.exListStatus! === 1) return <p>Under Shift-Supervisor Review</p>;
        if (rowKey.exListStatus! === 2) return <p>Under Plant SPV</p>;
        if (rowKey.exListStatus! === 3) return <p>Under CRO</p>;
        if (rowKey.exListStatus! === 4) return <p>Under Supervisor</p>;
        if (rowKey.exListStatus! === 5) return <p>Run & Maintaince</p>;
        if (rowKey.exListStatus! === 6) return <p>Fixed</p>;
        return null;
    };

    const rowSelection = {
        selectedExceedances,
        onChange: onSelectChange,
    };

    return (
        <Spin spinning={loading}>
            <Card>
                <h2>Run & Maintain</h2>
                <Table
                    dataSource={exceedances}
                    loading={loading}
                    bordered
                    rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                    pagination={{
                        current: pagination.current,
                        pageSize: pagination.pageSize,
                        total: pagination.total,
                        onChange: (page, pageSize) => {
                            setPagination({ ...pagination, current: page, pageSize: pageSize || 10 });
                            search(page, pageSize);
                        },
                    }}
                >
                    <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                    <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                    <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                    <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                    <Table.Column dataIndex="excListStatus" title="Status" render={renderStatus}></Table.Column>
                    <Table.Column title="Action" width={'130px'} render={renderAction}></Table.Column>
                </Table>
            </Card>
        </Spin>
    );
});

export default RunMaintainTable;
