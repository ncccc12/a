import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Drawer, Input, Select, Tag, InputNumber, Button, Switch} from 'antd';
import { Form } from 'antd';
import type { FormComponentProps } from '../../legacy-form-types';
import { DictionaryDto, ExceedancesVm, ListTypeValueVm } from '../../services/Client';



export type TagForm = {
    dataTypeCode: string;
    description: string;
    deviceName: string;
    id: number;
    name: string;
    listTypeCode?: string;
    maxValue?: number;
    minValue?: number;
    unitOfMeasurementCode?: string;

    taskValueId?: number;
    value?: any;
    comment?: string;
};

type Props = {
    visible: boolean;
    groups: ExceedancesVm
    onSubmit: () => void;
    onClose: () => void;
} & FormComponentProps<any>;

type State = {
    filteredLisTypeValues: ListTypeValueVm[];
    selectedDataTypeCode: string;
};

const CommentDrawer = withModernForm<Props>()(
    class extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                filteredLisTypeValues: [],
                selectedDataTypeCode: '',
            };
        }

        componentDidUpdate(prevProps: Props, prevState: State) {
            const { form } = this.props;

            if (!prevProps.visible && this.props.visible) {
                let listTypeCode = form.getFieldValue('listTypeCode');
                let dataTypeCode = form.getFieldValue('dataTypeCode');

            } else if (!this.props.visible && this.state.selectedDataTypeCode !== '') {
                this.setState({ selectedDataTypeCode: '' });
            }
        }

       

        

        render() {
            const {
                visible,
                
                form,
                groups,
            } = this.props;
            const { filteredLisTypeValues, selectedDataTypeCode } = this.state;

            const formItemLayout = {
                labelCol: {
                    span: 10,
                },
                wrapperCol: {
                    span: 14,
                },
            };
            

            void 0;
            let id = form.getFieldValue('id');
            void 0;
            void 0;
            void 0;
            let groupNames = form.getFieldValue('groupName')
            void 0;
            let taskNames = form.getFieldValue('taskName')
            void 0
            let title = 'edit tag'

            return (
                <Drawer title={title} visible={visible} width={700} onClose={this.props.onClose}>
                    <Form onValuesChange={(this.props as any).__onValuesChange} form={this.props.form} labelAlign="left" {...formItemLayout}>
                        <Form.Item label="Logsheet Name">
                            {<Form.Item name={'logsheetName'} noStyle>
                                <Input.TextArea readOnly   />
                            </Form.Item>}
                        </Form.Item>
                        <Form.Item label="Group/Device  name">
                            {<Form.Item name={'groupName'} noStyle><Input readOnly /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Task Name">
                            {<Form.Item name={'taskName'} noStyle><Input.TextArea readOnly   /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Task Value">
                            {<Form.Item name={'taskValue'} noStyle><Input.TextArea readOnly   /></Form.Item>}
                        </Form.Item>
                        <Form.Item label="Comment">
                                    {<Form.Item name={'comment'} noStyle><Input.TextArea /></Form.Item>}
                        </Form.Item>
                            
                        
                    </Form>

                    <div
                        style={{
                            position: 'absolute',
                            right: 0,
                            bottom: 0,
                            width: '100%',
                            borderTop: '1px solid #e9e9e9',
                            padding: '10px 16px',
                            background: '#fff',
                            textAlign: 'right',
                        }}
                    >
                        <Button onClick={this.props.onClose} style={{ marginRight: 8 }}>
                            Cancel
                        </Button>
                        <Button type="primary" onClick={this.props.onSubmit}>
                            Submit
                        </Button>
                    </div>
                </Drawer>
            );
        }
    },
);

export default CommentDrawer;
