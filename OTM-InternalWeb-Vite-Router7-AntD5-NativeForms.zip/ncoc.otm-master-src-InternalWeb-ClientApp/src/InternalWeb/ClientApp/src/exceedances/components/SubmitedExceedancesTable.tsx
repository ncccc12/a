import { withModernForm, modernFormField } from '../../modern-form';
import React from 'react';
import { Card, Spin, Button, Table, message} from 'antd';
import { Form } from 'antd';
import { reportsClient } from '../../services';
import {
    DeviceTag,
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UserVm,
    UpdateTagDataCommand,
    ExceedancesListVm,
} from '../../services/Client';
import type { FormComponentProps } from '../../legacy-form-types';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { Link } from 'react-router-dom';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
} & FormComponentProps<any>;

type State = {
    loading: boolean;
    datas: any[];
    topTags: DeviceTag[];
    filteredAreas: AreaVm[];
    exceedances: ExceedancesListVm[];
    selectedExceedances: ExceedancesListVm[];
    user: User;
    areaCode: string[];
};

const SubmitededExceedancesTable = withModernForm<Props>()(
    class SubmitededExceedancesTable extends React.Component<Props, State> {
        constructor(props: Props) {
            super(props);

            this.state = {
                loading: false,
                datas: [],
                topTags: [],
                filteredAreas: [],
                exceedances: [],
                selectedExceedances: [],
                user: {} as any,
                areaCode: [],
            };
        }

        componentDidMount() {
            this.getUser();
        }
        componentDidUpdate(prevProps: Readonly<Props>, prevState: Readonly<State>, snapshot?: any): void {
            // this.getUserArea(this.state.user.sub)
        }
        getUser = async () => {
            const data: User = await authService.getUser();
            this.setState({ user: data });

            this.getUserArea(data.sub);
            this.search();
        };
        getUserArea = async (value: any) => {
            let area: UserVm = await usersClient.getUsersArea(value);
            //let areaCode:string[] = area.areaCodes!
            this.setState({ areaCode: area.areaCodes! });
        };
        search = async () => {
            this.setState({ loading: true });
            const { form } = this.props;
            let userId = this.state.user.sub;
            let data = await reportsClient.getSubmitedExceedancesQuery(userId);
            this.setState({ exceedances: data, loading: false });
        };

        handleLocationChange = (value: string) => {
            const { form } = this.props;
            form.setFieldsValue({ areaCode: '' });
            this.filterAreas(value);
        };

        filterAreas = (locationCode: string) => {
            const { areas } = this.props;

            const filteredAreas = areas.filter((r) => r.locationCode === locationCode);
            this.setState({ filteredAreas });
        };

        onSelectChange = (selectedExceedances: any) => {
            this.setState({ selectedExceedances: selectedExceedances });
        };

        resetFilter = () => {
            this.props.form.resetFields();
            this.search();
        };
        updateTag = (values: ExceedancesVm) => {
            let updateCommand = new UpdateTagDataCommand();
            updateCommand.id = values.id;
            updateCommand.value = values.taskValue;
            updateCommand.comment = values.comment;

            reportsClient.updateTagData(updateCommand);
            message.success('Successfully updated');
        };
        renderStatus = (i: string, rowKey: ExceedancesListVm) => {
            console.log('Rowkeuuu', i, rowKey);
            if (rowKey.exListStatus! === 1) {
                return <p>Under Shift-Supervisor Review</p>;
            }
            if (rowKey.exListStatus! === 2) {
                return <p>Under Plant SPV</p>;
            }
            if (rowKey.exListStatus! === 3) {
                return <p>Under CRO</p>;
            }
            if (rowKey.exListStatus! === 4) {
                return <p>Under Supervisor</p>;
            }
            if (rowKey.exListStatus! === 5) {
                return <p>Run & Maintaince</p>;
            }
            if (rowKey.exListStatus! === 6) {
                return <p>Fixed</p>;
            }
        };
        renderAction = (i: string, rowKey: any) => {
            return (
                <>
                    <Link to={`/exceedances/${rowKey.id!}`}>
                        <Button shape="circle" icon="edit" title="edit"></Button>
                    </Link>
                </>
            );
        };
        render() {
            const { loading } = this.state;

            return (
                <Spin spinning={loading}>
                    <Card

                    // extra={this.renderHeader()}
                    >
                        <Table
                            dataSource={this.state.exceedances}
                            loading={this.state.loading}
                            bordered
                            //expandRowByClick={true}
                            // pagination={paginationConfig}
                            rowKey={(i: ExceedancesListVm) => i.id!.toString()}
                            //rowSelection={rowSelection}
                        >
                            {' '}
                            <Table.Column dataIndex="id" title="Exceedances List ID" width={'130px'} />
                            <Table.Column dataIndex="submitedBy" title="Submited By" width={'220px'} />
                            <Table.Column dataIndex="locationName" title="Location" width={'130px'} />
                            <Table.Column dataIndex="areaName" title="Area" width={'130px'} />
                            <Table.Column dataIndex="commentBySup" title="Supervisor Comment" />
                            <Table.Column
                                dataIndex="excListStatus"
                                title="Status"
                                render={(i: string, rowKey: ExceedancesListVm) => this.renderStatus(i, rowKey)}
                            ></Table.Column>
                            <Table.Column
                                title="Action"
                                width={'130px'}
                                render={(i: string, rowKey: any) => this.renderAction(i, rowKey)}
                            ></Table.Column>
                        </Table>
                    </Card>
                </Spin>
            );
        }
    },
);

export default SubmitededExceedancesTable;
