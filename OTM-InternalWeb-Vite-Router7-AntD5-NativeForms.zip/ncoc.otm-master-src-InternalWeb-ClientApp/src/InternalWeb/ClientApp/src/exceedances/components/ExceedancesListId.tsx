import { withModernForm, modernFormField } from '../../modern-form';
import React, { useEffect, useRef, useState } from 'react';
import { Card, Spin, Select, Button, Table, Input, message, Modal, Upload} from 'antd';
import { Form } from 'antd';
import moment from 'moment';
import { reportsClient } from '../../services';
import {
    DictionaryDto,
    AreaVm,
    ExceedancesVm,
    UpdateDisciplineCommentCommand,
    ExceedancesListVm,
    DisciplinesVm,
    CroListEmailVm,
} from '../../services/Client';
import type { FormComponentProps } from '../../legacy-form-types';
import { User } from '../../common/components/api-authorization/types';
import { usersClient } from '../../services';
import authService from '../../common/components/api-authorization/AuthorizeService';
import { WrappedFormUtils } from '../../legacy-form-types';
import DiscCommentDrawer from './DiscCommentDrawer';
import { UploadFile } from 'antd/lib/upload/interface';

type Props = {
    locations: DictionaryDto[];
    areas: AreaVm[];
    exceedancesListId: number;
} & FormComponentProps<any>;

const ExceedancesListId: React.FC<Props> = (props) => {
    const { form } = props;
    const exceedanceDrawerRef = useRef<any>(null);
    const [loading, setLoading] = useState(false);
    const [exceedances, setExceedances] = useState<ExceedancesVm[]>([]);
    const [exceedancesList, setExceedancesList] = useState<ExceedancesListVm>({} as any);
    const [exceedance, setExceedance] = useState<ExceedancesVm>({} as any);
    const [drawVisible, setDrawVisible] = useState(false);
    const [userDiscipline, setUserDiscipline] = useState<DisciplinesVm>({} as any);
    const [sendVisible, setSendVisible] = useState(false);
    const [exceedancesListStatus, setExceedancesListStatus] = useState<number>(0);
    const [croList, setCroList] = useState<CroListEmailVm[]>([]);

    useEffect(() => {
        getData();
    }, []);

    const getData = async () => {
        const data: User = await authService.getUser();
        // await getUserDiscipline(data.sub);
        await getExceeedanceList();
        await getCROList();
    };
    const getCROList = async () => {
        let croList = await usersClient.getCroListEmail(undefined);
        setCroList(croList);
    };
    const getExceeedanceList = async () => {
        let id = props.exceedancesListId;
        let result = await reportsClient.getExceedanceListId(id);
        let data = result.exceedances;
        let exceeedancesIds: number[] = [];
        data?.forEach((x) => exceeedancesIds.push(x.id!));
        setExceedances(result.exceedances!);
        setExceedancesList(result);
    };
    const getUserDiscipline = async (value: any) => {
        let discipline: DisciplinesVm = await usersClient.getUserDiscipline(value);
        setUserDiscipline(discipline!);
    };

    const sendToPOD = async () => {
        setSendVisible(true);
        setExceedancesListStatus(2);
    };

    const sendToFix = () => {
        setSendVisible(true);
        setExceedancesListStatus(6);
    };
    const sendToRM = async () => {
        setSendVisible(true);
        setExceedancesListStatus(5);
    };

    const onRowClick = (row: any) => {};
    const onClose = (): void => {
        setDrawVisible(false);
    };
    const submitTag = () => {
        const formRef = exceedanceDrawerRef.current?.props?.form as WrappedFormUtils<any>;
        formRef.validateFields(async (err: any, values: ExceedancesVm) => {
            if (err) return;
            try {
                setLoading(true);
                let updateCommand = new UpdateDisciplineCommentCommand();
                updateCommand.id = values.id;
                updateCommand.value = values.taskValue;
                updateCommand.comment = values.comment;
                updateCommand.disciplineComment = values.discComment;
                updateCommand.disciplineId = userDiscipline.id;
                await reportsClient.updateDisciplineComment(updateCommand);
                message.success('Successfully updated');
                setDrawVisible(false);
            } finally {
                message.success('Successfully updated');
                setLoading(false);
                window.location.reload();
            }
        });
    };
    const onCloseDrawer = (): void => {
        setSendVisible(false);
    };
    const updateExceedancesList = async (status: number) => {
        try {
            setLoading(true);
            let comment = form.getFieldValue('supervisorComment');
            await reportsClient.updateResolvedExc(exceedancesList.id, status, comment, null, null);
        } finally {
            setLoading(false);
            message.success('Successfully Created');
            window.location.reload();
        }
    };
    const onSelectCro = async (value: any) => {
        console.log('Value', value);
    };
    

    const renderHeader = () => {
        if (exceedancesList.exListStatus === 1) {
            return (
                <>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '18px' }}>
                        <Button style={{ marginRight: '10px' }} type="primary" onClick={sendToPOD}>
                            Return back to PRA
                        </Button>
                        <Button style={{ margin: '0,10px,0,10px' }} type="primary" onClick={sendToRM}>
                            Run & Maintain
                        </Button>
                    </div>
                </>
            );
        }
        return null;
    };
    return (
        <Spin spinning={loading}>
            <Card extra={renderHeader()}>
                <p>ExceedancesList ID: {exceedancesList.id}</p>
                <p>
                    Area Location: {exceedancesList.areaName}/{exceedancesList.locationName}
                </p>
                <p>Submited By: {exceedancesList.submitedBy}</p>
                <p>Number of Exceedances: {exceedancesList.numberOfExceedances}</p>
                <Table
                    dataSource={exceedances}
                    loading={loading}
                    bordered
                    rowKey={(i: ExceedancesVm) => i.id!.toString()}
                    onRowClick={onRowClick}
                >
                    <Table.Column dataIndex="logsheetName" title="Logsheet name" />
                    <Table.Column dataIndex="groupName" title="Device Name" />
                    <Table.Column dataIndex="taskName" title="Name of Point" />
                    <Table.Column
                        dataIndex="datePeriod"
                        title="Date"
                        render={(i: Date) => {
                            return moment(i).format('DD-MM-YYYY');
                        }}
                    />
                    <Table.Column
                        dataIndex="datePeriod"
                        title="Date"
                        render={(i: Date) => {
                            return moment(i).format('HH:mm');
                        }}
                    />
                    <Table.Column dataIndex="taskDescription" title="Allowed Range" />
                    <Table.Column dataIndex="taskValue" title="Actual Value" />
                    <Table.Column dataIndex="count" title="Count" />
                    <Table.Column dataIndex="comment" title="Comment By Supervisor/Operator" />
                </Table>
                <Button style={{ margin: '10px' }} type="primary" onClick={sendToFix}>
                    Fixed
                </Button>
                <Modal
                    destroyOnClose
                    onCancel={onCloseDrawer}
                    visible={sendVisible}
                    onOk={() => updateExceedancesList(exceedancesListStatus)}
                    title={'Supervisor Comment'}
                >
                    <Form form={form}>
                    {croList && exceedancesListStatus === 3 && (
                        <Form.Item style={{ width: '100px' }} label="CRO Area">
                            {<Form.Item name={'croList'} noStyle>
                                <Select
                                    filterOption={false}
                                    allowClear
                                    showSearch
                                    style={{ width: '300px' }}
                                    placeholder={'Select CRO area'}
                                    onSelect={onSelectCro}
                                >
                                    {croList.map((x) => (
                                        <Select.Option key={x.email!} value={x.email!} title={x.name}>
                                            {x.name!}
                                        </Select.Option>
                                    ))}
                                </Select>,
                            </Form.Item>}
                        </Form.Item>
                    )}
                    <Form.Item>{<Form.Item name={'supervisorComment'} noStyle><Input.TextArea /></Form.Item>}</Form.Item>
                    <Form.Item>
                        {<Form.Item name={'attachment'} noStyle>
                            <Upload
                                beforeUpload={(file: UploadFile<any>, fileList) => {
                                    reportsClient
                                        .addAttachment(exceedancesList.id, {
                                            data: file!,
                                            fileName: file.name!,
                                        })
                                        .then(() => {})
                                        .catch(() => {})
                                        .finally(() => {
                                            console.log('Tip', file);
                                        });
                                    return false;
                                }}
                            >
                                {' '}
                                <Button>Click to Upload</Button>
                            </Upload>,
                        </Form.Item>}
                    </Form.Item>
                                    </Form>
                </Modal>
                <DiscCommentDrawer
                    visible={drawVisible}
                    wrappedComponentRef={(ref: any) => (exceedanceDrawerRef.current = ref)}
                    groups={exceedance}
                    onClose={onClose}
                    onSubmit={submitTag}
                ></DiscCommentDrawer>
            </Card>
        </Spin>
    );
};

export default withModernForm<Props>()(ExceedancesListId);
