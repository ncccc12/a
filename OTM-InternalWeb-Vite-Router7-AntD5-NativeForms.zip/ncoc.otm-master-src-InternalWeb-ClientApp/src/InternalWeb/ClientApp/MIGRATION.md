# OTM ClientApp migration notes

## Changes
- CRA (`react-scripts`, `react-app-rewired`) replaced with Vite 7 and React 18 createRoot.
- Ant Design 3 dependency replaced by Ant Design 5, with `@ant-design/compatible` used for the historical `Form.create()`/`getFieldDecorator()` API. This is a **transitional compatibility migration**, not a wholesale conversion to `Form.useForm()`.
- Removed CRA-specific files and public HTML, introduced Vite entry, config, types, and example variables.
- Existing React Router v5 kept intentionally (upgrading it to v6 requires substantial route and HOC rewrites).
- Ant Design icon imports use a temporary legacy icon adapter.

## IMPORTANT: verification and follow-up
**Not build-verified.** The package registry was unreachable during preparation (`EAI_AGAIN`); no new lockfile could be generated. Install and build in an environment with npm registry access.

```bash
npm install
npm run typecheck
npm run build
npm run dev
```

Known follow-up work: replace `Form.create/getFieldDecorator` with `Form.useForm` and `Form.Item name`; migrate Moment-based values to Dayjs for Ant Design 5 DatePicker/RangePicker; audit all removed/deprecated Ant Design v3 component props (`visible`, `dropdownClassName`, `overlay`, old `Table` APIs etc); migrate React Router v5 separately. Test SSO callbacks, auth routing, API proxy and forms in an integration environment before deploying.

In production configure the Vite base path with `VITE_BASE_PATH` at build time if the SPA is not deployed at `/`. Keep the existing ASP.NET backend SPA fallback/asset hosting configuration compatible with the `build/` output.
